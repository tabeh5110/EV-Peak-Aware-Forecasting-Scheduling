"""
Step 07: tuned standard machine-learning forecasting models.

Run from the project root:
    python src/07_ml_forecasting.py

This step uses corrected Step 05B features only. It trains standard ML models
with validation-based tuning, then evaluates selected models once on the test
split. It does not create the proposed peak-aware weighted model, prediction
intervals, or scheduling optimization.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import importlib
import json
import re
import sys
import time
import types
import warnings

import numpy as np


# Environment guard for this workstation: the Python standard-library
# _strptime.py has been overwritten by old project code. Pandas/matplotlib need
# a small import-time API from _strptime, so provide it locally without editing
# the external Python installation.
if "_strptime" not in sys.modules:
    _strptime_stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    _strptime_stub.LocaleTime = LocaleTime
    _strptime_stub.TimeRE = TimeRE
    _strptime_stub._TimeRE_cache = TimeRE()
    _strptime_stub._regex_cache = {}
    _strptime_stub._getlang = _getlang
    _strptime_stub._strptime = _strptime
    _strptime_stub._strptime_time = _strptime
    _strptime_stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = _strptime_stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
FEATURE_FILE = PROJECT_ROOT / "data" / "processed" / "05B_forecasting_features.csv"
FEATURE_COLUMNS_FILE = (
    PROJECT_ROOT / "results" / "05B_fix_feature_engineering" / "05B_modeling_feature_columns.txt"
)
BASELINE_METRICS_FILE = PROJECT_ROOT / "results" / "06_baseline_forecasting" / "06_baseline_overall_metrics.csv"
BASELINE_TEST_PREDICTIONS_FILE = PROJECT_ROOT / "results" / "06_baseline_forecasting" / "06_test_predictions.csv"

RESULTS_DIR = PROJECT_ROOT / "results" / "07_ml_forecasting"
FIGURES_DIR = PROJECT_ROOT / "figures" / "07_ml_forecasting"
MODELS_DIR = PROJECT_ROOT / "models" / "07_ml_forecasting"

TUNING_FILE = RESULTS_DIR / "07_ml_tuning_results.csv"
SELECTED_FILE = RESULTS_DIR / "07_selected_hyperparameters.csv"
OVERALL_FILE = RESULTS_DIR / "07_ml_overall_metrics.csv"
SITE_FILE = RESULTS_DIR / "07_ml_site_metrics.csv"
VALIDATION_PREDICTIONS_FILE = RESULTS_DIR / "07_validation_predictions.csv"
TEST_PREDICTIONS_FILE = RESULTS_DIR / "07_test_predictions.csv"
COMPARISON_FILE = RESULTS_DIR / "07_baseline_vs_ml_comparison.csv"
ML_RANKING_FILE = RESULTS_DIR / "07_ml_model_ranking.csv"
COMBINED_RANKING_FILE = RESULTS_DIR / "07_baseline_vs_ml_ranking.csv"
FEATURE_IMPORTANCE_FILE = RESULTS_DIR / "07_feature_importance.csv"
BEST_SUMMARY_FILE = RESULTS_DIR / "07_best_ml_summary.csv"
PACKAGE_FILE = RESULTS_DIR / "07_package_availability.csv"
CAPTIONS_FILE = RESULTS_DIR / "07_figure_captions.txt"
LEAKAGE_REPORT_FILE = RESULTS_DIR / "07_ml_leakage_safety_report.txt"
REPORT_FILE = RESULTS_DIR / "07_ml_forecasting_report.txt"
NOVELTY_REPORT_FILE = RESULTS_DIR / "07_novelty_connection_report.txt"

TARGET = "target_load_kw"
RANDOM_STATE = 42


def parse_datetime(series: pd.Series) -> pd.Series:
    try:
        return pd.to_datetime(series, errors="coerce", format="mixed")
    except TypeError:
        return pd.to_datetime(series, errors="coerce")


def clip_prediction(values: Any) -> np.ndarray:
    return np.maximum(np.asarray(values, dtype=float), 0.0)


def metric_mae(actual: np.ndarray, pred: np.ndarray) -> float:
    return float(np.mean(np.abs(pred - actual))) if len(actual) else np.nan


def metric_rmse(actual: np.ndarray, pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((pred - actual) ** 2))) if len(actual) else np.nan


def metric_mape(actual: np.ndarray, pred: np.ndarray) -> float:
    mask = actual != 0
    return float(np.mean(np.abs((pred[mask] - actual[mask]) / actual[mask])) * 100) if mask.any() else np.nan


def metric_smape(actual: np.ndarray, pred: np.ndarray) -> float:
    denominator = np.abs(actual) + np.abs(pred)
    mask = denominator != 0
    return float(np.mean(2 * np.abs(pred[mask] - actual[mask]) / denominator[mask]) * 100) if mask.any() else np.nan


def metric_r2(actual: np.ndarray, pred: np.ndarray) -> float:
    if len(actual) == 0:
        return np.nan
    ss_res = float(np.sum((actual - pred) ** 2))
    ss_tot = float(np.sum((actual - np.mean(actual)) ** 2))
    return 1 - ss_res / ss_tot if ss_tot else np.nan


def rate(condition: np.ndarray) -> float:
    return float(np.mean(condition) * 100) if len(condition) else np.nan


def subset_peak_metrics(df: pd.DataFrame, pred_col: str, high: bool = False) -> dict[str, float]:
    flag = "is_high_peak_hour" if high else "is_peak_hour"
    prefix = "high_peak" if high else "peak"
    subset = df.loc[df[flag] == 1]
    if subset.empty:
        return {
            f"{prefix}_MAE": np.nan,
            f"{prefix}_RMSE": np.nan,
            f"{prefix}_underestimation_rate": np.nan,
            f"{prefix}_bias": np.nan,
            f"mean_actual_{prefix}_load_kw": np.nan,
            f"mean_predicted_{prefix}_load_kw": np.nan,
        }
    actual = subset[TARGET].to_numpy(dtype=float)
    pred = subset[pred_col].to_numpy(dtype=float)
    return {
        f"{prefix}_MAE": metric_mae(actual, pred),
        f"{prefix}_RMSE": metric_rmse(actual, pred),
        f"{prefix}_underestimation_rate": rate(pred < actual),
        f"{prefix}_bias": float(np.mean(pred - actual)),
        f"mean_actual_{prefix}_load_kw": float(np.mean(actual)),
        f"mean_predicted_{prefix}_load_kw": float(np.mean(pred)),
    }


def evaluate_overall(df: pd.DataFrame, model_name: str, split: str, pred_col: str) -> dict[str, Any]:
    actual = df[TARGET].to_numpy(dtype=float)
    pred = df[pred_col].to_numpy(dtype=float)
    peak = subset_peak_metrics(df, pred_col, high=False)
    high_peak = subset_peak_metrics(df, pred_col, high=True)
    return {
        "model_name": model_name,
        "split": split,
        "MAE": metric_mae(actual, pred),
        "RMSE": metric_rmse(actual, pred),
        "MAPE": metric_mape(actual, pred),
        "sMAPE": metric_smape(actual, pred),
        "R2": metric_r2(actual, pred),
        "MBE": float(np.mean(pred - actual)) if len(actual) else np.nan,
        "underestimation_rate": rate(pred < actual),
        "overestimation_rate": rate(pred > actual),
        "peak_MAE": peak["peak_MAE"],
        "high_peak_MAE": high_peak["high_peak_MAE"],
        "peak_RMSE": peak["peak_RMSE"],
        "high_peak_RMSE": high_peak["high_peak_RMSE"],
        "peak_underestimation_rate": peak["peak_underestimation_rate"],
        "high_peak_underestimation_rate": high_peak["high_peak_underestimation_rate"],
        "mean_actual_peak_load_kw": peak["mean_actual_peak_load_kw"],
        "mean_predicted_peak_load_kw": peak["mean_predicted_peak_load_kw"],
        "peak_bias": peak["peak_bias"],
        "high_peak_bias": high_peak["high_peak_bias"],
    }


def evaluate_site(df: pd.DataFrame, model_name: str, split: str, pred_col: str, site_means: dict[str, float]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for site_id, site_df in df.groupby("site_id", sort=True):
        actual = site_df[TARGET].to_numpy(dtype=float)
        pred = site_df[pred_col].to_numpy(dtype=float)
        site_mean = site_means.get(site_id, np.nan)
        peak = subset_peak_metrics(site_df, pred_col, high=False)
        high_peak = subset_peak_metrics(site_df, pred_col, high=True)
        rows.append(
            {
                "model_name": model_name,
                "split": split,
                "site_id": site_id,
                "row_count": len(site_df),
                "MAE": metric_mae(actual, pred),
                "RMSE": metric_rmse(actual, pred),
                "normalized_MAE_by_site_train_mean": metric_mae(actual, pred) / site_mean if site_mean else np.nan,
                "normalized_RMSE_by_site_train_mean": metric_rmse(actual, pred) / site_mean if site_mean else np.nan,
                "MBE": float(np.mean(pred - actual)) if len(actual) else np.nan,
                "underestimation_rate": rate(pred < actual),
                "peak_MAE": peak["peak_MAE"],
                "peak_underestimation_rate": peak["peak_underestimation_rate"],
                "high_peak_MAE": high_peak["high_peak_MAE"],
                "high_peak_underestimation_rate": high_peak["high_peak_underestimation_rate"],
            }
        )
    return rows


def package_version(package: str) -> tuple[bool, str]:
    try:
        module = importlib.import_module(package)
        return True, str(getattr(module, "__version__", "unknown"))
    except Exception:
        return False, ""


def build_model_specs(package_rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], bool]:
    specs: list[dict[str, Any]] = []
    sklearn_available, sklearn_version = package_version("sklearn")
    joblib_available, joblib_version = package_version("joblib")
    package_rows.append({"package/model": "sklearn", "available": sklearn_available, "version": sklearn_version, "action_taken": "used for sklearn regressors" if sklearn_available else "skipped sklearn models"})
    package_rows.append({"package/model": "joblib", "available": joblib_available, "version": joblib_version, "action_taken": "save model artifacts" if joblib_available else "skip model artifact saving"})

    if sklearn_available:
        from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor, HistGradientBoostingRegressor, RandomForestRegressor

        specs.extend(
            [
                {
                    "model_name": "RandomForestRegressor",
                    "factory": lambda p: RandomForestRegressor(random_state=RANDOM_STATE, n_jobs=-1, **p),
                    "params": [
                        {"n_estimators": 200, "max_depth": 12, "min_samples_leaf": 2, "max_features": "sqrt"},
                        {"n_estimators": 300, "max_depth": 16, "min_samples_leaf": 2, "max_features": "sqrt"},
                        {"n_estimators": 300, "max_depth": None, "min_samples_leaf": 5, "max_features": "sqrt"},
                    ],
                    "importance": "feature_importances_",
                },
                {
                    "model_name": "ExtraTreesRegressor",
                    "factory": lambda p: ExtraTreesRegressor(random_state=RANDOM_STATE, n_jobs=-1, **p),
                    "params": [
                        {"n_estimators": 300, "max_depth": 12, "min_samples_leaf": 2, "max_features": "sqrt"},
                        {"n_estimators": 300, "max_depth": 16, "min_samples_leaf": 2, "max_features": "sqrt"},
                        {"n_estimators": 400, "max_depth": None, "min_samples_leaf": 5, "max_features": "sqrt"},
                    ],
                    "importance": "feature_importances_",
                },
                {
                    "model_name": "GradientBoostingRegressor",
                    "factory": lambda p: GradientBoostingRegressor(random_state=RANDOM_STATE, **p),
                    "params": [
                        {"n_estimators": 200, "learning_rate": 0.05, "max_depth": 3, "subsample": 0.8},
                        {"n_estimators": 300, "learning_rate": 0.03, "max_depth": 3, "subsample": 0.8},
                        {"n_estimators": 200, "learning_rate": 0.05, "max_depth": 4, "subsample": 0.8},
                    ],
                    "importance": "feature_importances_",
                },
                {
                    "model_name": "HistGradientBoostingRegressor",
                    "factory": lambda p: HistGradientBoostingRegressor(random_state=RANDOM_STATE, **p),
                    "params": [
                        {"max_iter": 200, "learning_rate": 0.05, "max_leaf_nodes": 31, "l2_regularization": 0.0},
                        {"max_iter": 300, "learning_rate": 0.03, "max_leaf_nodes": 31, "l2_regularization": 0.1},
                        {"max_iter": 300, "learning_rate": 0.05, "max_leaf_nodes": 63, "l2_regularization": 0.1},
                    ],
                    "importance": "",
                },
            ]
        )
        package_rows.append({"package/model": "MLPRegressor", "available": True, "version": sklearn_version, "action_taken": "skipped optional MLP to keep Step 07 runtime safe and reproducible"})
        package_rows.append({"package/model": "LinearSVR", "available": True, "version": sklearn_version, "action_taken": "skipped optional LinearSVR; nonlinear SVR excluded as too costly for 80k rows and 114 features"})

    xgb_available, xgb_version = package_version("xgboost")
    package_rows.append({"package/model": "xgboost", "available": xgb_available, "version": xgb_version, "action_taken": "attempt XGBRegressor" if xgb_available else "skipped XGBoost"})
    if xgb_available:
        from xgboost import XGBRegressor

        specs.append(
            {
                "model_name": "XGBRegressor",
                "factory": lambda p: XGBRegressor(objective="reg:squarederror", random_state=RANDOM_STATE, n_jobs=-1, **p),
                "params": [
                    {"n_estimators": 300, "learning_rate": 0.05, "max_depth": 4, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0},
                    {"n_estimators": 500, "learning_rate": 0.03, "max_depth": 4, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0},
                    {"n_estimators": 300, "learning_rate": 0.05, "max_depth": 6, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 2.0},
                ],
                "importance": "feature_importances_",
            }
        )

    lgb_available, lgb_version = package_version("lightgbm")
    package_rows.append({"package/model": "lightgbm", "available": lgb_available, "version": lgb_version, "action_taken": "attempt LGBMRegressor" if lgb_available else "skipped LightGBM"})
    if lgb_available:
        from lightgbm import LGBMRegressor

        specs.append(
            {
                "model_name": "LGBMRegressor",
                "factory": lambda p: LGBMRegressor(random_state=RANDOM_STATE, n_jobs=-1, verbose=-1, **p),
                "params": [
                    {"n_estimators": 300, "learning_rate": 0.05, "num_leaves": 31, "max_depth": -1, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0},
                    {"n_estimators": 500, "learning_rate": 0.03, "num_leaves": 31, "max_depth": -1, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0},
                    {"n_estimators": 300, "learning_rate": 0.05, "num_leaves": 63, "max_depth": -1, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 2.0},
                ],
                "importance": "feature_importances_",
            }
        )

    cat_available, cat_version = package_version("catboost")
    package_rows.append({"package/model": "catboost", "available": cat_available, "version": cat_version, "action_taken": "attempt CatBoostRegressor" if cat_available else "skipped CatBoost"})
    if cat_available:
        from catboost import CatBoostRegressor

        specs.append(
            {
                "model_name": "CatBoostRegressor",
                "factory": lambda p: CatBoostRegressor(loss_function="RMSE", random_seed=RANDOM_STATE, verbose=False, **p),
                "params": [
                    {"iterations": 300, "learning_rate": 0.05, "depth": 6, "l2_leaf_reg": 3},
                    {"iterations": 500, "learning_rate": 0.03, "depth": 6, "l2_leaf_reg": 3},
                    {"iterations": 300, "learning_rate": 0.05, "depth": 8, "l2_leaf_reg": 5},
                ],
                "importance": "feature_importances_",
            }
        )

    return specs, joblib_available


def tune_and_evaluate(
    specs: list[dict[str, Any]],
    train: pd.DataFrame,
    validation: pd.DataFrame,
    test: pd.DataFrame,
    features: list[str],
    joblib_available: bool,
) -> tuple[list[str], list[str], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    X_train = train[features].to_numpy(dtype=float)
    y_train = train[TARGET].to_numpy(dtype=float)
    X_validation = validation[features].to_numpy(dtype=float)
    y_validation = validation[TARGET].to_numpy(dtype=float)
    X_train_validation = pd.concat([train, validation], ignore_index=True)[features].to_numpy(dtype=float)
    y_train_validation = pd.concat([train, validation], ignore_index=True)[TARGET].to_numpy(dtype=float)
    X_test = test[features].to_numpy(dtype=float)

    successful: list[str] = []
    skipped: list[str] = []
    tuning_rows: list[dict[str, Any]] = []
    selected_rows: list[dict[str, Any]] = []
    importance_rows: list[dict[str, Any]] = []

    joblib_module = importlib.import_module("joblib") if joblib_available else None

    for spec in specs:
        model_name = spec["model_name"]
        best: dict[str, Any] | None = None
        for candidate_id, params in enumerate(spec["params"], start=1):
            start = time.perf_counter()
            row = {
                "model_name": model_name,
                "candidate_id": candidate_id,
                "parameter_json": json.dumps(params, sort_keys=True),
                "validation_MAE": np.nan,
                "validation_RMSE": np.nan,
                "validation_peak_MAE": np.nan,
                "validation_high_peak_MAE": np.nan,
                "validation_underestimation_rate": np.nan,
                "training_time_seconds": np.nan,
                "status": "failed",
                "error_message_if_failed": "",
            }
            try:
                model = spec["factory"](params)
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    model.fit(X_train, y_train)
                pred = clip_prediction(model.predict(X_validation))
                temp = validation[[TARGET, "is_peak_hour", "is_high_peak_hour"]].copy()
                temp["pred"] = pred
                metrics = evaluate_overall(temp, model_name, "validation", "pred")
                row.update(
                    {
                        "validation_MAE": metrics["MAE"],
                        "validation_RMSE": metrics["RMSE"],
                        "validation_peak_MAE": metrics["peak_MAE"],
                        "validation_high_peak_MAE": metrics["high_peak_MAE"],
                        "validation_underestimation_rate": metrics["underestimation_rate"],
                        "training_time_seconds": round(time.perf_counter() - start, 3),
                        "status": "success",
                    }
                )
                if best is None or metrics["MAE"] < best["validation_MAE"]:
                    best = {"candidate_id": candidate_id, "params": params, "model": model, **metrics}
            except Exception as exc:
                row["training_time_seconds"] = round(time.perf_counter() - start, 3)
                row["error_message_if_failed"] = f"{type(exc).__name__}: {exc}"
            tuning_rows.append(row)

        if best is None:
            skipped.append(f"{model_name}: all candidates failed")
            continue

        validation[f"pred_{model_name}"] = clip_prediction(best["model"].predict(X_validation))
        final_model = spec["factory"](best["params"])
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            final_model.fit(X_train_validation, y_train_validation)
        test[f"pred_{model_name}"] = clip_prediction(final_model.predict(X_test))
        successful.append(model_name)
        selected_rows.append(
            {
                "model_name": model_name,
                "selected_candidate_id": best["candidate_id"],
                "selected_parameter_json": json.dumps(best["params"], sort_keys=True),
                "selection_metric": "validation_MAE",
                "validation_MAE": best["MAE"],
                "validation_RMSE": best["RMSE"],
                "validation_peak_MAE": best["peak_MAE"],
                "validation_high_peak_MAE": best["high_peak_MAE"],
            }
        )

        if joblib_module is not None:
            try:
                joblib_module.dump(final_model, MODELS_DIR / f"07_{model_name}.joblib")
            except Exception as exc:
                skipped.append(f"{model_name}: model artifact not saved ({type(exc).__name__}: {exc})")

        importance_attr = spec.get("importance", "")
        if importance_attr and hasattr(final_model, importance_attr):
            importances = np.asarray(getattr(final_model, importance_attr), dtype=float)
            for rank, index in enumerate(np.argsort(importances)[::-1], start=1):
                importance_rows.append(
                    {
                        "model_name": model_name,
                        "feature_name": features[index],
                        "importance": importances[index],
                        "importance_type": importance_attr,
                        "rank": rank,
                    }
                )
        elif model_name == "HistGradientBoostingRegressor":
            skipped.append("HistGradientBoostingRegressor: feature importance skipped to avoid slow permutation importance")

    return successful, skipped, tuning_rows, selected_rows, importance_rows


def prediction_export(df: pd.DataFrame, models: list[str]) -> pd.DataFrame:
    output = pd.DataFrame(
        {
            "timestamp": df["timestamp"],
            "site_id": df["site_id"],
            "actual_load_kw": df[TARGET],
            "split": df["split"],
            "is_peak_hour": df["is_peak_hour"],
            "is_high_peak_hour": df["is_high_peak_hour"],
        }
    )
    for model in models:
        output[f"prediction_{model}"] = df[f"pred_{model}"]
    return output


def build_rankings(metrics: pd.DataFrame, metrics_to_rank: list[str]) -> pd.DataFrame:
    rows: list[pd.DataFrame] = []
    for split in sorted(metrics["split"].unique()):
        split_df = metrics.loc[metrics["split"] == split]
        for metric in metrics_to_rank:
            ranking = split_df[["model_name", "split", metric]].dropna().copy()
            ranking = ranking.rename(columns={metric: "rank_value"})
            ranking["rank_metric"] = metric
            ranking["rank_position"] = ranking["rank_value"].rank(method="min", ascending=True)
            rows.append(ranking.sort_values(["rank_position", "model_name"]))
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


def build_best_summary(ml_metrics: pd.DataFrame, baseline_metrics: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    tests = {
        "best validation ML model by MAE": ("validation", "MAE"),
        "best test ML model by MAE": ("test", "MAE"),
        "best test ML model by RMSE": ("test", "RMSE"),
        "best test ML model by peak_MAE": ("test", "peak_MAE"),
        "best test ML model by high_peak_MAE": ("test", "high_peak_MAE"),
    }
    for label, (split, metric) in tests.items():
        subset = ml_metrics.loc[ml_metrics["split"] == split].dropna(subset=[metric])
        row = subset.loc[subset[metric].idxmin()]
        rows.append({"summary_item": label, "model_name": row["model_name"], "metric": metric, "metric_value": row[metric]})

    best_ml_test = ml_metrics.loc[ml_metrics["split"] == "test"].sort_values("MAE").iloc[0]
    best_baseline_test = baseline_metrics.loc[baseline_metrics["split"] == "test"].sort_values("MAE").iloc[0]
    best_ml_peak = ml_metrics.loc[ml_metrics["split"] == "test"].sort_values("peak_MAE").iloc[0]
    best_baseline_peak = baseline_metrics.loc[baseline_metrics["split"] == "test"].sort_values("peak_MAE").iloc[0]
    rows.append(
        {
            "summary_item": "best model compared with best Step 06 baseline",
            "model_name": best_ml_test["model_name"],
            "metric": "test_MAE_vs_baseline_MAE",
            "metric_value": best_ml_test["MAE"] - best_baseline_test["MAE"],
        }
    )
    rows.append(
        {
            "summary_item": "whether ML improves over baseline by MAE",
            "model_name": best_ml_test["model_name"],
            "metric": "improves",
            "metric_value": bool(best_ml_test["MAE"] < best_baseline_test["MAE"]),
        }
    )
    rows.append(
        {
            "summary_item": "whether ML improves over baseline by peak_MAE",
            "model_name": best_ml_peak["model_name"],
            "metric": "improves",
            "metric_value": bool(best_ml_peak["peak_MAE"] < best_baseline_peak["peak_MAE"]),
        }
    )
    return pd.DataFrame(rows)


def add_bar_labels(ax: plt.Axes) -> None:
    for patch in ax.patches:
        value = patch.get_height()
        if np.isfinite(value):
            ax.text(patch.get_x() + patch.get_width() / 2, value, f"{value:.2f}", ha="center", va="bottom", fontsize=8)


def metric_bar(df: pd.DataFrame, split: str, metric: str, title: str, ylabel: str, path: Path) -> None:
    plot_df = df.loc[df["split"] == split].sort_values(metric)
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.bar(plot_df["model_name"], plot_df[metric])
    ax.set_title(title)
    ax.set_xlabel("Model")
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=35)
    add_bar_labels(ax)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def baseline_vs_ml_bar(comparison: pd.DataFrame, path: Path) -> None:
    plot_df = comparison.loc[comparison["split"] == "test"].sort_values("MAE").head(10)
    labels = plot_df["model_name"] + " (" + plot_df["method_group"] + ")"
    fig, ax = plt.subplots(figsize=(13, 6))
    ax.bar(labels, plot_df["MAE"])
    ax.set_title("Baseline vs standard ML test MAE")
    ax.set_xlabel("Method")
    ax.set_ylabel("Test MAE (kW)")
    ax.tick_params(axis="x", rotation=35)
    add_bar_labels(ax)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def sample_plot(test: pd.DataFrame, best_model: str, path: Path, baseline_predictions: pd.DataFrame | None = None, baseline_model: str | None = None) -> None:
    site_id = test.groupby("site_id").size().sort_values(ascending=False).index[0]
    site_df = test.loc[test["site_id"] == site_id].sort_values("timestamp")
    start = site_df["timestamp"].min()
    sample = site_df.loc[site_df["timestamp"] < start + pd.Timedelta(days=7)].copy()
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(sample["timestamp"], sample[TARGET], label="Actual load", linewidth=2)
    ax.plot(sample["timestamp"], sample[f"pred_{best_model}"], label=best_model, linewidth=1.6)
    if baseline_predictions is not None and baseline_model is not None:
        baseline_col = f"prediction_{baseline_model}"
        if baseline_col in baseline_predictions.columns:
            base = baseline_predictions.copy()
            base["timestamp"] = parse_datetime(base["timestamp"])
            base_sample = base.loc[(base["site_id"] == site_id) & (base["timestamp"].isin(sample["timestamp"]))]
            ax.plot(base_sample["timestamp"], base_sample[baseline_col], label=baseline_model, linewidth=1.3)
    ax.set_title(f"Actual vs prediction sample: {site_id}")
    ax.set_xlabel("Timestamp")
    ax.set_ylabel("Load (kW)")
    ax.legend()
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def site_level_plot(site_metrics: pd.DataFrame, overall: pd.DataFrame, path: Path) -> None:
    top3 = overall.loc[overall["split"] == "test"].sort_values("MAE").head(3)["model_name"].tolist()
    pivot = site_metrics.loc[(site_metrics["split"] == "test") & (site_metrics["model_name"].isin(top3))].pivot(index="site_id", columns="model_name", values="MAE")
    fig, ax = plt.subplots(figsize=(12, 6))
    pivot.plot(kind="bar", ax=ax)
    ax.set_title("Site-level test MAE for top 3 ML models")
    ax.set_xlabel("Site")
    ax.set_ylabel("MAE (kW)")
    ax.tick_params(axis="x", rotation=35)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def importance_plot(importance: pd.DataFrame, best_model: str, path: Path) -> None:
    model_imp = importance.loc[importance["model_name"] == best_model].sort_values("rank").head(20)
    if model_imp.empty:
        return
    fig, ax = plt.subplots(figsize=(10, 7))
    ax.barh(model_imp["feature_name"][::-1], model_imp["importance"][::-1])
    ax.set_title(f"Top 20 feature importances: {best_model}")
    ax.set_xlabel("Importance")
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def write_reports(
    input_shape: tuple[int, int],
    counts: pd.Series,
    feature_count: int,
    specs: list[dict[str, Any]],
    successful: list[str],
    skipped: list[str],
    selected: pd.DataFrame,
    best_summary: pd.DataFrame,
    baseline_metrics: pd.DataFrame,
    ml_metrics: pd.DataFrame,
    importance: pd.DataFrame,
) -> None:
    best_val = best_summary.loc[best_summary["summary_item"] == "best validation ML model by MAE"].iloc[0]
    best_test = best_summary.loc[best_summary["summary_item"] == "best test ML model by MAE"].iloc[0]
    best_peak = best_summary.loc[best_summary["summary_item"] == "best test ML model by peak_MAE"].iloc[0]
    best_baseline = baseline_metrics.loc[baseline_metrics["split"] == "test"].sort_values("MAE").iloc[0]
    best_ml = ml_metrics.loc[ml_metrics["split"] == "test"].sort_values("MAE").iloc[0]
    best_baseline_peak = baseline_metrics.loc[baseline_metrics["split"] == "test"].sort_values("peak_MAE").iloc[0]
    best_ml_peak = ml_metrics.loc[ml_metrics["split"] == "test"].sort_values("peak_MAE").iloc[0]

    LEAKAGE_REPORT_FILE.write_text(
        "\n".join(
            [
                "Step 07 ML leakage safety report",
                "=" * 33,
                "- Step 05B chronological split was used exactly as saved.",
                "- No random split or shuffling was used.",
                "- Only features from 05B_modeling_feature_columns.txt were used.",
                "- Hyperparameters were selected using validation split only.",
                "- Test set was used only once for final evaluation.",
                "- Final models were retrained on train+validation only after validation selection.",
                "- Negative predictions were clipped to zero after prediction.",
                "- No future target, future session, price, weather, or traffic data was used.",
                "",
            ]
        ),
        encoding="utf-8",
    )

    selected_lines = [
        f"- {row.model_name}: candidate {row.selected_candidate_id}, {row.selected_parameter_json}"
        for row in selected.itertuples(index=False)
    ]
    skipped_lines = [f"- {item}" for item in skipped] if skipped else ["- None"]
    importance_lines = (
        [
            f"- {row.feature_name}: {row.importance:.6g} ({row.model_name})"
            for row in importance.loc[importance["model_name"] == best_test.model_name].sort_values("rank").head(10).itertuples(index=False)
        ]
        if not importance.empty
        else ["- Feature importance unavailable for the best model."]
    )
    REPORT_FILE.write_text(
        "\n".join(
            [
                "Step 07 ML forecasting report",
                "=" * 30,
                f"Input file used: {FEATURE_FILE}",
                f"Feature file used: {FEATURE_COLUMNS_FILE}",
                f"Input shape: {input_shape}",
                f"Train rows: {int(counts['train'])}",
                f"Validation rows: {int(counts['validation'])}",
                f"Test rows: {int(counts['test'])}",
                f"Number of modeling features: {feature_count}",
                "",
                "Models attempted:",
                *(f"- {spec['model_name']}" for spec in specs),
                "",
                "Models successfully evaluated:",
                *(f"- {model}" for model in successful),
                "",
                "Models skipped or partially skipped:",
                *skipped_lines,
                "",
                "Selected hyperparameters:",
                *selected_lines,
                "",
                f"Best validation ML model by MAE: {best_val.model_name} ({float(best_val.metric_value):.4f} kW)",
                f"Best test ML model by MAE: {best_test.model_name} ({float(best_test.metric_value):.4f} kW)",
                f"Best test ML model by peak_MAE: {best_peak.model_name} ({float(best_peak.metric_value):.4f} kW)",
                "",
                "Comparison against best Step 06 baseline:",
                f"- Best Step 06 baseline by test MAE: {best_baseline.model_name} ({best_baseline.MAE:.4f} kW)",
                f"- Best Step 07 ML by test MAE: {best_ml.model_name} ({best_ml.MAE:.4f} kW)",
                f"- ML improves normal-load MAE: {bool(best_ml.MAE < best_baseline.MAE)}",
                f"- Best Step 06 baseline by test peak_MAE: {best_baseline_peak.model_name} ({best_baseline_peak.peak_MAE:.4f} kW)",
                f"- Best Step 07 ML by test peak_MAE: {best_ml_peak.model_name} ({best_ml_peak.peak_MAE:.4f} kW)",
                f"- ML improves peak-load MAE: {bool(best_ml_peak.peak_MAE < best_baseline_peak.peak_MAE)}",
                "",
                "Key feature importance observations:",
                *importance_lines,
                "",
                "Limitations:",
                "- This step evaluates standard ML models only; it does not yet use peak_sample_weight.",
                "- Peak underestimation can remain high because models were not explicitly optimized for peak-aware loss.",
                "",
                "Recommended next step:",
                "- Step 08 should implement peak-aware weighted learning using peak_sample_weight.",
                "",
            ]
        ),
        encoding="utf-8",
    )

    NOVELTY_REPORT_FILE.write_text(
        "\n".join(
            [
                "Step 07 novelty connection report",
                "=" * 34,
                "- Step 07 is not the final proposed novelty.",
                "- Step 07 establishes strong tuned ML baselines under a strict chronological protocol.",
                "- Validation-based tuning addresses the old reviewer criticism about mostly default model settings.",
                "- The next contribution will be Step 08 peak-aware weighted learning using peak_sample_weight.",
                "- Step 07 helps show whether advanced ML alone is enough or whether explicit peak-aware learning is needed.",
                "",
            ]
        ),
        encoding="utf-8",
    )


def write_captions() -> None:
    captions = [
        "Fig. 1. Validation mean absolute error for tuned standard ML forecasting models.",
        "Fig. 2. Test mean absolute error for tuned standard ML forecasting models.",
        "Fig. 3. Test mean absolute error comparing the best Step 06 baselines and Step 07 ML models.",
        "Fig. 4. Test peak-hour mean absolute error for tuned standard ML forecasting models.",
        "Fig. 5. Test high-peak-hour mean absolute error for tuned standard ML forecasting models.",
        "Fig. 6. Actual load and best-by-test-MAE ML prediction for a seven-day test sample.",
        "Fig. 7. Actual load, best Step 06 baseline prediction, and best Step 07 ML prediction for the same seven-day test sample.",
        "Fig. 8. Test underestimation rate for tuned standard ML forecasting models.",
        "Fig. 9. Top 20 feature importances for the best-by-test-MAE ML model, when available.",
        "Fig. 10. Site-level test mean absolute error for the top three ML models by overall test MAE.",
    ]
    CAPTIONS_FILE.write_text("\n".join(captions) + "\n", encoding="utf-8")


def main() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    MODELS_DIR.mkdir(parents=True, exist_ok=True)

    features = [line.strip() for line in FEATURE_COLUMNS_FILE.read_text(encoding="utf-8").splitlines() if line.strip()]
    df = pd.read_csv(FEATURE_FILE)
    input_shape = df.shape
    df["timestamp"] = parse_datetime(df["timestamp"])
    train = df.loc[df["split"] == "train"].copy()
    validation = df.loc[df["split"] == "validation"].copy()
    test = df.loc[df["split"] == "test"].copy()
    counts = df["split"].value_counts().reindex(["train", "validation", "test"], fill_value=0)
    site_means = train.groupby("site_id")[TARGET].mean().to_dict()

    package_rows: list[dict[str, Any]] = []
    specs, joblib_available = build_model_specs(package_rows)
    successful, skipped, tuning_rows, selected_rows, importance_rows = tune_and_evaluate(
        specs, train, validation, test, features, joblib_available
    )

    tuning = pd.DataFrame(tuning_rows)
    selected = pd.DataFrame(selected_rows)
    importance = pd.DataFrame(importance_rows)
    tuning.to_csv(TUNING_FILE, index=False)
    selected.to_csv(SELECTED_FILE, index=False)
    pd.DataFrame(package_rows).to_csv(PACKAGE_FILE, index=False)

    overall_rows: list[dict[str, Any]] = []
    site_rows: list[dict[str, Any]] = []
    for split_name, split_df in [("validation", validation), ("test", test)]:
        for model in successful:
            overall_rows.append(evaluate_overall(split_df, model, split_name, f"pred_{model}"))
            site_rows.extend(evaluate_site(split_df, model, split_name, f"pred_{model}", site_means))
    overall = pd.DataFrame(overall_rows).sort_values(["split", "MAE", "model_name"])
    site_metrics = pd.DataFrame(site_rows).sort_values(["split", "site_id", "MAE", "model_name"])
    overall.to_csv(OVERALL_FILE, index=False)
    site_metrics.to_csv(SITE_FILE, index=False)
    prediction_export(validation, successful).to_csv(VALIDATION_PREDICTIONS_FILE, index=False)
    prediction_export(test, successful).to_csv(TEST_PREDICTIONS_FILE, index=False)

    baseline = pd.read_csv(BASELINE_METRICS_FILE)
    comparison = pd.concat(
        [
            baseline.assign(method_group="baseline"),
            overall.assign(method_group="standard_ml"),
        ],
        ignore_index=True,
        sort=False,
    )
    comparison.to_csv(COMPARISON_FILE, index=False)
    build_rankings(overall, ["MAE", "RMSE", "peak_MAE", "high_peak_MAE", "underestimation_rate"]).to_csv(ML_RANKING_FILE, index=False)
    build_rankings(comparison, ["MAE", "RMSE", "peak_MAE", "high_peak_MAE", "underestimation_rate"]).to_csv(COMBINED_RANKING_FILE, index=False)
    best_summary = build_best_summary(overall, baseline)
    best_summary.to_csv(BEST_SUMMARY_FILE, index=False)
    if not importance.empty:
        importance.to_csv(FEATURE_IMPORTANCE_FILE, index=False)
    else:
        pd.DataFrame(columns=["model_name", "feature_name", "importance", "importance_type", "rank"]).to_csv(FEATURE_IMPORTANCE_FILE, index=False)

    metric_bar(overall, "validation", "MAE", "Validation MAE for ML models", "MAE (kW)", FIGURES_DIR / "07_fig1_validation_mae_ml_models.png")
    metric_bar(overall, "test", "MAE", "Test MAE for ML models", "MAE (kW)", FIGURES_DIR / "07_fig2_test_mae_ml_models.png")
    baseline_vs_ml_bar(comparison, FIGURES_DIR / "07_fig3_baseline_vs_ml_test_mae.png")
    metric_bar(overall, "test", "peak_MAE", "Test peak-hour MAE for ML models", "Peak MAE (kW)", FIGURES_DIR / "07_fig4_test_peak_mae_ml_models.png")
    metric_bar(overall, "test", "high_peak_MAE", "Test high-peak-hour MAE for ML models", "High-peak MAE (kW)", FIGURES_DIR / "07_fig5_test_high_peak_mae_ml_models.png")
    best_test_model = overall.loc[overall["split"] == "test"].sort_values("MAE").iloc[0]["model_name"]
    sample_plot(test, best_test_model, FIGURES_DIR / "07_fig6_actual_vs_best_ml_test_sample.png")
    baseline_test = pd.read_csv(BASELINE_TEST_PREDICTIONS_FILE) if BASELINE_TEST_PREDICTIONS_FILE.exists() else None
    best_baseline_model = baseline.loc[baseline["split"] == "test"].sort_values("MAE").iloc[0]["model_name"]
    sample_plot(test, best_test_model, FIGURES_DIR / "07_fig7_actual_vs_best_baseline_vs_best_ml_test_sample.png", baseline_test, best_baseline_model)
    metric_bar(overall, "test", "underestimation_rate", "Test underestimation rate for ML models", "Underestimation rate (%)", FIGURES_DIR / "07_fig8_underestimation_rate_test.png")
    importance_plot(importance, best_test_model, FIGURES_DIR / "07_fig9_top_feature_importance_best_model.png")
    site_level_plot(site_metrics, overall, FIGURES_DIR / "07_fig10_site_level_test_mae_best_models.png")
    write_captions()
    write_reports(input_shape, counts, len(features), specs, successful, skipped, selected, best_summary, baseline, overall, importance)

    outputs = [
        TUNING_FILE,
        SELECTED_FILE,
        OVERALL_FILE,
        SITE_FILE,
        VALIDATION_PREDICTIONS_FILE,
        TEST_PREDICTIONS_FILE,
        COMPARISON_FILE,
        ML_RANKING_FILE,
        COMBINED_RANKING_FILE,
        FEATURE_IMPORTANCE_FILE,
        BEST_SUMMARY_FILE,
        PACKAGE_FILE,
        CAPTIONS_FILE,
        LEAKAGE_REPORT_FILE,
        REPORT_FILE,
        NOVELTY_REPORT_FILE,
    ]
    best_val = overall.loc[overall["split"] == "validation"].sort_values("MAE").iloc[0]
    best_test = overall.loc[overall["split"] == "test"].sort_values("MAE").iloc[0]
    best_peak = overall.loc[overall["split"] == "test"].sort_values("peak_MAE").iloc[0]
    best_baseline = baseline.loc[baseline["split"] == "test"].sort_values("MAE").iloc[0]
    best_baseline_peak = baseline.loc[baseline["split"] == "test"].sort_values("peak_MAE").iloc[0]

    print("Step 07 ML forecasting complete")
    print("===============================")
    print(f"Input shape: {input_shape}")
    print(f"Train/validation/test rows: {int(counts['train'])}/{int(counts['validation'])}/{int(counts['test'])}")
    print(f"Number of modeling features: {len(features)}")
    print("Packages available:")
    for row in package_rows:
        print(f"- {row['package/model']}: {row['available']} {row['version']} ({row['action_taken']})")
    print("Models successfully evaluated:")
    for model in successful:
        print(f"- {model}")
    print("Models skipped:")
    if skipped:
        for item in skipped:
            print(f"- {item}")
    else:
        print("- None")
    print(f"Best validation ML model by MAE: {best_val.model_name} ({best_val.MAE:.4f} kW)")
    print(f"Best test ML model by MAE: {best_test.model_name} ({best_test.MAE:.4f} kW)")
    print(f"Best test ML model by peak_MAE: {best_peak.model_name} ({best_peak.peak_MAE:.4f} kW)")
    print(f"ML improves over best Step 06 baseline by MAE: {bool(best_test.MAE < best_baseline.MAE)}")
    print(f"ML improves over best Step 06 baseline by peak_MAE: {bool(best_peak.peak_MAE < best_baseline_peak.peak_MAE)}")
    print("")
    print("Output files saved:")
    for path in outputs:
        print(f"- {path}")
    print("")
    print("Report locations:")
    print(f"- {REPORT_FILE}")
    print(f"- {LEAKAGE_REPORT_FILE}")
    print(f"- {NOVELTY_REPORT_FILE}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(1)
