"""
Step 11B: Scheduling robustness and sensitivity analysis.

Run from the project root:
    python src/11B_scheduling_robustness_sensitivity.py

This step validates the Step 11 constrained EV charging scheduling results and
documents the site/timestamp coverage limitation before manuscript writing.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import re
import sys
import types
import warnings

import numpy as np


if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
STEP11_DIR = PROJECT_ROOT / "results" / "11_constrained_scheduling"
RESULTS_DIR = PROJECT_ROOT / "results" / "11B_scheduling_robustness"
FIGURES_DIR = PROJECT_ROOT / "figures" / "11B_scheduling_robustness"

SESSION_FILE = PROCESSED_DIR / "02_scheduling_ready_sessions.csv"
HOURLY_FILE = PROCESSED_DIR / "03_hourly_load_all_sites.csv"
FORECAST_FILE = PROCESSED_DIR / "10_uncertainty_forecasts_for_scheduling.csv"
STEP11_HOURLY_FILE = PROCESSED_DIR / "11_scheduled_hourly_loads.csv"
STEP11_SESSIONS_FILE = PROCESSED_DIR / "11_scheduled_sessions.csv"
STEP11_OVERALL_FILE = STEP11_DIR / "11_scheduling_overall_metrics.csv"
STEP11_SITE_FILE = STEP11_DIR / "11_scheduling_site_metrics.csv"
STEP11_COMPARISON_FILE = STEP11_DIR / "11_strategy_comparison.csv"
STEP11_CAPACITY_FILE = STEP11_DIR / "11_site_capacity_assumptions.csv"
STEP11_COVERAGE_FILE = STEP11_DIR / "11_scheduling_coverage_report.csv"

STRATEGIES = ["uncontrolled", "valley_filling", "point_forecast", "peak_sensitive", "uncertainty_aware"]
STRATEGY_LABELS = {
    "uncontrolled": "Uncontrolled baseline",
    "valley_filling": "Deadline-aware valley filling",
    "point_forecast": "E-AHPA point forecast",
    "peak_sensitive": "PRC-E-AHPA peak-sensitive forecast",
    "uncertainty_aware": "Step 10 upper-bound uncertainty-aware",
}
CHARGER_POWERS = [6.6, 7.2, 11.0]
CAPACITY_SCENARIOS = [
    "capacity_p90",
    "capacity_p95",
    "capacity_p95_plus_10percent",
    "capacity_historical_peak",
    "capacity_mean_plus_2std",
]
FORECAST_SIGNAL_SCENARIOS = {
    "eahpa_point": "main_point_forecast_kw",
    "prc_peak_sensitive": "peak_sensitive_point_forecast_kw",
    "upper_bound": "upper_forecast_kw",
}
HORIZON_SCENARIOS = ["original_calendar_aligned", "shorter_high_confidence", "full_available_forecast"]
FULLY_SERVED_TOLERANCE_KWH = 0.05


def ensure_dirs() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)


def require(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Required file not found: {path}")


def read_csv(path: Path, **kwargs: Any) -> pd.DataFrame:
    require(path)
    return pd.read_csv(path, **kwargs)


def parse_time(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series, errors="coerce", utc=True)


def pct(num: float, den: float) -> float:
    if den == 0 or pd.isna(den):
        return 0.0
    return 100.0 * float(num) / float(den)


def safe_div(num: float, den: float) -> float:
    if den == 0 or pd.isna(den):
        return 0.0
    return float(num) / float(den)


def prepare_base_sessions() -> pd.DataFrame:
    step11_sessions = read_csv(STEP11_SESSIONS_FILE)
    base = step11_sessions.loc[step11_sessions["strategy"] == "uncontrolled"].copy()
    base["arrival_time"] = parse_time(base["arrival_time"])
    base["departure_time"] = parse_time(base["departure_time"])
    base["energy_requested_kwh"] = pd.to_numeric(base["energy_requested_kwh"], errors="coerce")
    base["max_charging_power_kw"] = pd.to_numeric(base["max_charging_power_kw"], errors="coerce").fillna(6.6)
    base = base.dropna(subset=["arrival_time", "departure_time", "energy_requested_kwh", "site_id"])
    base = base.loc[
        (base["departure_time"] > base["arrival_time"]) & (base["energy_requested_kwh"] > 0)
    ].copy()
    return base[
        [
            "session_id",
            "site_id",
            "original_site_id",
            "arrival_time",
            "departure_time",
            "energy_requested_kwh",
            "max_charging_power_kw",
            "scenario_mode",
        ]
    ].reset_index(drop=True)


def prepare_forecasts() -> pd.DataFrame:
    forecasts = read_csv(FORECAST_FILE)
    forecasts["timestamp"] = parse_time(forecasts["timestamp"])
    forecasts["site_id"] = forecasts["site_id"].astype(str)
    for col in ["main_point_forecast_kw", "peak_sensitive_point_forecast_kw", "upper_forecast_kw", "actual_load_kw"]:
        if col in forecasts.columns:
            forecasts[col] = pd.to_numeric(forecasts[col], errors="coerce").fillna(0.0).clip(lower=0.0)
    return forecasts.dropna(subset=["timestamp", "site_id"]).sort_values(["site_id", "timestamp"]).reset_index(drop=True)


def coverage_diagnosis(raw_sessions: pd.DataFrame, hourly: pd.DataFrame, forecasts: pd.DataFrame, base_sessions: pd.DataFrame) -> pd.DataFrame:
    raw_site_col = "siteID" if "siteID" in raw_sessions.columns else ("site_id" if "site_id" in raw_sessions.columns else None)
    raw_arr_col = "arrival_time" if "arrival_time" in raw_sessions.columns else None
    raw_dep_col = "departure_time" if "departure_time" in raw_sessions.columns else None
    raw_sessions = raw_sessions.copy()
    if raw_site_col is None:
        raw_sessions["raw_site"] = "unknown"
    else:
        raw_sessions["raw_site"] = raw_sessions[raw_site_col].astype(str)
    if raw_arr_col and raw_dep_col:
        raw_sessions["arrival_time"] = parse_time(raw_sessions[raw_arr_col])
        raw_sessions["departure_time"] = parse_time(raw_sessions[raw_dep_col])
    hourly = hourly.copy()
    hourly["timestamp"] = parse_time(hourly["timestamp"])
    hourly["site_id"] = hourly["site_id"].astype(str)

    rows: list[dict[str, Any]] = []
    all_sites = sorted(set(raw_sessions["raw_site"].astype(str)) | set(hourly["site_id"].astype(str)) | set(forecasts["site_id"].astype(str)))
    for site in all_sites:
        raw_group = raw_sessions.loc[raw_sessions["raw_site"].astype(str) == site]
        hourly_group = hourly.loc[hourly["site_id"].astype(str) == site]
        forecast_group = forecasts.loc[forecasts["site_id"].astype(str) == site]
        scheduled_group = base_sessions.loc[
            (base_sessions["site_id"].astype(str) == site) | (base_sessions["original_site_id"].astype(str) == site)
        ]
        direct_overlap = 0
        if len(raw_group) and len(forecast_group) and "arrival_time" in raw_group and "departure_time" in raw_group:
            f_start = forecast_group["timestamp"].min()
            f_end = forecast_group["timestamp"].max()
            direct_overlap = int(((raw_group["departure_time"] >= f_start) & (raw_group["arrival_time"] <= f_end)).sum())
        rows.append(
            {
                "site_id_or_raw_site": site,
                "raw_session_count": int(len(raw_group)),
                "raw_session_start": raw_group["arrival_time"].min() if "arrival_time" in raw_group else pd.NaT,
                "raw_session_end": raw_group["departure_time"].max() if "departure_time" in raw_group else pd.NaT,
                "hourly_load_hours": int(len(hourly_group)),
                "hourly_start": hourly_group["timestamp"].min() if len(hourly_group) else pd.NaT,
                "hourly_end": hourly_group["timestamp"].max() if len(hourly_group) else pd.NaT,
                "forecast_hours": int(len(forecast_group)),
                "forecast_start": forecast_group["timestamp"].min() if len(forecast_group) else pd.NaT,
                "forecast_end": forecast_group["timestamp"].max() if len(forecast_group) else pd.NaT,
                "direct_session_forecast_overlap_sessions": direct_overlap,
                "calendar_aligned_scheduled_sessions": int(scheduled_group["session_id"].nunique()) if len(scheduled_group) else 0,
                "coverage_explanation": (
                    "raw session site"
                    if len(raw_group)
                    else "forecast/hourly site without raw sessions in the session-level file"
                ),
            }
        )
    diagnosis = pd.DataFrame(rows)
    diagnosis.to_csv(RESULTS_DIR / "11B_site_coverage_diagnosis.csv", index=False)
    return diagnosis


def horizon_filter(hours: pd.DataFrame, sessions: pd.DataFrame, horizon_name: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    if horizon_name == "shorter_high_confidence":
        start = hours["timestamp"].min()
        end = start + pd.Timedelta(days=28)
    else:
        start = hours["timestamp"].min()
        end = hours["timestamp"].max() + pd.Timedelta(hours=1)
    h = hours.loc[(hours["timestamp"] >= start) & (hours["timestamp"] < end)].copy()
    s = sessions.loc[(sessions["departure_time"] > start) & (sessions["arrival_time"] < end)].copy()
    s["arrival_time"] = s["arrival_time"].clip(lower=start)
    s["departure_time"] = s["departure_time"].clip(upper=end)
    s = s.loc[s["departure_time"] > s["arrival_time"]].reset_index(drop=True)
    return h.reset_index(drop=True), s


def overlap_hours(arrival: pd.Timestamp, departure: pd.Timestamp, hour: pd.Timestamp) -> float:
    start = max(arrival, hour)
    end = min(departure, hour + pd.Timedelta(hours=1))
    return max(0.0, (end - start).total_seconds() / 3600.0)


def feasible_indices(session: pd.Series, timestamps: pd.Series) -> tuple[np.ndarray, np.ndarray]:
    start_idx = int(timestamps.searchsorted(session["arrival_time"] - pd.Timedelta(hours=1), side="right"))
    end_idx = int(timestamps.searchsorted(session["departure_time"], side="left"))
    idx = np.arange(start_idx, end_idx)
    if len(idx) == 0:
        return idx, np.array([])
    overlaps = np.array([overlap_hours(session["arrival_time"], session["departure_time"], timestamps.iloc[i]) for i in idx])
    keep = overlaps > 0
    return idx[keep], overlaps[keep]


def allocate_sessions(
    sessions: pd.DataFrame,
    hours: pd.DataFrame,
    strategy: str,
    signal_column: str,
    charger_power_kw: float,
    capacity_kw: float,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    timestamps = hours["timestamp"].reset_index(drop=True)
    scheduled = np.zeros(len(hours), dtype=float)
    base_signal = hours[signal_column].to_numpy(dtype=float) if signal_column in hours.columns else np.zeros(len(hours))
    session_rows: list[dict[str, Any]] = []
    allocation_rows: list[dict[str, Any]] = []

    ordered = sessions.sort_values(["departure_time", "arrival_time"]).reset_index(drop=True)
    for row in ordered.itertuples(index=False):
        session = pd.Series(row._asdict())
        demand = float(session["energy_requested_kwh"])
        max_power = float(charger_power_kw)
        idx, overlaps = feasible_indices(session, timestamps)
        remaining = demand
        delivered = 0.0
        weighted_delay = 0.0

        if len(idx):
            if strategy == "uncontrolled":
                order = np.arange(len(idx))
            elif strategy == "valley_filling":
                order = np.argsort(scheduled[idx])
            else:
                order = np.argsort(base_signal[idx] + 0.05 * scheduled[idx])

            for local_i in order:
                if remaining <= 1e-9:
                    break
                hour_i = int(idx[local_i])
                overlap = float(overlaps[local_i])
                slot_energy = max_power * overlap
                if strategy == "uncontrolled":
                    allowed = slot_energy
                else:
                    spare = max(0.0, capacity_kw - scheduled[hour_i])
                    allowed = min(slot_energy, spare * overlap)
                energy = min(remaining, allowed)
                if energy > 1e-9:
                    power = energy / overlap
                    scheduled[hour_i] += power
                    delivered += energy
                    remaining -= energy
                    weighted_delay += ((timestamps.iloc[hour_i] - session["arrival_time"]).total_seconds() / 3600.0) * energy
                    allocation_rows.append({"strategy": strategy, "session_id": session["session_id"], "timestamp": timestamps.iloc[hour_i], "energy_kwh": energy, "power_kw": power})

            if strategy != "uncontrolled" and remaining > 1e-9:
                for local_i in order:
                    if remaining <= 1e-9:
                        break
                    hour_i = int(idx[local_i])
                    overlap = float(overlaps[local_i])
                    already = sum(
                        a["energy_kwh"]
                        for a in allocation_rows[-len(idx) :]
                        if a["session_id"] == session["session_id"] and a["timestamp"] == timestamps.iloc[hour_i]
                    )
                    slot_left = max(0.0, max_power * overlap - already)
                    energy = min(remaining, slot_left)
                    if energy > 1e-9:
                        power = energy / overlap
                        scheduled[hour_i] += power
                        delivered += energy
                        remaining -= energy
                        weighted_delay += ((timestamps.iloc[hour_i] - session["arrival_time"]).total_seconds() / 3600.0) * energy
                        allocation_rows.append({"strategy": strategy, "session_id": session["session_id"], "timestamp": timestamps.iloc[hour_i], "energy_kwh": energy, "power_kw": power})

        session_rows.append(
            {
                "strategy": strategy,
                "session_id": session["session_id"],
                "site_id": session["site_id"],
                "energy_requested_kwh": demand,
                "energy_delivered_kwh": delivered,
                "unserved_energy_kwh": max(0.0, demand - delivered),
                "fully_served": delivered + FULLY_SERVED_TOLERANCE_KWH >= demand,
                "average_delay_hours": safe_div(weighted_delay, delivered) if delivered > 0 else np.nan,
            }
        )

    hourly = hours[["timestamp", "site_id"]].copy()
    hourly["strategy"] = strategy
    hourly["scheduled_load_kw"] = scheduled
    hourly["site_capacity_kw"] = capacity_kw
    hourly["capacity_violation_kw"] = np.clip(scheduled - capacity_kw, 0.0, None)
    return hourly, pd.DataFrame(session_rows)


def capacity_value(uncontrolled_load: np.ndarray, scenario: str) -> float:
    if len(uncontrolled_load) == 0:
        return 1.0
    if scenario == "capacity_p90":
        return float(np.percentile(uncontrolled_load, 90))
    if scenario == "capacity_p95":
        return float(np.percentile(uncontrolled_load, 95))
    if scenario == "capacity_p95_plus_10percent":
        return float(np.percentile(uncontrolled_load, 95) * 1.10)
    if scenario == "capacity_historical_peak":
        return float(np.max(uncontrolled_load))
    if scenario == "capacity_mean_plus_2std":
        return float(np.mean(uncontrolled_load) + 2 * np.std(uncontrolled_load))
    raise ValueError(f"Unknown capacity scenario: {scenario}")


def summarize(strategy_hourly: pd.DataFrame, strategy_sessions: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for strategy, h in strategy_hourly.groupby("strategy"):
        s = strategy_sessions.loc[strategy_sessions["strategy"] == strategy]
        load = h.groupby("timestamp")["scheduled_load_kw"].sum().sort_index()
        violations = h["capacity_violation_kw"]
        requested = float(s["energy_requested_kwh"].sum())
        delivered = float(s["energy_delivered_kwh"].sum())
        unserved = float(s["unserved_energy_kwh"].sum())
        peak = float(load.max()) if len(load) else 0.0
        mean_load = float(load.mean()) if len(load) else 0.0
        rows.append(
            {
                "strategy": strategy,
                "sessions_scheduled": int(s["session_id"].nunique()),
                "sites_scheduled": int(s["site_id"].nunique()),
                "total_energy_requested_kwh": requested,
                "total_energy_delivered_kwh": delivered,
                "unserved_energy_kwh": unserved,
                "unserved_energy_percent": pct(unserved, requested),
                "sessions_fully_served_percent": pct(float(s["fully_served"].sum()), len(s)),
                "peak_load_kw": peak,
                "capacity_violation_hours": int((violations > 1e-9).sum()),
                "capacity_violation_percent": pct(int((violations > 1e-9).sum()), len(h)),
                "max_capacity_violation_kw": float(violations.max()) if len(violations) else 0.0,
                "load_std_kw": float(load.std(ddof=0)) if len(load) else 0.0,
                "load_factor": safe_div(mean_load, peak),
                "average_delay_hours": float(s["average_delay_hours"].mean()) if len(s) else np.nan,
            }
        )
    out = pd.DataFrame(rows)
    if "uncontrolled" in set(out["strategy"]):
        base_peak = float(out.loc[out["strategy"] == "uncontrolled", "peak_load_kw"].iloc[0])
        out["peak_reduction_kw_vs_uncontrolled"] = base_peak - out["peak_load_kw"]
        out["peak_reduction_percent_vs_uncontrolled"] = [
            pct(v, base_peak) for v in out["peak_reduction_kw_vs_uncontrolled"]
        ]
    return out


def run_sensitivity(base_sessions: pd.DataFrame, forecasts: pd.DataFrame) -> pd.DataFrame:
    scheduled_site = base_sessions["site_id"].mode().iloc[0]
    site_hours_all = forecasts.loc[forecasts["site_id"] == scheduled_site].copy().sort_values("timestamp")
    all_metrics: list[pd.DataFrame] = []

    scenario_id = 0
    for horizon in HORIZON_SCENARIOS:
        hours_h, sessions_h = horizon_filter(site_hours_all, base_sessions, horizon)
        if hours_h.empty or sessions_h.empty:
            continue
        for charger_power in CHARGER_POWERS:
            uncontrolled_hourly, uncontrolled_sessions = allocate_sessions(
                sessions_h,
                hours_h,
                "uncontrolled",
                "main_point_forecast_kw",
                charger_power,
                np.inf,
            )
            uncontrolled_load = uncontrolled_hourly["scheduled_load_kw"].to_numpy(dtype=float)
            for capacity_name in CAPACITY_SCENARIOS:
                capacity_kw = capacity_value(uncontrolled_load, capacity_name)
                for signal_name, signal_column in FORECAST_SIGNAL_SCENARIOS.items():
                    hourly_frames = [uncontrolled_hourly.assign(site_capacity_kw=capacity_kw)]
                    hourly_frames[0]["capacity_violation_kw"] = np.clip(
                        hourly_frames[0]["scheduled_load_kw"] - capacity_kw, 0.0, None
                    )
                    session_frames = [uncontrolled_sessions]
                    for strategy in ["valley_filling", "point_forecast", "peak_sensitive", "uncertainty_aware"]:
                        if strategy == "valley_filling":
                            effective_signal = signal_column
                        elif strategy == "point_forecast":
                            effective_signal = "main_point_forecast_kw"
                        elif strategy == "peak_sensitive":
                            effective_signal = "peak_sensitive_point_forecast_kw"
                        else:
                            effective_signal = "upper_forecast_kw"
                        h, s = allocate_sessions(sessions_h, hours_h, strategy, effective_signal, charger_power, capacity_kw)
                        hourly_frames.append(h)
                        session_frames.append(s)
                    metrics = summarize(pd.concat(hourly_frames, ignore_index=True), pd.concat(session_frames, ignore_index=True))
                    scenario_id += 1
                    metrics.insert(0, "scenario_id", scenario_id)
                    metrics.insert(1, "horizon_scenario", horizon)
                    metrics.insert(2, "charger_power_kw", charger_power)
                    metrics.insert(3, "capacity_scenario", capacity_name)
                    metrics.insert(4, "forecast_signal_scenario", signal_name)
                    metrics.insert(5, "site_capacity_kw", capacity_kw)
                    all_metrics.append(metrics)
    return pd.concat(all_metrics, ignore_index=True)


def compare_uncertainty(metrics: pd.DataFrame) -> pd.DataFrame:
    rows = []
    scenario_cols = ["scenario_id", "horizon_scenario", "charger_power_kw", "capacity_scenario", "forecast_signal_scenario"]
    for keys, group in metrics.groupby(scenario_cols):
        ua = group.loc[group["strategy"] == "uncertainty_aware"].iloc[0]
        best_capacity = group["capacity_violation_hours"].min()
        best_peak = group["peak_reduction_percent_vs_uncontrolled"].max()
        for _, other in group.loc[group["strategy"] != "uncertainty_aware"].iterrows():
            rows.append(
                {
                    **dict(zip(scenario_cols, keys)),
                    "comparison_strategy": other["strategy"],
                    "peak_reduction_difference": ua["peak_reduction_percent_vs_uncontrolled"] - other["peak_reduction_percent_vs_uncontrolled"],
                    "capacity_violation_difference": ua["capacity_violation_hours"] - other["capacity_violation_hours"],
                    "unserved_energy_difference": ua["unserved_energy_percent"] - other["unserved_energy_percent"],
                    "energy_delivery_difference": ua["total_energy_delivered_kwh"] - other["total_energy_delivered_kwh"],
                    "uncertainty_aware_best_for_capacity_risk": bool(ua["capacity_violation_hours"] <= best_capacity),
                    "uncertainty_aware_best_for_peak_reduction": bool(ua["peak_reduction_percent_vs_uncontrolled"] >= best_peak),
                    "uncertainty_aware_safer_but_more_conservative": bool(
                        ua["capacity_violation_hours"] <= other["capacity_violation_hours"]
                        and ua["peak_reduction_percent_vs_uncontrolled"] < other["peak_reduction_percent_vs_uncontrolled"]
                    ),
                }
            )
    return pd.DataFrame(rows)


def decide_claim(metrics: pd.DataFrame, comparison: pd.DataFrame) -> pd.DataFrame:
    ua = metrics.loc[metrics["strategy"] == "uncertainty_aware"].copy()
    uncontrolled = metrics.loc[metrics["strategy"] == "uncontrolled", ["scenario_id", "capacity_violation_hours"]].rename(
        columns={"capacity_violation_hours": "uncontrolled_capacity_violation_hours"}
    )
    ua = ua.merge(uncontrolled, on="scenario_id", how="left")
    low_unserved_share = float((ua["unserved_energy_percent"] <= 1.0).mean())
    capacity_improvement_share = float((ua["capacity_violation_hours"] < ua["uncontrolled_capacity_violation_hours"]).mean())
    best_capacity_share = float(comparison.groupby("scenario_id")["uncertainty_aware_best_for_capacity_risk"].first().mean())
    best_peak_share = float(comparison.groupby("scenario_id")["uncertainty_aware_best_for_peak_reduction"].first().mean())

    if capacity_improvement_share >= 0.80 and low_unserved_share >= 0.80 and best_capacity_share >= 0.50:
        strength = "strong"
        reason = "uncertainty-aware scheduling reduces capacity violations in most scenarios while keeping unserved energy low"
    elif capacity_improvement_share >= 0.50 and low_unserved_share >= 0.80:
        strength = "moderate"
        reason = "uncertainty-aware scheduling improves capacity safety in many scenarios, but another strategy can have stronger peak reduction"
    elif capacity_improvement_share > 0:
        strength = "weak"
        reason = "improvement appears only in a subset of sensitivity scenarios"
    else:
        strength = "not supported"
        reason = "uncertainty-aware scheduling does not reliably reduce capacity risk"

    claim = pd.DataFrame(
        [
            {
                "claim_strength": strength,
                "reason": reason,
                "scenarios_evaluated": int(ua["scenario_id"].nunique()),
                "capacity_improvement_share_vs_uncontrolled": capacity_improvement_share,
                "low_unserved_energy_share_le_1pct": low_unserved_share,
                "uncertainty_aware_best_capacity_share": best_capacity_share,
                "uncertainty_aware_best_peak_share": best_peak_share,
                "mean_uncertainty_aware_peak_reduction_percent": float(ua["peak_reduction_percent_vs_uncontrolled"].mean()),
                "mean_uncertainty_aware_capacity_violation_hours": float(ua["capacity_violation_hours"].mean()),
                "mean_uncertainty_aware_unserved_energy_percent": float(ua["unserved_energy_percent"].mean()),
            }
        ]
    )
    claim.to_csv(RESULTS_DIR / "11B_scheduling_claim_strength.csv", index=False)
    return claim


def write_reports(diagnosis: pd.DataFrame, metrics: pd.DataFrame, comparison: pd.DataFrame, claim: pd.DataFrame) -> dict[str, Any]:
    raw_sites = int((diagnosis["raw_session_count"] > 0).sum())
    forecast_sites = int((diagnosis["forecast_hours"] > 0).sum())
    scheduled_sites = int((diagnosis["calendar_aligned_scheduled_sessions"] > 0).sum())
    scheduled_sessions = int(diagnosis["calendar_aligned_scheduled_sessions"].sum())
    scenario_count = int(metrics["scenario_id"].nunique())
    ua = metrics.loc[metrics["strategy"] == "uncertainty_aware"]
    uncontrolled = metrics.loc[metrics["strategy"] == "uncontrolled"]
    best_peak_row = metrics.sort_values("peak_reduction_percent_vs_uncontrolled", ascending=False).iloc[0]
    best_capacity_row = metrics.sort_values(["capacity_violation_hours", "unserved_energy_percent"]).iloc[0]
    claim_row = claim.iloc[0]

    coverage_report = f"""Step 11B coverage explanation report
====================================
Why only one site was scheduled:
The session-level file contains one raw session site, while the Step 10 forecast file contains six hourly forecast sites. Step 11 mapped the one available session site to a forecast/hourly site and therefore only one site had session-level demand that could be scheduled.

Data limitation or code issue:
This is a data limitation rather than a scheduling-code issue. The scheduler can evaluate any site that has session-level arrivals, departures, energy requests, and matching forecast hours. In this project version, the processed session file provides session-level constraints for one raw site only.

Timestamp limitation:
The raw session timestamps are from an earlier period than the Step 10 forecast horizon. Direct timestamp overlap between raw sessions and Step 10 forecasts is therefore unavailable. Step 11 used a documented calendar-aligned forecast-horizon scenario to test operational scheduling with real session durations, energy requests, and parking windows.

Calendar alignment:
Calendar alignment is acceptable as an operational scenario or stress test, but it should not be described as a direct historical replay. It preserves session constraints and uses forecasts only as scheduling signals, but the paper must clearly state that scheduling was evaluated under a calendar-aligned scenario.

Paper description:
Describe Step 11/11B as a constrained scheduling case study using one session-supported site under a calendar-aligned operational scenario. Do not claim multi-site session-level scheduling unless additional site-level session data are added.

Coverage summary:
Raw session sites: {raw_sites}
Forecast sites: {forecast_sites}
Scheduled session-supported sites: {scheduled_sites}
Calendar-aligned sessions available: {scheduled_sessions}
"""

    report = f"""Step 11B scheduling robustness report
=======================================
Why Step 11B was needed:
Step 11 produced promising constrained scheduling results, but it scheduled one session-supported site and used a calendar-aligned forecast-horizon scenario. Step 11B tests whether those findings are stable under alternative capacity assumptions, charger powers, forecast-signal settings, and scheduling horizons.

Coverage diagnosis:
The session-level file supports {raw_sites} raw site, while Step 10 forecasts cover {forecast_sites} sites. The final sensitivity analysis therefore remains a one-site session-level scheduling case study with {scheduled_sessions} usable calendar-aligned sessions.

Capacity sensitivity:
The analysis evaluated {len(CAPACITY_SCENARIOS)} capacity assumptions: p90, p95, p95 plus 10%, historical peak, and mean plus 2 standard deviations. Capacity violation outcomes vary by assumption, which confirms that capacity assumptions should be reported explicitly.

Charger power sensitivity:
The analysis evaluated 6.6, 7.2, and 11.0 kW charger assumptions. Higher charger power increases flexibility but can also increase instantaneous peak risk if unmanaged.

Strategy comparison:
Across {scenario_count} sensitivity scenarios, the best observed peak-reduction row was {best_peak_row.strategy} with {best_peak_row.peak_reduction_percent_vs_uncontrolled:.2f}% peak reduction. The best observed capacity-safety row was {best_capacity_row.strategy} with {int(best_capacity_row.capacity_violation_hours)} capacity violation hours.

Uncertainty-aware usefulness:
Uncertainty-aware scheduling averaged {ua['peak_reduction_percent_vs_uncontrolled'].mean():.2f}% peak reduction and {ua['capacity_violation_hours'].mean():.2f} capacity violation hours across sensitivity scenarios. Its mean unserved energy was {ua['unserved_energy_percent'].mean():.3f}%.

Final scheduling claim strength:
{claim_row.claim_strength}. Reason: {claim_row.reason}.

Limitations:
The scheduling evidence is a one-site, calendar-aligned operational case study. It is useful for demonstrating feasibility and forecast-informed scheduling logic, but it should not be overgeneralized to all forecast sites without additional session-level data.

Recommended paper wording:
Use cautious language: "In a one-site calendar-aligned scheduling case study, forecast-informed and uncertainty-aware scheduling reduced peak/capacity risk while preserving high charging completion rates." Avoid saying that multi-site real-time scheduling was validated.
"""

    leakage = """Step 11B leakage safety report
================================
- Scheduling decisions use only session constraints, capacity assumptions, and Step 10 forecast columns.
- Actual future load is not used to rank scheduling hours.
- Sensitivity scenarios vary capacity, charger power, forecast signal, and horizon definitions; they do not tune hidden test labels.
- The calendar-aligned scenario is documented as an operational stress-test scenario, not a direct historical replay.
- Evaluation metrics are computed after schedules are generated.
- No future information is used in scheduling decisions.
"""

    novelty = """Step 11B novelty contribution report
=====================================
Step 11B strengthens the scheduling contribution by adding robustness and sensitivity testing around the constrained scheduling case study.

Contribution elements:
- Session-level constrained scheduling with arrival/departure windows, energy requests, charger limits, and capacity assumptions.
- Forecast-informed scheduling using E-AHPA and PRC-E-AHPA forecast signals.
- Uncertainty-aware scheduling using Step 10 upper-bound forecasts.
- Sensitivity testing across capacity assumptions, charger power assumptions, forecast signals, and horizon choices.
- Honest feasibility reporting, including unserved energy, capacity violations, and the one-site/calendar-aligned limitation.
"""

    paper = f"""Scheduling robustness was evaluated as a one-site calendar-aligned operational case study because the available session-level data covered one raw site and did not directly overlap the Step 10 forecast horizon. Across {scenario_count} sensitivity scenarios varying capacity assumptions, charger power, forecast signal, and horizon choice, uncertainty-aware scheduling achieved an average peak reduction of {ua['peak_reduction_percent_vs_uncontrolled'].mean():.2f}% relative to uncontrolled charging, with average capacity violation hours of {ua['capacity_violation_hours'].mean():.2f} and average unserved energy of {ua['unserved_energy_percent'].mean():.3f}%. The resulting scheduling claim strength is {claim_row.claim_strength}: {claim_row.reason}. These results support the use of uncertainty-aware forecasts as a capacity-risk-aware scheduling signal, while the manuscript should present the scheduling evidence as a constrained one-site case study rather than a multi-site historical replay."""

    reports = {
        "11B_coverage_explanation_report.txt": coverage_report,
        "11B_scheduling_robustness_report.txt": report,
        "11B_leakage_safety_report.txt": leakage,
        "11B_novelty_contribution_report.txt": novelty,
        "11B_paper_ready_scheduling_paragraph.txt": paper,
    }
    for name, text in reports.items():
        (RESULTS_DIR / name).write_text(text, encoding="utf-8")
    return {
        "raw_sites": raw_sites,
        "forecast_sites": forecast_sites,
        "scheduled_sites": scheduled_sites,
        "scheduled_sessions": scheduled_sessions,
        "scenario_count": scenario_count,
        "best_peak_strategy": str(best_peak_row.strategy),
        "best_capacity_strategy": str(best_capacity_row.strategy),
        "ua_avg_peak_reduction": float(ua["peak_reduction_percent_vs_uncontrolled"].mean()),
        "ua_avg_capacity_reduction": float(
            uncontrolled.groupby("scenario_id")["capacity_violation_hours"].first().mean()
            - ua.groupby("scenario_id")["capacity_violation_hours"].first().mean()
        ),
        "claim_strength": str(claim_row.claim_strength),
    }


def make_figures(diagnosis: pd.DataFrame, metrics: pd.DataFrame, comparison: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(9, 5))
    plot_diag = diagnosis.copy()
    labels = plot_diag["site_id_or_raw_site"].astype(str)
    x = np.arange(len(plot_diag))
    ax.bar(x - 0.25, plot_diag["raw_session_count"], width=0.25, label="Raw sessions")
    ax.bar(x, plot_diag["forecast_hours"], width=0.25, label="Forecast hours")
    ax.bar(x + 0.25, plot_diag["calendar_aligned_scheduled_sessions"], width=0.25, label="Scheduled sessions")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=35, ha="right")
    ax.set_title("Site coverage diagnosis")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11B_fig1_site_coverage_diagnosis.png", dpi=300)
    plt.close(fig)

    means = metrics.groupby("strategy", as_index=False).agg(
        peak_reduction=("peak_reduction_percent_vs_uncontrolled", "mean"),
        violations=("capacity_violation_hours", "mean"),
        unserved=("unserved_energy_percent", "mean"),
        delivered=("total_energy_delivered_kwh", "mean"),
        load_factor=("load_factor", "mean"),
    )

    def bar(y: str, title: str, ylabel: str, path: str) -> None:
        fig, ax = plt.subplots(figsize=(9, 5))
        ax.bar(means["strategy"], means[y], color="#3b6ea8")
        ax.set_title(title)
        ax.set_ylabel(ylabel)
        ax.tick_params(axis="x", rotation=30)
        ax.grid(axis="y", alpha=0.25)
        fig.tight_layout()
        fig.savefig(FIGURES_DIR / path, dpi=300)
        plt.close(fig)

    bar("peak_reduction", "Average peak reduction across sensitivity scenarios", "Peak reduction (%)", "11B_fig2_peak_reduction_sensitivity.png")
    bar("violations", "Average capacity violation hours", "Violation hours", "11B_fig3_capacity_violation_sensitivity.png")
    bar("unserved", "Average unserved energy", "Unserved energy (%)", "11B_fig4_unserved_energy_sensitivity.png")
    delivered_pct = metrics.copy()
    delivered_pct["energy_delivered_percent"] = [
        pct(r.total_energy_delivered_kwh, r.total_energy_requested_kwh) for r in delivered_pct.itertuples()
    ]
    delivered_means = delivered_pct.groupby("strategy", as_index=False)["energy_delivered_percent"].mean()
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar(delivered_means["strategy"], delivered_means["energy_delivered_percent"], color="#3b6ea8")
    ax.set_title("Average energy delivery across sensitivity scenarios")
    ax.set_ylabel("Energy delivered (%)")
    ax.tick_params(axis="x", rotation=30)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11B_fig5_energy_delivery_sensitivity.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    for strategy, group in metrics.groupby("strategy"):
        ax.scatter(group["unserved_energy_percent"], group["peak_reduction_percent_vs_uncontrolled"], label=strategy, alpha=0.65)
    ax.set_xlabel("Unserved energy (%)")
    ax.set_ylabel("Peak reduction (%)")
    ax.set_title("Strategy tradeoff: peak reduction vs unserved energy")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11B_fig6_strategy_tradeoff_peak_vs_unserved.png", dpi=300)
    plt.close(fig)

    point_vs_ua = comparison.loc[comparison["comparison_strategy"] == "point_forecast"].copy()
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.scatter(point_vs_ua["peak_reduction_difference"], point_vs_ua["capacity_violation_difference"], alpha=0.7)
    ax.axhline(0, color="black", linewidth=0.8)
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_xlabel("Uncertainty-aware minus point peak reduction (%)")
    ax.set_ylabel("Uncertainty-aware minus point violation hours")
    ax.set_title("Uncertainty-aware vs point scheduling")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11B_fig7_uncertainty_vs_point_scheduling.png", dpi=300)
    plt.close(fig)


def main() -> None:
    ensure_dirs()
    for path in [
        SESSION_FILE,
        HOURLY_FILE,
        FORECAST_FILE,
        STEP11_HOURLY_FILE,
        STEP11_SESSIONS_FILE,
        STEP11_OVERALL_FILE,
        STEP11_SITE_FILE,
        STEP11_COMPARISON_FILE,
        STEP11_CAPACITY_FILE,
        STEP11_COVERAGE_FILE,
    ]:
        require(path)

    raw_sessions = read_csv(SESSION_FILE)
    hourly = read_csv(HOURLY_FILE)
    forecasts = prepare_forecasts()
    base_sessions = prepare_base_sessions()
    diagnosis = coverage_diagnosis(raw_sessions, hourly, forecasts, base_sessions)
    metrics = run_sensitivity(base_sessions, forecasts)
    metrics.to_csv(RESULTS_DIR / "11B_sensitivity_scenario_metrics.csv", index=False)
    metrics.to_csv(RESULTS_DIR / "11B_robustness_metrics.csv", index=False)
    comparison = compare_uncertainty(metrics)
    comparison.to_csv(RESULTS_DIR / "11B_uncertainty_aware_comparison.csv", index=False)
    claim = decide_claim(metrics, comparison)
    summary = write_reports(diagnosis, metrics, comparison, claim)
    make_figures(diagnosis, metrics, comparison)
    (RESULTS_DIR / "11B_run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    excluded = diagnosis.loc[diagnosis["calendar_aligned_scheduled_sessions"] == 0, "site_id_or_raw_site"].astype(str).tolist()
    print("Step 11B scheduling robustness and sensitivity complete")
    print(f"Sites available in sessions: {summary['raw_sites']}")
    print(f"Sites available in forecasts: {summary['forecast_sites']}")
    print(f"Sites scheduled: {summary['scheduled_sites']}")
    print(f"Why sites were excluded: no session-level demand existed for forecast-only sites; raw session timestamps also did not directly overlap the Step 10 forecast horizon.")
    print(f"Excluded forecast/raw site labels: {', '.join(excluded[:8]) if excluded else 'none'}")
    print(f"Sensitivity scenarios run: {summary['scenario_count']}")
    print(f"Best strategy by peak reduction: {summary['best_peak_strategy']}")
    print(f"Best strategy by capacity violations: {summary['best_capacity_strategy']}")
    print(f"Uncertainty-aware average peak reduction: {summary['ua_avg_peak_reduction']:.2f}%")
    print(f"Uncertainty-aware average capacity violation reduction: {summary['ua_avg_capacity_reduction']:.2f} hours")
    print(f"Claim strength: {summary['claim_strength']}")
    print(f"Results folder: {RESULTS_DIR}")
    print(f"Figures folder: {FIGURES_DIR}")


if __name__ == "__main__":
    main()
