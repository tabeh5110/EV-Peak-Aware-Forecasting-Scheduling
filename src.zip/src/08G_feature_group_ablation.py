"""
08G_feature_group_ablation.py

Reviewer m7 response analysis:
Feature-group ablation and gain-based importance analysis.

Purpose:
- Identify contribution of lag, rolling, EWM, peak-risk,
  calendar, and interaction features.
- Provide gain-based feature importance.
- Perform controlled feature-group ablation.

Run:
python src/08G_feature_group_ablation.py
"""


from pathlib import Path
import json
import pandas as pd

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

from lightgbm import LGBMRegressor



# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

TRAIN_FILE = ROOT / "data" / "processed" / "05B_train_features.csv"
VALID_FILE = ROOT / "data" / "processed" / "05B_validation_features.csv"
TEST_FILE = ROOT / "data" / "processed" / "05B_test_features.csv"


OUT = ROOT / "results" / "08G_feature_group_ablation"
OUT.mkdir(parents=True, exist_ok=True)


TARGET = "target_load_kw"



# ============================================================
# FEATURE GROUPING
# ============================================================

def feature_group(name):

    n = name.lower()


    # Dataset metadata
    if any(
        x in n
        for x in [
            "site_id",
            "site_total",
            "row_number",
            "source_file",
            "train_mean",
            "train_std",
            "train_max"
        ]
    ):
        return "Metadata"


    # Peak risk features
    if any(
        x in n
        for x in [
            "recent_peak",
            "hours_since_recent_peak",
            "no_previous_peak",
            "peak_threshold",
            "is_peak_hour",
            "is_high_peak_hour"
        ]
    ):
        return "Peak-risk"


    # Lag and historical features
    if (
        n.startswith("lag_")
        or "diff_" in n
        or "ratio_lag" in n
        or "same_hour" in n
    ):
        return "Lag-memory"


    # Rolling statistics
    if (
        n.startswith("rolling_")
        or "rolling_" in n
    ):
        return "Rolling-memory"


    # Exponential weighted memory
    if n.startswith("ewm_"):
        return "EWM-memory"


    # Interaction features
    if "_x_" in n:
        return "Interaction"


    # Calendar features
    if any(
        x in n
        for x in [
            "hour",
            "day",
            "week",
            "month",
            "year",
            "quarter",
            "business",
            "sin",
            "cos",
            "weekend"
        ]
    ):
        return "Calendar"


    # Missing indicators
    if (
        "missing" in n
        or "was_missing" in n
    ):
        return "Missing indicators"


    return "Other"




# ============================================================
# METRICS
# ============================================================

def evaluate(y_true, y_pred):

    peak_threshold = y_true.quantile(0.90)
    high_threshold = y_true.quantile(0.95)

    peak_mask = y_true >= peak_threshold
    high_mask = y_true >= high_threshold


    return {

        "MAE":
            mean_absolute_error(
                y_true,
                y_pred
            ),


        "RMSE":
            mean_squared_error(
                y_true,
                y_pred
            ) ** 0.5,


        "R2":
            r2_score(
                y_true,
                y_pred
            ),


        "Peak_MAE":
            mean_absolute_error(
                y_true[peak_mask],
                y_pred[peak_mask]
            ),


        "High_peak_MAE":
            mean_absolute_error(
                y_true[high_mask],
                y_pred[high_mask]
            ),


        "Underestimation_rate":
            float(
                (y_pred < y_true).mean()*100
            )
    }




# ============================================================
# MODEL
# ============================================================

def build_model():

    return LGBMRegressor(

        n_estimators=600,

        learning_rate=0.03,

        max_depth=-1,

        random_state=42,

        n_jobs=-1
    )




# ============================================================
# MAIN
# ============================================================

def main():

    print("Loading datasets...")


    train = pd.read_csv(TRAIN_FILE)

    valid = pd.read_csv(VALID_FILE)

    test = pd.read_csv(TEST_FILE)



    print(
        f"Train: {train.shape} "
        f"Validation: {valid.shape} "
        f"Test: {test.shape}"
    )



    # Remove leakage/non-predictive columns

    DROP_COLUMNS = [

        TARGET,

        "split",

        "timestamp",

        "site_id",

        "source_file"

    ]



    features = [

        c for c in train.columns

        if c not in DROP_COLUMNS

    ]



    print(
        "Number of forecasting features:",
        len(features)
    )



    X_train = train[features]

    y_train = train[TARGET]


    X_test = test[features]

    y_test = test[TARGET]




    # ========================================================
    # FULL MODEL FEATURE IMPORTANCE
    # ========================================================


    print("\nTraining full LightGBM model...")


    model = build_model()


    model.fit(

        X_train,

        y_train

    )



    importance = pd.DataFrame({

        "feature":

            features,


        "gain":

            model.booster_.feature_importance(

                importance_type="gain"

            )

    })



    importance["group"] = (

        importance["feature"]

        .apply(feature_group)

    )



    importance = importance.sort_values(

        "gain",

        ascending=False

    )



    importance.to_csv(

        OUT /
        "08G_feature_importance_gain.csv",

        index=False

    )



    # Remove metadata for scientific summary

    importance_scientific = importance[

        importance["group"] != "Metadata"

    ].copy()



    grouped = (

        importance_scientific

        .groupby("group")["gain"]

        .sum()

        .reset_index()

    )



    grouped["Gain_percentage"] = (

        grouped["gain"]

        /

        grouped["gain"].sum()

        *

        100

    )



    grouped = grouped.sort_values(

        "Gain_percentage",

        ascending=False

    )



    grouped.rename(

        columns={

            "group":

            "Feature_group"

        },

        inplace=True

    )



    grouped.to_csv(

        OUT /

        "08G_group_importance_summary.csv",

        index=False

    )




    # ========================================================
    # FEATURE GROUP ABLATION
    # ========================================================


    experiments = {


        "Full_features":

        [],


        "Without_lag_memory":

        ["Lag-memory"],


        "Without_rolling_memory":

        ["Rolling-memory"],


        "Without_EWM_memory":

        ["EWM-memory"],


        "Without_peak_risk":

        ["Peak-risk"],


        "Without_calendar":

        ["Calendar"],


        "Without_interactions":

        ["Interaction"]

    }



    results = []



    for name, removed_groups in experiments.items():


        print(

            "\nRunning:",

            name

        )



        selected_features = [

            f for f in features

            if feature_group(f)

            not in removed_groups

            and feature_group(f)

            != "Metadata"

        ]



        model = build_model()



        model.fit(

            train[selected_features],

            y_train

        )



        pred = model.predict(

            test[selected_features]

        )



        metrics = evaluate(

            y_test,

            pred

        )



        metrics["Configuration"] = name


        metrics["Number_of_features"] = len(

            selected_features

        )



        results.append(metrics)



    results = pd.DataFrame(results)



    results.to_csv(

        OUT /

        "08G_ablation_results.csv",

        index=False

    )




    summary = {


        "train_rows":

        len(train),


        "validation_rows":

        len(valid),


        "test_rows":

        len(test),


        "total_features":

        len(features),


        "target":

        TARGET,


        "experiments":

        list(experiments.keys())

    }



    with open(

        OUT /

        "08G_run_summary.json",

        "w"

    ) as f:


        json.dump(

            summary,

            f,

            indent=4

        )



    print("\nCompleted successfully.")

    print(results)




if __name__ == "__main__":

    main()