"""
Step 04: exploratory analysis for EV charging load and session data.

Run from the project root:
    python src/04_exploratory_analysis.py

This script creates paper-safe EDA tables, figures, captions, and a report.
It does not create forecasting features, forecasting models, or scheduling
optimization.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import re
import sys
import types

import numpy as np


# Environment guard for this workstation: the Python standard-library
# _strptime.py has been overwritten by old project code. Pandas/matplotlib need
# a small import-time API from _strptime, so provide it locally without editing
# the external Python installation.
if "_strptime" not in sys.modules:
    _strptime_stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    _strptime_stub.LocaleTime = LocaleTime
    _strptime_stub.TimeRE = TimeRE
    _strptime_stub._TimeRE_cache = TimeRE()
    _strptime_stub._regex_cache = {}
    _strptime_stub._getlang = _getlang
    _strptime_stub._strptime = _strptime
    _strptime_stub._strptime_time = _strptime
    _strptime_stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = _strptime_stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
HOURLY_FILE = PROJECT_ROOT / "data" / "processed" / "03_hourly_load_all_sites.csv"
CLEAN_SESSIONS_FILE = PROJECT_ROOT / "data" / "processed" / "02_clean_sessions.csv"
SCHEDULING_READY_FILE = PROJECT_ROOT / "data" / "processed" / "02_scheduling_ready_sessions.csv"
RESULTS_DIR = PROJECT_ROOT / "results" / "04_exploratory_analysis"
FIGURES_DIR = PROJECT_ROOT / "figures" / "04_exploratory_analysis"

HOURLY_SUMMARY_FILE = RESULTS_DIR / "04_hourly_summary_by_site.csv"
LOAD_BY_HOUR_FILE = RESULTS_DIR / "04_average_load_by_hour.csv"
LOAD_BY_WEEKDAY_FILE = RESULTS_DIR / "04_average_load_by_weekday.csv"
SESSION_SUMMARY_FILE = RESULTS_DIR / "04_session_summary.csv"
PEAK_LOAD_FILE = RESULTS_DIR / "04_peak_load_by_site.csv"
CAPTIONS_FILE = RESULTS_DIR / "04_figure_captions.txt"
REPORT_FILE = RESULTS_DIR / "04_exploratory_analysis_report.txt"

WEEKDAY_ORDER = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def parse_datetime(series: pd.Series) -> pd.Series:
    """Parse datetimes safely; invalid values become NaT."""
    try:
        return pd.to_datetime(series, errors="coerce", format="mixed")
    except TypeError:
        return pd.to_datetime(series, errors="coerce")


def add_temporal_columns(hourly: pd.DataFrame) -> pd.DataFrame:
    df = hourly.copy()
    df["timestamp"] = parse_datetime(df["timestamp"])
    df = df.dropna(subset=["timestamp"]).copy()
    df["hour"] = df["timestamp"].dt.hour
    df["day_of_week"] = df["timestamp"].dt.dayofweek
    df["day_name"] = df["timestamp"].dt.day_name()
    df["month"] = df["timestamp"].dt.month
    df["date"] = df["timestamp"].dt.date
    df["is_weekend"] = df["day_of_week"].isin([5, 6])
    return df


def load_sessions(path: Path) -> pd.DataFrame | None:
    if not path.exists():
        return None
    df = pd.read_csv(path)
    for column in ["arrival_time", "departure_time", "done_time", "requestedDeparture"]:
        if column in df.columns:
            df[column] = parse_datetime(df[column])
    return df


def build_hourly_summary(hourly: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for site_id, site_df in hourly.groupby("site_id", sort=True):
        total_hours = len(site_df)
        observed_hours = int(site_df["load_kw_observed"].notna().sum())
        missing_hours = int(site_df["was_missing_hour"].sum())
        rows.append(
            {
                "site_id": site_id,
                "start_time": site_df["timestamp"].min(),
                "end_time": site_df["timestamp"].max(),
                "total_hours": total_hours,
                "observed_hours": observed_hours,
                "missing_hours": missing_hours,
                "missing_hours_percentage": round(missing_hours / total_hours * 100, 4)
                if total_hours
                else 0.0,
                "mean_load_kw": site_df["load_kw"].mean(),
                "median_load_kw": site_df["load_kw"].median(),
                "std_load_kw": site_df["load_kw"].std(),
                "min_load_kw": site_df["load_kw"].min(),
                "max_load_kw": site_df["load_kw"].max(),
                "total_energy_kwh": site_df["load_kw"].sum(),
                "zero_load_hours": int((site_df["load_kw"] == 0).sum()),
                "nonzero_load_hours": int((site_df["load_kw"] > 0).sum()),
            }
        )
    return pd.DataFrame(rows)


def build_load_by_hour(hourly: pd.DataFrame) -> pd.DataFrame:
    return (
        hourly.groupby(["site_id", "hour"], as_index=False)
        .agg(
            mean_load_kw=("load_kw", "mean"),
            median_load_kw=("load_kw", "median"),
            sample_count=("load_kw", "size"),
        )
        .sort_values(["site_id", "hour"])
    )


def build_load_by_weekday(hourly: pd.DataFrame) -> pd.DataFrame:
    df = (
        hourly.groupby(["site_id", "day_of_week", "day_name"], as_index=False)
        .agg(
            mean_load_kw=("load_kw", "mean"),
            median_load_kw=("load_kw", "median"),
            sample_count=("load_kw", "size"),
        )
        .sort_values(["site_id", "day_of_week"])
    )
    return df


def describe_series(prefix: str, series: pd.Series) -> dict[str, Any]:
    numeric = pd.to_numeric(series, errors="coerce")
    return {
        f"min_{prefix}": numeric.min(),
        f"max_{prefix}": numeric.max(),
        f"mean_{prefix}": numeric.mean(),
        f"median_{prefix}": numeric.median(),
    }


def build_session_summary(cleaned: pd.DataFrame | None, scheduling_ready: pd.DataFrame | None) -> pd.DataFrame:
    if cleaned is None:
        return pd.DataFrame(
            [
                {
                    "total_sessions": 0,
                    "scheduling_ready_sessions": 0,
                    "note": "cleaned session file not found",
                }
            ]
        )

    row: dict[str, Any] = {
        "total_sessions": len(cleaned),
        "scheduling_ready_sessions": len(scheduling_ready) if scheduling_ready is not None else np.nan,
    }
    for column in ["energy_kwh", "session_duration_hours", "average_power_kw"]:
        if column in cleaned.columns:
            row.update(describe_series(column, cleaned[column]))
        else:
            row.update(
                {
                    f"min_{column}": np.nan,
                    f"max_{column}": np.nan,
                    f"mean_{column}": np.nan,
                    f"median_{column}": np.nan,
                }
            )
    for column in ["stationID", "spaceID", "siteID"]:
        row[f"unique_{column}"] = int(cleaned[column].nunique(dropna=True)) if column in cleaned.columns else np.nan
    return pd.DataFrame([row])


def build_peak_load(hourly: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for site_id, site_df in hourly.groupby("site_id", sort=True):
        peak_idx = site_df["load_kw"].idxmax()
        peak_load = float(site_df.loc[peak_idx, "load_kw"])
        mean_load = float(site_df["load_kw"].mean())
        rows.append(
            {
                "site_id": site_id,
                "peak_load_kw": peak_load,
                "peak_timestamp": site_df.loc[peak_idx, "timestamp"],
                "mean_load_kw": mean_load,
                "peak_to_mean_ratio": peak_load / mean_load if mean_load else np.nan,
            }
        )
    return pd.DataFrame(rows)


def add_bar_labels(ax: plt.Axes, fmt: str = "{:.1f}") -> None:
    for patch in ax.patches:
        height = patch.get_height()
        ax.text(
            patch.get_x() + patch.get_width() / 2,
            height,
            fmt.format(height),
            ha="center",
            va="bottom",
            fontsize=8,
        )


def save_timeseries_by_site(hourly: pd.DataFrame, path: Path) -> None:
    sites = sorted(hourly["site_id"].unique())
    fig, axes = plt.subplots(len(sites), 1, figsize=(13, 2.4 * len(sites)), sharex=False)
    if len(sites) == 1:
        axes = [axes]
    for ax, site_id in zip(axes, sites):
        site_df = hourly.loc[hourly["site_id"] == site_id].sort_values("timestamp")
        ax.plot(site_df["timestamp"], site_df["load_kw"], linewidth=0.8)
        ax.set_title(site_id)
        ax.set_ylabel("Load (kW)")
        ax.grid(True, alpha=0.3)
    axes[-1].set_xlabel("Timestamp")
    fig.suptitle("Hourly EV charging load over time by site", y=0.995)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def save_average_load_by_hour(load_by_hour: pd.DataFrame, path: Path) -> None:
    overall = load_by_hour.groupby("hour", as_index=False)["mean_load_kw"].mean()
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(overall["hour"], overall["mean_load_kw"], marker="o", linewidth=2)
    ax.set_xticks(range(24))
    ax.set_xlim(0, 23)
    ax.set_xlabel("Hour of day")
    ax.set_ylabel("Mean load (kW)")
    ax.set_title("Average hourly EV charging load by hour of day")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def save_average_load_by_weekday(hourly: pd.DataFrame, path: Path) -> None:
    overall = hourly.groupby(["day_of_week", "day_name"], as_index=False)["load_kw"].mean()
    overall = overall.sort_values("day_of_week")
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar(overall["day_name"], overall["load_kw"])
    ax.set_xlabel("Day of week")
    ax.set_ylabel("Mean load (kW)")
    ax.set_title("Average EV charging load by weekday")
    ax.tick_params(axis="x", rotation=30)
    add_bar_labels(ax)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def save_histogram(df: pd.DataFrame, column: str, xlabel: str, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(9, 5))
    values = pd.to_numeric(df[column], errors="coerce").dropna()
    ax.hist(values, bins=40)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Number of sessions")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def save_site_bar(df: pd.DataFrame, value_column: str, ylabel: str, title: str, path: Path) -> None:
    plot_df = df.sort_values(value_column, ascending=False)
    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.bar(plot_df["site_id"], plot_df[value_column])
    ax.set_xlabel("Site")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.tick_params(axis="x", rotation=35)
    add_bar_labels(ax)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def save_weekend_vs_weekday(hourly: pd.DataFrame, path: Path) -> pd.DataFrame:
    summary = (
        hourly.assign(day_type=np.where(hourly["is_weekend"], "Weekend", "Weekday"))
        .groupby("day_type", as_index=False)["load_kw"]
        .mean()
    )
    summary["sort_order"] = summary["day_type"].map({"Weekday": 0, "Weekend": 1})
    summary = summary.sort_values("sort_order")
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.bar(summary["day_type"], summary["load_kw"])
    ax.set_xlabel("Day type")
    ax.set_ylabel("Mean load (kW)")
    ax.set_title("Average EV charging load on weekdays and weekends")
    add_bar_labels(ax)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)
    return summary.drop(columns=["sort_order"])


def write_captions() -> None:
    captions = [
        "Fig. 1. Hourly EV charging load over time by site, shown as one stacked time-series panel per charging site.",
        "Fig. 2. Average hourly EV charging load by hour of day across charging sites.",
        "Fig. 3. Average EV charging load by weekday across charging sites.",
        "Fig. 4. Distribution of session duration in hours for cleaned EV charging sessions.",
        "Fig. 5. Distribution of delivered charging energy in kWh for cleaned EV charging sessions.",
        "Fig. 6. Peak hourly EV charging load by site, matching the values reported in 04_peak_load_by_site.csv.",
        "Fig. 7. Mean hourly EV charging load by site.",
        "Fig. 8. Average EV charging load for weekday hours compared with weekend hours.",
    ]
    CAPTIONS_FILE.write_text("\n".join(captions) + "\n", encoding="utf-8")


def write_report(
    hourly: pd.DataFrame,
    cleaned_sessions: pd.DataFrame | None,
    scheduling_ready: pd.DataFrame | None,
    hourly_summary: pd.DataFrame,
    load_by_hour: pd.DataFrame,
    load_by_weekday: pd.DataFrame,
    peak_load: pd.DataFrame,
    weekend_summary: pd.DataFrame,
) -> None:
    timestamp_min = hourly["timestamp"].min()
    timestamp_max = hourly["timestamp"].max()
    num_sites = hourly["site_id"].nunique()
    session_count = len(cleaned_sessions) if cleaned_sessions is not None else 0
    scheduling_count = len(scheduling_ready) if scheduling_ready is not None else 0

    hourly_profile = load_by_hour.groupby("hour")["mean_load_kw"].mean()
    peak_hour = int(hourly_profile.idxmax())
    low_hour = int(hourly_profile.idxmin())
    weekday_profile = load_by_weekday.groupby(["day_of_week", "day_name"])["mean_load_kw"].mean().reset_index()
    weekday_peak = weekday_profile.loc[weekday_profile["mean_load_kw"].idxmax()]

    lines = [
        "Step 04 exploratory analysis report",
        "=" * 36,
        "",
        "Input files used:",
        f"- {HOURLY_FILE}",
        f"- {CLEAN_SESSIONS_FILE} ({'found' if cleaned_sessions is not None else 'not found'})",
        f"- {SCHEDULING_READY_FILE} ({'found' if scheduling_ready is not None else 'not found'})",
        "",
        f"Hourly records: {len(hourly)}",
        f"Number of sites: {num_sites}",
        f"Timestamp range: {timestamp_min} to {timestamp_max}",
        f"Cleaned session count: {session_count}",
        f"Scheduling-ready session count: {scheduling_count}",
        "",
        "Main descriptive observations:",
        *(
            f"- {row.site_id}: mean {row.mean_load_kw:.2f} kW, median {row.median_load_kw:.2f} kW, "
            f"peak {row.max_load_kw:.2f} kW, missing hours {row.missing_hours_percentage:.2f}%."
            for row in hourly_summary.itertuples(index=False)
        ),
        f"- Highest average hour of day: {peak_hour}:00.",
        f"- Lowest average hour of day: {low_hour}:00.",
        f"- Highest average weekday: {weekday_peak['day_name']} (day_of_week={int(weekday_peak['day_of_week'])}).",
        *(
            f"- {row.day_type}: mean load {row.load_kw:.2f} kW."
            for row in weekend_summary.itertuples(index=False)
        ),
        "",
        "Peak load by site:",
        *(
            f"- {row.site_id}: {row.peak_load_kw:.2f} kW at {row.peak_timestamp}; "
            f"peak/mean ratio {row.peak_to_mean_ratio:.2f}."
            for row in peak_load.itertuples(index=False)
        ),
        "",
        "Daily and weekly patterns:",
        "- Average load varies by hour of day and by weekday, indicating temporal structure in demand.",
        "- Weekday/weekend average load differs, supporting calendar-based EDA and later calendar variables.",
        "",
        "Why calendar features are justified for later forecasting:",
        "- Hour of day, day of week, month, and weekend indicators capture recurring operational rhythms in EV charging demand.",
        "- These patterns should be validated in later model experiments rather than assumed as final predictive features here.",
        "",
        "Recommended next step:",
        "- Create the next numbered script for forecasting dataset preparation or time-based splitting. Do not train models or run scheduling optimization yet.",
        "",
    ]
    REPORT_FILE.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)

    if not HOURLY_FILE.exists():
        raise FileNotFoundError(f"Hourly processed file not found: {HOURLY_FILE}")

    hourly = pd.read_csv(HOURLY_FILE)
    required_columns = {"timestamp", "site_id", "load_kw", "load_kw_observed", "was_missing_hour", "source_file"}
    missing_columns = sorted(required_columns - set(hourly.columns))
    if missing_columns:
        raise ValueError(f"Hourly file is missing required columns: {missing_columns}")

    hourly = add_temporal_columns(hourly)
    hourly["load_kw"] = pd.to_numeric(hourly["load_kw"], errors="coerce")
    hourly["load_kw_observed"] = pd.to_numeric(hourly["load_kw_observed"], errors="coerce")
    hourly["was_missing_hour"] = hourly["was_missing_hour"].astype(bool)

    cleaned_sessions = load_sessions(CLEAN_SESSIONS_FILE)
    scheduling_ready = load_sessions(SCHEDULING_READY_FILE)

    hourly_summary = build_hourly_summary(hourly)
    load_by_hour = build_load_by_hour(hourly)
    load_by_weekday = build_load_by_weekday(hourly)
    session_summary = build_session_summary(cleaned_sessions, scheduling_ready)
    peak_load = build_peak_load(hourly)

    hourly_summary.to_csv(HOURLY_SUMMARY_FILE, index=False)
    load_by_hour.to_csv(LOAD_BY_HOUR_FILE, index=False)
    load_by_weekday.to_csv(LOAD_BY_WEEKDAY_FILE, index=False)
    session_summary.to_csv(SESSION_SUMMARY_FILE, index=False)
    peak_load.to_csv(PEAK_LOAD_FILE, index=False)

    save_timeseries_by_site(hourly, FIGURES_DIR / "04_fig1_hourly_load_timeseries_by_site.png")
    save_average_load_by_hour(load_by_hour, FIGURES_DIR / "04_fig2_average_load_by_hour.png")
    save_average_load_by_weekday(hourly, FIGURES_DIR / "04_fig3_average_load_by_weekday.png")
    if cleaned_sessions is not None and "session_duration_hours" in cleaned_sessions.columns:
        save_histogram(
            cleaned_sessions,
            "session_duration_hours",
            "Session duration (hours)",
            "Distribution of EV charging session duration",
            FIGURES_DIR / "04_fig4_session_duration_distribution.png",
        )
    if cleaned_sessions is not None and "energy_kwh" in cleaned_sessions.columns:
        save_histogram(
            cleaned_sessions,
            "energy_kwh",
            "Delivered energy (kWh)",
            "Distribution of delivered EV charging energy",
            FIGURES_DIR / "04_fig5_energy_distribution.png",
        )
    save_site_bar(
        peak_load,
        "peak_load_kw",
        "Peak load (kW)",
        "Peak hourly EV charging load by site",
        FIGURES_DIR / "04_fig6_peak_load_by_site.png",
    )
    save_site_bar(
        hourly_summary,
        "mean_load_kw",
        "Mean load (kW)",
        "Mean hourly EV charging load by site",
        FIGURES_DIR / "04_fig7_mean_load_by_site.png",
    )
    weekend_summary = save_weekend_vs_weekday(hourly, FIGURES_DIR / "04_fig8_weekend_vs_weekday_load.png")

    write_captions()
    write_report(
        hourly,
        cleaned_sessions,
        scheduling_ready,
        hourly_summary,
        load_by_hour,
        load_by_weekday,
        peak_load,
        weekend_summary,
    )

    result_files = sorted(path for path in RESULTS_DIR.iterdir() if path.is_file())
    figure_files = sorted(path for path in FIGURES_DIR.iterdir() if path.is_file())

    print("Step 04 exploratory analysis complete")
    print("=====================================")
    print(f"Hourly dataset shape: {hourly.shape}")
    print(f"Number of sites: {hourly['site_id'].nunique()}")
    print(f"Timestamp range: {hourly['timestamp'].min()} to {hourly['timestamp'].max()}")
    print(f"Session dataset shape: {cleaned_sessions.shape if cleaned_sessions is not None else 'not found'}")
    print("")
    print("Output result files:")
    for path in result_files:
        print(f"- {path}")
    print("")
    print("Output figure files:")
    for path in figure_files:
        print(f"- {path}")
    print("")
    print(f"EDA report: {REPORT_FILE}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(1)
