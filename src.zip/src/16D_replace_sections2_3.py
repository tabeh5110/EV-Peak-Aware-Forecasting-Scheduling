from __future__ import annotations

import hashlib
import shutil
from copy import deepcopy
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH


ROOT = Path(__file__).resolve().parents[1]
MAN_DIR = ROOT / "manuscript" / "16_reviewer_aware_final"
INPUT_DOCX = MAN_DIR / "16_final_reviewer_ready_manuscript_FIGURES_AND_SECTION4_FIXED.docx"
BACKUP_DOCX = MAN_DIR / "16_final_reviewer_ready_manuscript_BACKUP_before_sections2_3.docx"
OUTPUT_DOCX = MAN_DIR / "16_final_reviewer_ready_manuscript_SECTIONS2_3_UPDATED.docx"
REPORT_PATH = MAN_DIR / "sections2_3_update_report.txt"


def iter_body_blocks(doc: Document):
    for child in doc.element.body:
        if child.tag.endswith("}p") or child.tag.endswith("}tbl"):
            yield child


def block_text(block) -> str:
    if block.tag.endswith("}p"):
        return "".join(node.text or "" for node in block.iter() if node.tag.endswith("}t")).strip()
    rows = []
    for tr in block.iter():
        if tr.tag.endswith("}tr"):
            cells = []
            for tc in tr:
                if tc.tag.endswith("}tc"):
                    cells.append("".join(node.text or "" for node in tc.iter() if node.tag.endswith("}t")).strip())
            if cells:
                rows.append("|".join(cells))
    return "\n".join(rows)


def body_signature(blocks) -> str:
    text = "\n---BLOCK---\n".join(block_text(block) for block in blocks)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def find_block_index(blocks, heading: str) -> int:
    for idx, block in enumerate(blocks):
        if block_text(block) == heading:
            return idx
    raise ValueError(f"Could not find heading: {heading}")


def paragraph_has_image(paragraph) -> bool:
    return bool(paragraph._p.xpath(".//*[local-name()='drawing' or local-name()='pict']"))


def count_images_in_blocks(blocks) -> int:
    count = 0
    for block in blocks:
        count += len(block.xpath(".//*[local-name()='drawing' or local-name()='pict']"))
    return count


def find_figure2_image_element(doc: Document):
    for idx, paragraph in enumerate(doc.paragraphs):
        if paragraph.text.strip().startswith("Figure 2.") and idx > 0 and paragraph_has_image(doc.paragraphs[idx - 1]):
            return deepcopy(doc.paragraphs[idx - 1]._p)
    return None


def append_paragraph(doc: Document, text: str, style: str | None = None, bold: bool = False, center: bool = False):
    paragraph = doc.add_paragraph(style=style) if style else doc.add_paragraph()
    run = paragraph.add_run(text)
    run.bold = bold
    if center:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    return paragraph._element


def append_table(doc: Document, headers: list[str], rows: list[list[str]]):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    for idx, header in enumerate(headers):
        cell = table.rows[0].cells[idx]
        cell.text = header
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.bold = True
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for row in rows:
        cells = table.add_row().cells
        for idx, value in enumerate(row):
            cells[idx].text = value
    return table._element


def replacement_elements(doc: Document, figure2_image_element):
    items = []

    def p(text: str, style: str | None = None, bold: bool = False):
        items.append(append_paragraph(doc, text, style=style, bold=bold))

    def t(headers: list[str], rows: list[list[str]]):
        items.append(append_table(doc, headers, rows))

    p("2. Related Work", "Heading 1")
    p("2.1 EV Charging Load Forecasting", "Heading 2")
    p(
        "EV charging-load forecasting is difficult because charging demand depends on irregular user arrivals, "
        "parking duration, requested energy, workplace schedules, site-level usage patterns, and occasional peak "
        "events. Open datasets such as ACN-Data support detailed analysis of real EV charging sessions and "
        "aggregate charging behavior [1, 2]. Prior studies have applied statistical, machine-learning, "
        "deep-learning, and hybrid methods for EV charging-demand prediction [3, 4, 18–20, 28]. These studies "
        "show that EV charging demand contains both recurring temporal structure and stochastic user-driven "
        "variation, making accurate short-term forecasting difficult, especially during high-load periods."
    )
    p("2.2 Machine-Learning and Ensemble Forecasting Models", "Heading 2")
    p(
        "Tree-based ensemble models are strong baselines for structured forecasting problems because they can "
        "capture nonlinear relationships among lagged, calendar, and site-level features. XGBoost, LightGBM, "
        "and CatBoost are widely used benchmark models for tabular regression tasks [6–8]. Recent EV charging "
        "forecasting studies also show that ensemble and hybrid models can improve forecasting performance when "
        "charging behavior is nonlinear and site-dependent [17, 20, 27, 28]. In this paper, these models are used "
        "as strong comparators rather than as the main novelty. The proposed contribution is the E-AHPA and "
        "PRC-E-AHPA forecast-to-schedule framework, which connects average forecasting accuracy with peak-risk "
        "behavior and downstream scheduling needs."
    )
    p("2.3 Probabilistic and Uncertainty-Aware Forecasting", "Heading 2")
    p(
        "Point forecasts alone do not express uncertainty, which is a limitation for operational charging-site "
        "management. Probabilistic load forecasting provides information about possible future load ranges rather "
        "than only a single expected value [15]. Conformal prediction offers a practical calibration framework for "
        "predictive intervals [9, 10], while adaptive and asymmetric intervals are useful when error behavior "
        "changes across load regimes [11]. Recent EV charging-demand research has also emphasized the value of "
        "probabilistic forecasts for risk-aware energy and operational decisions [18]. This study follows that "
        "direction by using validation-calibrated conformal-style intervals as an upper-bound signal for "
        "uncertainty-aware scheduling."
    )
    p("2.4 EV Charging Scheduling and Load Management", "Heading 2")
    p(
        "EV charging scheduling aims to reduce peak load, limit capacity violations, and satisfy user charging "
        "requirements. Prior work has studied optimal charging, decentralized charging control, large-population "
        "EV control, and adaptive charging networks [2, 12–14]. These studies show that realistic charging control "
        "must consider arrival time, departure or deadline constraints, requested energy, charging-rate limits, and "
        "site capacity. Forecast-informed scheduling has also been studied as a way to connect short-term EV demand "
        "prediction with aggregate charging control [17]. This paper differs from simplified load-redistribution "
        "studies by evaluating scheduling under session-level feasibility constraints and by using both "
        "peak-sensitive forecasts and uncertainty-aware upper bounds."
    )
    p("2.5 Research Gap", "Heading 2")
    p(
        "Existing studies often focus on forecasting accuracy, probabilistic forecasting, or charging scheduling "
        "separately. Fewer studies integrate leakage-free forecasting, peak-risk-aware prediction, uncertainty "
        "calibration, and constrained scheduling in one framework. This paper addresses that gap by evaluating not "
        "only average error, but also peak-risk behavior and downstream scheduling usefulness."
    )

    p("3. Data Description and Preprocessing", "Heading 1")
    p("3.1 Dataset and Study Scope", "Heading 2")
    p(
        "The raw EV charging data used in this study were obtained from the publicly available Adaptive Charging "
        "Network dataset hosted by Caltech [1, 2]. The dataset contains real EV charging records that can be "
        "processed into hourly site-level load series and session-level scheduling inputs. Six charging sites are "
        "used for forecasting analysis, while session records are used where available for constrained scheduling "
        "evaluation."
    )
    p(
        "Table 1 summarizes the final modeling scope. The forecasting dataset contains 82,618 hourly load rows "
        "across six sites. After leakage-free feature construction and chronological splitting, 55,814 rows are "
        "used for training, 12,393 rows for validation, and 12,395 rows for testing. The final feature set contains "
        "114 modeling features."
    )
    p("Table 1. Dataset and modeling summary.", bold=True)
    t(
        ["Item", "Value"],
        [
            ["Hourly load rows", "82,618"],
            ["Charging sites", "6"],
            ["Timestamp range", "2018-05-10 04:00:00+00:00 to 2020-12-05 02:00:00+00:00"],
            ["Real session records", "12,645"],
            ["Scheduling-ready session records", "12,645"],
            ["Training rows", "55,814"],
            ["Validation rows", "12,393"],
            ["Test rows", "12,395"],
            ["Modeling features", "114"],
        ],
    )
    p(
        "Table 2 reports site-level coverage and scheduling-session availability. Only California_Garage_01 has "
        "observed real sessions available for the real/session-limited scheduling case study. For other forecast "
        "sites, synthetic empirical sessions are generated for scenario-based scalability analysis. These synthetic "
        "sessions are not treated as observed session-log validation."
    )
    p("Table 2. Site-level data summary.", bold=True)
    t(
        ["Site", "Hourly rows", "Mean load (kW)", "Peak load (kW)", "Missing rate (%)", "Real sessions", "Synthetic sessions"],
        [
            ["Arroyo_Garage_01", "4,038", "23.46", "177.41", "40.34", "No", "Yes"],
            ["California_Garage_01", "22,512", "14.21", "233.58", "25.66", "Yes", "No"],
            ["California_Garage_02", "17,713", "13.63", "206.33", "15.12", "No", "Yes"],
            ["N_Wilson_Garage_01", "8,816", "15.57", "1606.92*", "13.77", "No", "Yes"],
            ["Parking_Lot_01", "14,817", "1.75", "41.01", "70.24", "No", "Yes"],
            ["S_Wilson_Garage_01", "14,722", "2.64", "24.66", "40.49", "No", "Yes"],
        ],
    )
    p("*The N_Wilson_Garage_01 peak value must be retained only if confirmed by the raw/hourly-load audit.")
    if figure2_image_element is not None:
        items.append(figure2_image_element)
    p(
        "Figure 2. Exploratory EV charging load patterns across the study data. The figure summarizes temporal and "
        "site-level charging behavior used to motivate calendar-enhanced, site-aware, and peak-aware feature construction.",
        bold=True,
    )

    p("3.2 Data Cleaning and Chronological Splitting", "Heading 2")
    p(
        "The preprocessing pipeline converts raw charging records into site-level hourly load series and scheduling-ready "
        "session records. The hourly forecasting data are arranged chronologically and split into training, validation, "
        "and test periods without random shuffling. This protects the time order of the forecasting task and avoids "
        "leakage from future observations into training, feature construction, model selection, or calibration [16]. "
        "Lagged, rolling, exponentially weighted, and peak-memory variables are computed using past observations only. "
        "Model selection, peak-risk calibration, and prediction-interval calibration use validation data only, while "
        "final claims are evaluated on the held-out test period."
    )
    p("3.3 Real Session Coverage and Synthetic Scenario Motivation", "Heading 2")
    p(
        "Complete real session coverage is limited across the forecast sites. Therefore, the scheduling analysis is "
        "separated into a real/session-limited case study and a synthetic empirical multi-site scenario. The "
        "real/session-limited case uses available observed session constraints. The synthetic empirical scenario is "
        "used only for scalability analysis across all forecast sites. Synthetic sessions are generated from empirical "
        "real-session distributions and preserve realistic patterns such as arrival time, dwell time, requested energy, "
        "and weekday/weekend behavior, but they are not observed six-site session logs."
    )
    return items


def main() -> None:
    if not INPUT_DOCX.exists():
        raise FileNotFoundError(INPUT_DOCX)
    shutil.copy2(INPUT_DOCX, BACKUP_DOCX)

    doc = Document(INPUT_DOCX)
    figure_count_before = len(doc.inline_shapes)
    original_blocks = list(iter_body_blocks(doc))
    start_idx = find_block_index(original_blocks, "2. Related Work")
    section4_idx = find_block_index(original_blocks, "4. Methodology")
    before_sig = body_signature(original_blocks[:start_idx])
    after_sig = body_signature(original_blocks[section4_idx:])
    removed_image_count = count_images_in_blocks(original_blocks[start_idx:section4_idx])
    figure2_image = find_figure2_image_element(doc)

    for block in original_blocks[start_idx:section4_idx]:
        block.getparent().remove(block)

    refreshed_blocks = list(iter_body_blocks(doc))
    anchor_idx = find_block_index(refreshed_blocks, "4. Methodology")
    anchor = refreshed_blocks[anchor_idx]
    new_elements = replacement_elements(doc, figure2_image)
    body = doc.element.body
    for element in new_elements:
        if element.getparent() is body:
            body.remove(element)
        anchor.addprevious(element)

    doc.save(OUTPUT_DOCX)

    updated = Document(OUTPUT_DOCX)
    updated_blocks = list(iter_body_blocks(updated))
    new_start = find_block_index(updated_blocks, "2. Related Work")
    new_section3 = find_block_index(updated_blocks, "3. Data Description and Preprocessing")
    new_section4 = find_block_index(updated_blocks, "4. Methodology")
    outside_before_unchanged = body_signature(updated_blocks[:new_start]) == before_sig
    outside_after_unchanged = body_signature(updated_blocks[new_section4:]) == after_sig
    figure_count_after = len(updated.inline_shapes)
    section4_starts = block_text(updated_blocks[new_section4]) == "4. Methodology"
    section_tables = sum(1 for block in updated_blocks[new_start:new_section4] if block.tag.endswith("}tbl"))
    figure2_present = any(
        paragraph.text.strip().startswith("Figure 2.")
        for paragraph in updated.paragraphs
    )

    report = [
        "Sections 2-3 DOCX replacement report",
        "====================================",
        f"Input DOCX: {INPUT_DOCX}",
        f"Backup DOCX: {BACKUP_DOCX}",
        f"Updated DOCX: {OUTPUT_DOCX}",
        "",
        f"Section 2 was replaced: {'yes' if new_start < new_section3 else 'no'}",
        f"Section 3 was replaced: {'yes' if new_section3 < new_section4 else 'no'}",
        f"Section 4 still starts with '4. Methodology': {'yes' if section4_starts else 'no'}",
        f"Table 1 and Table 2 converted to real Word tables: {'yes' if section_tables == 2 else 'no'}",
        f"Word tables in replacement Sections 2-3: {section_tables}",
        f"All sections before Section 2 unchanged: {'yes' if outside_before_unchanged else 'no'}",
        f"All sections from Section 4 onward unchanged: {'yes' if outside_after_unchanged else 'no'}",
        f"All other sections were unchanged: {'yes' if outside_before_unchanged and outside_after_unchanged else 'no'}",
        f"Inline images before: {figure_count_before}",
        f"Inline images after: {figure_count_after}",
        f"Images found inside removed Sections 2-3: {removed_image_count}",
        f"Figure 2 image preserved: {'yes' if figure2_image is not None and figure_count_after == figure_count_before else 'no'}",
        f"Figure 2 caption present: {'yes' if figure2_present else 'no'}",
        f"No figure images were deleted: {'yes' if figure_count_after == figure_count_before else 'no'}",
    ]
    REPORT_PATH.write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))


if __name__ == "__main__":
    main()
