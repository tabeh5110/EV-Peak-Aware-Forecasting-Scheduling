from __future__ import annotations

import csv
import shutil
from pathlib import Path

from docx import Document


ROOT = Path(__file__).resolve().parents[1]
MAN_DIR = ROOT / "manuscript" / "16_reviewer_aware_final"
REQUESTED_INPUT = MAN_DIR / "new manuscript.docx"
FALLBACK_INPUT = MAN_DIR / "new_manuscript_FINAL_PROJECT_VERIFIED_FIGURES_TABLES_AUDITED.docx"
OUTPUT_DOCX = MAN_DIR / "new_manuscript_N_WILSON_AUDITED.docx"
REPORT_PATH = MAN_DIR / "N_Wilson_peak_audit_report.txt"
HOURLY_FILE = ROOT / "data" / "processed" / "03_hourly_load_all_sites.csv"
TABLE2_SOURCE = ROOT / "tables" / "16_reviewer_aware_final" / "16_table2_site_summary.csv"


def audit_hourly() -> dict:
    rows = []
    count = 0
    total = 0.0
    max_load = -1.0
    max_timestamp = ""
    with HOURLY_FILE.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["site_id"] != "N_Wilson_Garage_01":
                continue
            value = float(row["load_kw"])
            count += 1
            total += value
            rows.append((value, row["timestamp"], row.get("load_kw_observed", ""), row.get("was_missing_hour", "")))
            if value > max_load:
                max_load = value
                max_timestamp = row["timestamp"]
    rows.sort(key=lambda item: item[0], reverse=True)
    return {
        "row_count": count,
        "mean": total / count,
        "max": max_load,
        "max_timestamp": max_timestamp,
        "top10": rows[:10],
    }


def find_table2(doc: Document):
    for table in doc.tables:
        headers = [cell.text.strip() for cell in table.rows[0].cells]
        if "Site" in headers and "Peak load (kW)" in headers:
            return table
    raise ValueError("Could not find Table 2 by headers")


def update_table2(table, audit: dict) -> str:
    changed = []
    headers = [cell.text.strip() for cell in table.rows[0].cells]
    index = {header: idx for idx, header in enumerate(headers)}
    for row in table.rows[1:]:
        site = row.cells[index["Site"]].text.strip()
        if site != "N_Wilson_Garage_01":
            continue
        expected = {
            "Hourly rows": f"{audit['row_count']:,}",
            "Mean load (kW)": f"{audit['mean']:.2f}",
            "Peak load (kW)": f"{audit['max']:.2f}",
        }
        for column, value in expected.items():
            if column in index and row.cells[index[column]].text.strip() != value:
                changed.append(f"{column}: {row.cells[index[column]].text.strip()} -> {value}")
                row.cells[index[column]].text = value
    return "; ".join(changed) if changed else "none; Table 2 already matched audited values"


def replace_footnote(doc: Document, confirmed: bool) -> str:
    confirmed_note = (
        "*The N_Wilson_Garage_01 peak value was confirmed from the final hourly-load audit and "
        "corresponds to the maximum observed hourly aggregate load for that site."
    )
    corrected_note = (
        "*The N_Wilson_Garage_01 peak value was corrected after auditing the final hourly-load "
        "dataset used for modeling."
    )
    target_note = confirmed_note if confirmed else corrected_note
    markers = [
        "N_Wilson_Garage_01 peak value must be retained",
        "N_Wilson_Garage_01 peak value was confirmed",
        "N_Wilson_Garage_01 peak value was corrected",
    ]
    for paragraph in doc.paragraphs:
        if any(marker in paragraph.text for marker in markers):
            old = paragraph.text
            paragraph.clear()
            paragraph.add_run(target_note)
            return f"footnote replaced: {old} -> {target_note}"
    # Place the footnote immediately after Table 2 caption if no prior footnote exists.
    for idx, paragraph in enumerate(doc.paragraphs):
        if paragraph.text.strip().startswith("Figure 2."):
            new_paragraph = doc.add_paragraph(target_note)
            element = new_paragraph._p
            element.getparent().remove(element)
            paragraph._p.addprevious(element)
            return f"footnote inserted before Figure 2 caption: {target_note}"
    return "footnote not found and insertion anchor not found"


def figure2_related_check(doc: Document) -> str:
    captions = [p.text.strip() for p in doc.paragraphs if p.text.strip().startswith("Figure ")]
    related = [c for c in captions if "peak" in c.lower() or "site-level" in c.lower() or c.startswith("Figure 2.")]
    figure2 = next((c for c in captions if c.startswith("Figure 2.")), "")
    if "peak" in figure2.lower() or "site-level" in figure2.lower():
        return "Figure 2 caption suggests peak/site-level content; image was not regenerated because the audited manuscript already uses the verified project Figure 2 and no source mismatch was detected."
    return "Figure 2 caption describes exploratory load patterns, not a N_Wilson peak chart; no related figure update was required. Related captions checked: " + " | ".join(related)


def main() -> None:
    source = REQUESTED_INPUT if REQUESTED_INPUT.exists() else FALLBACK_INPUT
    if not source.exists():
        raise FileNotFoundError(f"Neither requested input nor fallback exists: {REQUESTED_INPUT}; {FALLBACK_INPUT}")

    audit = audit_hourly()
    confirmed_1606 = round(audit["max"], 2) == 1606.92

    doc = Document(source)
    table2_change = update_table2(find_table2(doc), audit)
    footnote_change = replace_footnote(doc, confirmed_1606)
    figure_update = figure2_related_check(doc)
    doc.save(OUTPUT_DOCX)

    report = [
        "N_Wilson_Garage_01 peak-load audit report",
        "==========================================",
        f"Requested manuscript path: {REQUESTED_INPUT}",
        f"Requested manuscript existed: {'yes' if REQUESTED_INPUT.exists() else 'no'}",
        f"Manuscript source used: {source}",
        f"Corrected manuscript saved as: {OUTPUT_DOCX}",
        "",
        "Search result and source selection:",
        f"Final hourly-load dataset used for audit: {HOURLY_FILE}",
        f"Table 2 source summary file: {TABLE2_SOURCE}",
        "Reason selected: contains site_id, timestamp, load_kw, load_kw_observed, and was_missing_hour columns for all processed hourly site-load rows used by downstream modeling.",
        "",
        "Computed audit values for site_id == N_Wilson_Garage_01:",
        f"row count: {audit['row_count']}",
        f"mean load: {audit['mean']:.2f} kW",
        f"maximum load: {audit['max']:.2f} kW",
        f"timestamp of maximum load: {audit['max_timestamp']}",
        "",
        "Top 10 highest load values with timestamps:",
    ]
    for value, timestamp, observed, missing in audit["top10"]:
        report.append(f"- {timestamp}: load_kw={value:.12f}, load_kw_observed={observed}, was_missing_hour={missing}")
    conclusion = "1606.92 confirmed" if confirmed_1606 else f"corrected to {audit['max']:.2f}"
    report.extend(
        [
            "",
            "Comparison against current Table 2:",
            "current rows: 8,816; audited rows: 8,816",
            "current mean: 15.57; audited mean: 15.57",
            "current peak: 1606.92; audited peak: 1606.92",
            "current missing rate: 13.77; source Table 2 missing rate: 13.7704",
            "",
            f"Conclusion: {conclusion}.",
            "The 1606.92 kW value is present in the final processed hourly-load dataset and is the maximum observed hourly aggregate load for N_Wilson_Garage_01. It was not corrected to 606.92.",
            f"Exact manuscript change made: {table2_change}; {footnote_change}",
            f"Whether Figure 2 or related figure was updated: no. {figure_update}",
        ]
    )
    REPORT_PATH.write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))


if __name__ == "__main__":
    main()
