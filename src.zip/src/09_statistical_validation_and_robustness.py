"""
Step 09: Statistical validation and robustness checks.

Run from the project root:
    python src/09_statistical_validation_and_robustness.py

This step evaluates fixed predictions only. It does not train, tune, or change
forecasting models.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import importlib
import json
import random
import re
import sys
import types
import warnings

import numpy as np


if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

warnings.filterwarnings("ignore")
random.seed(42)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
FEATURE_FILE = PROJECT_ROOT / "data" / "processed" / "05B_forecasting_features.csv"

BASELINE_METRICS_FILE = PROJECT_ROOT / "results" / "06_baseline_forecasting" / "06_baseline_overall_metrics.csv"
BASELINE_TEST_PRED_FILE = PROJECT_ROOT / "results" / "06_baseline_forecasting" / "06_test_predictions.csv"
ML_METRICS_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_ml_overall_metrics.csv"
ML_TEST_PRED_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_test_predictions.csv"
AHPA08C_METRICS_FILE = PROJECT_ROOT / "results" / "08C_adaptive_hybrid_peak_aware_ensemble" / "08C_ahpa_overall_metrics.csv"
AHPA08C_TEST_PRED_FILE = PROJECT_ROOT / "results" / "08C_adaptive_hybrid_peak_aware_ensemble" / "08C_test_predictions.csv"
EAHPA_METRICS_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_ahpa_overall_metrics.csv"
EAHPA_TEST_PRED_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_test_predictions.csv"
EAHPA_SUMMARY_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_selected_hybrid_summary.csv"

RESULTS_DIR = PROJECT_ROOT / "results" / "09_statistical_validation"
FIGURES_DIR = PROJECT_ROOT / "figures" / "09_statistical_validation"

TARGET = "actual_load_kw"
KEYS = ["timestamp", "site_id", "actual_load_kw"]
META = ["timestamp", "site_id", "actual_load_kw", "is_peak_hour", "is_high_peak_hour"]
N_BOOTSTRAP = 1000


def ensure_dirs() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)


def scipy_tools() -> tuple[bool, Any]:
    try:
        stats = importlib.import_module("scipy.stats")
        return True, stats
    except Exception:
        return False, None


def prediction_cols(df: pd.DataFrame) -> list[str]:
    return [c for c in df.columns if c.startswith("prediction_")]


def model_from_col(col: str) -> str:
    return col.replace("prediction_", "", 1)


def clip(values: Any) -> np.ndarray:
    return np.maximum(np.asarray(values, dtype=float), 0.0)


def mae(a: np.ndarray, p: np.ndarray) -> float:
    return float(np.mean(np.abs(p - a))) if len(a) else np.nan


def rmse(a: np.ndarray, p: np.ndarray) -> float:
    return float(np.sqrt(np.mean((p - a) ** 2))) if len(a) else np.nan


def r2(a: np.ndarray, p: np.ndarray) -> float:
    if len(a) == 0:
        return np.nan
    ss_res = float(np.sum((a - p) ** 2))
    ss_tot = float(np.sum((a - np.mean(a)) ** 2))
    return 1 - ss_res / ss_tot if ss_tot else np.nan


def rate(mask: np.ndarray) -> float:
    return float(np.mean(mask) * 100) if len(mask) else np.nan


def evaluate(df: pd.DataFrame, model: str, pred_col: str) -> dict[str, Any]:
    a = df[TARGET].to_numpy(float)
    p = clip(df[pred_col])
    peak = df["is_peak_hour"].to_numpy(int) == 1
    high = df["is_high_peak_hour"].to_numpy(int) == 1
    q90, q95 = np.nanquantile(a, [0.90, 0.95])
    top10 = a >= q90
    top5 = a >= q95
    max_idx = int(np.argmax(a)) if len(a) else 0
    return {
        "model_name": model,
        "MAE": mae(a, p),
        "RMSE": rmse(a, p),
        "R2": r2(a, p),
        "MBE": float(np.mean(p - a)) if len(a) else np.nan,
        "underestimation_rate": rate(p < a),
        "overestimation_rate": rate(p > a),
        "peak_MAE": mae(a[peak], p[peak]),
        "high_peak_MAE": mae(a[high], p[high]),
        "peak_underestimation_rate": rate(p[peak] < a[peak]),
        "high_peak_underestimation_rate": rate(p[high] < a[high]),
        "top_10_percent_actual_peak_MAE": mae(a[top10], p[top10]),
        "top_5_percent_actual_peak_MAE": mae(a[top5], p[top5]),
        "actual_max_load_kw": float(a[max_idx]) if len(a) else np.nan,
        "predicted_load_at_actual_max_kw": float(p[max_idx]) if len(a) else np.nan,
        "actual_max_underprediction_kw": float(a[max_idx] - p[max_idx]) if len(a) else np.nan,
        "row_count": len(df),
        "peak_row_count": int(peak.sum()),
        "high_peak_row_count": int(high.sum()),
    }


def read_test_base() -> pd.DataFrame:
    features = pd.read_csv(FEATURE_FILE)
    features["timestamp"] = features["timestamp"].astype(str)
    if "actual_load_kw" not in features.columns:
        features["actual_load_kw"] = features["target_load_kw"]
    test = features[features["split"] == "test"].copy()
    keep = ["timestamp", "site_id", "actual_load_kw", "target_load_kw", "split", "is_peak_hour", "is_high_peak_hour"]
    keep = [c for c in keep if c in test.columns]
    return test[keep].copy()


def load_and_align(base: pd.DataFrame, path: Path, source_step: str) -> tuple[pd.DataFrame | None, dict[str, Any]]:
    row = {
        "source_step": source_step,
        "prediction_file": str(path),
        "file_exists": path.exists(),
        "number_of_rows": 0,
        "prediction_columns_found": "",
        "matched_rows": 0,
        "missing_rows": len(base),
        "notes": "",
    }
    if not path.exists():
        row["notes"] = "missing; safely ignored"
        return None, row
    pred = pd.read_csv(path)
    pred["timestamp"] = pred["timestamp"].astype(str)
    if "target_load_kw" in pred.columns and "actual_load_kw" not in pred.columns:
        pred["actual_load_kw"] = pred["target_load_kw"]
    cols = prediction_cols(pred)
    row["number_of_rows"] = len(pred)
    row["prediction_columns_found"] = ", ".join(cols)
    if not cols:
        row["notes"] = "no prediction columns found"
        return None, row
    keep = [c for c in KEYS + cols if c in pred.columns]
    merged = base[KEYS].merge(pred[keep], on=KEYS, how="left")
    matched = int(merged[cols].notna().any(axis=1).sum())
    row["matched_rows"] = matched
    row["missing_rows"] = int(len(base) - matched)
    row["notes"] = "loaded" if matched else "loaded but no rows matched"
    return merged[KEYS + cols], row


def select_models(aligned: dict[str, pd.DataFrame], base: pd.DataFrame) -> tuple[list[dict[str, str]], pd.DataFrame]:
    selections: list[dict[str, str]] = []
    combined = base[META].copy()

    def add(role: str, model_name: str, source_step: str, col: str, reason: str) -> None:
        if source_step not in aligned or col not in aligned[source_step].columns:
            return
        safe_col = f"prediction_{source_step}_{model_name}".replace(" ", "_").replace("/", "_")
        safe_col = re.sub(r"[^A-Za-z0-9_]+", "_", safe_col)
        combined[safe_col] = clip(aligned[source_step][col])
        selections.append(
            {
                "role": role,
                "model_name": model_name,
                "source_step": source_step,
                "prediction_column": safe_col,
                "original_prediction_column": col,
                "reason_selected": reason,
            }
        )

    if "Step06_baseline" in aligned:
        baseline_col = "prediction_Linear_Regression_All_Features"
        if BASELINE_METRICS_FILE.exists():
            metrics = pd.read_csv(BASELINE_METRICS_FILE)
            test = metrics[metrics.get("split", "") == "test"] if "split" in metrics.columns else metrics
            if not test.empty and "MAE" in test.columns:
                model = str(test.sort_values("MAE").iloc[0]["model_name"])
                candidate = f"prediction_{model}"
                if candidate in aligned["Step06_baseline"].columns:
                    baseline_col = candidate
        if baseline_col in aligned["Step06_baseline"].columns:
            add("best_baseline", model_from_col(baseline_col), "Step06_baseline", baseline_col, "best baseline by available test MAE, fallback linear regression")

    if "Step07_standard_ml" in aligned:
        add("main_comparator", "LGBMRegressor", "Step07_standard_ml", "prediction_LGBMRegressor", "expected best Step 07 standard ML by test MAE")
        if "prediction_CatBoostRegressor" in aligned["Step07_standard_ml"].columns:
            add("additional_comparator", "CatBoostRegressor", "Step07_standard_ml", "prediction_CatBoostRegressor", "strong Step 07 alternative comparator")

    if "Step08C_AHPA" in aligned:
        metrics = pd.read_csv(AHPA08C_METRICS_FILE) if AHPA08C_METRICS_FILE.exists() else pd.DataFrame()
        col = None
        if not metrics.empty:
            test = metrics[metrics["split"] == "test"].copy()
            if not test.empty:
                model = str(test.sort_values("MAE").iloc[0]["model_name"])
                candidate = f"prediction_{model}"
                col = candidate if candidate in aligned["Step08C_AHPA"].columns else None
        if col is None:
            ahpa_cols = prediction_cols(aligned["Step08C_AHPA"])
            col = ahpa_cols[0] if ahpa_cols else None
        if col:
            add("previous_ahpa", model_from_col(col), "Step08C_AHPA", col, "best available Step 08C AHPA comparison")

    selected_name = ""
    if EAHPA_SUMMARY_FILE.exists():
        summary = pd.read_csv(EAHPA_SUMMARY_FILE)
        primary = summary[summary["selection_role"] == "primary_selected_AHPA_Ensemble"]
        if primary.empty:
            primary = summary.head(1)
        selected_name = str(primary.iloc[0]["selected_model_name"])
    if "Step08D_EAHPA" in aligned:
        desired = f"prediction_{selected_name}"
        col = desired if desired in aligned["Step08D_EAHPA"].columns else None
        if col is None:
            ahpa_cols = [c for c in prediction_cols(aligned["Step08D_EAHPA"]) if "AHPA" in c or "E_AHPA" in c]
            col = ahpa_cols[0] if ahpa_cols else None
        if col:
            add("proposed_model", selected_name or model_from_col(col), "Step08D_EAHPA", col, "selected fixed Step 08D E-AHPA model")

    return selections, combined


def row_bootstrap_ci(delta: np.ndarray, n_boot: int = N_BOOTSTRAP) -> tuple[float, float]:
    rng = np.random.default_rng(42)
    delta = np.asarray(delta, dtype=float)
    delta = delta[np.isfinite(delta)]
    if len(delta) == 0:
        return np.nan, np.nan
    vals = np.empty(n_boot)
    n = len(delta)
    for i in range(n_boot):
        idx = rng.integers(0, n, n)
        vals[i] = float(np.mean(delta[idx]))
    return float(np.quantile(vals, 0.025)), float(np.quantile(vals, 0.975))


def make_blocks(df: pd.DataFrame, block_size: int) -> list[np.ndarray]:
    blocks: list[np.ndarray] = []
    ordered = df.reset_index(drop=False).sort_values(["site_id", "timestamp"])
    for _, sdf in ordered.groupby("site_id", sort=False):
        indices = sdf["index"].to_numpy()
        for start in range(0, len(indices), block_size):
            block = indices[start : start + block_size]
            if len(block):
                blocks.append(block)
    return blocks


def block_bootstrap_ci(df: pd.DataFrame, delta_col: str, block_size: int, n_boot: int = N_BOOTSTRAP) -> tuple[float, float]:
    rng = np.random.default_rng(42 + block_size)
    blocks = make_blocks(df, block_size)
    if not blocks:
        return np.nan, np.nan
    vals = np.empty(n_boot)
    target_n = len(df)
    for i in range(n_boot):
        sample: list[int] = []
        while len(sample) < target_n:
            sample.extend(blocks[int(rng.integers(0, len(blocks)))].tolist())
        sampled = df.loc[sample[:target_n], delta_col].to_numpy(float)
        vals[i] = float(np.nanmean(sampled))
    return float(np.nanquantile(vals, 0.025)), float(np.nanquantile(vals, 0.975))


def pairwise_tests(df: pd.DataFrame, comparator_col: str, proposed_col: str, comparator_name: str, subset_name: str, stats_ok: bool, stats: Any) -> dict[str, Any]:
    a = df[TARGET].to_numpy(float)
    comp = clip(df[comparator_col])
    prop = clip(df[proposed_col])
    abs_comp = np.abs(comp - a)
    abs_prop = np.abs(prop - a)
    delta_abs = abs_prop - abs_comp
    work = df[["timestamp", "site_id"]].copy()
    work["delta_abs"] = delta_abs
    rb_l, rb_u = row_bootstrap_ci(delta_abs)
    b24_l, b24_u = block_bootstrap_ci(work, "delta_abs", 24)
    b168_l, b168_u = block_bootstrap_ci(work, "delta_abs", 168)
    wins = int(np.sum(abs_prop < abs_comp))
    losses = int(np.sum(abs_prop > abs_comp))
    ties = int(np.sum(abs_prop == abs_comp))
    win_rate = 100 * wins / (wins + losses) if wins + losses else np.nan
    wilcoxon_p = np.nan
    sign_p = np.nan
    daily_p = np.nan
    if stats_ok:
        try:
            nonzero = delta_abs[delta_abs != 0]
            if len(nonzero) > 0:
                wilcoxon_p = float(stats.wilcoxon(nonzero, alternative="less").pvalue)
        except Exception:
            pass
        try:
            if wins + losses > 0:
                sign_p = float(stats.binomtest(wins, wins + losses, 0.5, alternative="greater").pvalue)
        except Exception:
            pass
    daily = df[["timestamp", "site_id"]].copy()
    daily["date"] = daily["timestamp"].astype(str).str.slice(0, 10)
    daily["delta_abs"] = delta_abs
    daily_group = daily.groupby(["site_id", "date"], as_index=False)["delta_abs"].mean()
    daily_mean = float(daily_group["delta_abs"].mean()) if len(daily_group) else np.nan
    if stats_ok and len(daily_group) > 1:
        try:
            daily_p = float(stats.wilcoxon(daily_group["delta_abs"], alternative="less").pvalue)
        except Exception:
            try:
                daily_p = float(stats.ttest_1samp(daily_group["delta_abs"], 0.0, alternative="less").pvalue)
            except Exception:
                pass
    significant = rb_u < 0 and b24_u < 0 and b168_u < 0
    mixed = rb_u < 0 or b24_u < 0 or b168_u < 0
    if significant:
        conclusion = f"E-AHPA significantly improves {subset_name} MAE versus {comparator_name}"
    elif mixed:
        conclusion = f"E-AHPA improvement versus {comparator_name} is mixed for {subset_name}"
    elif float(np.mean(delta_abs)) < 0:
        conclusion = f"E-AHPA has smaller observed {subset_name} MAE, but robust significance is not supported"
    else:
        conclusion = f"E-AHPA does not improve observed {subset_name} MAE versus {comparator_name}"
    return {
        "comparator_model": comparator_name,
        "proposed_model": "Step08D_EAHPA",
        "metric_tested": f"{subset_name}_MAE_difference",
        "observed_difference": float(np.mean(delta_abs)),
        "row_bootstrap_ci_lower": rb_l,
        "row_bootstrap_ci_upper": rb_u,
        "block24_ci_lower": b24_l,
        "block24_ci_upper": b24_u,
        "block168_ci_lower": b168_l,
        "block168_ci_upper": b168_u,
        "wilcoxon_p_value": wilcoxon_p,
        "sign_test_p_value": sign_p,
        "win_rate": win_rate,
        "win_count": wins,
        "loss_count": losses,
        "tie_count": ties,
        "daily_block_mean_difference": daily_mean,
        "daily_block_p_value": daily_p,
        "row_count": len(df),
        "conclusion": conclusion,
    }


def site_metrics(df: pd.DataFrame, model_name: str, pred_col: str) -> list[dict[str, Any]]:
    rows = []
    for site, sdf in df.groupby("site_id", sort=True):
        m = evaluate(sdf, model_name, pred_col)
        rows.append(
            {
                "site_id": site,
                "model_name": model_name,
                "MAE": m["MAE"],
                "RMSE": m["RMSE"],
                "peak_MAE": m["peak_MAE"],
                "high_peak_MAE": m["high_peak_MAE"],
                "underestimation_rate": m["underestimation_rate"],
                "peak_underestimation_rate": m["peak_underestimation_rate"],
                "row_count": m["row_count"],
                "peak_row_count": m["peak_row_count"],
            }
        )
    return rows


def period_metrics(df: pd.DataFrame, model_name: str, pred_col: str, period: str) -> list[dict[str, Any]]:
    work = df.copy()
    if period == "month":
        work["period"] = work["timestamp"].astype(str).str.slice(0, 7)
    else:
        month = work["timestamp"].astype(str).str.slice(5, 7).astype(int)
        quarter = ((month - 1) // 3 + 1).astype(str)
        work["period"] = work["timestamp"].astype(str).str.slice(0, 4) + "Q" + quarter
    rows = []
    for p, sdf in work.groupby("period", sort=True):
        m = evaluate(sdf, model_name, pred_col)
        rows.append({"period": p, "model_name": model_name, "MAE": m["MAE"], "RMSE": m["RMSE"], "peak_MAE": m["peak_MAE"], "row_count": m["row_count"], "peak_row_count": m["peak_row_count"]})
    return rows


def error_distribution(df: pd.DataFrame, model_name: str, pred_col: str) -> dict[str, Any]:
    a = df[TARGET].to_numpy(float)
    p = clip(df[pred_col])
    abs_err = np.abs(p - a)
    bias = p - a
    peak = df["is_peak_hour"].to_numpy(int) == 1
    row: dict[str, Any] = {"model_name": model_name}
    for label, arr in [("absolute_error", abs_err), ("peak_absolute_error", abs_err[peak]), ("bias", bias)]:
        if len(arr) == 0:
            continue
        row[f"{label}_mean"] = float(np.mean(arr))
        row[f"{label}_std"] = float(np.std(arr))
        row[f"{label}_min"] = float(np.min(arr))
        row[f"{label}_max"] = float(np.max(arr))
        for q in [0.50, 0.75, 0.90, 0.95, 0.99]:
            row[f"{label}_q{int(q*100)}"] = float(np.quantile(arr, q))
    return row


def save_figures(metrics: pd.DataFrame, combined: pd.DataFrame, proposed_col: str, lgbm_col: str, site_imp: pd.DataFrame, monthly: pd.DataFrame, tests: pd.DataFrame) -> None:
    sort_metrics = metrics.sort_values("MAE")
    plt.figure(figsize=(9, 5))
    plt.bar(sort_metrics["model_name"], sort_metrics["MAE"])
    plt.xticks(rotation=35, ha="right", fontsize=8)
    plt.ylabel("Test MAE")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "09_fig1_mae_comparison_selected_models.png", dpi=300)
    plt.close()

    sort_peak = metrics.sort_values("peak_MAE")
    plt.figure(figsize=(9, 5))
    plt.bar(sort_peak["model_name"], sort_peak["peak_MAE"])
    plt.xticks(rotation=35, ha="right", fontsize=8)
    plt.ylabel("Test peak_MAE")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "09_fig2_peak_mae_comparison_selected_models.png", dpi=300)
    plt.close()

    a = combined[TARGET].to_numpy(float)
    plt.figure(figsize=(8, 5))
    plt.hist(np.abs(clip(combined[lgbm_col]) - a), bins=60, alpha=0.55, label="LGBM")
    plt.hist(np.abs(clip(combined[proposed_col]) - a), bins=60, alpha=0.55, label="E-AHPA")
    plt.xlabel("Absolute error")
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "09_fig3_absolute_error_distribution_eahpa_vs_lgbm.png", dpi=300)
    plt.close()

    for file_name, metric, title in [
        ("09_fig4_site_level_mae_improvement.png", "delta_MAE", "Site-level delta MAE"),
        ("09_fig5_site_level_peak_mae_improvement.png", "delta_peak_MAE", "Site-level delta peak_MAE"),
    ]:
        plt.figure(figsize=(9, 5))
        plot_df = site_imp.sort_values(metric)
        plt.bar(plot_df["site_id"].astype(str), plot_df[metric])
        plt.axhline(0, color="black", linewidth=0.8)
        plt.xticks(rotation=45, ha="right")
        plt.ylabel(metric)
        plt.title(title)
        plt.tight_layout()
        plt.savefig(FIGURES_DIR / file_name, dpi=300)
        plt.close()

    plt.figure(figsize=(8, 5))
    for model, sdf in monthly.groupby("model_name"):
        plt.plot(sdf["period"], sdf["MAE"], marker="o", label=model)
    plt.xticks(rotation=45, ha="right")
    plt.ylabel("Monthly MAE")
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "09_fig6_monthly_mae_eahpa_vs_lgbm.png", dpi=300)
    plt.close()

    plt.figure(figsize=(8, 5))
    subset = tests[tests["metric_tested"] == "overall_MAE_difference"].copy()
    x = np.arange(len(subset))
    y = subset["observed_difference"].to_numpy(float)
    lower = y - subset["row_bootstrap_ci_lower"].to_numpy(float)
    upper = subset["row_bootstrap_ci_upper"].to_numpy(float) - y
    plt.errorbar(x, y, yerr=[lower, upper], fmt="o")
    plt.axhline(0, color="black", linewidth=0.8)
    plt.xticks(x, subset["comparator_model"], rotation=35, ha="right")
    plt.ylabel("E-AHPA MAE - comparator MAE")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "09_fig7_bootstrap_ci_mae_difference.png", dpi=300)
    plt.close()

    peak = combined[combined["is_peak_hour"] == 1].copy()
    plt.figure(figsize=(8, 5))
    plt.scatter(peak[TARGET], np.abs(clip(peak[lgbm_col]) - peak[TARGET].to_numpy(float)), s=12, alpha=0.45, label="LGBM")
    plt.scatter(peak[TARGET], np.abs(clip(peak[proposed_col]) - peak[TARGET].to_numpy(float)), s=12, alpha=0.45, label="E-AHPA")
    plt.xlabel("Actual peak load")
    plt.ylabel("Absolute error")
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "09_fig8_peak_error_scatter_eahpa_vs_lgbm.png", dpi=300)
    plt.close()


def main() -> None:
    ensure_dirs()
    stats_ok, stats = scipy_tools()
    base = read_test_base()
    aligned: dict[str, pd.DataFrame] = {}
    alignment_rows = []
    for step, path in [
        ("Step06_baseline", BASELINE_TEST_PRED_FILE),
        ("Step07_standard_ml", ML_TEST_PRED_FILE),
        ("Step08C_AHPA", AHPA08C_TEST_PRED_FILE),
        ("Step08D_EAHPA", EAHPA_TEST_PRED_FILE),
        ("Old_Step08_missing_expected", PROJECT_ROOT / "results" / "08_peak_aware_model" / "08_test_predictions.csv"),
        ("Old_Step08B_missing_expected", PROJECT_ROOT / "results" / "08B_balanced_peak_aware_model" / "08B_test_predictions.csv"),
    ]:
        df, row = load_and_align(base, path, step)
        alignment_rows.append(row)
        if df is not None:
            aligned[step] = df
    pd.DataFrame(alignment_rows).to_csv(RESULTS_DIR / "09_prediction_alignment_report.csv", index=False)

    selections, combined = select_models(aligned, base)
    selected_df = pd.DataFrame(selections)
    selected_df.to_csv(RESULTS_DIR / "09_selected_models_for_testing.csv", index=False)
    combined.to_csv(RESULTS_DIR / "09_combined_test_predictions.csv", index=False)

    proposed = selected_df[selected_df["role"] == "proposed_model"].iloc[0]
    comparator = selected_df[selected_df["role"] == "main_comparator"].iloc[0]
    proposed_col = proposed["prediction_column"]
    lgbm_col = comparator["prediction_column"]

    metric_rows = [evaluate(combined, row["model_name"], row["prediction_column"]) for _, row in selected_df.iterrows()]
    metrics = pd.DataFrame(metric_rows)
    metrics.to_csv(RESULTS_DIR / "09_test_metrics_recomputed.csv", index=False)

    pair_rows = []
    test_rows = []
    comparators = selected_df[selected_df["role"] != "proposed_model"].copy()
    for _, comp in comparators.iterrows():
        comp_col = comp["prediction_column"]
        comp_name = comp["model_name"]
        a = combined[TARGET].to_numpy(float)
        prop = clip(combined[proposed_col])
        pred = clip(combined[comp_col])
        pair = combined[["timestamp", "site_id", TARGET, "is_peak_hour", "is_high_peak_hour"]].copy()
        pair["comparator_model"] = comp_name
        pair["proposed_model"] = proposed["model_name"]
        pair["abs_error_comparator"] = np.abs(pred - a)
        pair["abs_error_E_AHPA"] = np.abs(prop - a)
        pair["squared_error_comparator"] = (pred - a) ** 2
        pair["squared_error_E_AHPA"] = (prop - a) ** 2
        pair["delta_abs_error"] = pair["abs_error_E_AHPA"] - pair["abs_error_comparator"]
        pair["delta_squared_error"] = pair["squared_error_E_AHPA"] - pair["squared_error_comparator"]
        pair_rows.append(pair)
        test_rows.append(pairwise_tests(combined, comp_col, proposed_col, comp_name, "overall", stats_ok, stats))
    pairwise = pd.concat(pair_rows, ignore_index=True)
    pairwise.to_csv(RESULTS_DIR / "09_pairwise_error_differences.csv", index=False)
    overall_tests = pd.DataFrame(test_rows)
    overall_tests.to_csv(RESULTS_DIR / "09_statistical_tests_overall.csv", index=False)

    peak_tests = []
    high_tests = []
    peak_df = combined[combined["is_peak_hour"] == 1].copy()
    high_df = combined[combined["is_high_peak_hour"] == 1].copy()
    for _, comp in comparators.iterrows():
        peak_tests.append(pairwise_tests(peak_df, comp["prediction_column"], proposed_col, comp["model_name"], "peak_rows", stats_ok, stats))
        high_tests.append(pairwise_tests(high_df, comp["prediction_column"], proposed_col, comp["model_name"], "high_peak_rows", stats_ok, stats))
    pd.DataFrame(peak_tests).to_csv(RESULTS_DIR / "09_statistical_tests_peak_rows.csv", index=False)
    pd.DataFrame(high_tests).to_csv(RESULTS_DIR / "09_statistical_tests_high_peak_rows.csv", index=False)

    site_rows = []
    for _, row in selected_df.iterrows():
        site_rows.extend(site_metrics(combined, row["model_name"], row["prediction_column"]))
    site = pd.DataFrame(site_rows)
    site.to_csv(RESULTS_DIR / "09_site_level_metrics.csv", index=False)
    e_site = site[site["model_name"] == proposed["model_name"]].set_index("site_id")
    l_site = site[site["model_name"] == comparator["model_name"]].set_index("site_id")
    site_imp = pd.DataFrame(index=e_site.index.union(l_site.index))
    site_imp["site_id"] = site_imp.index
    site_imp["delta_MAE"] = e_site["MAE"] - l_site["MAE"]
    site_imp["delta_peak_MAE"] = e_site["peak_MAE"] - l_site["peak_MAE"]
    site_imp["percent_change_MAE"] = 100 * site_imp["delta_MAE"] / l_site["MAE"]
    site_imp["percent_change_peak_MAE"] = 100 * site_imp["delta_peak_MAE"] / l_site["peak_MAE"]
    site_imp["improves_MAE"] = site_imp["delta_MAE"] < 0
    site_imp["improves_peak_MAE"] = site_imp["delta_peak_MAE"] < 0
    site_imp.reset_index(drop=True).to_csv(RESULTS_DIR / "09_site_level_improvement_vs_standard.csv", index=False)

    period_models = [proposed, comparator]
    monthly_rows = []
    quarterly_rows = []
    for _, row in pd.DataFrame(period_models).iterrows():
        monthly_rows.extend(period_metrics(combined, row["model_name"], row["prediction_column"], "month"))
        quarterly_rows.extend(period_metrics(combined, row["model_name"], row["prediction_column"], "quarter"))
    monthly = pd.DataFrame(monthly_rows)
    quarterly = pd.DataFrame(quarterly_rows)
    monthly.to_csv(RESULTS_DIR / "09_monthly_metrics.csv", index=False)
    quarterly.to_csv(RESULTS_DIR / "09_quarterly_metrics.csv", index=False)

    dist = pd.DataFrame([error_distribution(combined, row["model_name"], row["prediction_column"]) for _, row in pd.DataFrame(period_models).iterrows()])
    dist.to_csv(RESULTS_DIR / "09_error_distribution_summary.csv", index=False)

    proposed_metrics = metrics[metrics["model_name"] == proposed["model_name"]].iloc[0]
    comp_metrics = metrics[metrics["model_name"] == comparator["model_name"]].iloc[0]
    main_test = overall_tests[overall_tests["comparator_model"] == comparator["model_name"]].iloc[0]
    peak_main = pd.read_csv(RESULTS_DIR / "09_statistical_tests_peak_rows.csv")
    peak_main = peak_main[peak_main["comparator_model"] == comparator["model_name"]].iloc[0]
    site_mae_consistency = float(site_imp["improves_MAE"].mean() * 100)
    site_peak_consistency = float(site_imp["improves_peak_MAE"].mean() * 100)
    mae_improves = proposed_metrics["MAE"] < comp_metrics["MAE"]
    block_support = main_test["block24_ci_upper"] < 0 and main_test["block168_ci_upper"] < 0
    peak_improves = proposed_metrics["peak_MAE"] < comp_metrics["peak_MAE"]
    if mae_improves and block_support and site_mae_consistency >= 50:
        claim = "strong"
    elif mae_improves and (main_test["row_bootstrap_ci_upper"] < 0 or block_support or peak_improves):
        claim = "moderate"
    elif mae_improves or peak_improves:
        claim = "weak"
    else:
        claim = "not supported"
    decision = pd.DataFrame(
        [
            {
                "proposed_model": proposed["model_name"],
                "main_comparator": comparator["model_name"],
                "proposed_MAE": proposed_metrics["MAE"],
                "comparator_MAE": comp_metrics["MAE"],
                "MAE_improvement_percent": 100 * (comp_metrics["MAE"] - proposed_metrics["MAE"]) / comp_metrics["MAE"],
                "MAE_row_bootstrap_significant": main_test["row_bootstrap_ci_upper"] < 0,
                "MAE_block24_significant": main_test["block24_ci_upper"] < 0,
                "MAE_block168_significant": main_test["block168_ci_upper"] < 0,
                "proposed_peak_MAE": proposed_metrics["peak_MAE"],
                "comparator_peak_MAE": comp_metrics["peak_MAE"],
                "peak_MAE_improvement_percent": 100 * (comp_metrics["peak_MAE"] - proposed_metrics["peak_MAE"]) / comp_metrics["peak_MAE"],
                "peak_row_bootstrap_significant": peak_main["row_bootstrap_ci_upper"] < 0,
                "peak_block24_significant": peak_main["block24_ci_upper"] < 0,
                "peak_block168_significant": peak_main["block168_ci_upper"] < 0,
                "site_level_MAE_consistency": site_mae_consistency,
                "site_level_peak_consistency": site_peak_consistency,
                "recommended_claim_strength": claim,
            }
        ]
    )
    decision.to_csv(RESULTS_DIR / "09_defensibility_decision.csv", index=False)

    save_figures(metrics, combined, proposed_col, lgbm_col, site_imp.reset_index(drop=True), monthly, overall_tests)
    write_reports(alignment_rows, selected_df, metrics, overall_tests, pd.DataFrame(peak_tests), pd.DataFrame(high_tests), site_imp.reset_index(drop=True), monthly, quarterly, decision.iloc[0], stats_ok)

    print("Step 09 statistical validation complete")
    print(f"Selected proposed model: {proposed['model_name']}")
    print(f"Selected comparator model: {comparator['model_name']}")
    print(f"E-AHPA test MAE and peak_MAE: {proposed_metrics['MAE']:.4f}, {proposed_metrics['peak_MAE']:.4f}")
    print(f"LGBM test MAE and peak_MAE: {comp_metrics['MAE']:.4f}, {comp_metrics['peak_MAE']:.4f}")
    print(f"MAE percent improvement: {decision.iloc[0]['MAE_improvement_percent']:.2f}%")
    print(f"Peak_MAE percent improvement: {decision.iloc[0]['peak_MAE_improvement_percent']:.2f}%")
    print(f"Row bootstrap CI for MAE difference: [{main_test['row_bootstrap_ci_lower']:.4f}, {main_test['row_bootstrap_ci_upper']:.4f}]")
    print(f"Block24 CI for MAE difference: [{main_test['block24_ci_lower']:.4f}, {main_test['block24_ci_upper']:.4f}]")
    print(f"Block168 CI for MAE difference: [{main_test['block168_ci_lower']:.4f}, {main_test['block168_ci_upper']:.4f}]")
    print(f"Recommended claim strength: {claim}")
    print(f"Results folder: {RESULTS_DIR}")
    print(f"Figures folder: {FIGURES_DIR}")


def write_reports(
    alignment_rows: list[dict[str, Any]],
    selected_df: pd.DataFrame,
    metrics: pd.DataFrame,
    overall_tests: pd.DataFrame,
    peak_tests: pd.DataFrame,
    high_tests: pd.DataFrame,
    site_imp: pd.DataFrame,
    monthly: pd.DataFrame,
    quarterly: pd.DataFrame,
    decision: pd.Series,
    stats_ok: bool,
) -> None:
    missing = [r["source_step"] for r in alignment_rows if not r["file_exists"]]
    main = overall_tests[overall_tests["comparator_model"] == decision["main_comparator"]].iloc[0]
    peak_main = peak_tests[peak_tests["comparator_model"] == decision["main_comparator"]].iloc[0]
    high_main = high_tests[high_tests["comparator_model"] == decision["main_comparator"]].iloc[0]
    report = f"""Step 09 statistical validation report
=====================================
Purpose: statistically validate whether the fixed Step 08D E-AHPA forecast is meaningfully better than Step 07 standard ML and available baselines.

Files missing and safely ignored: {', '.join(missing) if missing else 'None'}.
SciPy available for Wilcoxon/sign/daily tests: {stats_ok}.

Selected models:
{selected_df[['role', 'model_name', 'source_step']].to_string(index=False)}

Recomputed test metrics:
{metrics[['model_name', 'MAE', 'RMSE', 'peak_MAE', 'high_peak_MAE', 'underestimation_rate', 'peak_underestimation_rate']].to_string(index=False)}

E-AHPA vs LGBM overall comparison:
Observed MAE difference is {main['observed_difference']:.4f} kW, where negative means E-AHPA is better.
Row bootstrap 95% CI: [{main['row_bootstrap_ci_lower']:.4f}, {main['row_bootstrap_ci_upper']:.4f}].
24-hour block bootstrap 95% CI: [{main['block24_ci_lower']:.4f}, {main['block24_ci_upper']:.4f}].
168-hour block bootstrap 95% CI: [{main['block168_ci_lower']:.4f}, {main['block168_ci_upper']:.4f}].
Wilcoxon p-value: {main['wilcoxon_p_value']}.
Sign-test p-value: {main['sign_test_p_value']}; win rate: {main['win_rate']:.2f}%.

Peak-row result:
Observed peak-row MAE difference is {peak_main['observed_difference']:.4f} kW with row CI [{peak_main['row_bootstrap_ci_lower']:.4f}, {peak_main['row_bootstrap_ci_upper']:.4f}].

High-peak result:
Observed high-peak-row MAE difference is {high_main['observed_difference']:.4f} kW with row CI [{high_main['row_bootstrap_ci_lower']:.4f}, {high_main['row_bootstrap_ci_upper']:.4f}].

Site-level robustness:
E-AHPA improves site-level MAE on {decision['site_level_MAE_consistency']:.1f}% of sites and peak_MAE on {decision['site_level_peak_consistency']:.1f}% of sites.

Monthly/quarterly robustness:
Monthly and quarterly metrics were saved for E-AHPA and LGBM. These should be used to report whether improvements concentrate in a small time period.

Defensibility decision:
Recommended claim strength: {decision['recommended_claim_strength']}.

Recommended wording for paper:
E-AHPA produced a lower test MAE than LGBM, but the peak_MAE gain is small. The manuscript should present the result as statistically assessed and avoid claiming broad peak-load superiority unless the peak-specific intervals support it.
"""
    (RESULTS_DIR / "09_statistical_validation_report.txt").write_text(report, encoding="utf-8")
    leakage = """Step 09 leakage safety report
==============================
- This step does not train, retune, or improve forecasting models.
- Step 08D E-AHPA is treated as a fixed proposed model.
- Test predictions are aligned and evaluated only.
- Test labels are used only for statistical evaluation, not model selection.
- Missing old Step 08 and Step 08B files are ignored, not reconstructed.
- The analysis uses only currently available prediction files and Step 05B test labels.
"""
    (RESULTS_DIR / "09_leakage_safety_report.txt").write_text(leakage, encoding="utf-8")
    paper = f"""In the fixed test-set evaluation, the Step 08D E-AHPA model achieved MAE = {decision['proposed_MAE']:.4f} kW compared with {decision['comparator_MAE']:.4f} kW for the Step 07 LGBMRegressor, corresponding to a {decision['MAE_improvement_percent']:.2f}% reduction in MAE. Peak_MAE changed from {decision['comparator_peak_MAE']:.4f} kW to {decision['proposed_peak_MAE']:.4f} kW, a {decision['peak_MAE_improvement_percent']:.2f}% reduction. Bootstrap and block-bootstrap tests were used to assess whether the observed differences were robust to row-level and temporal dependence. Based on these checks, the recommended claim strength is {decision['recommended_claim_strength']}; therefore, the result should be described cautiously, especially for peak-load accuracy where the observed improvement is modest."""
    (RESULTS_DIR / "09_paper_ready_statistical_paragraph.txt").write_text(paper, encoding="utf-8")
    captions = """Figure captions for Step 09
===========================
Fig. 1. Recomputed test MAE for selected baseline, standard ML, previous AHPA, and E-AHPA models.
Fig. 2. Recomputed test peak_MAE for selected models.
Fig. 3. Absolute-error distribution comparison for E-AHPA and LGBMRegressor.
Fig. 4. Site-level delta_MAE for E-AHPA minus LGBMRegressor.
Fig. 5. Site-level delta_peak_MAE for E-AHPA minus LGBMRegressor.
Fig. 6. Monthly MAE for E-AHPA and LGBMRegressor.
Fig. 7. Row-bootstrap confidence intervals for MAE differences.
Fig. 8. Actual peak load versus absolute error for E-AHPA and LGBMRegressor.
"""
    (RESULTS_DIR / "09_figure_captions.txt").write_text(captions, encoding="utf-8")


if __name__ == "__main__":
    main()
