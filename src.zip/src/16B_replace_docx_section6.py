from __future__ import annotations

import hashlib
import shutil
from copy import deepcopy
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH


ROOT = Path(__file__).resolve().parents[1]
MAN_DIR = ROOT / "manuscript" / "16_reviewer_aware_final"
SOURCE_DOCX = MAN_DIR / "16_final_reviewer_ready_manuscript.docx"
BACKUP_DOCX = MAN_DIR / "16_final_reviewer_ready_manuscript_BACKUP_before_section6.docx"
UPDATED_DOCX = MAN_DIR / "16_final_reviewer_ready_manuscript_SECTION6_UPDATED.docx"
REPORT_PATH = MAN_DIR / "16_section6_update_report.txt"


def iter_body_blocks(doc: Document):
    for child in doc.element.body:
        if child.tag.endswith("}p") or child.tag.endswith("}tbl"):
            yield child


def block_text(block) -> str:
    if block.tag.endswith("}p"):
        return "".join(node.text or "" for node in block.iter() if node.tag.endswith("}t")).strip()
    rows = []
    for tr in block.iter():
        if tr.tag.endswith("}tr"):
            cells = []
            for tc in tr:
                if tc.tag.endswith("}tc"):
                    cells.append("".join(node.text or "" for node in tc.iter() if node.tag.endswith("}t")).strip())
            if cells:
                rows.append("|".join(cells))
    return "\n".join(rows)


def body_signature(blocks) -> str:
    text = "\n---BLOCK---\n".join(block_text(block) for block in blocks)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def find_block_index(blocks, heading: str) -> int:
    for idx, block in enumerate(blocks):
        if block_text(block) == heading:
            return idx
    raise ValueError(f"Could not find heading: {heading}")


def append_paragraph(doc: Document, text: str, style: str | None = None, bold: bool = False):
    paragraph = doc.add_paragraph(style=style) if style else doc.add_paragraph()
    run = paragraph.add_run(text)
    run.bold = bold
    return paragraph._element


def append_table(doc: Document, headers: list[str], rows: list[list[str]]):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    header_cells = table.rows[0].cells
    for idx, header in enumerate(headers):
        header_cells[idx].text = header
        for paragraph in header_cells[idx].paragraphs:
            for run in paragraph.runs:
                run.bold = True
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for row in rows:
        cells = table.add_row().cells
        for idx, value in enumerate(row):
            cells[idx].text = value
    return table._element


def section6_elements(doc: Document):
    items = []

    def p(text: str, style: str | None = None, bold: bool = False):
        items.append(append_paragraph(doc, text, style=style, bold=bold))

    def t(headers: list[str], rows: list[list[str]]):
        items.append(append_table(doc, headers, rows))

    p("6. Results", "Heading 1")
    p("6.1 Forecasting and Statistical Validation", "Heading 2")
    p(
        "Table 4 compares the final forecasting models under the same chronological test protocol. "
        "The table separates the standard machine-learning benchmarks from E-AHPA, which is the main "
        "proposed forecasting model, and PRC-E-AHPA, which is retained as the peak-risk calibrated operational variant."
    )
    p(
        "Table 4. Forecasting performance comparison on the held-out test set. E-AHPA is the main proposed "
        "forecasting model, while PRC-E-AHPA is retained as the peak-risk calibrated operational variant. "
        "MAE, RMSE, R², peak_MAE, high_peak_MAE, and underestimation rate are reported using the same chronological test period.",
        bold=True,
    )
    t(
        ["Model", "Category", "MAE", "RMSE", "R²", "Peak_MAE", "High_peak_MAE", "Underestimation rate (%)"],
        [
            ["Linear Regression", "Baseline", "4.5397", "10.2296", "0.5789", "20.0637", "29.6880", "18.53"],
            ["LGBMRegressor", "Standard ML", "4.3504", "10.7040", "0.5389", "18.9936", "28.4912", "21.51"],
            ["CatBoostRegressor", "Standard ML", "4.3617", "10.4110", "0.5638", "18.9985", "28.0392", "21.24"],
            ["E-AHPA", "Proposed main", "4.1909", "9.9061", "0.6051", "18.8912", "28.0026", "18.90"],
            ["PRC-E-AHPA", "Operational variant", "4.2179", "9.9398", "0.6024", "18.5486", "27.2268", "18.55"],
        ],
    )
    p(
        "E-AHPA achieves the lowest overall MAE among the final compared models, improving MAE from 4.3504 "
        "for LGBM to 4.1909. PRC-E-AHPA slightly increases average MAE relative to E-AHPA but reduces "
        "peak_MAE and high_peak_MAE. This supports the use of E-AHPA as the main forecasting model and "
        "PRC-E-AHPA as the peak-sensitive operational forecast."
    )
    p(
        "Figure 3. Forecasting model comparison on the chronological test set. E-AHPA achieves the lowest "
        "overall MAE among the final compared models, while PRC-E-AHPA provides a peak-risk calibrated "
        "operational variant for scheduling.",
        bold=True,
    )
    p(
        "Table 5 reports paired statistical comparisons. The strongest supported result is the overall MAE "
        "improvement of E-AHPA over LGBM. Peak-row improvements are interpreted more cautiously because some "
        "confidence intervals overlap zero."
    )
    p(
        "Table 5. Statistical validation summary for final forecasting comparisons. Negative MAE differences "
        "indicate improvement over the comparator. Empty block-bootstrap entries for peak-row comparisons are "
        "not shown because they were not available in the summary output.",
        bold=True,
    )
    t(
        ["Comparison", "Evaluation subset", "Observed MAE difference", "Row bootstrap CI", "Block bootstrap CI", "Statistical tests", "Interpretation"],
        [
            ["E-AHPA vs LGBMRegressor", "Overall", "-0.1595", "[-0.228, -0.094]", "24h [-0.243, -0.086]; 168h [-0.258, -0.073]", "Wilcoxon < 0.0001; sign < 0.0001", "Overall improvement supported"],
            ["PRC-E-AHPA vs LGBMRegressor", "Overall", "-0.1324", "[-0.203, -0.068]", "24h [-0.214, -0.061]; 168h [-0.223, -0.053]", "Wilcoxon < 0.0001; sign < 0.0001", "Overall improvement supported"],
            ["PRC-E-AHPA vs E-AHPA", "Overall", "0.0271", "[0.017, 0.038]", "24h [0.015, 0.038]; 168h [0.014, 0.044]", "Wilcoxon = 1.0000; sign = 1.0000", "PRC trades small average-error loss for peak-risk behavior"],
            ["PRC-E-AHPA vs CatBoostRegressor", "Overall", "-0.1437", "[-0.197, -0.093]", "24h [-0.208, -0.089]; 168h [-0.226, -0.070]", "Wilcoxon < 0.0001; sign < 0.0001", "Overall improvement supported"],
            ["E-AHPA vs LGBMRegressor", "Peak rows", "-0.1024", "[-0.707, 0.371]", "Not available", "Wilcoxon = 0.4389; sign = 0.1008", "Peak-row improvement not conclusive"],
            ["PRC-E-AHPA vs LGBMRegressor", "Peak rows", "-0.4450", "[-1.028, 0.043]", "Not available", "Wilcoxon = 0.0923; sign = 0.0166", "Operationally promising but statistically cautious"],
            ["PRC-E-AHPA vs E-AHPA", "Peak rows", "-0.3426", "[-0.471, -0.210]", "Not available", "Wilcoxon < 0.0001; sign < 0.0001", "PRC improves peak-row error relative to E-AHPA"],
            ["PRC-E-AHPA vs CatBoostRegressor", "Peak rows", "-0.4499", "[-0.764, -0.171]", "Not available", "Wilcoxon = 0.0001; sign = 0.0018", "Peak-row improvement supported"],
        ],
    )
    p(
        "The statistical validation supports the main claim that E-AHPA improves overall MAE over the strongest "
        "standard ML benchmark. PRC-E-AHPA also improves overall MAE relative to LGBM and CatBoost, but its main "
        "role is operational: it reduces observed peak and high-peak errors. Because the PRC-E-AHPA versus LGBM "
        "peak-row confidence interval crosses zero, that specific peak-row comparison is described cautiously "
        "rather than as definitive statistical superiority."
    )
    p(
        "Figure 4. Statistical validation of forecasting improvements. Confidence intervals and paired tests support "
        "the overall MAE improvement of E-AHPA over the strongest standard ML benchmark; peak-row results are "
        "interpreted cautiously where uncertainty intervals overlap zero.",
        bold=True,
    )

    p("6.2 Prediction Intervals and Underestimation Risk", "Heading 2")
    p(
        "Prediction intervals provide an operational upper-bound signal for scheduling. Table 6 summarizes the "
        "selected validation-calibrated site-risk asymmetric interval."
    )
    p(
        "Table 6. Prediction interval and upper-bound forecast summary. The selected site-risk asymmetric interval "
        "is calibrated from validation residuals and used to reduce upper-bound underestimation risk for scheduling.",
        bold=True,
    )
    t(
        ["Interval method", "Forecast track", "Nominal coverage", "Empirical coverage", "Average width (kW)", "Peak coverage", "High-peak coverage", "Upper-bound underestimation rate (%)"],
        [["Site-risk asymmetric", "Main point forecast", "0.90", "0.8682", "19.6965", "0.7829", "0.7624", "5.18"]],
    )
    p(
        "The selected interval reduces upper-bound underestimation risk by 13.723 percentage points. Empirical "
        "coverage is below the nominal 90% level, especially during peak and high-peak periods. Therefore, the "
        "interval is not presented as a perfect calibrated-coverage guarantee; it is presented as an operational "
        "tool that reduces the risk of underestimating future load."
    )
    p(
        "Figure 5. Prediction interval behavior for uncertainty-aware scheduling. The upper-bound forecast is "
        "calibrated from validation residuals and reduces the risk of underestimating future load, although empirical "
        "coverage is below nominal during peak periods.",
        bold=True,
    )

    p("6.3 Real/Session-Limited Constrained Scheduling", "Heading 2")
    p(
        "Table 7 reports the calendar-aligned real/session-limited scheduling case study. This experiment uses "
        "available observed session constraints and evaluates whether forecast-informed scheduling can reduce peak "
        "and capacity risk while preserving energy delivery."
    )
    p(
        "Table 7. Real/session-limited constrained scheduling summary. The calendar-aligned case study uses available "
        "real session demand and reports energy delivery, unserved energy, peak reduction, and capacity-violation "
        "reduction under arrival, departure, requested-energy, charger-power, and capacity constraints.",
        bold=True,
    )
    t(
        ["Scenario mode", "Sites scheduled", "Sessions scheduled", "Requested energy (kWh)", "Delivered energy (kWh)", "Unserved energy (kWh)", "Unserved energy (%)", "Peak reduction (%)"],
        [["Calendar-aligned forecast horizon", "1", "9,110", "79,676.49", "79,644.66", "31.84", "0.04", "41.84"]],
    )
    p(
        "In this real/session-limited case study, uncertainty-aware scheduling reduces peak load by 41.84%, reduces "
        "capacity violation hours by 164, and leaves only 0.04% unserved energy. The result is useful because it uses "
        "realistic session constraints, but the claim is intentionally limited because the observed real-session "
        "coverage is available for one scheduled site rather than all six forecast sites."
    )
    p(
        "Figure 6. Real/session-limited constrained scheduling case study. The uncertainty-aware scheduler reduces "
        "peak load and capacity-violation hours while maintaining high energy delivery under arrival, departure, "
        "requested-energy, charger-power, and capacity constraints.",
        bold=True,
    )

    p("6.4 Synthetic Empirical Multi-Site Scheduling", "Heading 2")
    p(
        "Table 8 reports the six-site synthetic empirical scheduling scenario. This scenario combines 9,079 aligned "
        "real empirical sessions with 12,256 schedulable synthetic empirical sessions. It is used to evaluate multi-site "
        "scalability across all forecast sites, but it is not a substitute for observed session logs from every site."
    )
    p(
        "Table 8. Synthetic empirical six-site scheduling scenario summary. Synthetic sessions are generated from "
        "empirical real-session distributions and used only for scalability analysis. The table must not be interpreted "
        "as validation using observed session logs from all six sites.",
        bold=True,
    )
    t(
        ["Sites scheduled", "Real sessions used", "Synthetic sessions used", "Total sessions", "Capacity scenario", "Recommended strategy", "Peak reduction (%)", "Capacity violations", "Unserved energy (%)"],
        [["6", "9,079", "12,256", "21,335", "Capacity p95 + 10%", "Hybrid uncertainty/peak", "34.19", "484 → 8", "≈0.001"]],
    )
    p(
        "The hybrid uncertainty/peak strategy is recommended for paper discussion because it directly connects scheduling "
        "decisions to both the peak-sensitive forecasting track and the uncertainty-aware upper-bound signal. In this "
        "synthetic empirical six-site scenario, uncertainty-aware scheduling reduces aggregate peak load by 34.19%, reduces "
        "capacity violation hours from 484 to 8, and leaves approximately 0.001% unserved energy. These results support "
        "scalability analysis under empirical scenario demand, not observed six-site session-log validation."
    )
    p(
        "Figure 7. Synthetic empirical six-site scheduling scenario. The figure compares scheduling strategies across all "
        "forecast sites using real aligned sessions and synthetic empirical sessions. Results demonstrate scalability under "
        "scenario demand, not validation using observed session logs from all six sites.",
        bold=True,
    )
    p(
        "Figure 8. Site-level scheduling robustness in the synthetic empirical scenario. The figure shows how peak reduction, "
        "energy service, and capacity-risk behavior vary across sites, supporting the scalability analysis of the proposed "
        "forecast-informed scheduler.",
        bold=True,
    )

    p("6.5 Ablation and Development Summary", "Heading 2")
    p(
        "Table 9 summarizes the development path. Each stage addresses a specific weakness in the earlier manuscript: standard "
        "ML benchmarking, adaptive hybrid novelty, peak-risk calibration, uncertainty intervals, and constrained scheduling feasibility."
    )
    p(
        "Table 9. Development and ablation summary. Each stage addresses a reviewer-relevant weakness and shows how the final framework was built.",
        bold=True,
    )
    t(
        ["Stage", "Added component", "Main result", "Why it matters"],
        [
            ["Step 07 standard ML", "Leakage-free tree-based ML comparators", "LGBM test MAE = 4.3504", "Establishes a strong standard benchmark"],
            ["Step 08D E-AHPA", "Adaptive hybrid peak-aware ensemble", "E-AHPA test MAE = 4.1909", "Provides the main statistically supported forecasting contribution"],
            ["Step 08E PRC-E-AHPA", "Peak-risk calibration on top of E-AHPA", "Peak_MAE = 18.5486; high_peak_MAE = 27.2268", "Provides an operational peak-sensitive forecast track"],
            ["Step 10 intervals", "Validation-calibrated prediction intervals", "Underestimation risk reduced by 13.723 percentage points", "Provides an uncertainty-aware scheduling signal"],
            ["Step 11E scheduling", "Synthetic empirical six-site scalability scenario", "Peak reduction = 34.19%; capacity violations 484 → 8", "Tests operational scalability without claiming observed six-site session validation"],
        ],
    )
    p(
        "This development sequence shows that the final framework was not a simple comparison of standard regressors. Standard "
        "ML models established the benchmark, E-AHPA provided the main forecasting contribution, PRC-E-AHPA addressed peak-risk "
        "behavior, prediction intervals reduced upper-bound underestimation risk, and constrained scheduling tested operational "
        "feasibility under realistic session and capacity constraints."
    )

    return items


def main() -> None:
    if not SOURCE_DOCX.exists():
        raise FileNotFoundError(SOURCE_DOCX)

    MAN_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE_DOCX, BACKUP_DOCX)

    doc = Document(SOURCE_DOCX)
    original_blocks = list(iter_body_blocks(doc))
    start_idx = find_block_index(original_blocks, "6. Results")
    section7_idx = find_block_index(original_blocks, "7. Discussion")
    before_sig = body_signature(original_blocks[:start_idx])
    after_sig = body_signature(original_blocks[section7_idx:])
    original_removed_count = section7_idx - start_idx

    for block in original_blocks[start_idx:section7_idx]:
        block.getparent().remove(block)

    refreshed_blocks = list(iter_body_blocks(doc))
    anchor_idx = find_block_index(refreshed_blocks, "7. Discussion")
    anchor = refreshed_blocks[anchor_idx]
    new_elements = section6_elements(doc)
    body = doc.element.body
    for element in new_elements:
        body.remove(element)
        anchor.addprevious(element)

    doc.save(UPDATED_DOCX)

    updated = Document(UPDATED_DOCX)
    updated_blocks = list(iter_body_blocks(updated))
    new_start = find_block_index(updated_blocks, "6. Results")
    new_section7 = find_block_index(updated_blocks, "7. Discussion")
    outside_before_unchanged = body_signature(updated_blocks[:new_start]) == before_sig
    outside_after_unchanged = body_signature(updated_blocks[new_section7:]) == after_sig
    section7_starts_correctly = block_text(updated_blocks[new_section7]) == "7. Discussion"

    section6_table_count = sum(1 for block in updated_blocks[new_start:new_section7] if block.tag.endswith("}tbl"))
    section6_replaced = section6_table_count == 6 and new_section7 > new_start

    report = [
        "Section 6 DOCX replacement report",
        "=================================",
        f"Source DOCX: {SOURCE_DOCX}",
        f"Backup DOCX: {BACKUP_DOCX}",
        f"Updated DOCX: {UPDATED_DOCX}",
        "",
        f"Original Section 6 block count removed: {original_removed_count}",
        f"New Section 6 block count inserted: {new_section7 - new_start}",
        f"Section 6 replaced: {'yes' if section6_replaced else 'no'}",
        f"All sections before Section 6 unchanged: {'yes' if outside_before_unchanged else 'no'}",
        f"All sections from Section 7 onward unchanged: {'yes' if outside_after_unchanged else 'no'}",
        f"All other sections unchanged: {'yes' if outside_before_unchanged and outside_after_unchanged else 'no'}",
        f"Tables 4-9 converted to Word tables: {'yes' if section6_table_count == 6 else 'no'}",
        f"Word tables in replacement Section 6: {section6_table_count}",
        f"Section 7 still starts with '7. Discussion': {'yes' if section7_starts_correctly else 'no'}",
    ]
    REPORT_PATH.write_text("\n".join(report) + "\n", encoding="utf-8")

    print("\n".join(report))


if __name__ == "__main__":
    main()
