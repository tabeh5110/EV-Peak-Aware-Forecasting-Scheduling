"""
Step 11D: Synthetic multi-site session generation.

Run from the project root:
    python src/11D_synthetic_multisite_session_generation.py

Synthetic sessions created here are scenario data for robustness/scalability
analysis. They are not real charging logs.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import re
import sys
import types
import warnings

import numpy as np


if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "11D_synthetic_multisite_sessions"
FIGURES_DIR = PROJECT_ROOT / "figures" / "11D_synthetic_multisite_sessions"

REAL_SESSION_FILE = PROCESSED_DIR / "02_scheduling_ready_sessions.csv"
HOURLY_FILE = PROCESSED_DIR / "03_hourly_load_all_sites.csv"
FORECAST_FILE = PROCESSED_DIR / "10_uncertainty_forecasts_for_scheduling.csv"
DIAGNOSIS_11B_FILE = PROJECT_ROOT / "results" / "11B_scheduling_robustness" / "11B_site_coverage_diagnosis.csv"
CLAIM_11B_FILE = PROJECT_ROOT / "results" / "11B_scheduling_robustness" / "11B_scheduling_claim_strength.csv"
STEP11_MAPPING_FILE = PROJECT_ROOT / "results" / "11_constrained_scheduling" / "11_site_mapping_report.csv"

SYNTHETIC_MISSING_FILE = PROCESSED_DIR / "11D_synthetic_sessions_missing_sites_only.csv"
SYNTHETIC_ALL_FILE = PROCESSED_DIR / "11D_synthetic_sessions_all_sites.csv"
COMBINED_FILE = PROCESSED_DIR / "11D_real_plus_synthetic_sessions_for_scheduling.csv"

RANDOM_STATE = 42
DEFAULT_CHARGER_POWER_KW = 6.6
SENSITIVITY_CHARGER_POWER_KW = "6.6;7.2;11.0"
SCENARIO_TYPE = "synthetic_multisite_scenario"


def ensure_dirs() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)


def require(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Required file not found: {path}")


def read_csv(path: Path, **kwargs: Any) -> pd.DataFrame:
    require(path)
    return pd.read_csv(path, **kwargs)


def pick_column(columns: list[str], candidates: list[str]) -> str | None:
    lower_map = {column.lower(): column for column in columns}
    for candidate in candidates:
        if candidate.lower() in lower_map:
            return lower_map[candidate.lower()]
    return None


def parse_time(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series, errors="coerce", utc=True)


def safe_div(num: float, den: float) -> float:
    if den == 0 or pd.isna(den):
        return 0.0
    return float(num) / float(den)


def weighted_choice(rng: np.random.Generator, values: np.ndarray, weights: np.ndarray) -> Any:
    if len(values) == 0:
        return None
    weights = np.asarray(weights, dtype=float)
    if weights.sum() <= 0:
        weights = np.ones(len(values), dtype=float) / len(values)
    else:
        weights = weights / weights.sum()
    return rng.choice(values, p=weights)


def standardize_real_sessions(raw: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, str]]:
    columns = list(raw.columns)
    mapping = {
        "session_id": pick_column(columns, ["session_id", "sessionID", "_id", "id"]),
        "site_id": pick_column(columns, ["site_id", "siteID", "site"]),
        "arrival_time": pick_column(columns, ["arrival_time", "arrival", "connectionTime"]),
        "departure_time": pick_column(columns, ["departure_time", "done_time", "requestedDeparture", "disconnectTime"]),
        "energy_kwh": pick_column(columns, ["energy_kwh", "kWhDelivered", "kWhRequested", "requested_energy_kwh"]),
        "station_id": pick_column(columns, ["stationID", "station_id", "evse_id"]),
        "space_id": pick_column(columns, ["spaceID", "space_id"]),
        "timezone": pick_column(columns, ["timezone", "time_zone"]),
        "max_power": pick_column(columns, ["max_charging_power_kw", "max_power_kw", "charger_power_kw"]),
    }
    required = ["arrival_time", "departure_time", "energy_kwh"]
    missing = [name for name in required if mapping[name] is None]
    if missing:
        raise ValueError(f"Missing required real-session columns: {missing}")

    out = pd.DataFrame()
    out["session_id"] = raw[mapping["session_id"]].astype(str) if mapping["session_id"] else [f"real_{i:07d}" for i in range(len(raw))]
    out["raw_site_id"] = raw[mapping["site_id"]].astype(str) if mapping["site_id"] else "unknown"
    out["site_id"] = out["raw_site_id"]
    out["arrival_time"] = parse_time(raw[mapping["arrival_time"]])
    out["departure_time"] = parse_time(raw[mapping["departure_time"]])
    out["energy_kwh"] = pd.to_numeric(raw[mapping["energy_kwh"]], errors="coerce")
    out["station_id"] = raw[mapping["station_id"]].astype(str) if mapping["station_id"] else "real_station_unknown"
    out["space_id"] = raw[mapping["space_id"]].astype(str) if mapping["space_id"] else "real_space_unknown"
    out["timezone"] = raw[mapping["timezone"]].astype(str) if mapping["timezone"] else "unknown"
    if mapping["max_power"]:
        out["max_charging_power_kw"] = pd.to_numeric(raw[mapping["max_power"]], errors="coerce").fillna(DEFAULT_CHARGER_POWER_KW)
    else:
        out["max_charging_power_kw"] = DEFAULT_CHARGER_POWER_KW
    out["dwell_hours"] = (out["departure_time"] - out["arrival_time"]).dt.total_seconds() / 3600.0
    out = out.loc[
        out["arrival_time"].notna()
        & out["departure_time"].notna()
        & (out["departure_time"] > out["arrival_time"])
        & out["energy_kwh"].notna()
        & (out["energy_kwh"] > 0)
        & (out["dwell_hours"] > 0)
    ].copy()
    max_real_dwell = float(out["dwell_hours"].quantile(0.995)) if len(out) else 48.0
    dwell_cap = max(48.0, max_real_dwell)
    out = out.loc[out["dwell_hours"] <= dwell_cap].copy()
    out["arrival_hour"] = out["arrival_time"].dt.hour
    out["arrival_minute"] = out["arrival_time"].dt.minute
    out["weekday"] = out["arrival_time"].dt.weekday
    out["is_weekend"] = out["weekday"] >= 5
    out["arrival_date"] = out["arrival_time"].dt.date
    out["energy_per_dwell_hour"] = out["energy_kwh"] / out["dwell_hours"]
    return out.reset_index(drop=True), {k: v or "" for k, v in mapping.items()}


def load_hourly_and_forecasts() -> tuple[pd.DataFrame, pd.DataFrame]:
    hourly = read_csv(HOURLY_FILE)
    forecasts = read_csv(FORECAST_FILE)
    for df in [hourly, forecasts]:
        df["timestamp"] = parse_time(df["timestamp"])
        df["site_id"] = df["site_id"].astype(str)
    hourly["load_kw"] = pd.to_numeric(hourly["load_kw"], errors="coerce").fillna(0.0).clip(lower=0.0)
    for column in ["actual_load_kw", "main_point_forecast_kw", "peak_sensitive_point_forecast_kw", "upper_forecast_kw"]:
        if column in forecasts.columns:
            forecasts[column] = pd.to_numeric(forecasts[column], errors="coerce").fillna(0.0).clip(lower=0.0)
    hourly = hourly.dropna(subset=["timestamp", "site_id"]).reset_index(drop=True)
    forecasts = forecasts.dropna(subset=["timestamp", "site_id"]).reset_index(drop=True)
    return hourly, forecasts


def real_forecast_site_mapping(real: pd.DataFrame, forecast_sites: list[str]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    if STEP11_MAPPING_FILE.exists():
        step11_map = pd.read_csv(STEP11_MAPPING_FILE)
        if {"original_site_id", "mapped_site_id"}.issubset(step11_map.columns):
            mapping.update({str(r.original_site_id): str(r.mapped_site_id) for r in step11_map.itertuples()})
    for raw_site in sorted(real["raw_site_id"].astype(str).unique()):
        if raw_site not in mapping:
            mapping[raw_site] = raw_site if raw_site in forecast_sites else forecast_sites[0]
    return mapping


def calendar_align_real_sessions(real: pd.DataFrame, forecasts: pd.DataFrame, site_map: dict[str, str]) -> pd.DataFrame:
    frames = []
    forecast_ranges = forecasts.groupby("site_id")["timestamp"].agg(["min", "max"]).reset_index()
    for raw_site, group in real.groupby("raw_site_id"):
        mapped_site = site_map.get(str(raw_site))
        range_row = forecast_ranges.loc[forecast_ranges["site_id"] == mapped_site]
        if range_row.empty:
            continue
        f_start = range_row.iloc[0]["min"]
        f_end = range_row.iloc[0]["max"]
        g = group.sort_values("arrival_time").copy()
        shift = f_start.floor("H") - g["arrival_time"].min().floor("H")
        g["original_arrival_time"] = g["arrival_time"]
        g["original_departure_time"] = g["departure_time"]
        g["site_id"] = mapped_site
        g["arrival_time"] = g["arrival_time"] + shift
        g["departure_time"] = g["departure_time"] + shift
        g = g.loc[(g["departure_time"] >= f_start) & (g["arrival_time"] <= f_end)].copy()
        g["arrival_time"] = g["arrival_time"].clip(lower=f_start)
        g["departure_time"] = g["departure_time"].clip(upper=f_end + pd.Timedelta(hours=1))
        g["dwell_hours"] = (g["departure_time"] - g["arrival_time"]).dt.total_seconds() / 3600.0
        g = g.loc[g["dwell_hours"] > 0].copy()
        frames.append(g)
    if not frames:
        return real.iloc[0:0].copy()
    out = pd.concat(frames, ignore_index=True)
    out["session_source"] = "real"
    out["scenario_type"] = SCENARIO_TYPE
    out["generated_from_distribution"] = "observed_real_session_calendar_aligned"
    out["random_state"] = RANDOM_STATE
    out["charger_power_sensitivity_kw"] = SENSITIVITY_CHARGER_POWER_KW
    return out.reset_index(drop=True)


def empirical_summary(real: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for metric, series in {
        "energy_kwh": real["energy_kwh"],
        "dwell_hours": real["dwell_hours"],
        "energy_per_dwell_hour": real["energy_per_dwell_hour"],
        "arrival_hour": real["arrival_hour"],
        "weekday": real["weekday"],
    }.items():
        rows.append(
            {
                "metric": metric,
                "count": int(series.count()),
                "mean": float(series.mean()),
                "median": float(series.median()),
                "std": float(series.std(ddof=0)),
                "q25": float(series.quantile(0.25)),
                "q75": float(series.quantile(0.75)),
                "q90": float(series.quantile(0.90)),
                "q95": float(series.quantile(0.95)),
                "min": float(series.min()),
                "max": float(series.max()),
            }
        )
    daily_counts = real.groupby("arrival_date").size()
    rows.append(
        {
            "metric": "session_count_per_day",
            "count": int(daily_counts.count()),
            "mean": float(daily_counts.mean()),
            "median": float(daily_counts.median()),
            "std": float(daily_counts.std(ddof=0)),
            "q25": float(daily_counts.quantile(0.25)),
            "q75": float(daily_counts.quantile(0.75)),
            "q90": float(daily_counts.quantile(0.90)),
            "q95": float(daily_counts.quantile(0.95)),
            "min": float(daily_counts.min()),
            "max": float(daily_counts.max()),
        }
    )
    summary = pd.DataFrame(rows)
    summary["default_charger_power_kw"] = DEFAULT_CHARGER_POWER_KW
    summary["charger_power_sensitivity_kw"] = SENSITIVITY_CHARGER_POWER_KW
    summary.to_csv(RESULTS_DIR / "11D_empirical_distribution_summary.csv", index=False)
    return summary


def build_generation_plan(
    real: pd.DataFrame,
    aligned_real: pd.DataFrame,
    hourly: pd.DataFrame,
    forecasts: pd.DataFrame,
    site_map: dict[str, str],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    forecast_sites = sorted(forecasts["site_id"].unique())
    hourly_sites = set(hourly["site_id"].unique())
    aligned_real_sites = set(aligned_real["site_id"].unique())
    mapped_real_site = next(iter(aligned_real_sites)) if aligned_real_sites else forecast_sites[0]
    hourly_stats = hourly.groupby("site_id")["load_kw"].agg(["mean", lambda s: s.quantile(0.95), "max"]).reset_index()
    hourly_stats.columns = ["site_id", "mean_load_kw", "p95_load_kw", "peak_load_kw"]
    real_stats = hourly_stats.loc[hourly_stats["site_id"] == mapped_real_site]
    if real_stats.empty:
        ref_mean = max(float(hourly["load_kw"].mean()), 1.0)
        ref_p95 = max(float(hourly["load_kw"].quantile(0.95)), 1.0)
    else:
        ref_mean = max(float(real_stats.iloc[0]["mean_load_kw"]), 1e-6)
        ref_p95 = max(float(real_stats.iloc[0]["p95_load_kw"]), 1e-6)

    real_daily_count = aligned_real.groupby(aligned_real["arrival_time"].dt.date).size()
    real_daily_mean = float(real_daily_count.mean()) if len(real_daily_count) else float(real.groupby("arrival_date").size().mean())
    forecast_ranges = forecasts.groupby("site_id")["timestamp"].agg(["min", "max", "count"]).reset_index()
    rows = []
    scale_rows = []
    for site in forecast_sites:
        stat = hourly_stats.loc[hourly_stats["site_id"] == site]
        if stat.empty:
            mean_load = float(forecasts.loc[forecasts["site_id"] == site, "upper_forecast_kw"].mean())
            p95_load = float(forecasts.loc[forecasts["site_id"] == site, "upper_forecast_kw"].quantile(0.95))
            peak_load = float(forecasts.loc[forecasts["site_id"] == site, "upper_forecast_kw"].max())
        else:
            mean_load = float(stat.iloc[0]["mean_load_kw"])
            p95_load = float(stat.iloc[0]["p95_load_kw"])
            peak_load = float(stat.iloc[0]["peak_load_kw"])
        mean_ratio = safe_div(mean_load, ref_mean)
        peak_ratio = safe_div(p95_load, ref_p95)
        raw_scale = 0.7 * mean_ratio + 0.3 * peak_ratio
        scale = float(np.clip(raw_scale, 0.10, 3.0))
        needs_synth = site not in aligned_real_sites
        range_row = forecast_ranges.loc[forecast_ranges["site_id"] == site].iloc[0]
        days = max(1.0, (range_row["max"] - range_row["min"]).total_seconds() / 86400.0)
        target_daily = real_daily_mean * scale
        if needs_synth and mean_load > 0.25:
            target_daily = max(5.0, target_daily)
        if raw_scale > 3.0 and peak_load > 2 * ref_p95:
            target_daily = min(real_daily_mean * 4.0, target_daily)
            notes = "high-load site allowed limited scale above normal cap"
        else:
            target_daily = min(real_daily_mean * 3.0, target_daily)
            notes = "synthetic site" if needs_synth else "mapped real-session site"
        target_number = int(round(target_daily * days)) if needs_synth else 0
        rows.append(
            {
                "site_id": site,
                "has_real_sessions": site in aligned_real_sites,
                "has_hourly_load": site in hourly_sites,
                "has_forecast": True,
                "needs_synthetic_sessions": needs_synth,
                "target_number_synthetic_sessions": target_number,
                "scaling_factor": scale,
                "notes": notes,
            }
        )
        scale_rows.append(
            {
                "site_id": site,
                "mapped_real_reference_site": mapped_real_site,
                "mean_load_kw": mean_load,
                "p95_load_kw": p95_load,
                "peak_load_kw": peak_load,
                "reference_mean_load_kw": ref_mean,
                "reference_p95_load_kw": ref_p95,
                "mean_load_ratio": mean_ratio,
                "p95_load_ratio": peak_ratio,
                "blended_raw_scale": raw_scale,
                "scaling_factor": scale,
                "target_daily_session_count": target_daily,
                "target_number_synthetic_sessions": target_number,
            }
        )
    plan = pd.DataFrame(rows)
    scaling = pd.DataFrame(scale_rows)
    plan.to_csv(RESULTS_DIR / "11D_site_generation_plan.csv", index=False)
    scaling.to_csv(RESULTS_DIR / "11D_site_scaling_factors.csv", index=False)
    return plan, scaling


def hour_distribution(real: pd.DataFrame, weekend: bool) -> tuple[np.ndarray, np.ndarray]:
    subset = real.loc[real["is_weekend"] == weekend]
    if subset.empty:
        subset = real
    counts = subset["arrival_hour"].value_counts().reindex(range(24), fill_value=0).sort_index()
    weights = counts.to_numpy(dtype=float)
    if weights.sum() <= 0:
        weights = np.ones(24)
    return counts.index.to_numpy(), weights / weights.sum()


def generate_synthetic_sessions(
    real: pd.DataFrame,
    forecasts: pd.DataFrame,
    plan: pd.DataFrame,
    scaling: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(RANDOM_STATE)
    daily_counts = real.groupby("arrival_date").size().to_numpy(dtype=float)
    if len(daily_counts) == 0:
        daily_counts = np.array([20.0])
    dwell_samples = real["dwell_hours"].to_numpy(dtype=float)
    energy_samples = real["energy_kwh"].to_numpy(dtype=float)
    minute_samples = real["arrival_minute"].to_numpy(dtype=int)
    station_count = max(4, int(real["station_id"].nunique()))
    space_count = max(8, int(real["space_id"].nunique()))
    weekday_hours, weekday_weights = hour_distribution(real, weekend=False)
    weekend_hours, weekend_weights = hour_distribution(real, weekend=True)

    rows = []
    adjustments = []
    forecast_ranges = forecasts.groupby("site_id")["timestamp"].agg(["min", "max"]).reset_index()
    for plan_row in plan.loc[plan["needs_synthetic_sessions"]].itertuples(index=False):
        site = str(plan_row.site_id)
        range_row = forecast_ranges.loc[forecast_ranges["site_id"] == site].iloc[0]
        start = range_row["min"].floor("D")
        end = range_row["max"].floor("D")
        dates = pd.date_range(start=start, end=end, freq="D", tz="UTC")
        target_daily = float(scaling.loc[scaling["site_id"] == site, "target_daily_session_count"].iloc[0])
        generated_for_site = 0
        for day in dates:
            sampled_count = float(rng.choice(daily_counts))
            if np.mean(daily_counts) > 0:
                expected = target_daily * safe_div(sampled_count, float(np.mean(daily_counts)))
            else:
                expected = target_daily
            session_count = int(max(0, rng.poisson(max(expected, 0.0))))
            if target_daily >= 5 and session_count < 1 and rng.random() < 0.8:
                session_count = 1
            for _ in range(session_count):
                is_weekend = day.weekday() >= 5
                if is_weekend:
                    hour = int(weighted_choice(rng, weekend_hours, weekend_weights))
                else:
                    hour = int(weighted_choice(rng, weekday_hours, weekday_weights))
                minute = int(rng.choice(minute_samples)) if len(minute_samples) else int(rng.integers(0, 60))
                second = int(rng.integers(0, 60))
                arrival = day + pd.Timedelta(hours=hour, minutes=minute, seconds=second)
                dwell = float(rng.choice(dwell_samples))
                energy = float(rng.choice(energy_samples))
                max_power = DEFAULT_CHARGER_POWER_KW
                adjustment = "none"
                feasible_energy = max_power * dwell
                if energy > feasible_energy:
                    needed_dwell = energy / max_power
                    if needed_dwell <= 48.0:
                        dwell = needed_dwell
                        adjustment = "increased_dwell_to_make_energy_feasible"
                    else:
                        energy = feasible_energy
                        adjustment = "capped_energy_to_charger_feasible_max"
                departure = arrival + pd.Timedelta(hours=dwell)
                if arrival < range_row["min"]:
                    arrival = range_row["min"]
                if departure > range_row["max"] + pd.Timedelta(hours=1):
                    departure = range_row["max"] + pd.Timedelta(hours=1)
                    dwell = (departure - arrival).total_seconds() / 3600.0
                    feasible_energy = max_power * max(dwell, 0.0)
                    if energy > feasible_energy:
                        energy = max(0.01, feasible_energy)
                        adjustment = "clipped_departure_and_capped_energy"
                if departure <= arrival or energy <= 0:
                    adjustments.append(
                        {
                            "site_id": site,
                            "synthetic_session_id": f"11D_SYN_{site}_{generated_for_site + 1:07d}",
                            "adjustment_type": "removed_infeasible_after_horizon_clip",
                            "original_energy_kwh": energy,
                            "final_energy_kwh": 0.0,
                            "final_dwell_hours": dwell,
                        }
                    )
                    continue
                generated_for_site += 1
                session_id = f"11D_SYN_{site}_{generated_for_site:07d}"
                if adjustment != "none":
                    adjustments.append(
                        {
                            "site_id": site,
                            "synthetic_session_id": session_id,
                            "adjustment_type": adjustment,
                            "original_energy_kwh": float(rng.choice(energy_samples)),
                            "final_energy_kwh": energy,
                            "final_dwell_hours": dwell,
                        }
                    )
                rows.append(
                    {
                        "session_id": session_id,
                        "site_id": site,
                        "raw_site_id": site,
                        "arrival_time": arrival,
                        "departure_time": departure,
                        "energy_kwh": energy,
                        "max_charging_power_kw": max_power,
                        "station_id": f"{site}_synthetic_station_{int(rng.integers(1, station_count + 1)):03d}",
                        "space_id": f"{site}_synthetic_space_{int(rng.integers(1, space_count + 1)):03d}",
                        "timezone": "UTC",
                        "dwell_hours": dwell,
                        "arrival_hour": arrival.hour,
                        "weekday": arrival.weekday(),
                        "is_weekend": arrival.weekday() >= 5,
                        "session_source": "synthetic_empirical",
                        "scenario_type": SCENARIO_TYPE,
                        "generated_from_distribution": "empirical_real_sessions_scaled_by_site_load",
                        "random_state": RANDOM_STATE,
                        "charger_power_sensitivity_kw": SENSITIVITY_CHARGER_POWER_KW,
                    }
                )
    synthetic = pd.DataFrame(rows)
    adjustments_df = pd.DataFrame(adjustments)
    if adjustments_df.empty:
        adjustments_df = pd.DataFrame(
            columns=["site_id", "synthetic_session_id", "adjustment_type", "original_energy_kwh", "final_energy_kwh", "final_dwell_hours"]
        )
    synthetic.to_csv(SYNTHETIC_MISSING_FILE, index=False)
    adjustments_df.to_csv(RESULTS_DIR / "11D_synthetic_generation_adjustments.csv", index=False)
    return synthetic, adjustments_df


def standardized_output(df: pd.DataFrame) -> pd.DataFrame:
    keep = [
        "session_id",
        "site_id",
        "arrival_time",
        "departure_time",
        "energy_kwh",
        "max_charging_power_kw",
        "station_id",
        "space_id",
        "session_source",
        "scenario_type",
        "generated_from_distribution",
        "random_state",
        "charger_power_sensitivity_kw",
    ]
    out = df.copy()
    for col in keep:
        if col not in out.columns:
            out[col] = ""
    return out[keep].sort_values(["site_id", "arrival_time", "session_id"]).reset_index(drop=True)


def distribution_metrics(real_aligned: pd.DataFrame, synthetic: pd.DataFrame) -> pd.DataFrame:
    rows = []
    frames = [("real", real_aligned), ("synthetic_empirical", synthetic)]
    for source, df in frames:
        if df.empty:
            continue
        d = df.copy()
        d["arrival_date"] = pd.to_datetime(d["arrival_time"], utc=True).dt.date
        for metric in ["energy_kwh", "dwell_hours", "arrival_hour"]:
            series = pd.to_numeric(d[metric], errors="coerce").dropna()
            rows.append(
                {
                    "session_source": source,
                    "metric": metric,
                    "count": int(series.count()),
                    "mean": float(series.mean()),
                    "median": float(series.median()),
                    "std": float(series.std(ddof=0)),
                    "q25": float(series.quantile(0.25)),
                    "q75": float(series.quantile(0.75)),
                    "q90": float(series.quantile(0.90)),
                    "q95": float(series.quantile(0.95)),
                }
            )
        daily_counts = d.groupby("arrival_date").size()
        daily_energy = d.groupby("arrival_date")["energy_kwh"].sum()
        for metric, series in [("sessions_per_day", daily_counts), ("requested_energy_per_day_kwh", daily_energy)]:
            rows.append(
                {
                    "session_source": source,
                    "metric": metric,
                    "count": int(series.count()),
                    "mean": float(series.mean()),
                    "median": float(series.median()),
                    "std": float(series.std(ddof=0)),
                    "q25": float(series.quantile(0.25)),
                    "q75": float(series.quantile(0.75)),
                    "q90": float(series.quantile(0.90)),
                    "q95": float(series.quantile(0.95)),
                }
            )
        weekend_series = pd.Series(d["is_weekend"]).astype(float)
        rows.append(
            {
                "session_source": source,
                "metric": "weekend_share",
                "count": int(len(d)),
                "mean": float(weekend_series.mean()),
                "median": float(weekend_series.median()),
                "std": float(weekend_series.std(ddof=0)),
                "q25": float(weekend_series.quantile(0.25)),
                "q75": float(weekend_series.quantile(0.75)),
                "q90": float(weekend_series.quantile(0.90)),
                "q95": float(weekend_series.quantile(0.95)),
            }
        )
    metrics = pd.DataFrame(rows)
    metrics.to_csv(RESULTS_DIR / "11D_real_vs_synthetic_distribution_metrics.csv", index=False)
    return metrics


def site_summary(all_sessions: pd.DataFrame, adjustments: pd.DataFrame) -> pd.DataFrame:
    df = all_sessions.copy()
    df["arrival_date"] = pd.to_datetime(df["arrival_time"], utc=True).dt.date
    adjustment_counts = adjustments.groupby("site_id").size().to_dict() if len(adjustments) else {}
    rows = []
    for site, group in df.groupby("site_id"):
        daily = group.groupby("arrival_date").size()
        rows.append(
            {
                "site_id": site,
                "session_source_mix": ";".join(sorted(group["session_source"].unique())),
                "session_count": int(len(group)),
                "total_requested_energy_kwh": float(group["energy_kwh"].sum()),
                "average_sessions_per_day": float(daily.mean()) if len(daily) else 0.0,
                "mean_energy_kwh": float(group["energy_kwh"].mean()),
                "median_energy_kwh": float(group["energy_kwh"].median()),
                "q90_energy_kwh": float(group["energy_kwh"].quantile(0.90)),
                "q95_energy_kwh": float(group["energy_kwh"].quantile(0.95)),
                "mean_dwell_hours": float(group["dwell_hours"].mean()),
                "median_dwell_hours": float(group["dwell_hours"].median()),
                "q90_dwell_hours": float(group["dwell_hours"].quantile(0.90)),
                "q95_dwell_hours": float(group["dwell_hours"].quantile(0.95)),
                "feasibility_adjustment_count": int(adjustment_counts.get(site, 0)),
                "infeasible_sessions_removed": int(
                    len(adjustments.loc[(adjustments["site_id"] == site) & (adjustments["adjustment_type"] == "removed_infeasible_after_horizon_clip")])
                )
                if len(adjustments)
                else 0,
            }
        )
    summary = pd.DataFrame(rows)
    summary.to_csv(RESULTS_DIR / "11D_synthetic_session_summary_by_site.csv", index=False)
    return summary


def make_figures(plan: pd.DataFrame, real_aligned: pd.DataFrame, synthetic: pd.DataFrame, summary: pd.DataFrame, scaling: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    x = np.arange(len(plan))
    ax.bar(x - 0.2, plan["has_forecast"].astype(int), width=0.2, label="Forecast")
    ax.bar(x, plan["has_real_sessions"].astype(int), width=0.2, label="Real sessions")
    ax.bar(x + 0.2, plan["needs_synthetic_sessions"].astype(int), width=0.2, label="Synthetic needed")
    ax.set_xticks(x)
    ax.set_xticklabels(plan["site_id"], rotation=35, ha="right")
    ax.set_ylim(0, 1.2)
    ax.set_title("Site session/forecast coverage")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11D_fig1_site_session_coverage.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 5))
    real_counts = real_aligned["arrival_hour"].value_counts().reindex(range(24), fill_value=0).sort_index()
    synth_counts = synthetic["arrival_hour"].value_counts().reindex(range(24), fill_value=0).sort_index()
    ax.plot(real_counts.index, real_counts / max(real_counts.sum(), 1), label="Real", marker="o")
    ax.plot(synth_counts.index, synth_counts / max(synth_counts.sum(), 1), label="Synthetic", marker="o")
    ax.set_title("Arrival hour distribution")
    ax.set_xlabel("Arrival hour")
    ax.set_ylabel("Share")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11D_fig2_arrival_hour_real_vs_synthetic.png", dpi=300)
    plt.close(fig)

    for metric, path, title, xlabel in [
        ("energy_kwh", "11D_fig3_energy_distribution_real_vs_synthetic.png", "Energy distribution", "Energy (kWh)"),
        ("dwell_hours", "11D_fig4_dwell_duration_real_vs_synthetic.png", "Dwell duration distribution", "Dwell duration (hours)"),
    ]:
        fig, ax = plt.subplots(figsize=(9, 5))
        ax.hist(real_aligned[metric], bins=40, alpha=0.55, label="Real", density=True)
        ax.hist(synthetic[metric], bins=40, alpha=0.55, label="Synthetic", density=True)
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.set_ylabel("Density")
        ax.legend()
        fig.tight_layout()
        fig.savefig(FIGURES_DIR / path, dpi=300)
        plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(summary["site_id"], summary["average_sessions_per_day"], color="#3b6ea8")
    ax.set_title("Average sessions per day by site")
    ax.set_ylabel("Sessions/day")
    ax.tick_params(axis="x", rotation=35)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11D_fig5_sessions_per_day_by_site.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(summary["site_id"], summary["total_requested_energy_kwh"], color="#3b6ea8")
    ax.set_title("Total requested energy by site")
    ax.set_ylabel("Requested energy (kWh)")
    ax.tick_params(axis="x", rotation=35)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11D_fig6_total_requested_energy_by_site.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(scaling["site_id"], scaling["scaling_factor"], color="#3b6ea8")
    ax.set_title("Synthetic site scaling factors")
    ax.set_ylabel("Scaling factor")
    ax.tick_params(axis="x", rotation=35)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11D_fig7_site_scaling_factors.png", dpi=300)
    plt.close(fig)


def write_reports(
    real: pd.DataFrame,
    aligned_real: pd.DataFrame,
    synthetic: pd.DataFrame,
    combined: pd.DataFrame,
    plan: pd.DataFrame,
    scaling: pd.DataFrame,
    dist_metrics: pd.DataFrame,
    summary: pd.DataFrame,
    adjustments: pd.DataFrame,
) -> dict[str, Any]:
    synthetic_sites = sorted(synthetic["site_id"].unique()) if len(synthetic) else []
    forecast_sites = sorted(plan.loc[plan["has_forecast"], "site_id"].astype(str).tolist())
    real_sites = sorted(aligned_real["site_id"].unique()) if len(aligned_real) else []
    total_real_energy = float(aligned_real["energy_kwh"].sum()) if len(aligned_real) else 0.0
    total_synth_energy = float(synthetic["energy_kwh"].sum()) if len(synthetic) else 0.0
    adjustment_count = int(len(adjustments))
    removed_count = int((adjustments["adjustment_type"] == "removed_infeasible_after_horizon_clip").sum()) if len(adjustments) else 0

    method = f"""Step 11D synthetic multi-site generation method report
====================================================
Why synthetic sessions were needed:
Step 11 real session scheduling was limited because complete session-level demand was available for one usable raw site, while Step 10 forecasts exist for {len(forecast_sites)} sites. To test scheduling scalability across forecast sites, this step creates clearly labeled synthetic session demand for forecast-only sites.

Real session limitation:
The raw session file contains {len(real)} cleaned real sessions from raw site labels {sorted(real['raw_site_id'].astype(str).unique())}. The real sessions were calendar-aligned to the forecast-supported site(s) {real_sites} for scenario analysis, following the Step 11 limitation.

Empirical distribution method:
Synthetic sessions are sampled from empirical real-session distributions: arrival hour, weekday/weekend timing, arrival minute, dwell duration, requested energy, and sessions per day. The random_state is fixed at {RANDOM_STATE}.

Site scaling method:
For each forecast site without real session logs, the target session count is scaled using a blended load ratio: 0.7 times the mean hourly load ratio plus 0.3 times the p95 hourly load ratio relative to the real-session reference site. Reasonable minimum and maximum limits are applied.

Feasibility checks:
Each synthetic session has positive energy, positive dwell time, a 6.6 kW default charger power, and energy no greater than max_charging_power_kw times dwell_hours. Infeasible samples are adjusted by increasing dwell time or capping energy, and all adjustments are saved.

Important interpretation:
Synthetic sessions are scenario data for robustness and scalability analysis. They are not real logs and must not be presented as real six-site session validation.
"""

    validation = f"""Step 11D synthetic session validation report
============================================
Real cleaned sessions used for empirical distributions: {len(real)}
Calendar-aligned real sessions included in scenario file: {len(aligned_real)}
Synthetic sessions generated: {len(synthetic)}
Combined real plus synthetic sessions: {len(combined)}
Forecast sites covered: {len(forecast_sites)}
Synthetic sites generated: {', '.join(synthetic_sites)}

Requested energy:
Calendar-aligned real requested energy: {total_real_energy:.2f} kWh
Synthetic requested energy: {total_synth_energy:.2f} kWh

Distribution comparison:
Real and synthetic distribution metrics are saved in 11D_real_vs_synthetic_distribution_metrics.csv. The synthetic sessions are generated from empirical arrival-time, dwell-duration, energy, weekday/weekend, and daily session-count distributions, then scaled by site load.

Feasibility adjustments:
Adjustment records: {adjustment_count}
Removed infeasible synthetic sessions: {removed_count}

Limitations:
Synthetic sessions extend the scheduling scenario to forecast-only sites, but they are not observed charging logs. They should be used only for robustness and scalability analysis, not as a replacement for real multi-site session validation.
"""

    leakage = """Step 11D leakage safety report
================================
- Synthetic sessions are generated from empirical real-session distributions only.
- No test target load is used to create exact charging schedules or session labels.
- Forecast/hourly load is used only for site-level demand scaling and coverage planning, not to reconstruct hidden real sessions.
- Every synthetic row is labeled session_source=synthetic_empirical and scenario_type=synthetic_multisite_scenario.
- Original 02_scheduling_ready_sessions.csv is not overwritten.
- The combined output is a scenario file for robustness analysis, not a real-data replacement.
"""

    novelty = """Step 11D novelty contribution report
=====================================
Step 11D adds a transparent multi-site scenario generator to address the session-data limitation discovered in Step 11/11B.

Contribution elements:
- Real session scheduling limitation is acknowledged rather than hidden.
- Forecast-only sites receive synthetic empirical session demand for scalability testing.
- Synthetic demand preserves observed arrival, dwell-time, energy, weekday/weekend, and session-count patterns.
- Site demand is scaled using hourly load profiles.
- Feasibility adjustments are recorded and synthetic sessions are explicitly labeled.

This supports robustness analysis, but it is not a substitute for real multi-site session validation.
"""

    paragraph = f"""Complete session-level charging logs were available for a limited set of sites, while Step 10 produced forecasts for {len(forecast_sites)} sites. To evaluate scheduling scalability without overstating the available real data, we constructed an additional synthetic multi-site scenario. Synthetic sessions were generated only for forecast-supported sites without real session logs, using empirical distributions from the real session data for arrival hour, weekday/weekend behavior, dwell duration, requested energy, and sessions per day. Site-level demand was scaled using mean and p95 hourly load ratios, and every generated row was labeled as session_source=synthetic_empirical under scenario_type=synthetic_multisite_scenario. The resulting scenario contains {len(aligned_real)} calendar-aligned real sessions and {len(synthetic)} synthetic empirical sessions across {len(forecast_sites)} forecast sites. This scenario is used only for robustness and scalability analysis and is not claimed as real-world six-site session validation."""

    reports = {
        "11D_generation_method_report.txt": method,
        "11D_validation_report.txt": validation,
        "11D_leakage_safety_report.txt": leakage,
        "11D_novelty_contribution_report.txt": novelty,
        "11D_paper_ready_synthetic_scenario_paragraph.txt": paragraph,
    }
    for name, text in reports.items():
        (RESULTS_DIR / name).write_text(text, encoding="utf-8")

    return {
        "real_session_sites": sorted(real["raw_site_id"].astype(str).unique()),
        "forecast_sites": forecast_sites,
        "synthetic_sites": synthetic_sites,
        "real_sessions": int(len(aligned_real)),
        "synthetic_sessions": int(len(synthetic)),
        "combined_sessions": int(len(combined)),
        "total_real_energy": total_real_energy,
        "total_synthetic_energy": total_synth_energy,
        "adjustments": adjustment_count,
    }


def main() -> None:
    ensure_dirs()
    for path in [REAL_SESSION_FILE, HOURLY_FILE, FORECAST_FILE, DIAGNOSIS_11B_FILE, CLAIM_11B_FILE]:
        require(path)
    raw = read_csv(REAL_SESSION_FILE)
    real, mapping = standardize_real_sessions(raw)
    hourly, forecasts = load_hourly_and_forecasts()
    forecast_sites = sorted(forecasts["site_id"].unique())
    site_map = real_forecast_site_mapping(real, forecast_sites)
    aligned_real = calendar_align_real_sessions(real, forecasts, site_map)
    empirical_summary(real)
    plan, scaling = build_generation_plan(real, aligned_real, hourly, forecasts, site_map)
    synthetic, adjustments = generate_synthetic_sessions(real, forecasts, plan, scaling)

    real_output = aligned_real.copy()
    if len(real_output):
        real_output["session_source"] = "real"
        real_output["scenario_type"] = SCENARIO_TYPE
        real_output["generated_from_distribution"] = "observed_real_session_calendar_aligned"
        real_output["random_state"] = RANDOM_STATE
        real_output["charger_power_sensitivity_kw"] = SENSITIVITY_CHARGER_POWER_KW

    all_sessions = pd.concat([real_output, synthetic], ignore_index=True, sort=False)
    dist_metrics = distribution_metrics(real_output, synthetic)
    summary = site_summary(all_sessions, adjustments)

    standardized_synthetic = standardized_output(synthetic)
    standardized_all = standardized_output(all_sessions)
    standardized_synthetic.to_csv(SYNTHETIC_MISSING_FILE, index=False)
    standardized_all.to_csv(SYNTHETIC_ALL_FILE, index=False)
    standardized_all.to_csv(COMBINED_FILE, index=False)
    pd.DataFrame([mapping]).to_csv(RESULTS_DIR / "11D_column_mapping.csv", index=False)
    pd.DataFrame([site_map]).to_csv(RESULTS_DIR / "11D_real_site_to_forecast_site_mapping.csv", index=False)

    make_figures(plan, real_output, synthetic, summary, scaling)
    run_summary = write_reports(real, real_output, synthetic, standardized_all, plan, scaling, dist_metrics, summary, adjustments)
    (RESULTS_DIR / "11D_run_summary.json").write_text(json.dumps(run_summary, indent=2), encoding="utf-8")

    print("Step 11D synthetic multi-site session generation complete")
    print(f"Real session sites: {', '.join(run_summary['real_session_sites'])}")
    print(f"Forecast sites: {', '.join(run_summary['forecast_sites'])}")
    print(f"Sites needing synthetic sessions: {', '.join(run_summary['synthetic_sites'])}")
    print(f"Number of real sessions included: {run_summary['real_sessions']}")
    print(f"Number of synthetic sessions generated: {run_summary['synthetic_sessions']}")
    print(f"Number of combined sessions: {run_summary['combined_sessions']}")
    print(f"Total requested energy real: {run_summary['total_real_energy']:.2f} kWh")
    print(f"Total requested energy synthetic: {run_summary['total_synthetic_energy']:.2f} kWh")
    print(f"Feasibility adjustments: {run_summary['adjustments']}")
    print(f"Synthetic missing-site file: {SYNTHETIC_MISSING_FILE}")
    print(f"Synthetic all-sites file: {SYNTHETIC_ALL_FILE}")
    print(f"Combined real plus synthetic file: {COMBINED_FILE}")
    print(f"Reports folder: {RESULTS_DIR}")
    print(f"Figures folder: {FIGURES_DIR}")


if __name__ == "__main__":
    main()
