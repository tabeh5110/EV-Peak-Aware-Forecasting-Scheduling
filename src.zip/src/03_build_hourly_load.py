"""
Step 03: build standardized hourly EV charging load data.

Run from the project root:
    python src/03_build_hourly_load.py

This script standardizes the six official hourly total files and creates the
official hourly load foundation for later forecasting. It does not create
forecasting features, train models, or run scheduling optimization.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import re
import sys
import types

import numpy as np


# Environment guard for this workstation: the Python standard-library
# _strptime.py has been overwritten by old project code. Pandas/matplotlib need
# a small import-time API from _strptime, so provide it locally without editing
# the external Python installation.
if "_strptime" not in sys.modules:
    _strptime_stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    _strptime_stub.LocaleTime = LocaleTime
    _strptime_stub.TimeRE = TimeRE
    _strptime_stub._TimeRE_cache = TimeRE()
    _strptime_stub._regex_cache = {}
    _strptime_stub._getlang = _getlang
    _strptime_stub._strptime = _strptime
    _strptime_stub._strptime_time = _strptime
    _strptime_stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = _strptime_stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = PROJECT_ROOT / "data" / "raw"
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "03_build_hourly_load"
FIGURES_DIR = PROJECT_ROOT / "figures" / "03_build_hourly_load"

INPUT_FILES = [
    "Arroyo_Garage_01_hourly_total.csv",
    "California_Garage_01_hourly_total.csv",
    "California_Garage_02_hourly_total.csv",
    "N_Wilson_Garage_01_hourly_total.csv",
    "Parking_Lot_01_hourly_total.csv",
    "S_Wilson_Garage_01_hourly_total.csv",
]

TIMESTAMP_PRIORITY = ["timestamp", "datetime", "date", "time", "Unnamed: 0"]
LOAD_PRIORITY = ["Power (kW)", "power_kw", "load_kw", "Load (kW)", "0"]

COMBINED_OUTPUT = PROCESSED_DIR / "03_hourly_load_all_sites.csv"
STANDARDIZATION_REPORT = RESULTS_DIR / "03_hourly_file_standardization.csv"
SITE_SUMMARY_REPORT = RESULTS_DIR / "03_site_load_summary.csv"
PEAK_REPORT = RESULTS_DIR / "03_peak_load_by_site.csv"
TEXT_REPORT = RESULTS_DIR / "03_build_hourly_load_report.txt"


def parse_datetime(series: pd.Series) -> pd.Series:
    """Parse timestamps safely; invalid values become NaT."""
    try:
        return pd.to_datetime(series, errors="coerce", format="mixed")
    except TypeError:
        return pd.to_datetime(series, errors="coerce")


def site_id_from_file(file_name: str) -> str:
    return file_name.replace("_hourly_total.csv", "")


def is_timestamp_like(column: str) -> bool:
    normalized = column.strip().lower()
    return any(token in normalized for token in ["timestamp", "datetime", "date", "time"])


def detect_timestamp_column(df: pd.DataFrame) -> tuple[str | None, str]:
    for candidate in TIMESTAMP_PRIORITY:
        if candidate in df.columns:
            return candidate, "priority_match"

    best_column: str | None = None
    best_rate = 0.0
    for column in df.columns:
        parsed = parse_datetime(df[column])
        non_missing = int(df[column].notna().sum())
        if non_missing == 0:
            continue
        success_rate = float(parsed.notna().sum() / non_missing)
        if success_rate > best_rate:
            best_column = str(column)
            best_rate = success_rate

    if best_column is not None and best_rate >= 0.8:
        return best_column, f"fallback_parse_success_{best_rate:.3f}"
    return None, "not_detected"


def detect_load_column(df: pd.DataFrame, timestamp_column: str | None) -> tuple[str | None, str]:
    for candidate in LOAD_PRIORITY:
        if candidate in df.columns and candidate != timestamp_column:
            return candidate, "priority_match"

    for column in df.columns:
        if column == timestamp_column or is_timestamp_like(str(column)):
            continue
        numeric = pd.to_numeric(df[column], errors="coerce")
        if numeric.notna().sum() > 0:
            return str(column), "fallback_first_numeric"
    return None, "not_detected"


def standardize_one_file(file_name: str) -> tuple[pd.DataFrame, dict[str, Any], list[str]]:
    path = RAW_DIR / file_name
    site_id = site_id_from_file(file_name)
    notes: list[str] = []

    if not path.exists():
        raise FileNotFoundError(f"Missing official hourly input file: {path}")

    original = pd.read_csv(path)
    original_rows = len(original)
    timestamp_column, timestamp_note = detect_timestamp_column(original)
    load_column, load_note = detect_load_column(original, timestamp_column)

    if timestamp_column is None:
        raise ValueError(f"Could not detect timestamp column for {file_name}")
    if load_column is None:
        raise ValueError(f"Could not detect load column for {file_name}")

    if timestamp_note != "priority_match":
        notes.append(f"timestamp detection used {timestamp_note}")
    if load_note != "priority_match":
        notes.append(f"load detection used {load_note}")
    if timestamp_column != "timestamp" or load_column != "Power (kW)":
        notes.append(f"standardized columns from {timestamp_column}/{load_column}")

    standardized = pd.DataFrame(
        {
            "timestamp": parse_datetime(original[timestamp_column]),
            "site_id": site_id,
            "load_kw": pd.to_numeric(original[load_column], errors="coerce"),
            "source_file": file_name,
        }
    )

    invalid_timestamp_rows = int(standardized["timestamp"].isna().sum())
    invalid_load_rows = int(standardized["load_kw"].isna().sum())
    if invalid_timestamp_rows:
        notes.append(f"dropped invalid timestamps: {invalid_timestamp_rows}")
    if invalid_load_rows:
        notes.append(f"dropped invalid load values: {invalid_load_rows}")

    standardized = standardized.dropna(subset=["timestamp", "load_kw"]).copy()
    standardized = standardized.sort_values("timestamp")

    duplicate_timestamps = int(standardized["timestamp"].duplicated(keep=False).sum())
    if duplicate_timestamps:
        notes.append(f"duplicate timestamp rows averaged: {duplicate_timestamps}")

    negative_count = int((standardized["load_kw"] < 0).sum())
    if negative_count:
        standardized.loc[standardized["load_kw"] < 0, "load_kw"] = 0
        notes.append(f"negative load values set to zero: {negative_count}")

    grouped = (
        standardized.groupby(["timestamp", "site_id", "source_file"], as_index=False)["load_kw"]
        .mean()
        .sort_values("timestamp")
    )
    rows_before_continuous = len(grouped)

    if grouped.empty:
        raise ValueError(f"No valid hourly rows after standardization for {file_name}")

    timestamp_min = grouped["timestamp"].min()
    timestamp_max = grouped["timestamp"].max()
    full_index = pd.date_range(start=timestamp_min, end=timestamp_max, freq="h")
    continuous = pd.DataFrame({"timestamp": full_index})
    continuous["site_id"] = site_id
    continuous["source_file"] = file_name
    continuous = continuous.merge(
        grouped[["timestamp", "load_kw"]],
        on="timestamp",
        how="left",
    )
    continuous["load_kw_observed"] = continuous["load_kw"]
    continuous["was_missing_hour"] = continuous["load_kw_observed"].isna()
    continuous["load_kw"] = continuous["load_kw_observed"].fillna(0)
    continuous = continuous[
        ["timestamp", "site_id", "load_kw", "load_kw_observed", "was_missing_hour", "source_file"]
    ]

    missing_hours = int(continuous["was_missing_hour"].sum())
    final_rows = len(continuous)
    summary = {
        "source_file": file_name,
        "site_id": site_id,
        "original_rows": original_rows,
        "standardized_rows_before_continuous_index": rows_before_continuous,
        "final_rows_after_continuous_index": final_rows,
        "detected_timestamp_column": timestamp_column,
        "detected_load_column": load_column,
        "timestamp_min": timestamp_min,
        "timestamp_max": timestamp_max,
        "duplicate_timestamps_count": duplicate_timestamps,
        "missing_hours_count": missing_hours,
        "missing_hours_percentage": round(missing_hours / final_rows * 100, 4) if final_rows else 0.0,
        "negative_load_values_corrected": negative_count,
        "min_load_kw": float(continuous["load_kw"].min()),
        "max_load_kw": float(continuous["load_kw"].max()),
        "mean_load_kw": float(continuous["load_kw"].mean()),
        "zero_load_hours_count": int((continuous["load_kw"] == 0).sum()),
        "notes": "; ".join(notes) if notes else "none",
    }
    return continuous, summary, notes


def build_site_summary(combined: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for site_id, site_df in combined.groupby("site_id", sort=True):
        rows.append(
            {
                "site_id": site_id,
                "start_time": site_df["timestamp"].min(),
                "end_time": site_df["timestamp"].max(),
                "total_hours": len(site_df),
                "observed_hours": int(site_df["load_kw_observed"].notna().sum()),
                "missing_hours": int(site_df["was_missing_hour"].sum()),
                "missing_hours_percentage": round(site_df["was_missing_hour"].mean() * 100, 4),
                "mean_load_kw": float(site_df["load_kw"].mean()),
                "median_load_kw": float(site_df["load_kw"].median()),
                "max_load_kw": float(site_df["load_kw"].max()),
                "total_energy_kwh": float(site_df["load_kw"].sum()),
                "zero_load_hours": int((site_df["load_kw"] == 0).sum()),
                "nonzero_load_hours": int((site_df["load_kw"] > 0).sum()),
            }
        )
    return pd.DataFrame(rows)


def build_peak_summary(combined: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for site_id, site_df in combined.groupby("site_id", sort=True):
        peak_idx = site_df["load_kw"].idxmax()
        peak_load = float(site_df.loc[peak_idx, "load_kw"])
        mean_load = float(site_df["load_kw"].mean())
        rows.append(
            {
                "site_id": site_id,
                "peak_load_kw": peak_load,
                "peak_timestamp": site_df.loc[peak_idx, "timestamp"],
                "mean_load_kw": mean_load,
                "peak_to_mean_ratio": peak_load / mean_load if mean_load else np.nan,
            }
        )
    return pd.DataFrame(rows)


def save_bar_chart(
    df: pd.DataFrame,
    value_column: str,
    title: str,
    ylabel: str,
    output_path: Path,
    value_format: str = "{:.1f}",
) -> None:
    plot_df = df.sort_values(value_column, ascending=False)
    fig, ax = plt.subplots(figsize=(11, 6))
    bars = ax.bar(plot_df["site_id"], plot_df[value_column], color="#2f6f9f")
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.set_xlabel("Site")
    ax.tick_params(axis="x", rotation=35)
    for bar, value in zip(bars, plot_df[value_column]):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),
            value_format.format(value),
            ha="center",
            va="bottom",
            fontsize=9,
        )
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def save_timeseries_sample(combined: pd.DataFrame, output_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(13, 6))
    for site_id, site_df in combined.groupby("site_id", sort=True):
        start = site_df["timestamp"].min()
        sample = site_df.loc[site_df["timestamp"] < start + pd.Timedelta(days=14)]
        ax.plot(sample["timestamp"], sample["load_kw"], linewidth=1.2, label=site_id)
    ax.set_title("Hourly load sample by site: first 14 days")
    ax.set_xlabel("Timestamp")
    ax.set_ylabel("Load (kW)")
    ax.legend(fontsize=8)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def write_text_report(
    standardization_df: pd.DataFrame,
    site_summary_df: pd.DataFrame,
    peak_df: pd.DataFrame,
    warnings: list[str],
) -> None:
    lines = [
        "Step 03 build hourly load report",
        "=" * 33,
        "",
        "Input files used:",
        *(f"- {name}" for name in INPUT_FILES),
        "",
        "Detected column mappings:",
        *(
            f"- {row.source_file}: timestamp='{row.detected_timestamp_column}', "
            f"load='{row.detected_load_column}', notes={row.notes}"
            for row in standardization_df.itertuples(index=False)
        ),
        "",
        "Rows and timestamp coverage per site:",
        *(
            f"- {row.site_id}: {row.total_hours} total hours, "
            f"{row.observed_hours} observed, {row.missing_hours} missing "
            f"({row.missing_hours_percentage:.2f}%), "
            f"{row.start_time} to {row.end_time}"
            for row in site_summary_df.itertuples(index=False)
        ),
        "",
        "Peak load per site:",
        *(
            f"- {row.site_id}: {row.peak_load_kw:.3f} kW at {row.peak_timestamp}; "
            f"mean {row.mean_load_kw:.3f} kW; peak/mean {row.peak_to_mean_ratio:.2f}"
            for row in peak_df.itertuples(index=False)
        ),
        "",
        "Negative load corrections:",
        *(
            f"- {row.site_id}: {row.negative_load_values_corrected}"
            for row in standardization_df.itertuples(index=False)
        ),
        "",
        "Warnings:",
        *(f"- {warning}" for warning in warnings),
        *(["- None"] if not warnings else []),
        "",
        "Suitability for forecasting:",
        "- The standardized hourly dataset is suitable as a forecasting foundation. "
        "Missing hours are explicitly flagged and filled with zero in load_kw, while "
        "load_kw_observed preserves the original observed values for transparency.",
        "",
        "Recommended next step:",
        "- Create the next numbered script for hourly data validation/exploration or "
        "time-based train/test splitting. Do not train models or create scheduling "
        "optimization yet.",
        "",
    ]
    TEXT_REPORT.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)

    standardized_frames: list[pd.DataFrame] = []
    standardization_rows: list[dict[str, Any]] = []
    processed_outputs: list[Path] = []
    warnings: list[str] = []

    for file_name in INPUT_FILES:
        try:
            continuous, summary, notes = standardize_one_file(file_name)
        except Exception as exc:
            warnings.append(f"{file_name}: {type(exc).__name__}: {exc}")
            continue

        standardized_frames.append(continuous)
        standardization_rows.append(summary)
        site_output = PROCESSED_DIR / f"03_hourly_load_{summary['site_id']}.csv"
        continuous.to_csv(site_output, index=False)
        processed_outputs.append(site_output)
        if notes:
            warnings.extend(f"{summary['site_id']}: {note}" for note in notes)

    if not standardized_frames:
        raise RuntimeError("No hourly files were successfully standardized.")

    combined = pd.concat(standardized_frames, ignore_index=True).sort_values(["site_id", "timestamp"])
    combined.to_csv(COMBINED_OUTPUT, index=False)
    processed_outputs.insert(0, COMBINED_OUTPUT)

    standardization_df = pd.DataFrame(standardization_rows)
    site_summary_df = build_site_summary(combined)
    peak_df = build_peak_summary(combined)

    standardization_df.to_csv(STANDARDIZATION_REPORT, index=False)
    site_summary_df.to_csv(SITE_SUMMARY_REPORT, index=False)
    peak_df.to_csv(PEAK_REPORT, index=False)

    save_bar_chart(
        peak_df,
        "peak_load_kw",
        "Peak hourly load by site",
        "Peak load (kW)",
        FIGURES_DIR / "03_peak_load_by_site.png",
    )
    save_bar_chart(
        site_summary_df,
        "mean_load_kw",
        "Mean hourly load by site",
        "Mean load (kW)",
        FIGURES_DIR / "03_mean_load_by_site.png",
    )
    save_bar_chart(
        site_summary_df,
        "missing_hours_percentage",
        "Missing hourly observations by site",
        "Missing hours (%)",
        FIGURES_DIR / "03_missing_hours_by_site.png",
        value_format="{:.2f}",
    )
    save_timeseries_sample(combined, FIGURES_DIR / "03_hourly_load_timeseries_sample.png")
    write_text_report(standardization_df, site_summary_df, peak_df, warnings)

    print("Step 03 hourly load build complete")
    print("==================================")
    print(f"Number of input files loaded: {len(standardized_frames)}")
    print(f"Combined output shape: {combined.shape}")
    print("")
    print("Processed output files:")
    for path in processed_outputs:
        print(f"- {path}")
    print("")
    print(f"Summary report folder: {RESULTS_DIR}")
    print(f"Human-readable report: {TEXT_REPORT}")
    print("")
    print("Warnings:")
    if warnings:
        for warning in warnings:
            print(f"- {warning}")
    else:
        print("- None")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(1)
