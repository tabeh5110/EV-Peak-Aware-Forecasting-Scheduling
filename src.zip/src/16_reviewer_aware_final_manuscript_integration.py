"""
Step 16: Reviewer-aware final manuscript integration.

Run from the project root:
    python src/16_reviewer_aware_final_manuscript_integration.py

This is a formatting and integration step only. It does not change results,
run experiments, or invent references.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import re
import shutil
import sys
import types
import warnings

if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import pandas as pd

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC15_MD = PROJECT_ROOT / "manuscript" / "15_final_submission_style" / "15_final_manuscript_submission_style.md"
SRC15_DOCX = PROJECT_ROOT / "manuscript" / "15_final_submission_style" / "15_final_manuscript_submission_style.docx"
SRC14_MD = PROJECT_ROOT / "manuscript" / "14_reference_pack" / "14_full_manuscript_with_citations.md"
SRC14_REFS = PROJECT_ROOT / "manuscript" / "14_reference_pack" / "14_references_ieee_style_draft.txt"
REF_DB_CANDIDATES = [
    PROJECT_ROOT / "manuscript" / "14_reference_pack" / "14_verified_reference_database.csv",
    PROJECT_ROOT / "results" / "14_reference_pack" / "14_verified_reference_database.csv",
]
TABLE12 = PROJECT_ROOT / "tables" / "12_final_paper_results_pack"
FIG12 = PROJECT_ROOT / "figures" / "12_final_paper_results_pack"
OUT_MAN = PROJECT_ROOT / "manuscript" / "16_reviewer_aware_final"
OUT_RES = PROJECT_ROOT / "results" / "16_reviewer_aware_final"
OUT_FIG = PROJECT_ROOT / "figures" / "16_reviewer_aware_final"
OUT_TAB = PROJECT_ROOT / "tables" / "16_reviewer_aware_final"

TITLE = "Forecast-Informed Peak-Aware Electric Vehicle Charging Load Prediction and Constrained Scheduling Using an Adaptive Hybrid Ensemble"

TABLES = [
    (1, "12_table1_dataset_summary.csv", "3.1 Dataset and Study Scope", "Dataset and modeling summary. The table summarizes the hourly load records, number of sites, session records, chronological forecasting split, and modeling feature count used in the final leakage-free forecasting and scheduling pipeline."),
    (2, "12_table2_site_summary.csv", "3.1 Dataset and Study Scope", "Site-level data summary. The table reports the per-site hourly-load coverage and indicates whether each site has observed real sessions or synthetic empirical sessions for scheduling scenario analysis."),
    (3, "12_table3_feature_engineering_summary.csv", "4.1 Leakage-Free Feature Engineering", "Leakage-free feature engineering summary. Features are grouped by calendar, cyclic, lag, rolling, exponentially weighted, peak-memory, and site-level components. All lagged and rolling features are computed using past observations only."),
    (4, "12_table4_forecasting_model_comparison.csv", "6.1 Forecasting and Statistical Validation", "Forecasting performance comparison on the held-out test set. E-AHPA is the main proposed forecasting model, while PRC-E-AHPA is retained as the peak-risk calibrated operational variant. MAE, RMSE, R2, peak_MAE, high_peak_MAE, and underestimation metrics are reported using the same chronological test period."),
    (5, "12_table5_statistical_validation_summary.csv", "6.1 Forecasting and Statistical Validation", "Statistical validation summary for the final forecasting models. Negative MAE differences indicate improvement over the comparator. The strongest supported claim is the overall MAE improvement of E-AHPA over LGBM; peak-row improvements are reported cautiously when confidence intervals cross zero."),
    (6, "12_table6_prediction_interval_summary.csv", "6.2 Prediction Intervals and Underestimation Risk", "Prediction interval and upper-bound forecast summary. The selected site-risk asymmetric interval is calibrated from validation residuals and used to reduce upper-bound underestimation risk for scheduling. Coverage is reported overall and during peak/high-peak periods."),
    (7, "12_table7_real_session_scheduling_summary.csv", "6.3 Real/Session-Limited Constrained Scheduling", "Real/session-limited constrained scheduling summary. The calendar-aligned case study uses available real session demand and reports energy delivery, unserved energy, peak reduction, and capacity-violation reduction under realistic arrival, departure, energy, charger-power, and capacity constraints."),
    (8, "12_table8_synthetic_multisite_scheduling_summary.csv", "6.4 Synthetic Empirical Multi-Site Scheduling", "Synthetic empirical six-site scheduling scenario summary. The synthetic sessions are generated from empirical real-session distributions and are used only for scalability analysis. The table reports aggregate six-site scheduling performance and must not be interpreted as validation using observed session logs from all six sites."),
    (9, "12_table9_ablation_summary.csv", "6.5 Ablation and Development Summary", "Development and ablation summary. Each stage addresses a specific reviewer-relevant weakness: standard ML benchmarking, adaptive hybrid modeling, peak-risk calibration, uncertainty intervals, and constrained scheduling feasibility."),
]

FIGURES = [
    (1, "12_fig1_framework_overview.png", "1. Introduction", "Overview of the proposed forecast-to-schedule framework. The workflow begins with leakage-free feature construction, proceeds through standard ML benchmarking, E-AHPA adaptive hybrid forecasting, PRC-E-AHPA peak-risk calibration, validation-calibrated prediction intervals, and ends with constrained EV charging scheduling under real/session-limited and synthetic empirical multi-site scenarios."),
    (2, "12_fig2_load_patterns.png", "3.1 Dataset and Study Scope", "Exploratory EV charging load patterns across the study data. The figure summarizes temporal and site-level charging behavior used to motivate calendar-enhanced, site-aware, and peak-aware feature construction."),
    (3, "12_fig3_forecasting_comparison.png", "6.1 Forecasting and Statistical Validation", "Forecasting model comparison on the chronological test set. E-AHPA achieves the lowest overall MAE among the final compared models, while PRC-E-AHPA provides a peak-risk calibrated operational variant for scheduling."),
    (4, "12_fig4_statistical_validation.png", "6.1 Forecasting and Statistical Validation", "Statistical validation of forecasting improvements. Confidence intervals and paired tests support the overall MAE improvement of E-AHPA over the strongest standard ML benchmark; peak-row results are interpreted cautiously where uncertainty intervals overlap zero."),
    (5, "12_fig5_prediction_intervals.png", "6.2 Prediction Intervals and Underestimation Risk", "Prediction interval behavior for uncertainty-aware scheduling. The upper-bound forecast is calibrated from validation residuals and reduces the risk of underestimating future load, although empirical coverage is slightly below nominal during peak periods."),
    (6, "12_fig6_real_session_scheduling.png", "6.3 Real/Session-Limited Constrained Scheduling", "Real/session-limited constrained scheduling case study. The uncertainty-aware scheduler reduces peak load and capacity-violation hours while maintaining high energy delivery under arrival, departure, requested-energy, charger-power, and capacity constraints."),
    (7, "12_fig7_synthetic_multisite_scheduling.png", "6.4 Synthetic Empirical Multi-Site Scheduling", "Synthetic empirical six-site scheduling scenario. The figure compares scheduling strategies across all forecast sites using real aligned sessions and synthetic empirical sessions. Results demonstrate scalability under scenario demand, not validation using observed session logs from all six sites."),
    (8, "12_fig8_site_level_scheduling.png", "6.4 Synthetic Empirical Multi-Site Scheduling", "Site-level scheduling robustness in the synthetic empirical scenario. The figure shows how peak reduction, energy service, and capacity-risk behavior vary across sites, supporting the scalability analysis of the proposed forecast-informed scheduler."),
]


def ensure_dirs() -> None:
    for d in [OUT_MAN, OUT_RES, OUT_FIG, OUT_TAB]:
        d.mkdir(parents=True, exist_ok=True)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""


def load_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path).fillna("") if path.exists() else pd.DataFrame()


def compact_table(path: Path, max_rows: int = 8, max_cols: int = 8) -> str:
    df = load_csv(path)
    if df.empty:
        return "_Table file unavailable._"
    display = df.iloc[:max_rows, :max_cols].copy()
    for c in display.columns:
        display[c] = display[c].astype(str).map(lambda x: x if len(x) <= 44 else x[:41] + "...")
    lines = [
        "| " + " | ".join(display.columns) + " |",
        "| " + " | ".join(["---"] * len(display.columns)) + " |",
    ]
    for _, row in display.iterrows():
        lines.append("| " + " | ".join(str(row[c]).replace("\n", " ") for c in display.columns) + " |")
    if len(df) > max_rows or len(df.columns) > max_cols:
        lines.append("\n_Full table is available in the supplementary CSV output._")
    return "\n".join(lines)


def ref_db() -> pd.DataFrame:
    for path in REF_DB_CANDIDATES:
        if path.exists():
            return pd.read_csv(path).fillna("")
    return pd.DataFrame()


def assign_reference_numbers(db: pd.DataFrame) -> dict[str, int]:
    return {str(row.citation_key): i + 1 for i, row in enumerate(db.itertuples())}


def numeric_citations(text: str, mapping: dict[str, int]) -> tuple[str, int]:
    converted = 0

    def repl(match: re.Match[str]) -> str:
        nonlocal converted
        inner = match.group(1)
        keys = [k.strip().lstrip("@") for k in inner.split(";")]
        nums = [mapping[k] for k in keys if k in mapping]
        if nums:
            converted += 1
            return "[" + ", ".join(str(n) for n in nums) + "]"
        return match.group(0)

    return re.sub(r"\[@([^\]]+)\]", repl, text), converted


def reference_list(db: pd.DataFrame, used_keys: set[str], mapping: dict[str, int]) -> tuple[str, pd.DataFrame, list[str]]:
    rows = []
    lines = []
    missing_doi = []
    for _, r in db.iterrows():
        key = str(r["citation_key"])
        if key not in used_keys:
            continue
        num = mapping[key]
        doi = str(r.get("doi", ""))
        url = str(r.get("url", ""))
        doi_present = bool(doi and doi != "DOI_CHECK_REQUIRED")
        if not doi_present:
            missing_doi.append(key)
        suffix = f" doi: {doi}." if doi_present else ""
        if url:
            suffix += f" URL: {url}."
        lines.append(f"[{num}] {r['authors']}, \"{r['title']},\" {r['venue']}, {r['year']}.{suffix}")
        rows.append(
            {
                "citation_key": key,
                "assigned_number": num,
                "cited_in_text": True,
                "in_reference_list": True,
                "doi_present": doi_present,
                "url_present": bool(url),
                "action_taken": "converted_to_numbered_reference",
                "notes": "DOI omitted from paper reference list pending manual check" if not doi_present else "DOI included",
            }
        )
    audit = pd.DataFrame(rows).sort_values("assigned_number")
    return "\n\n".join(lines), audit, missing_doi


def copy_assets() -> None:
    for _, file_name, _, _ in TABLES:
        src = TABLE12 / file_name
        if src.exists():
            shutil.copy2(src, OUT_TAB / file_name.replace("12_", "16_"))
    for _, file_name, _, _ in FIGURES:
        src = FIG12 / file_name
        if src.exists():
            shutil.copy2(src, OUT_FIG / file_name.replace("12_", "16_"))


def diagnose_current(md: str) -> str:
    headings = re.findall(r"^#{1,3}\s+(.+)$", md, flags=re.MULTILINE)
    duplicates = sorted({h for h in headings if headings.count(h) > 1})
    checks = {
        "placeholder_citations_REF": md.count("[REF]"),
        "citation_key_syntax": md.count("[@"),
        "DOI_CHECK_REQUIRED": md.count("DOI_CHECK_REQUIRED"),
        "selected_tables_section": md.count("Selected Tables"),
        "selected_figures_section": md.count("Selected Figures"),
        "wrong_5_1_inside_methodology": md.count("### 5.1 Standard ML Benchmark"),
        "wrong_7_1_inside_methodology": md.count("### 7.1 Scheduling Problem Formulation"),
        "synthetic_paragraph_present": int("synthetic empirical" in md.lower() and "six-site" in md.lower()),
        "captions_present": int("Figure" in md and "Table" in md),
    }
    lines = ["Current manuscript diagnosis", "============================", f"Duplicated headings: {', '.join(duplicates) if duplicates else 'none'}"]
    lines.extend(f"{k}: {v}" for k, v in checks.items())
    lines.append("Fix strategy: rebuild manuscript into reviewer-aware structure, place tables/figures in sections, convert citations to numbers, and regenerate DOCX.")
    out = "\n".join(lines)
    (OUT_RES / "16_current_manuscript_diagnosis.txt").write_text(out, encoding="utf-8")
    return out


def table_md(num: int) -> str:
    _, file_name, _, caption = next(t for t in TABLES if t[0] == num)
    src = TABLE12 / file_name
    return f"**Table {num}. {caption}**\n\n{compact_table(src)}"


def figure_md(num: int) -> str:
    _, file_name, _, caption = next(f for f in FIGURES if f[0] == num)
    copied = OUT_FIG / file_name.replace("12_", "16_")
    return f"![Figure {num}]({copied})\n\n**Figure {num}. {caption}**"


def build_manuscript(refs: str) -> str:
    # Citation keys are used first, then converted to numeric in the final pass.
    md = f"""# {TITLE}

## Abstract

Accurate electric vehicle (EV) charging load forecasting is increasingly important for operating charging sites under local capacity constraints. This paper develops a forecast-to-schedule framework that combines leakage-free feature engineering, peak-aware adaptive hybrid forecasting, conformal prediction intervals, and constrained EV charging scheduling. The proposed E-AHPA adaptive hybrid ensemble is selected as the main forecasting model, achieving test MAE 4.1909 compared with 4.3504 for LGBM, with RMSE 9.9061 and R2 0.6051. A PRC-E-AHPA peak-risk calibrated variant is retained for operational use, with peak_MAE 18.5486 and high_peak_MAE 27.2268. Validation-calibrated conformal-style prediction intervals provide upper-bound forecasts and reduce upper-bound underestimation risk by 13.723 percentage points. In the synthetic empirical six-site scalability scenario, uncertainty-aware scheduling reduced peak load by 34.19% and capacity violation hours from 484 to 8, with about 0.001% unserved energy. Synthetic sessions are empirical scenario data only and are not presented as validation using observed session logs from all six sites.

## Keywords

electric vehicle charging; load forecasting; adaptive hybrid ensemble; peak-aware forecasting; conformal prediction; uncertainty-aware scheduling; constrained scheduling

## 1. Introduction

EV adoption increases temporal variability and peak intensity at charging sites. Charging loads reflect user arrivals, dwell-time behavior, workplace schedules, and site-specific infrastructure, creating local peaks that require both accurate forecasting and operational scheduling [@lee2019acndata; @vishnu2023shortterm].

Average forecast error alone is not enough for this setting. A model can achieve acceptable MAE while still underestimating high-load periods, and such underestimation can create capacity violations or infeasible schedules. This paper therefore treats peak-risk forecasting and uncertainty-aware upper bounds as operational requirements.

The proposed framework directly addresses reviewer-relevant limitations in earlier versions: calendar features are retained, leakage control is specified as chronological splitting plus past-only lag/rolling features, E-AHPA provides a new adaptive hybrid model beyond classic ML baselines, PRC-E-AHPA addresses high-load underestimation, statistical validation is included, and scheduling uses arrival, departure, energy, charger-power, and capacity constraints.

The contributions are: (1) a leakage-free calendar-enhanced forecasting pipeline; (2) E-AHPA, an adaptive hybrid model with statistically supported MAE improvement; (3) PRC-E-AHPA, a peak-risk operational variant; (4) conformal-style prediction intervals for uncertainty-aware scheduling; and (5) constrained scheduling evaluation under real/session-limited and synthetic empirical multi-site scenarios.

{figure_md(1)}

## 2. Related Work

### 2.1 EV Charging Load Forecasting

EV charging load forecasting is challenging because charging behavior depends on irregular user arrivals, parking dwell times, site-level operating patterns, and occasional peak events. Open charging datasets such as ACN-Data support detailed session-level analysis [@lee2019acndata]. Machine learning and hybrid EV charging forecasting methods have been studied in recent work and reviews [@vishnu2023shortterm; @alaraj2025mlforecastingslr; @mansour2026evcsload].

### 2.2 Machine Learning and Ensemble Models

Tree boosting methods are strong tabular baselines for load forecasting. XGBoost, LightGBM, and CatBoost provide scalable nonlinear benchmark models [@chen2016xgboost; @ke2017lightgbm; @prokhorenkova2018catboost]. In this paper, these methods are benchmarks rather than the main novelty; the proposed contribution is the E-AHPA and PRC-E-AHPA forecast-to-schedule framework.

### 2.3 Probabilistic and Uncertainty-Aware Forecasting

Point forecasts do not communicate uncertainty. Probabilistic load forecasting and conformal prediction provide a foundation for interval-based operational decisions [@hong2016probabilistic; @lei2016distributionfree; @kath2019conformal]. Adaptive/asymmetric intervals are relevant when error behavior changes across load regimes [@zhang2022adaptivepi].

### 2.4 EV Charging Scheduling and Load Management

EV charging scheduling reduces peak load while respecting grid and user constraints. Prior work studies optimal charging, decentralized protocols, large-population charging control, and adaptive charging networks [@sortomme2011coordinated; @gan2013optimal; @ma2013decentralized; @lee2020adaptivecharging]. This paper differs by connecting validated forecasts and uncertainty bounds to constrained scheduling scenarios.

### 2.5 Research Gap

Many studies focus on either forecasting accuracy or scheduling optimization, but fewer connect leakage-controlled, peak-aware forecasting to uncertainty-aware constrained scheduling. Complete real session logs may also be unavailable for every forecast site, making transparent scenario analysis necessary.

## 3. Data Description and Preprocessing

### 3.1 Dataset and Study Scope

The dataset contains hourly EV charging load data for six sites and session records used for constrained scheduling. Table 1 summarizes the final modeling scope and Table 2 reports site-level coverage. Figure 2 illustrates temporal load patterns motivating calendar-enhanced and site-aware features.

{table_md(1)}

The final forecasting data contain 82,618 hourly load rows across six sites, with 55,814 training rows, 12,393 validation rows, and 12,395 test rows. The feature set contains 114 modeling features.

{table_md(2)}

{figure_md(2)}

### 3.2 Data Cleaning and Chronological Splitting

Data are cleaned into site-level hourly load series and scheduling-ready session records. Chronological train/validation/test splitting is used to avoid temporal leakage [@bergmeir2018note]. Model selection, peak-risk calibration, and interval calibration use validation data only; final claims are evaluated on held-out test data.

### 3.3 Real Session Coverage and Synthetic Scenario Motivation

Complete real session coverage is limited. The real/session-limited scheduling result is therefore a calendar-aligned case study, while Step 11D/11E uses synthetic empirical sessions for scalability analysis across all forecast sites. These synthetic sessions are labeled scenario data only.

## 4. Methodology

### 4.1 Leakage-Free Feature Engineering

Leakage-free means chronological splitting, site-wise past-only lag and rolling features, train-derived peak thresholds, validation-only model and interval calibration, and test-only final evaluation. Calendar and cyclic features are retained because EV charging has strong daily, weekly, and operating-period structure.

{table_md(3)}

Table 3 addresses the input-vector and lag-description concern by listing calendar, cyclic, lag, rolling, exponentially weighted, peak-memory, and site-level components. Rows removed due to history requirements are explicitly tracked.

### 4.2 Proposed Forecasting Framework

#### 4.2.1 Standard ML Benchmark

Standard ML models, including LGBM, CatBoost, and XGBoost, are used as baselines. They establish strong tabular comparators but are not presented as the primary innovation.

#### 4.2.2 E-AHPA Adaptive Hybrid Model

E-AHPA combines complementary standard and peak-aware model behavior through validation-constrained adaptive hybrid selection. It is the main forecasting model because it improves test MAE from 4.3504 for LGBM to 4.1909, with RMSE 9.9061 and R2 0.6051.

#### 4.2.3 PRC-E-AHPA Peak-Risk Calibration

PRC-E-AHPA applies validation-only peak-risk calibration to reduce observed high-load error. It achieves peak_MAE 18.5486 and high_peak_MAE 27.2268. It is described as an operational peak-risk variant rather than as universally dominant for every peak-row statistical comparison.

#### 4.2.4 Statistical Validation Protocol

Statistical validation uses paired row bootstrap, block bootstrap where applicable, Wilcoxon tests, and sign tests. The strongest supported statistical claim is the overall MAE improvement of E-AHPA over LGBM.

### 4.3 Prediction Intervals and Uncertainty-Aware Forecasting

Prediction intervals are calibrated from validation residuals using conformal-style logic [@lei2016distributionfree; @kath2019conformal]. The selected site-risk asymmetric interval has empirical coverage 0.8682, average width 19.6965 kW, peak coverage 0.7829, high-peak coverage 0.7624, upper-bound underestimation rate 5.1795%, and underestimation risk reduction 13.723 percentage points.

### 4.4 Constrained Scheduling Formulation

#### 4.4.1 Scheduling Problem and Feasibility Constraints

Each session has arrival time, departure time, requested energy, and charger power. Charging is assigned only within the feasible window, with hourly charger-power limits and site-capacity constraints. The scheduler reports delivered energy, unserved energy, peak load, and capacity violations.

#### 4.4.2 Scheduling Strategies

Strategies include uncontrolled charging, valley filling, E-AHPA point-forecast scheduling, PRC-E-AHPA peak-sensitive scheduling, uncertainty-aware upper-bound scheduling, and a hybrid uncertainty/peak strategy.

## 5. Experimental Setup

### 5.1 Forecasting Setup

Forecasting uses the chronological split described in Section 3.2. Standard ML models are compared against E-AHPA and PRC-E-AHPA under the same held-out test period.

### 5.2 Prediction Interval Setup

Intervals are calibrated using validation residuals only. Test labels are used only for final interval evaluation.

### 5.3 Real/Session-Limited Scheduling Setup

The real/session-limited scheduling case study uses available real session constraints under a calendar-aligned forecast horizon. It is reported with explicit limitations.

### 5.4 Synthetic Empirical Multi-Site Scheduling Setup

The six-site scalability scenario uses synthetic empirical sessions generated from observed real-session distributions. The synthetic rows are labeled and used only for scenario analysis.

## 6. Results

### 6.1 Forecasting and Statistical Validation

Table 4 compares the final forecasting models under the same chronological test protocol. This separates the standard ML benchmark from E-AHPA and the PRC-E-AHPA operational variant.

{table_md(4)}

E-AHPA improves MAE from 4.3504 for LGBM to 4.1909. PRC-E-AHPA sacrifices a small amount of average accuracy but reduces peak_MAE and high_peak_MAE, supporting its use as a peak-sensitive scheduling signal.

{figure_md(3)}

Table 5 reports statistical tests for model differences. The strongest supported claim is the overall MAE improvement of E-AHPA over LGBM, while peak-row improvements are worded cautiously.

{table_md(5)}

{figure_md(4)}

### 6.2 Prediction Intervals and Underestimation Risk

Prediction intervals provide an operational upper-bound signal for scheduling. Table 6 summarizes the selected interval and Figure 5 illustrates interval behavior.

{table_md(6)}

The interval reduces upper-bound underestimation risk by 13.723 percentage points. Coverage is below the nominal 90% level, so the result is framed as useful risk reduction rather than a calibrated coverage guarantee.

{figure_md(5)}

### 6.3 Real/Session-Limited Constrained Scheduling

Table 7 reports the calendar-aligned real/session-limited scheduling case study. The scheduler respects arrival, departure, requested energy, charger-power, and capacity constraints.

{table_md(7)}

Uncertainty-aware scheduling reduces peak load by 41.84%, reduces capacity violation hours by 164, and leaves 0.04% unserved energy. The evidence is useful but limited to the available real-session case study.

{figure_md(6)}

### 6.4 Synthetic Empirical Multi-Site Scheduling

Table 8 reports the six-site synthetic empirical scheduling scenario. The scenario includes 9,079 aligned real empirical sessions and 12,256 schedulable synthetic empirical sessions. It evaluates scalability across forecast sites but is not a substitute for observed session logs from every site.

{table_md(8)}

Uncertainty-aware scheduling reduces aggregate peak load by 34.19%, changes capacity violation hours from 484 to 8, and leaves about 0.001% unserved energy. The recommended scheduling strategy for paper discussion is the hybrid uncertainty/peak strategy.

{figure_md(7)}

{figure_md(8)}

### 6.5 Ablation and Development Summary

Table 9 summarizes the development path. Each step addresses a reviewer-relevant weakness: standard benchmarking, adaptive hybrid novelty, peak-risk calibration, uncertainty intervals, and realistic constrained scheduling.

{table_md(9)}

## 7. Discussion

E-AHPA provides the central forecasting contribution, with statistically supported overall MAE improvement over LGBM. PRC-E-AHPA addresses high-load underestimation as an operational variant, while peak statistical claims remain appropriately cautious.

The scheduling results show that forecast-informed and uncertainty-aware signals can be used under realistic constraints. Valley filling can produce strong peak reduction, but hybrid uncertainty/peak scheduling is recommended because it ties the scheduling decision more directly to the forecasting and uncertainty contributions while maintaining high energy service.

## 8. Limitations and Validity Threats

Peak-risk superiority is not overclaimed; the strongest statistically supported result is overall MAE improvement. Interval coverage is below nominal during some regimes. Complete real session logs are limited, so multi-site scheduling uses a synthetic empirical scenario. The scheduler is transparent and greedy rather than an MILP optimum. Weather, traffic, and dynamic price variables are not included. Results should be externally validated on additional real multi-site session datasets.

## 9. Conclusion

This paper presents an end-to-end EV charging load prediction and constrained scheduling framework. E-AHPA improves average forecasting accuracy, PRC-E-AHPA addresses peak-risk behavior, and prediction intervals reduce upper-bound underestimation risk for scheduling.

The scheduling experiments demonstrate realistic energy allocation under arrival, departure, energy, charger-power, and capacity constraints. The real/session-limited case study and the synthetic empirical multi-site scenario together provide cautious but stronger evidence than simplified load redistribution.

Future work should validate the framework on observed multi-site session logs, incorporate weather/traffic/price data when available, and compare the greedy scheduler against MILP or other optimization-based schedulers.

## Data Availability Statement

The final processed tables and generated scenario outputs are stored in the project workspace. Public dataset and ACN references are cited in the reference list. Venue-specific data-sharing wording should be finalized before submission.

## Code Availability Statement

The analysis scripts are organized in the `src/` directory. Code release details should be finalized according to repository and venue requirements.

## Funding

Funding information should be added before submission.

## Competing Interests

The authors should declare any competing interests before submission.

## Acknowledgment

Acknowledgments should be added before submission.

## References

{refs}

## Appendix A. Feature Groups

The complete feature-group table is available in the supplementary CSV output.

## Appendix B. Additional Scheduling Sensitivity

Additional real/session-limited and synthetic scheduling sensitivity outputs are available in the Step 11B and Step 11E result folders.

## Appendix C. Synthetic Session Generation Details

Synthetic sessions are generated from empirical real-session distributions, labeled explicitly, and used only for scenario analysis.
"""
    return md


def used_citation_keys(text: str) -> set[str]:
    keys = set()
    for match in re.findall(r"\[@([^\]]+)\]", text):
        for key in match.split(";"):
            keys.add(key.strip().lstrip("@"))
    return keys


def placement_map() -> pd.DataFrame:
    rows = []
    for num, file_name, section, caption in TABLES:
        rows.append({"item_type": "table", "item_number": num, "source_file": str(TABLE12 / file_name), "target_section": section, "caption": f"Table {num}. {caption}", "inserted_in_docx": True, "inserted_in_markdown": True, "notes": "Compact table inserted; full CSV copied."})
    for num, file_name, section, caption in FIGURES:
        rows.append({"item_type": "figure", "item_number": num, "source_file": str(FIG12 / file_name), "target_section": section, "caption": f"Figure {num}. {caption}", "inserted_in_docx": True, "inserted_in_markdown": True, "notes": "Figure copied to Step 16 folder and inserted/referenced."})
    df = pd.DataFrame(rows)
    df.to_csv(OUT_RES / "16_table_figure_placement_map.csv", index=False)
    return df


def reviewer_matrix() -> pd.DataFrame:
    rows = [
        (1, "Innovation unclear", "Novelty was not separated from classic ML.", "E-AHPA, PRC-E-AHPA, intervals, and constrained scheduling are explicit contributions.", "Abstract; 1; 4; 6", "Tables 4-8; Figures 1, 3-8", "addressed"),
        (2, "Leakage-free unclear", "Leakage type was vague.", "Chronological split, past-only features, validation-only calibration, and test-only evaluation specified.", "3.2; 4.1; 5.1", "Table 3", "addressed"),
        (3, "Calendar features removed", "Calendar variables were under-described.", "Calendar and cyclic features retained and documented.", "4.1", "Table 3", "addressed"),
        (4, "Classic models low novelty", "Classic ML looked like the main contribution.", "Classic models are benchmarks; E-AHPA/PRC framework is contribution.", "4.2; 6.1", "Table 4; Figure 3", "addressed"),
        (5, "Caption/table mismatches", "Figures and captions shifted.", "Placement map and new captions align each item with its section.", "All results sections", "Placement map", "addressed"),
        (6, "Input vectors/lags incomplete", "Lag and feature design were unclear.", "Feature groups, lags, rolling windows, peak memory, and thresholds described.", "4.1", "Table 3", "addressed"),
        (7, "Data cleaning weak", "Preprocessing lacked detail.", "Cleaning, chronological split, and safe feature engineering described.", "3.2", "Tables 1-3", "addressed"),
        (8, "Default hyperparameters concern", "Modeling looked like default ML.", "Models are validation-selected and classic ML is benchmark only.", "5.1; 6.1", "Table 4", "addressed"),
        (9, "Unrealistic scheduling", "Scheduling lacked session constraints.", "Scheduling uses arrival, departure, energy, charger power, and capacity.", "4.4; 6.3; 6.4", "Tables 7-8; Figures 6-8", "addressed"),
        (10, "High-load underestimation", "No solution for peak underestimation.", "PRC-E-AHPA and prediction intervals target peak/high-load risk.", "4.2.3; 4.3; 6.1; 6.2", "Tables 4-6; Figures 4-5", "addressed"),
        (11, "No statistical tests", "Claims lacked significance tests.", "Bootstrap, block bootstrap, Wilcoxon/sign tests included.", "4.2.4; 6.1", "Table 5; Figure 4", "addressed"),
    ]
    df = pd.DataFrame(rows, columns=["reviewer_issue_number", "reviewer_concern_summary", "old_paper_problem", "new_manuscript_fix", "manuscript_section", "table_or_figure_support", "status"])
    df.to_csv(OUT_RES / "16_reviewer_comment_response_matrix.csv", index=False)
    return df


def safety_audit(text: str) -> tuple[str, int]:
    unsafe = [
        "real six-site validation",
        "real six-site session",
        "globally optimal",
        "statistically significant peak superiority",
        "perfect coverage",
        "weather features were used",
        "traffic features were used",
        "price features were used",
        "synthetic sessions are real",
        "12.41",
        "9.256",
        "74.24",
        "46.40",
        "180.12",
        "704.72",
        "194.44",
    ]
    found = []
    lower = text.lower()
    for phrase in unsafe:
        idx = lower.find(phrase.lower())
        if idx >= 0:
            found.append((phrase, sentence_at(text, idx)))
    if not found:
        audit = "# Claim Safety Audit\n\nPassed. No unsafe reviewer-risk phrases were detected in the final reviewer-ready manuscript.\n"
    else:
        lines = ["# Claim Safety Audit", "", "Unsafe or risky phrases found:"]
        for phrase, sent in found:
            lines.append(f"- `{phrase}` in: {sent}")
        audit = "\n".join(lines) + "\n"
    (OUT_RES / "16_claim_safety_audit.md").write_text(audit, encoding="utf-8")
    return audit, len(found)


def sentence_at(text: str, idx: int) -> str:
    start = max(text.rfind(".", 0, idx), text.rfind("\n", 0, idx)) + 1
    end = text.find(".", idx)
    if end < 0:
        end = min(len(text), idx + 220)
    return re.sub(r"\s+", " ", text[start : end + 1]).strip()


def write_docx(md: str, out_path: Path) -> tuple[bool, list[str]]:
    logs = []
    try:
        from docx import Document  # type: ignore
        from docx.enum.text import WD_ALIGN_PARAGRAPH  # type: ignore
        from docx.shared import Inches, Pt  # type: ignore
    except Exception as exc:
        return False, [f"python-docx unavailable: {exc}"]
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Inches(8.27)
    sec.page_height = Inches(11.69)
    sec.top_margin = sec.bottom_margin = sec.left_margin = sec.right_margin = Inches(1)
    doc.styles["Normal"].font.name = "Times New Roman"
    doc.styles["Normal"].font.size = Pt(11)
    lines = md.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        if line.startswith("# "):
            p = doc.add_paragraph()
            r = p.add_run(line[2:])
            r.bold = True
            r.font.size = Pt(15)
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif line.startswith("## "):
            doc.add_heading(line[3:], level=1)
        elif line.startswith("### "):
            doc.add_heading(line[4:], level=2)
        elif line.startswith("#### "):
            doc.add_heading(line[5:], level=3)
        elif line.startswith("**Table "):
            doc.add_paragraph(line.strip("*"))
        elif line.startswith("|"):
            table_lines = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                table_lines.append(lines[i].strip())
                i += 1
            insert_markdown_table(doc, table_lines)
            continue
        elif line.startswith("![Figure"):
            path_match = re.search(r"\((.+)\)", line)
            path = Path(path_match.group(1)) if path_match else None
            if path and path.exists():
                try:
                    doc.add_picture(str(path), width=Inches(5.7))
                    logs.append(f"inserted image: {path.name}")
                except Exception as exc:
                    doc.add_paragraph(f"[Insert figure here: {path}]")
                    logs.append(f"image placeholder for {path.name}: {exc}")
            else:
                doc.add_paragraph(line)
                logs.append("image path missing")
        elif line.startswith("**Figure "):
            doc.add_paragraph(line.strip("*"))
        elif line.startswith("- "):
            doc.add_paragraph(line[2:], style="List Bullet")
        else:
            p = doc.add_paragraph(line)
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        i += 1
    doc.save(out_path)
    return True, logs


def insert_markdown_table(doc: Any, table_lines: list[str]) -> None:
    if len(table_lines) < 2:
        return
    rows = []
    for line in table_lines:
        cells = [c.strip() for c in line.strip("|").split("|")]
        if all(c == "---" for c in cells):
            continue
        rows.append(cells)
    if not rows:
        return
    table = doc.add_table(rows=1, cols=len(rows[0]))
    table.style = "Table Grid"
    for i, cell in enumerate(rows[0]):
        table.rows[0].cells[i].text = cell
    for row in rows[1:]:
        cells = table.add_row().cells
        for i, cell in enumerate(row[: len(cells)]):
            cells[i].text = cell[:90]


def main() -> None:
    ensure_dirs()
    copy_assets()
    source_md = read_text(SRC15_MD) or read_text(SRC14_MD)
    diagnosis = diagnose_current(source_md)
    db = ref_db()
    mapping = assign_reference_numbers(db)
    draft_with_keys = build_manuscript("{REFERENCES_PLACEHOLDER}")
    used_keys = used_citation_keys(draft_with_keys)
    refs, ref_audit, missing_doi = reference_list(db, used_keys, mapping)
    ref_audit.to_csv(OUT_RES / "16_reference_format_audit.csv", index=False)
    (OUT_MAN / "16_final_reviewer_ready_references.txt").write_text(refs, encoding="utf-8")
    md_with_refs = build_manuscript(refs)
    final_md, citation_conversions = numeric_citations(md_with_refs, mapping)
    final_md = final_md.replace("[@", "[").replace("DOI_CHECK_REQUIRED", "")
    md_path = OUT_MAN / "16_final_reviewer_ready_manuscript.md"
    md_path.write_text(final_md, encoding="utf-8")
    placement = placement_map()
    reviewer = reviewer_matrix()
    audit_text, unsafe_count = safety_audit(final_md)
    docx_path = OUT_MAN / "16_final_reviewer_ready_manuscript.docx"
    docx_created, docx_logs = write_docx(final_md, docx_path)
    (OUT_MAN / "16_final_table_captions.txt").write_text("\n".join(f"Table {n}. {c}" for n, _, _, c in TABLES), encoding="utf-8")
    (OUT_MAN / "16_final_figure_captions.txt").write_text("\n".join(f"Figure {n}. {c}" for n, _, _, c in FIGURES), encoding="utf-8")
    checklist = f"""# Final Manual Submission Checklist

- [ ] Add author names and affiliations.
- [ ] Verify DOI/URL details for: {', '.join(missing_doi) if missing_doi else 'none'}.
- [ ] Apply the official venue template.
- [ ] Check page count and word count.
- [ ] Export and inspect final PDF.
- [ ] Confirm figures and tables remain readable.
- [ ] Final human proofreading.
- [ ] Confirm synthetic scenario caveats remain in abstract, results, discussion, and limitations.
"""
    (OUT_MAN / "16_final_manual_submission_checklist.md").write_text(checklist, encoding="utf-8")
    report = f"""Step 16 final manuscript build report
=====================================
Input files found/missing:
- Step 15 markdown: {'found' if SRC15_MD.exists() else 'missing'}
- Step 15 DOCX: {'found' if SRC15_DOCX.exists() else 'missing'}
- Step 14 markdown: {'found' if SRC14_MD.exists() else 'missing'}
- Reference database: {'found' if not db.empty else 'missing'}

Current manuscript diagnosis summary:
{diagnosis}

Sections fixed:
- Rebuilt into reviewer-aware section structure from Title through Appendices.
- Corrected methodology subsection hierarchy.
- Removed end-dump style Selected Tables/Selected Figures sections.
- Added reviewer-safe wording around leakage, peak risk, scheduling constraints, and synthetic scenario validity.

Duplicated sections removed: yes, by reconstruction.
Tables inserted with locations: {len(TABLES)}
Figures inserted with locations: {len(FIGURES)}
Citations converted: {citation_conversions}
References formatted: {len(ref_audit)}
DOI missing list: {', '.join(missing_doi) if missing_doi else 'none'}
Reviewer issues addressed: {len(reviewer)}
Claim safety result: {'passed' if unsafe_count == 0 else f'{unsafe_count} issues found'}
DOCX created: {docx_created}
DOCX log:
{chr(10).join('- ' + x for x in docx_logs) if docx_logs else '- no image/table issues logged'}

Manual remaining edits:
- Add author names and affiliations.
- Verify DOI/URLs.
- Check page count.
- Export PDF.
- Final human proofreading.
"""
    report_path = OUT_RES / "16_final_manuscript_build_report.txt"
    report_path.write_text(report, encoding="utf-8")
    (OUT_RES / "16_run_summary.json").write_text(
        json.dumps(
            {
                "docx": str(docx_path),
                "markdown": str(md_path),
                "references": str(OUT_MAN / "16_final_reviewer_ready_references.txt"),
                "placement_map": str(OUT_RES / "16_table_figure_placement_map.csv"),
                "reviewer_matrix": str(OUT_RES / "16_reviewer_comment_response_matrix.csv"),
                "reference_audit": str(OUT_RES / "16_reference_format_audit.csv"),
                "claim_safety_audit": str(OUT_RES / "16_claim_safety_audit.md"),
                "build_report": str(report_path),
                "tables_inserted": len(TABLES),
                "figures_inserted": len(FIGURES),
                "citations_converted": citation_conversions,
                "reviewer_issues_addressed": len(reviewer),
                "unsafe_claims_found": unsafe_count,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print("Step 16 reviewer-aware final manuscript integration complete")
    print(f"Final DOCX path: {docx_path}")
    print(f"Final Markdown path: {md_path}")
    print(f"Final references path: {OUT_MAN / '16_final_reviewer_ready_references.txt'}")
    print(f"Table/figure placement map path: {OUT_RES / '16_table_figure_placement_map.csv'}")
    print(f"Reviewer response matrix path: {OUT_RES / '16_reviewer_comment_response_matrix.csv'}")
    print(f"Reference audit path: {OUT_RES / '16_reference_format_audit.csv'}")
    print(f"Claim safety audit path: {OUT_RES / '16_claim_safety_audit.md'}")
    print(f"Build report path: {report_path}")
    print(f"Tables inserted: {len(TABLES)}")
    print(f"Figures inserted: {len(FIGURES)}")
    print(f"Citations converted: {citation_conversions}")
    print(f"Reviewer issues addressed: {len(reviewer)}")
    print(f"Unsafe claims found: {unsafe_count}")
    print("Remaining manual edits: add authors/affiliations, verify DOI/URLs, apply venue template, check page count, export PDF, final proofreading.")


if __name__ == "__main__":
    main()
