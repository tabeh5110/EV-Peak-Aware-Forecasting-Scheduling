"""
Step 08F: Peak-Specialized Enhanced Adaptive Hybrid Peak-Aware Ensemble.

Run from the project root:
    python src/08F_peak_specialized_two_stage_ensemble.py

This step makes a final validation-only attempt to improve peak/high-peak
forecasting. It trains peak-risk gates and peak-specialist regressors on the
train split, selects two-stage ensembles on validation, and evaluates the
selected fixed candidate once on test.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import importlib
import json
import re
import sys
import time
import types
import warnings

import numpy as np


if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
FEATURE_FILE = PROJECT_ROOT / "data" / "processed" / "05B_forecasting_features.csv"
FEATURE_COLUMNS_FILE = PROJECT_ROOT / "results" / "05B_fix_feature_engineering" / "05B_modeling_feature_columns.txt"

ML_METRICS_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_ml_overall_metrics.csv"
ML_VAL_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_validation_predictions.csv"
ML_TEST_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_test_predictions.csv"
EAHPA_VAL_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_validation_predictions.csv"
EAHPA_TEST_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_test_predictions.csv"
EAHPA_SUMMARY_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_selected_hybrid_summary.csv"
PRC_VAL_FILE = PROJECT_ROOT / "results" / "08E_peak_risk_calibrated_eahpa" / "08E_validation_predictions.csv"
PRC_TEST_FILE = PROJECT_ROOT / "results" / "08E_peak_risk_calibrated_eahpa" / "08E_test_predictions.csv"
PRC_METRICS_FILE = PROJECT_ROOT / "results" / "08E_peak_risk_calibrated_eahpa" / "08E_prc_eahpa_overall_metrics.csv"

RESULTS_DIR = PROJECT_ROOT / "results" / "08F_peak_specialized_two_stage_ensemble"
FIGURES_DIR = PROJECT_ROOT / "figures" / "08F_peak_specialized_two_stage_ensemble"
MODELS_DIR = PROJECT_ROOT / "models" / "08F_peak_specialized_two_stage_ensemble"

TARGET = "target_load_kw"
ACTUAL = "actual_load_kw"
KEYS = ["timestamp", "site_id", "actual_load_kw"]
RANDOM_STATE = 42
N_BOOTSTRAP = 1000

BASE_RISK_FEATURES = [
    "lag_1h",
    "lag_2h",
    "lag_3h",
    "lag_6h",
    "lag_12h",
    "lag_24h",
    "lag_48h",
    "lag_72h",
    "lag_168h",
    "lag_336h",
    "rolling_mean_6h",
    "rolling_mean_12h",
    "rolling_mean_24h",
    "rolling_mean_168h",
    "rolling_std_24h",
    "rolling_std_168h",
    "rolling_max_24h",
    "rolling_max_168h",
    "rolling_q75_24h",
    "rolling_q90_24h",
    "rolling_q95_24h",
    "rolling_q75_168h",
    "rolling_q90_168h",
    "rolling_q95_168h",
    "recent_peak_24h_count",
    "recent_peak_168h_count",
    "recent_peak_24h_flag",
    "recent_peak_168h_flag",
    "hours_since_recent_peak_90",
    "hour",
    "day_of_week",
    "month",
    "is_weekend",
    "is_business_hour",
    "is_morning_arrival_period",
    "is_evening_departure_period",
    "site_id_encoded",
    "peak_threshold_90_train_kw",
    "peak_threshold_95_train_kw",
]
DERIVED_RISK_FEATURES = [
    "risk_eahpa_vs_p90",
    "risk_eahpa_vs_p95",
    "risk_lgbm_vs_p90",
    "risk_lag24_vs_p90",
    "risk_lag168_vs_p90",
    "risk_rollmax24_vs_p90",
    "risk_rollmax168_vs_p90",
    "risk_rollq90_24_vs_p90",
    "risk_rollq90_168_vs_p90",
    "risk_recent_peak24_norm",
    "risk_recent_peak168_norm",
    "risk_gap_eahpa_lgbm",
    "risk_gap_prc_eahpa",
    "risk_combined_mean",
    "risk_business_interaction",
    "risk_morning_interaction",
    "risk_recent_peak_interaction",
]


def ensure_dirs() -> None:
    for folder in [RESULTS_DIR, FIGURES_DIR, MODELS_DIR]:
        folder.mkdir(parents=True, exist_ok=True)


def package(name: str) -> tuple[bool, Any]:
    try:
        return True, importlib.import_module(name)
    except Exception:
        return False, None


def scipy_tools() -> tuple[bool, Any]:
    return package("scipy.stats")


def clip(values: Any) -> np.ndarray:
    return np.maximum(np.asarray(values, dtype=float), 0.0)


def safe_div(num: pd.Series, den: pd.Series) -> pd.Series:
    return num.astype(float) / den.replace(0, np.nan).astype(float)


def mae(a: np.ndarray, p: np.ndarray) -> float:
    return float(np.mean(np.abs(p - a))) if len(a) else np.nan


def rmse(a: np.ndarray, p: np.ndarray) -> float:
    return float(np.sqrt(np.mean((p - a) ** 2))) if len(a) else np.nan


def r2(a: np.ndarray, p: np.ndarray) -> float:
    if len(a) == 0:
        return np.nan
    ss_res = float(np.sum((a - p) ** 2))
    ss_tot = float(np.sum((a - np.mean(a)) ** 2))
    return 1 - ss_res / ss_tot if ss_tot else np.nan


def rate(mask: np.ndarray) -> float:
    return float(np.mean(mask) * 100) if len(mask) else np.nan


def evaluate(df: pd.DataFrame, model_name: str, pred_col: str, split: str) -> dict[str, Any]:
    a = df[ACTUAL].to_numpy(float)
    p = clip(df[pred_col])
    peak = df["is_peak_hour"].to_numpy(int) == 1
    high = df["is_high_peak_hour"].to_numpy(int) == 1
    q90, q95 = np.nanquantile(a, [0.90, 0.95])
    top10 = a >= q90
    top5 = a >= q95
    max_idx = int(np.argmax(a)) if len(a) else 0
    return {
        "model_name": model_name,
        "split": split,
        "MAE": mae(a, p),
        "RMSE": rmse(a, p),
        "R2": r2(a, p),
        "MBE": float(np.mean(p - a)) if len(a) else np.nan,
        "underestimation_rate": rate(p < a),
        "overestimation_rate": rate(p > a),
        "peak_MAE": mae(a[peak], p[peak]),
        "high_peak_MAE": mae(a[high], p[high]),
        "peak_RMSE": rmse(a[peak], p[peak]),
        "high_peak_RMSE": rmse(a[high], p[high]),
        "peak_underestimation_rate": rate(p[peak] < a[peak]),
        "high_peak_underestimation_rate": rate(p[high] < a[high]),
        "peak_bias": float(np.mean(p[peak] - a[peak])) if peak.any() else np.nan,
        "high_peak_bias": float(np.mean(p[high] - a[high])) if high.any() else np.nan,
        "peak_overestimation_rate": rate(p[peak] > a[peak]),
        "high_peak_overestimation_rate": rate(p[high] > a[high]),
        "top_10_percent_actual_peak_MAE": mae(a[top10], p[top10]),
        "top_5_percent_actual_peak_MAE": mae(a[top5], p[top5]),
        "actual_max_load_kw": float(a[max_idx]) if len(a) else np.nan,
        "predicted_load_at_actual_max_kw": float(p[max_idx]) if len(a) else np.nan,
        "actual_max_underprediction_kw": float(a[max_idx] - p[max_idx]) if len(a) else np.nan,
        "row_count": len(df),
        "peak_row_count": int(peak.sum()),
        "high_peak_row_count": int(high.sum()),
    }


def selected_eahpa_column() -> tuple[str, str]:
    summary = pd.read_csv(EAHPA_SUMMARY_FILE)
    primary = summary[summary["selection_role"] == "primary_selected_AHPA_Ensemble"]
    if primary.empty:
        primary = summary.head(1)
    name = str(primary.iloc[0]["selected_model_name"])
    return name, f"prediction_{name}"


def add_actual(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if ACTUAL not in out.columns:
        out[ACTUAL] = out[TARGET]
    out["timestamp"] = out["timestamp"].astype(str)
    return out


def prediction_columns(df: pd.DataFrame) -> list[str]:
    return [c for c in df.columns if c.startswith("prediction_")]


def align_prediction(base: pd.DataFrame, path: Path, source: str, col: str, out_col: str) -> tuple[pd.DataFrame, dict[str, Any]]:
    row = {
        "source": source,
        "file": str(path),
        "file_exists": path.exists(),
        "requested_column": col,
        "prediction_columns_found": "",
        "rows": 0,
        "matched_rows": 0,
        "notes": "",
    }
    if not path.exists():
        row["notes"] = "missing"
        return base, row
    pred = add_actual(pd.read_csv(path))
    row["rows"] = len(pred)
    row["prediction_columns_found"] = ", ".join(prediction_columns(pred))
    if col not in pred.columns:
        row["notes"] = "requested column missing"
        return base, row
    merge = pred[KEYS + [col]].rename(columns={col: out_col})
    out = base.merge(merge, on=KEYS, how="left")
    if out_col not in out.columns:
        y_col = f"{out_col}_y"
        x_col = f"{out_col}_x"
        if y_col in out.columns:
            out[out_col] = out[y_col]
            if x_col in out.columns:
                out[out_col] = out[out_col].fillna(out[x_col])
            out = out.drop(columns=[c for c in [x_col, y_col] if c in out.columns])
    row["matched_rows"] = int(out[out_col].notna().sum())
    row["notes"] = "loaded"
    return out, row


def load_data() -> tuple[pd.DataFrame, list[str], list[dict[str, Any]], str]:
    features = add_actual(pd.read_csv(FEATURE_FILE))
    feature_cols = [x.strip() for x in FEATURE_COLUMNS_FILE.read_text(encoding="utf-8").splitlines() if x.strip()]
    if "site_id_encoded" not in features.columns:
        features["site_id_encoded"] = pd.factorize(features["site_id"])[0]
    if "peak_threshold_90_train_kw" not in features.columns or "peak_threshold_95_train_kw" not in features.columns:
        train = features[features["split"] == "train"]
        p90 = train.groupby("site_id")[TARGET].quantile(0.90).to_dict()
        p95 = train.groupby("site_id")[TARGET].quantile(0.95).to_dict()
        features["peak_threshold_90_train_kw"] = features["site_id"].map(p90).fillna(train[TARGET].quantile(0.90))
        features["peak_threshold_95_train_kw"] = features["site_id"].map(p95).fillna(train[TARGET].quantile(0.95))
    eahpa_name, eahpa_col = selected_eahpa_column()
    rows: list[dict[str, Any]] = []
    data = features.copy()
    for path, source, split, col, out_col in [
        (EAHPA_VAL_FILE, "08D E-AHPA validation", "validation", eahpa_col, "eahpa_pred"),
        (EAHPA_TEST_FILE, "08D E-AHPA test", "test", eahpa_col, "eahpa_pred"),
        (ML_VAL_FILE, "07 LGBM validation", "validation", "prediction_LGBMRegressor", "lgbm_pred"),
        (ML_TEST_FILE, "07 LGBM test", "test", "prediction_LGBMRegressor", "lgbm_pred"),
        (ML_VAL_FILE, "07 CatBoost validation", "validation", "prediction_CatBoostRegressor", "catboost_pred"),
        (ML_TEST_FILE, "07 CatBoost test", "test", "prediction_CatBoostRegressor", "catboost_pred"),
        (ML_VAL_FILE, "07 XGB validation", "validation", "prediction_XGBRegressor", "xgb_pred"),
        (ML_TEST_FILE, "07 XGB test", "test", "prediction_XGBRegressor", "xgb_pred"),
        (PRC_VAL_FILE, "08E PRC validation", "validation", "prc_eahpa_pred", "prc_pred"),
        (PRC_TEST_FILE, "08E PRC test", "test", "prc_eahpa_pred", "prc_pred"),
    ]:
        base = data[data["split"] == split].copy()
        aligned, row = align_prediction(base, path, source, col, out_col)
        rows.append(row)
        data = data.merge(aligned[KEYS + ["split", out_col]], on=KEYS + ["split"], how="left", suffixes=("", "_dup"))
        dup = f"{out_col}_dup"
        if dup in data.columns:
            data[out_col] = data[out_col].fillna(data[dup])
            data = data.drop(columns=[dup])
    data = make_risk_features(data)
    pd.DataFrame(rows).to_csv(RESULTS_DIR / "08F_alignment_report.csv", index=False)
    return data, feature_cols, rows, eahpa_name


def make_risk_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    defaults = {
        "rolling_max_24h": "rolling_q95_24h",
        "rolling_max_168h": "rolling_q95_168h",
        "rolling_std_24h": "rolling_mean_24h",
        "rolling_std_168h": "rolling_mean_168h",
        "lag_2h": "lag_1h",
        "lag_3h": "lag_1h",
        "lag_6h": "lag_1h",
        "lag_12h": "lag_24h",
        "lag_48h": "lag_24h",
        "lag_72h": "lag_24h",
        "lag_336h": "lag_168h",
        "rolling_mean_6h": "rolling_mean_24h",
        "rolling_mean_12h": "rolling_mean_24h",
    }
    for col, fallback in defaults.items():
        if col not in out.columns:
            out[col] = out[fallback] if fallback in out.columns else 0.0
    for col in BASE_RISK_FEATURES:
        if col not in out.columns:
            out[col] = 0.0
    p90 = out["peak_threshold_90_train_kw"]
    p95 = out["peak_threshold_95_train_kw"]
    for pred_col in ["eahpa_pred", "lgbm_pred", "prc_pred"]:
        if pred_col not in out.columns:
            out[pred_col] = np.nan
    out["risk_eahpa_vs_p90"] = safe_div(out["eahpa_pred"].fillna(out["lag_1h"]), p90)
    out["risk_eahpa_vs_p95"] = safe_div(out["eahpa_pred"].fillna(out["lag_1h"]), p95)
    out["risk_lgbm_vs_p90"] = safe_div(out["lgbm_pred"].fillna(out["lag_1h"]), p90)
    out["risk_lag24_vs_p90"] = safe_div(out["lag_24h"], p90)
    out["risk_lag168_vs_p90"] = safe_div(out["lag_168h"], p90)
    out["risk_rollmax24_vs_p90"] = safe_div(out["rolling_max_24h"], p90)
    out["risk_rollmax168_vs_p90"] = safe_div(out["rolling_max_168h"], p90)
    out["risk_rollq90_24_vs_p90"] = safe_div(out["rolling_q90_24h"], p90)
    out["risk_rollq90_168_vs_p90"] = safe_div(out["rolling_q90_168h"], p90)
    out["risk_recent_peak24_norm"] = out["recent_peak_24h_count"].astype(float) / 24.0
    out["risk_recent_peak168_norm"] = out["recent_peak_168h_count"].astype(float) / 168.0
    out["risk_gap_eahpa_lgbm"] = out["eahpa_pred"].fillna(0) - out["lgbm_pred"].fillna(0)
    out["risk_gap_prc_eahpa"] = out["prc_pred"].fillna(out["eahpa_pred"]).fillna(0) - out["eahpa_pred"].fillna(0)
    ratio_cols = [
        "risk_eahpa_vs_p90",
        "risk_eahpa_vs_p95",
        "risk_lgbm_vs_p90",
        "risk_lag24_vs_p90",
        "risk_lag168_vs_p90",
        "risk_rollmax24_vs_p90",
        "risk_rollmax168_vs_p90",
        "risk_rollq90_24_vs_p90",
        "risk_rollq90_168_vs_p90",
        "risk_recent_peak24_norm",
        "risk_recent_peak168_norm",
        "recent_peak_24h_flag",
        "recent_peak_168h_flag",
    ]
    out["risk_combined_mean"] = out[ratio_cols].replace([np.inf, -np.inf], np.nan).fillna(0).mean(axis=1)
    out["risk_business_interaction"] = out["risk_combined_mean"] * out["is_business_hour"]
    out["risk_morning_interaction"] = out["risk_combined_mean"] * out["is_morning_arrival_period"]
    out["risk_recent_peak_interaction"] = out["risk_combined_mean"] * out["recent_peak_24h_flag"]
    for col in BASE_RISK_FEATURES + DERIVED_RISK_FEATURES:
        out[col] = out[col].replace([np.inf, -np.inf], np.nan).fillna(0)
    return out


def gate_features() -> list[str]:
    return [c for c in BASE_RISK_FEATURES + ["risk_lag24_vs_p90", "risk_lag168_vs_p90", "risk_rollmax24_vs_p90", "risk_rollmax168_vs_p90", "risk_rollq90_24_vs_p90", "risk_rollq90_168_vs_p90", "risk_recent_peak24_norm", "risk_recent_peak168_norm", "risk_business_interaction", "risk_morning_interaction", "risk_recent_peak_interaction"]]


def train_gates(train: pd.DataFrame, val: pd.DataFrame, test: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    rows, fi_rows = [], []
    val_pred = val[["timestamp", "site_id", ACTUAL, "split", "is_peak_hour", "is_high_peak_hour"]].copy()
    test_pred = test[["timestamp", "site_id", ACTUAL, "split", "is_peak_hour", "is_high_peak_hour"]].copy()
    try:
        from sklearn.ensemble import GradientBoostingClassifier, HistGradientBoostingClassifier, RandomForestClassifier
        from sklearn.linear_model import LogisticRegression
        from sklearn.metrics import average_precision_score, balanced_accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
    except Exception as exc:
        fallback = val["risk_combined_mean"].rank(pct=True).to_numpy(float)
        val_pred["gate_peak_rule_risk"] = fallback
        test_pred["gate_peak_rule_risk"] = test["risk_combined_mean"].rank(pct=True).to_numpy(float)
        rows.append({"gate_name": "rule_risk", "target": "peak", "status": "fallback", "error": repr(exc)})
        return pd.DataFrame(rows), val_pred, test_pred, pd.DataFrame(fi_rows)
    X_train = train[gate_features()].replace([np.inf, -np.inf], np.nan).fillna(0)
    X_val = val[gate_features()].replace([np.inf, -np.inf], np.nan).fillna(0)
    X_test = test[gate_features()].replace([np.inf, -np.inf], np.nan).fillna(0)
    specs = [
        ("logistic", make_pipeline(StandardScaler(), LogisticRegression(class_weight="balanced", max_iter=500, random_state=RANDOM_STATE))),
        ("rf", RandomForestClassifier(class_weight="balanced", n_estimators=120, max_depth=10, min_samples_leaf=5, n_jobs=1, random_state=RANDOM_STATE)),
        ("gbc", GradientBoostingClassifier(n_estimators=120, learning_rate=0.05, max_depth=3, random_state=RANDOM_STATE)),
        ("histgb", HistGradientBoostingClassifier(max_iter=120, learning_rate=0.05, max_leaf_nodes=31, random_state=RANDOM_STATE)),
    ]
    for target_col, target_name in [("is_peak_hour", "peak"), ("is_high_peak_hour", "high_peak")]:
        y_train = train[target_col].astype(int)
        y_val = val[target_col].astype(int)
        for name, model in specs:
            gate_name = f"{name}_{target_name}"
            try:
                start = time.time()
                model.fit(X_train, y_train)
                prob_val = model.predict_proba(X_val)[:, 1] if hasattr(model, "predict_proba") else model.decision_function(X_val)
                prob_test = model.predict_proba(X_test)[:, 1] if hasattr(model, "predict_proba") else model.decision_function(X_test)
                prob_val = np.asarray(prob_val, dtype=float)
                prob_test = np.asarray(prob_test, dtype=float)
                if prob_val.max() > prob_val.min():
                    prob_val = (prob_val - prob_val.min()) / (prob_val.max() - prob_val.min())
                    prob_test = (prob_test - prob_val.min()) / max(prob_val.max() - prob_val.min(), 1e-9)
                pred_label = prob_val >= 0.5
                rows.append(
                    {
                        "gate_name": gate_name,
                        "target": target_name,
                        "ROC_AUC": roc_auc_score(y_val, prob_val) if y_val.nunique() > 1 else np.nan,
                        "PR_AUC": average_precision_score(y_val, prob_val) if y_val.nunique() > 1 else np.nan,
                        "precision": precision_score(y_val, pred_label, zero_division=0),
                        "recall": recall_score(y_val, pred_label, zero_division=0),
                        "F1": f1_score(y_val, pred_label, zero_division=0),
                        "balanced_accuracy": balanced_accuracy_score(y_val, pred_label),
                        "capture_top_10pct": float(y_val[prob_val >= np.quantile(prob_val, 0.90)].mean() * 100),
                        "training_time_seconds": time.time() - start,
                        "status": "success",
                        "error": "",
                    }
                )
                val_pred[f"gate_{gate_name}"] = clip(prob_val)
                test_pred[f"gate_{gate_name}"] = clip(prob_test)
                importances = getattr(model, "feature_importances_", None)
                if importances is not None:
                    for feat, imp in zip(gate_features(), importances):
                        fi_rows.append({"gate_name": gate_name, "feature": feat, "importance": float(imp)})
            except Exception as exc:
                rows.append({"gate_name": gate_name, "target": target_name, "status": "failed", "error": repr(exc)})
    if not any(c.startswith("gate_") for c in val_pred.columns):
        val_pred["gate_peak_rule_risk"] = val["risk_combined_mean"].rank(pct=True).to_numpy(float)
        test_pred["gate_peak_rule_risk"] = test["risk_combined_mean"].rank(pct=True).to_numpy(float)
    return pd.DataFrame(rows), val_pred, test_pred, pd.DataFrame(fi_rows)


def specialist_features(feature_cols: list[str], train: pd.DataFrame) -> list[str]:
    cols = [c for c in feature_cols if c in train.columns]
    return cols


def train_specialists(train: pd.DataFrame, val: pd.DataFrame, test: pd.DataFrame, feature_cols: list[str]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    rows, errors = [], []
    val_pred = val[["timestamp", "site_id", ACTUAL, "split", "is_peak_hour", "is_high_peak_hour"]].copy()
    test_pred = test[["timestamp", "site_id", ACTUAL, "split", "is_peak_hour", "is_high_peak_hour"]].copy()
    feats = specialist_features(feature_cols, train)
    X_train_all = train[feats].replace([np.inf, -np.inf], np.nan).fillna(0)
    X_val = val[feats].replace([np.inf, -np.inf], np.nan).fillna(0)
    X_test = test[feats].replace([np.inf, -np.inf], np.nan).fillna(0)
    y_train = train[TARGET].to_numpy(float)
    weights = np.ones(len(train))
    weights[train["is_peak_hour"].to_numpy(int) == 1] = 3.0
    weights[train["is_high_peak_hour"].to_numpy(int) == 1] = 5.0
    specs: list[tuple[str, Any]] = []
    try:
        from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor, HistGradientBoostingRegressor
        specs.extend(
            [
                ("ExtraTrees_weighted", ExtraTreesRegressor(n_estimators=160, max_depth=14, min_samples_leaf=3, max_features=0.7, n_jobs=1, random_state=RANDOM_STATE)),
                ("GBR_weighted", GradientBoostingRegressor(n_estimators=180, learning_rate=0.04, max_depth=3, subsample=0.8, random_state=RANDOM_STATE)),
                ("HistGB_weighted", HistGradientBoostingRegressor(max_iter=220, learning_rate=0.03, max_leaf_nodes=31, l2_regularization=0.1, random_state=RANDOM_STATE)),
            ]
        )
    except Exception as exc:
        errors.append({"model_name": "sklearn_specialists", "strategy": "import", "status": "failed", "error": repr(exc)})
    ok_lgb, lgb = package("lightgbm")
    if ok_lgb:
        specs.append(("LGBM_weighted", lgb.LGBMRegressor(n_estimators=300, learning_rate=0.04, num_leaves=31, reg_lambda=1.0, subsample=0.8, colsample_bytree=0.8, random_state=RANDOM_STATE, n_jobs=1, verbose=-1)))
    ok_xgb, xgb = package("xgboost")
    if ok_xgb:
        specs.append(("XGB_weighted", xgb.XGBRegressor(n_estimators=300, learning_rate=0.04, max_depth=4, reg_lambda=1.0, subsample=0.8, colsample_bytree=0.8, random_state=RANDOM_STATE, n_jobs=1, objective="reg:squarederror")))
    ok_cat, cat = package("catboost")
    if ok_cat:
        specs.append(("CatBoost_weighted", cat.CatBoostRegressor(iterations=300, learning_rate=0.04, depth=6, random_seed=RANDOM_STATE, verbose=False, allow_writing_files=False)))
    peak_idx = train.index[train["is_peak_hour"] == 1].to_numpy()
    normal_idx = train.index[train["is_peak_hour"] == 0].to_numpy()
    rng = np.random.default_rng(RANDOM_STATE)
    if len(peak_idx) and len(normal_idx):
        sample_normal = rng.choice(normal_idx, size=min(len(normal_idx), len(peak_idx) * 2), replace=False)
        subset_idx = np.concatenate([peak_idx, sample_normal])
        try:
            from sklearn.ensemble import ExtraTreesRegressor
            specs.append(("ExtraTrees_peak_subset_2x", ExtraTreesRegressor(n_estimators=160, max_depth=14, min_samples_leaf=2, max_features=0.7, n_jobs=1, random_state=RANDOM_STATE)))
        except Exception:
            subset_idx = np.array([], dtype=int)
    else:
        subset_idx = np.array([], dtype=int)
    joblib_ok, joblib = package("joblib")
    for model_name, model in specs:
        strategy = "peak_subset" if "subset" in model_name else "weighted_all_train"
        try:
            start = time.time()
            if strategy == "peak_subset" and len(subset_idx):
                local_pos = train.index.get_indexer(subset_idx)
                X_fit = X_train_all.iloc[local_pos]
                y_fit = train.loc[subset_idx, TARGET].to_numpy(float)
                model.fit(X_fit, y_fit)
            else:
                try:
                    model.fit(X_train_all, y_train, sample_weight=weights)
                except TypeError:
                    model.fit(X_train_all, y_train)
            val_col = f"prediction_{model_name}"
            test_col = val_col
            val_pred[val_col] = clip(model.predict(X_val))
            test_pred[test_col] = clip(model.predict(X_test))
            m = evaluate(val_pred.assign(tmp=val_pred[val_col]), model_name, "tmp", "validation")
            m.update({"strategy": strategy, "training_time_seconds": time.time() - start, "status": "success"})
            rows.append(m)
            if joblib_ok:
                joblib.dump(model, MODELS_DIR / f"08F_{model_name}.joblib")
        except Exception as exc:
            errors.append({"model_name": model_name, "strategy": strategy, "status": "failed", "error": repr(exc)})
    return pd.DataFrame(rows), val_pred, test_pred, pd.DataFrame(errors)


def add_candidate(rows: list[dict[str, Any]], store: dict[str, dict[str, np.ndarray]], name: str, strategy: str, meta: dict[str, Any], val: pd.DataFrame, pred_val: np.ndarray, pred_test: np.ndarray, base: dict[str, float], lgbm: dict[str, float]) -> None:
    tmp = val.copy()
    tmp["candidate_pred"] = clip(pred_val)
    m = evaluate(tmp, name, "candidate_pred", "validation")
    m.update(meta)
    m["candidate_name"] = name
    m["strategy"] = strategy
    m["score"] = m["MAE"] + 0.30 * m["peak_MAE"] + 0.15 * m["high_peak_MAE"] + 0.03 * abs(m["peak_bias"])
    m["delta_MAE_vs_base_EAHPA"] = m["MAE"] - base["MAE"]
    m["delta_peak_MAE_vs_base_EAHPA"] = m["peak_MAE"] - base["peak_MAE"]
    m["delta_high_peak_MAE_vs_base_EAHPA"] = m["high_peak_MAE"] - base["high_peak_MAE"]
    m["acceptable"] = bool(
        (m["MAE"] <= base["MAE"] * 1.01 or m["MAE"] <= lgbm["MAE"])
        and m["peak_MAE"] < base["peak_MAE"]
        and m["high_peak_MAE"] <= base["high_peak_MAE"] * 1.02
        and m["peak_underestimation_rate"] <= base["peak_underestimation_rate"] + 3.0
    )
    rows.append(m)
    store[name] = {"validation": clip(pred_val), "test": clip(pred_test)}


def build_ensemble_candidates(val: pd.DataFrame, test: pd.DataFrame, gate_val: pd.DataFrame, gate_test: pd.DataFrame, spec_val: pd.DataFrame, spec_test: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, dict[str, np.ndarray]]]:
    rows: list[dict[str, Any]] = []
    store: dict[str, dict[str, np.ndarray]] = {}
    base_tmp = val.assign(tmp=val["eahpa_pred"])
    lgbm_tmp = val.assign(tmp=val["lgbm_pred"])
    base = evaluate(base_tmp, "E-AHPA", "tmp", "validation")
    lgbm = evaluate(lgbm_tmp, "LGBMRegressor", "tmp", "validation")
    base_options = {"E_AHPA": ("eahpa_pred", "eahpa_pred"), "LGBM": ("lgbm_pred", "lgbm_pred")}
    if "prc_pred" in val.columns and val["prc_pred"].notna().any():
        base_options["PRC_EAHPA"] = ("prc_pred", "prc_pred")
    if "catboost_pred" in val.columns:
        base_options["CatBoost"] = ("catboost_pred", "catboost_pred")
    peak_options: dict[str, tuple[str, str]] = {}
    for col in prediction_columns(spec_val):
        if col in spec_test.columns:
            peak_options[col.replace("prediction_", "")] = (col, col)
    if "prc_pred" in val.columns and val["prc_pred"].notna().any():
        peak_options["PRC_EAHPA"] = ("prc_pred", "prc_pred")
    gate_scores: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    for col in [c for c in gate_val.columns if c.startswith("gate_")]:
        if col in gate_test.columns:
            gate_scores[col] = (gate_val[col].to_numpy(float), gate_test[col].to_numpy(float))
    for col in ["risk_combined_mean", "risk_eahpa_vs_p90", "risk_rollq90_168_vs_p90"]:
        gate_scores[col] = (val[col].rank(pct=True).to_numpy(float), test[col].rank(pct=True).to_numpy(float))
    val_ext = val.merge(spec_val[KEYS + prediction_columns(spec_val)], on=KEYS, how="left")
    test_ext = test.merge(spec_test[KEYS + prediction_columns(spec_test)], on=KEYS, how="left")
    for base_name, (b_val_col, b_test_col) in base_options.items():
        for peak_name, (p_val_col, p_test_col) in peak_options.items():
            if p_val_col not in val_ext.columns or p_test_col not in test_ext.columns:
                continue
            bval = val_ext[b_val_col].to_numpy(float)
            btest = test_ext[b_test_col].to_numpy(float)
            pval = val_ext[p_val_col].to_numpy(float)
            ptest = test_ext[p_test_col].to_numpy(float)
            for gate_name, (gv, gt) in gate_scores.items():
                for th in [0.30, 0.40, 0.50, 0.60]:
                    for alpha in [0.10, 0.20, 0.30, 0.50, 0.75]:
                        mask_v = gv >= th
                        mask_t = gt >= th
                        pred_v = bval.copy()
                        pred_t = btest.copy()
                        pred_v[mask_v] = bval[mask_v] + alpha * np.maximum(pval[mask_v] - bval[mask_v], 0)
                        pred_t[mask_t] = btest[mask_t] + alpha * np.maximum(ptest[mask_t] - btest[mask_t], 0)
                        name = f"uplift_{base_name}_{peak_name}_{gate_name}_t{th}_a{alpha}"
                        add_candidate(rows, store, name, "conservative_peak_uplift", {"base_model": base_name, "peak_model": peak_name, "gate": gate_name, "threshold": th, "alpha": alpha}, val_ext, pred_v, pred_t, base, lgbm)
                for th in [0.30, 0.40, 0.50, 0.60, 0.70]:
                    pred_v = np.where(gv >= th, pval, bval)
                    pred_t = np.where(gt >= th, ptest, btest)
                    name = f"switch_{base_name}_{peak_name}_{gate_name}_t{th}"
                    add_candidate(rows, store, name, "hard_switch", {"base_model": base_name, "peak_model": peak_name, "gate": gate_name, "threshold": th}, val_ext, pred_v, pred_t, base, lgbm)
                for th in [0.20, 0.40, 0.60]:
                    for scale in [0.20, 0.40]:
                        for max_alpha in [0.25, 0.50, 0.75]:
                            wv = np.clip((gv - th) / scale, 0, max_alpha)
                            wt = np.clip((gt - th) / scale, 0, max_alpha)
                            pred_v = (1 - wv) * bval + wv * pval
                            pred_t = (1 - wt) * btest + wt * ptest
                            name = f"pblend_{base_name}_{peak_name}_{gate_name}_t{th}_s{scale}_m{max_alpha}"
                            add_candidate(rows, store, name, "probability_weighted_blend", {"base_model": base_name, "peak_model": peak_name, "gate": gate_name, "threshold": th, "scale": scale, "max_alpha": max_alpha}, val_ext, pred_v, pred_t, base, lgbm)
                for pct in [0.05, 0.10, 0.15, 0.20, 0.25]:
                    q = np.quantile(gv, 1 - pct)
                    mask_v = gv >= q
                    mask_t = gt >= q
                    pred_v = bval.copy()
                    pred_t = btest.copy()
                    pred_v[mask_v] = bval[mask_v] + 0.5 * np.maximum(pval[mask_v] - bval[mask_v], 0)
                    pred_t[mask_t] = btest[mask_t] + 0.5 * np.maximum(ptest[mask_t] - btest[mask_t], 0)
                    name = f"toprisk_{base_name}_{peak_name}_{gate_name}_p{int(pct*100)}"
                    add_candidate(rows, store, name, "top_risk_percentile_uplift", {"base_model": base_name, "peak_model": peak_name, "gate": gate_name, "top_percent": pct, "risk_threshold_from_validation": q}, val_ext, pred_v, pred_t, base, lgbm)
    build_meta_candidates(val_ext, test_ext, rows, store, base, lgbm, peak_options, gate_scores)
    return pd.DataFrame(rows), store


def build_meta_candidates(val: pd.DataFrame, test: pd.DataFrame, rows: list[dict[str, Any]], store: dict[str, dict[str, np.ndarray]], base: dict[str, float], lgbm: dict[str, float], peak_options: dict[str, tuple[str, str]], gate_scores: dict[str, tuple[np.ndarray, np.ndarray]]) -> None:
    try:
        from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor
        from sklearn.linear_model import Ridge
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
    except Exception:
        return
    base_cols = [c for c in ["eahpa_pred", "lgbm_pred", "catboost_pred", "prc_pred"] if c in val.columns and val[c].notna().any()]
    risk_cols = [c for c in DERIVED_RISK_FEATURES if c in val.columns]
    peak_cols = [v[0] for v in list(peak_options.values())[:3] if v[0] in val.columns]
    cols = base_cols + peak_cols + risk_cols[:8]
    if not cols:
        return
    Xv = val[cols].replace([np.inf, -np.inf], np.nan).fillna(0)
    Xt = test[cols].replace([np.inf, -np.inf], np.nan).fillna(0)
    y = val[ACTUAL].to_numpy(float)
    specs = [
        ("ridge_meta", make_pipeline(StandardScaler(), Ridge(alpha=1.0))),
        ("gbr_meta", GradientBoostingRegressor(n_estimators=80, learning_rate=0.04, max_depth=2, random_state=RANDOM_STATE)),
        ("extratrees_meta", ExtraTreesRegressor(n_estimators=80, max_depth=8, min_samples_leaf=5, n_jobs=1, random_state=RANDOM_STATE)),
    ]
    joblib_ok, joblib = package("joblib")
    for name, model in specs:
        try:
            model.fit(Xv, y)
            pv = clip(model.predict(Xv))
            pt = clip(model.predict(Xt))
            add_candidate(rows, store, name, "validation_meta_model", {"features": cols, "meta_model": name}, val, pv, pt, base, lgbm)
            if joblib_ok:
                joblib.dump(model, MODELS_DIR / f"08F_{name}.joblib")
        except Exception:
            continue


def select_candidate(candidates: pd.DataFrame) -> tuple[pd.Series, pd.DataFrame]:
    acceptable = candidates[candidates["acceptable"]].copy()
    if acceptable.empty:
        selected = candidates[candidates["candidate_name"] == "base_EAHPA"].iloc[0] if "base_EAHPA" in set(candidates["candidate_name"]) else candidates.sort_values("MAE").iloc[0]
        rule = "no acceptable candidate; selected safest validation MAE candidate"
    else:
        selected = acceptable.sort_values(["score", "MAE", "peak_MAE"]).iloc[0]
        rule = "lowest score among validation-acceptable candidates"
    summary = []
    for role, sorter in [
        ("primary_selected", None),
        ("best_validation_MAE", "MAE"),
        ("best_validation_peak_MAE", "peak_MAE"),
        ("best_validation_high_peak_MAE", "high_peak_MAE"),
        ("best_validation_score", "score"),
    ]:
        row = selected if sorter is None else candidates.sort_values(sorter).iloc[0]
        d = row.to_dict()
        d["selection_role"] = role
        d["selection_rule_used"] = rule
        summary.append(d)
    return selected, pd.DataFrame(summary)


def row_bootstrap_ci(delta: np.ndarray) -> tuple[float, float]:
    rng = np.random.default_rng(RANDOM_STATE)
    delta = np.asarray(delta, dtype=float)
    delta = delta[np.isfinite(delta)]
    if len(delta) == 0:
        return np.nan, np.nan
    vals = np.empty(N_BOOTSTRAP)
    n = len(delta)
    for i in range(N_BOOTSTRAP):
        vals[i] = np.mean(delta[rng.integers(0, n, n)])
    return float(np.quantile(vals, 0.025)), float(np.quantile(vals, 0.975))


def block_ci(df: pd.DataFrame, delta_col: str, block_size: int) -> tuple[float, float]:
    rng = np.random.default_rng(RANDOM_STATE + block_size)
    ordered = df.reset_index(drop=False).sort_values(["site_id", "timestamp"])
    blocks = []
    for _, sdf in ordered.groupby("site_id", sort=False):
        idx = sdf["index"].to_numpy()
        for start in range(0, len(idx), block_size):
            blocks.append(idx[start : start + block_size])
    if not blocks:
        return np.nan, np.nan
    vals = np.empty(N_BOOTSTRAP)
    n = len(df)
    for i in range(N_BOOTSTRAP):
        sample = []
        while len(sample) < n:
            sample.extend(blocks[int(rng.integers(0, len(blocks)))].tolist())
        vals[i] = np.mean(df.loc[sample[:n], delta_col])
    return float(np.quantile(vals, 0.025)), float(np.quantile(vals, 0.975))


def stat_test(df: pd.DataFrame, ps_col: str, comp_col: str, comp_name: str, subset: str, stats_ok: bool, stats: Any) -> dict[str, Any]:
    a = df[ACTUAL].to_numpy(float)
    ps = clip(df[ps_col])
    comp = clip(df[comp_col])
    delta = np.abs(ps - a) - np.abs(comp - a)
    rb = row_bootstrap_ci(delta)
    work = df[["timestamp", "site_id"]].copy()
    work["delta"] = delta
    b24 = block_ci(work, "delta", 24) if subset == "overall" else (np.nan, np.nan)
    b168 = block_ci(work, "delta", 168) if subset == "overall" else (np.nan, np.nan)
    wins = int(np.sum(np.abs(ps - a) < np.abs(comp - a)))
    losses = int(np.sum(np.abs(ps - a) > np.abs(comp - a)))
    wilcoxon_p, sign_p = np.nan, np.nan
    if stats_ok:
        try:
            nz = delta[delta != 0]
            wilcoxon_p = float(stats.wilcoxon(nz, alternative="less").pvalue) if len(nz) else np.nan
        except Exception:
            pass
        try:
            sign_p = float(stats.binomtest(wins, wins + losses, 0.5, alternative="greater").pvalue) if wins + losses else np.nan
        except Exception:
            pass
    return {
        "comparison": f"PS-EAHPA_vs_{comp_name}",
        "subset": subset,
        "observed_difference": float(np.mean(delta)),
        "row_bootstrap_ci_lower": rb[0],
        "row_bootstrap_ci_upper": rb[1],
        "block24_ci_lower": b24[0],
        "block24_ci_upper": b24[1],
        "block168_ci_lower": b168[0],
        "block168_ci_upper": b168[1],
        "wilcoxon_p_value": wilcoxon_p,
        "sign_test_p_value": sign_p,
        "win_rate": 100 * wins / (wins + losses) if wins + losses else np.nan,
        "row_count": len(df),
        "significant_row_bootstrap": rb[1] < 0,
        "significant_block24": b24[1] < 0 if subset == "overall" else np.nan,
        "significant_block168": b168[1] < 0 if subset == "overall" else np.nan,
    }


def save_figures(gate_metrics: pd.DataFrame, specialist: pd.DataFrame, candidates: pd.DataFrame, metrics: pd.DataFrame, test: pd.DataFrame, stats: pd.DataFrame) -> None:
    plt.figure(figsize=(8, 5))
    gm = gate_metrics[gate_metrics["status"] == "success"].copy()
    if not gm.empty:
        plt.bar(gm["gate_name"], gm["PR_AUC"].fillna(gm["F1"]))
        plt.xticks(rotation=45, ha="right", fontsize=7)
    plt.ylabel("Validation PR-AUC/F1")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08F_fig1_gate_validation_performance.png", dpi=300)
    plt.close()
    plt.figure(figsize=(7, 5))
    if not specialist.empty:
        plt.scatter(specialist["MAE"], specialist["peak_MAE"], s=40)
    plt.xlabel("Validation MAE")
    plt.ylabel("Validation peak_MAE")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08F_fig2_peak_specialist_validation_tradeoff.png", dpi=300)
    plt.close()
    plt.figure(figsize=(7, 5))
    plt.scatter(candidates["MAE"], candidates["peak_MAE"], s=10, alpha=0.35)
    plt.xlabel("Validation MAE")
    plt.ylabel("Validation peak_MAE")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08F_fig3_ensemble_candidate_tradeoff.png", dpi=300)
    plt.close()
    mt = metrics[metrics["split"] == "test"].copy()
    for fname, metric in [
        ("08F_fig4_test_mae_comparison.png", "MAE"),
        ("08F_fig5_test_peak_mae_comparison.png", "peak_MAE"),
        ("08F_fig6_test_high_peak_mae_comparison.png", "high_peak_MAE"),
        ("08F_fig7_peak_underestimation_comparison.png", "peak_underestimation_rate"),
    ]:
        plt.figure(figsize=(8, 5))
        plot = mt.sort_values(metric)
        plt.bar(plot["model_name"], plot[metric])
        plt.xticks(rotation=35, ha="right", fontsize=8)
        plt.ylabel(metric)
        plt.tight_layout()
        plt.savefig(FIGURES_DIR / fname, dpi=300)
        plt.close()
    sample = test.sort_values(["site_id", "timestamp"]).head(24 * 7)
    plt.figure(figsize=(10, 5))
    plt.plot(sample[ACTUAL].to_numpy(), label="Actual")
    for col, lab in [("lgbm_pred", "LGBM"), ("eahpa_pred", "E-AHPA"), ("prc_pred", "PRC"), ("ps_eahpa_pred", "PS-EAHPA")]:
        if col in sample.columns:
            plt.plot(sample[col].to_numpy(), label=lab)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08F_fig8_actual_vs_lgbm_eahpa_prc_ps_peak_sample.png", dpi=300)
    plt.close()
    site_rows = []
    for model, col in [("LGBM", "lgbm_pred"), ("E-AHPA", "eahpa_pred"), ("PRC", "prc_pred"), ("PS-EAHPA", "ps_eahpa_pred")]:
        if col not in test.columns:
            continue
        for site, sdf in test.groupby("site_id"):
            site_rows.append({"site": site, "model": model, "peak_MAE": evaluate(sdf, model, col, "test")["peak_MAE"]})
    pd.DataFrame(site_rows).pivot(index="site", columns="model", values="peak_MAE").plot(kind="bar", figsize=(10, 5))
    plt.ylabel("Peak MAE")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08F_fig9_site_level_peak_mae.png", dpi=300)
    plt.close()
    peak_stats = stats[stats["subset"] == "peak_rows"].copy()
    plt.figure(figsize=(8, 4))
    x = np.arange(len(peak_stats))
    y = peak_stats["observed_difference"].to_numpy(float)
    plt.errorbar(x, y, yerr=[y - peak_stats["row_bootstrap_ci_lower"].to_numpy(float), peak_stats["row_bootstrap_ci_upper"].to_numpy(float) - y], fmt="o")
    plt.axhline(0, color="black", linewidth=0.8)
    plt.xticks(x, peak_stats["comparison"], rotation=35, ha="right", fontsize=8)
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08F_fig10_bootstrap_ci_peak_difference.png", dpi=300)
    plt.close()
    plt.figure(figsize=(8, 5))
    gate_cols = [c for c in test.columns if c.startswith("gate_")]
    if gate_cols:
        plt.hist(test[gate_cols[0]], bins=40)
    plt.xlabel("Gate probability/risk score")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08F_fig11_gate_probability_distribution.png", dpi=300)
    plt.close()


def write_reports(selected: pd.Series, metrics: pd.DataFrame, stats: pd.DataFrame, recommendation: str) -> None:
    test = metrics[metrics["split"] == "test"].set_index("model_name")
    lgbm = test.loc["LGBMRegressor"]
    eahpa = test.loc["E-AHPA"]
    ps = test.loc["PS-EAHPA"]
    prc_txt = ""
    if "PRC-E-AHPA" in test.index:
        prc = test.loc["PRC-E-AHPA"]
        prc_txt = f"- PRC-E-AHPA: MAE {prc['MAE']:.4f}, peak_MAE {prc['peak_MAE']:.4f}, high_peak_MAE {prc['high_peak_MAE']:.4f}.\n"
    peak_support = bool(stats[(stats["comparison"] == "PS-EAHPA_vs_LGBMRegressor") & (stats["subset"] == "peak_rows")]["significant_row_bootstrap"].iloc[0])
    method = """Step 08F method report
==========================
PS-EAHPA is a Peak-Specialized Enhanced Adaptive Hybrid Peak-Aware Ensemble.
Step 08D E-AHPA gave strong overall MAE improvement, while Step 08E PRC improved observed peak errors but still had mixed peak significance.
Step 08F therefore trains train-only peak-risk gates and peak-specialist regressors, then uses validation-only multi-objective selection to decide when a peak-specialist prediction should replace or adjust the base forecast.
The design avoids test chasing by fixing all thresholds, blends, and candidate choices before test evaluation.
"""
    leakage = """Step 08F leakage safety report
===============================
- Peak-risk gates and peak-specialist regressors are fitted only on the train split.
- Ensemble thresholds, blends, switches, and meta-models are selected only on validation.
- Test labels are used only for final evaluation.
- Actual test peak labels are not used as predictors.
- Inputs are Step 05B leakage-free features and saved predictions only.
- No future load, session, weather, traffic, price, or scheduling information is used.
"""
    novelty = """Step 08F novelty contribution report
=====================================
This study proposes two-stage peak-specialized EV charging load forecasting.
The method combines a strong E-AHPA base forecast with a peak-risk gate and train-only peak-specialist regressors.
Validation-constrained multi-objective selection preserves average accuracy while targeting peak and high-peak errors.
The method is statistically evaluated before scheduling, supporting defensible claims about the peak/average tradeoff.
"""
    results = f"""Step 08F results report
========================
Selected PS-EAHPA strategy: {selected['strategy']}.
Selected candidate: {selected['candidate_name']}.
Validation MAE: {selected['MAE']:.4f}; validation peak_MAE: {selected['peak_MAE']:.4f}; validation high_peak_MAE: {selected['high_peak_MAE']:.4f}.

Test metrics:
- LGBMRegressor: MAE {lgbm['MAE']:.4f}, peak_MAE {lgbm['peak_MAE']:.4f}, high_peak_MAE {lgbm['high_peak_MAE']:.4f}.
- E-AHPA: MAE {eahpa['MAE']:.4f}, peak_MAE {eahpa['peak_MAE']:.4f}, high_peak_MAE {eahpa['high_peak_MAE']:.4f}.
{prc_txt}- PS-EAHPA: MAE {ps['MAE']:.4f}, peak_MAE {ps['peak_MAE']:.4f}, high_peak_MAE {ps['high_peak_MAE']:.4f}.

PS improves MAE over E-AHPA: {ps['MAE'] < eahpa['MAE']}.
PS improves peak_MAE over E-AHPA: {ps['peak_MAE'] < eahpa['peak_MAE']}.
PS improves high_peak_MAE over E-AHPA: {ps['high_peak_MAE'] < eahpa['high_peak_MAE']}.
Peak bootstrap support versus LGBM: {peak_support}.
Final recommendation: {recommendation}.
"""
    paper = f"""The PS-EAHPA two-stage ensemble selected {selected['strategy']} using validation-only multi-objective selection. On the test set, PS-EAHPA achieved MAE = {ps['MAE']:.4f} kW, peak_MAE = {ps['peak_MAE']:.4f} kW, and high_peak_MAE = {ps['high_peak_MAE']:.4f} kW, compared with E-AHPA MAE = {eahpa['MAE']:.4f} kW and peak_MAE = {eahpa['peak_MAE']:.4f} kW. The final recommended forecasting model is {recommendation}. Peak-specific claims should remain cautious if the bootstrap confidence interval crosses zero."""
    (RESULTS_DIR / "08F_method_report.txt").write_text(method, encoding="utf-8")
    (RESULTS_DIR / "08F_leakage_safety_report.txt").write_text(leakage, encoding="utf-8")
    (RESULTS_DIR / "08F_novelty_contribution_report.txt").write_text(novelty, encoding="utf-8")
    (RESULTS_DIR / "08F_results_report.txt").write_text(results, encoding="utf-8")
    (RESULTS_DIR / "08F_paper_ready_results_paragraph.txt").write_text(paper, encoding="utf-8")


def main() -> None:
    ensure_dirs()
    stats_ok, stats = scipy_tools()
    data, feature_cols, _, _ = load_data()
    train = data[data["split"] == "train"].copy()
    val = data[data["split"] == "validation"].dropna(subset=["eahpa_pred", "lgbm_pred"]).copy()
    test = data[data["split"] == "test"].dropna(subset=["eahpa_pred", "lgbm_pred"]).copy()
    risk_summary = pd.DataFrame({"feature": BASE_RISK_FEATURES + DERIVED_RISK_FEATURES, "train_mean": [train[c].mean() for c in BASE_RISK_FEATURES + DERIVED_RISK_FEATURES], "validation_mean": [val[c].mean() for c in BASE_RISK_FEATURES + DERIVED_RISK_FEATURES], "test_mean": [test[c].mean() for c in BASE_RISK_FEATURES + DERIVED_RISK_FEATURES]})
    risk_summary.to_csv(RESULTS_DIR / "08F_peak_risk_feature_summary.csv", index=False)
    gate_metrics, gate_val, gate_test, gate_fi = train_gates(train, val, test)
    gate_metrics.to_csv(RESULTS_DIR / "08F_peak_gate_validation_metrics.csv", index=False)
    gate_val.to_csv(RESULTS_DIR / "08F_peak_gate_predictions_validation.csv", index=False)
    gate_test.to_csv(RESULTS_DIR / "08F_peak_gate_predictions_test.csv", index=False)
    gate_fi.to_csv(RESULTS_DIR / "08F_peak_gate_feature_importance.csv", index=False)
    spec_metrics, spec_val, spec_test, spec_errors = train_specialists(train, val, test, feature_cols)
    spec_metrics.to_csv(RESULTS_DIR / "08F_peak_specialist_training_results.csv", index=False)
    spec_val.to_csv(RESULTS_DIR / "08F_peak_specialist_validation_predictions.csv", index=False)
    spec_test.to_csv(RESULTS_DIR / "08F_peak_specialist_test_predictions.csv", index=False)
    spec_errors.to_csv(RESULTS_DIR / "08F_peak_specialist_error_log.csv", index=False)
    candidates, store = build_ensemble_candidates(val, test, gate_val, gate_test, spec_val, spec_test)
    # Include the base E-AHPA row as an explicit fallback.
    base_val = val["eahpa_pred"].to_numpy(float)
    base_test = test["eahpa_pred"].to_numpy(float)
    base_m = evaluate(val.assign(candidate_pred=base_val), "base_EAHPA", "candidate_pred", "validation")
    base_l = evaluate(val.assign(candidate_pred=val["lgbm_pred"]), "LGBMRegressor", "candidate_pred", "validation")
    add_candidate([], store, "base_EAHPA", "base", {"base_model": "E-AHPA"}, val, base_val, base_test, base_m, base_l)
    base_row = evaluate(val.assign(candidate_pred=base_val), "base_EAHPA", "candidate_pred", "validation")
    base_row.update({"candidate_name": "base_EAHPA", "strategy": "base", "score": base_row["MAE"] + 0.30 * base_row["peak_MAE"] + 0.15 * base_row["high_peak_MAE"], "acceptable": True})
    candidates = pd.concat([candidates, pd.DataFrame([base_row])], ignore_index=True)
    candidates.to_csv(RESULTS_DIR / "08F_ensemble_candidate_validation_results.csv", index=False)
    selected, summary = select_candidate(candidates)
    summary.to_csv(RESULTS_DIR / "08F_selected_model_summary.csv", index=False)
    test["ps_eahpa_pred"] = clip(store[selected["candidate_name"]]["test"])
    val["ps_eahpa_pred"] = clip(store[selected["candidate_name"]]["validation"])
    val_out_cols = ["timestamp", "site_id", ACTUAL, "split", "is_peak_hour", "is_high_peak_hour", "lgbm_pred", "catboost_pred", "eahpa_pred", "prc_pred", "ps_eahpa_pred"]
    val[[c for c in val_out_cols if c in val.columns]].to_csv(RESULTS_DIR / "08F_validation_predictions.csv", index=False)
    test[[c for c in val_out_cols if c in test.columns]].to_csv(RESULTS_DIR / "08F_test_predictions.csv", index=False)
    metric_rows = []
    for split, frame in [("validation", val), ("test", test)]:
        for model, col in [("LGBMRegressor", "lgbm_pred"), ("CatBoostRegressor", "catboost_pred"), ("E-AHPA", "eahpa_pred"), ("PRC-E-AHPA", "prc_pred"), ("PS-EAHPA", "ps_eahpa_pred")]:
            if col in frame.columns and frame[col].notna().any():
                metric_rows.append(evaluate(frame, model, col, split))
    metrics = pd.DataFrame(metric_rows)
    metrics.to_csv(RESULTS_DIR / "08F_ps_eahpa_overall_metrics.csv", index=False)
    site_rows = []
    for split, frame in [("validation", val), ("test", test)]:
        for model, col in [("LGBMRegressor", "lgbm_pred"), ("E-AHPA", "eahpa_pred"), ("PRC-E-AHPA", "prc_pred"), ("PS-EAHPA", "ps_eahpa_pred")]:
            if col in frame.columns and frame[col].notna().any():
                for site, sdf in frame.groupby("site_id"):
                    site_rows.append(evaluate(sdf, model, col, split) | {"site_id": site})
    pd.DataFrame(site_rows).to_csv(RESULTS_DIR / "08F_ps_eahpa_site_metrics.csv", index=False)
    comp = metrics[metrics["split"] == "test"].copy()
    comp.to_csv(RESULTS_DIR / "08F_ps_eahpa_comparison.csv", index=False)
    comp.sort_values(["MAE", "peak_MAE"]).to_csv(RESULTS_DIR / "08F_final_forecasting_summary.csv", index=False)
    stat_rows = []
    for name, col in [("LGBMRegressor", "lgbm_pred"), ("E-AHPA", "eahpa_pred"), ("PRC-E-AHPA", "prc_pred")]:
        if col in test.columns and test[col].notna().any():
            stat_rows.append(stat_test(test, "ps_eahpa_pred", col, name, "overall", stats_ok, stats))
            stat_rows.append(stat_test(test[test["is_peak_hour"] == 1], "ps_eahpa_pred", col, name, "peak_rows", stats_ok, stats))
            stat_rows.append(stat_test(test[test["is_high_peak_hour"] == 1], "ps_eahpa_pred", col, name, "high_peak_rows", stats_ok, stats))
    stat_df = pd.DataFrame(stat_rows)
    stat_df.to_csv(RESULTS_DIR / "08F_statistical_tests.csv", index=False)
    test_metrics = metrics[metrics["split"] == "test"].set_index("model_name")
    ps = test_metrics.loc["PS-EAHPA"]
    eahpa = test_metrics.loc["E-AHPA"]
    prc_available = "PRC-E-AHPA" in test_metrics.index
    prc = test_metrics.loc["PRC-E-AHPA"] if prc_available else None
    if ps["MAE"] <= eahpa["MAE"] * 1.01 and ps["peak_MAE"] < eahpa["peak_MAE"]:
        recommendation = "PS-EAHPA"
    elif prc_available and prc["peak_MAE"] < eahpa["peak_MAE"] and prc["MAE"] <= eahpa["MAE"] * 1.01:
        recommendation = "PRC-E-AHPA"
    else:
        recommendation = "E-AHPA"
    save_figures(gate_metrics, spec_metrics, candidates, metrics, test, stat_df)
    write_reports(selected, metrics, stat_df, recommendation)
    lgbm = test_metrics.loc["LGBMRegressor"]
    print("Step 08F peak-specialized two-stage ensemble complete")
    print(f"LGBM test MAE, peak_MAE, high_peak_MAE: {lgbm['MAE']:.4f}, {lgbm['peak_MAE']:.4f}, {lgbm['high_peak_MAE']:.4f}")
    print(f"E-AHPA test MAE, peak_MAE, high_peak_MAE: {eahpa['MAE']:.4f}, {eahpa['peak_MAE']:.4f}, {eahpa['high_peak_MAE']:.4f}")
    if prc_available:
        print(f"PRC-E-AHPA test MAE, peak_MAE, high_peak_MAE: {prc['MAE']:.4f}, {prc['peak_MAE']:.4f}, {prc['high_peak_MAE']:.4f}")
    print(f"Selected PS-EAHPA strategy: {selected['strategy']}")
    print(f"Selected PS-EAHPA validation MAE, peak_MAE, high_peak_MAE: {selected['MAE']:.4f}, {selected['peak_MAE']:.4f}, {selected['high_peak_MAE']:.4f}")
    print(f"Selected PS-EAHPA test MAE, peak_MAE, high_peak_MAE: {ps['MAE']:.4f}, {ps['peak_MAE']:.4f}, {ps['high_peak_MAE']:.4f}")
    print(f"PS improves MAE over E-AHPA: {ps['MAE'] < eahpa['MAE']}")
    print(f"PS improves peak_MAE over E-AHPA: {ps['peak_MAE'] < eahpa['peak_MAE']}")
    print(f"PS improves peak_MAE over LGBM: {ps['peak_MAE'] < lgbm['peak_MAE']}")
    peak_lgbm = stat_df[(stat_df['comparison'] == 'PS-EAHPA_vs_LGBMRegressor') & (stat_df['subset'] == 'peak_rows')].iloc[0]
    print(f"Peak bootstrap CI supports improvement: {peak_lgbm['row_bootstrap_ci_upper'] < 0}")
    print(f"Final recommendation: {recommendation}")
    print(f"Results folder: {RESULTS_DIR}")
    print(f"Figures folder: {FIGURES_DIR}")


if __name__ == "__main__":
    main()
