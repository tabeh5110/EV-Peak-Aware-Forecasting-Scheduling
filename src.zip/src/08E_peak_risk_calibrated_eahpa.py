"""
Step 08E: Peak-Risk Calibrated E-AHPA (PRC-E-AHPA).

Run from the project root:
    python src/08E_peak_risk_calibrated_eahpa.py

This step fits a leakage-free validation residual correction layer on top of
the fixed Step 08D E-AHPA forecast. It does not retrain the main forecaster and
does not use test labels for correction selection.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable
import importlib
import json
import re
import sys
import time
import types
import warnings

import numpy as np


if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
FEATURE_FILE = PROJECT_ROOT / "data" / "processed" / "05B_forecasting_features.csv"
FEATURE_COLUMNS_FILE = PROJECT_ROOT / "results" / "05B_fix_feature_engineering" / "05B_modeling_feature_columns.txt"
EAHPA_VAL_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_validation_predictions.csv"
EAHPA_TEST_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_test_predictions.csv"
EAHPA_SUMMARY_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_selected_hybrid_summary.csv"
ML_VAL_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_validation_predictions.csv"
ML_TEST_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_test_predictions.csv"
BASELINE_TEST_FILE = PROJECT_ROOT / "results" / "06_baseline_forecasting" / "06_test_predictions.csv"
STEP09_METRICS_FILE = PROJECT_ROOT / "results" / "09_statistical_validation" / "09_test_metrics_recomputed.csv"

RESULTS_DIR = PROJECT_ROOT / "results" / "08E_peak_risk_calibrated_eahpa"
FIGURES_DIR = PROJECT_ROOT / "figures" / "08E_peak_risk_calibrated_eahpa"
MODELS_DIR = PROJECT_ROOT / "models" / "08E_peak_risk_calibrated_eahpa"

TARGET = "actual_load_kw"
KEYS = ["timestamp", "site_id", "actual_load_kw"]
RANDOM_STATE = 42
N_BOOTSTRAP = 1000

RISK_BINS = {
    "risk_combined_mean": [0, 0.5, 0.75, 1.0, 1.25, 1.5, np.inf],
    "risk_pred_vs_p90": [0, 0.5, 0.75, 1.0, 1.25, np.inf],
    "risk_rollq90_168_vs_p90": [0, 0.5, 0.75, 1.0, 1.25, np.inf],
}
RISK_MODEL_FEATURES = [
    "risk_pred_vs_p90",
    "risk_pred_vs_p95",
    "risk_lag24_vs_p90",
    "risk_lag168_vs_p90",
    "risk_rollmax24_vs_p90",
    "risk_rollq90_24_vs_p90",
    "risk_rollq90_168_vs_p90",
    "risk_recent_peak24_norm",
    "risk_recent_peak168_norm",
    "risk_combined_mean",
    "risk_business_interaction",
    "risk_morning_interaction",
    "hour",
    "day_of_week",
    "is_weekend",
    "is_business_hour",
    "is_morning_arrival_period",
    "is_evening_departure_period",
    "site_id_encoded",
]


def ensure_dirs() -> None:
    for folder in [RESULTS_DIR, FIGURES_DIR, MODELS_DIR]:
        folder.mkdir(parents=True, exist_ok=True)


def scipy_tools() -> tuple[bool, Any]:
    try:
        return True, importlib.import_module("scipy.stats")
    except Exception:
        return False, None


def package_version(name: str) -> tuple[bool, str]:
    try:
        mod = importlib.import_module(name)
        return True, str(getattr(mod, "__version__", "unknown"))
    except Exception:
        return False, ""


def prediction_cols(df: pd.DataFrame) -> list[str]:
    return [c for c in df.columns if c.startswith("prediction_")]


def selected_eahpa_column() -> tuple[str, str]:
    summary = pd.read_csv(EAHPA_SUMMARY_FILE)
    primary = summary[summary["selection_role"] == "primary_selected_AHPA_Ensemble"]
    if primary.empty:
        primary = summary.head(1)
    name = str(primary.iloc[0]["selected_model_name"])
    return name, f"prediction_{name}"


def clip(values: Any) -> np.ndarray:
    return np.maximum(np.asarray(values, dtype=float), 0.0)


def safe_div(num: pd.Series, den: pd.Series) -> pd.Series:
    return num.astype(float) / den.replace(0, np.nan).astype(float)


def mae(a: np.ndarray, p: np.ndarray) -> float:
    return float(np.mean(np.abs(p - a))) if len(a) else np.nan


def rmse(a: np.ndarray, p: np.ndarray) -> float:
    return float(np.sqrt(np.mean((p - a) ** 2))) if len(a) else np.nan


def r2(a: np.ndarray, p: np.ndarray) -> float:
    if len(a) == 0:
        return np.nan
    ss_res = float(np.sum((a - p) ** 2))
    ss_tot = float(np.sum((a - np.mean(a)) ** 2))
    return 1 - ss_res / ss_tot if ss_tot else np.nan


def rate(mask: np.ndarray) -> float:
    return float(np.mean(mask) * 100) if len(mask) else np.nan


def evaluate(df: pd.DataFrame, model_name: str, pred_col: str, split: str) -> dict[str, Any]:
    a = df[TARGET].to_numpy(float)
    p = clip(df[pred_col])
    peak = df["is_peak_hour"].to_numpy(int) == 1
    high = df["is_high_peak_hour"].to_numpy(int) == 1
    q90, q95 = np.nanquantile(a, [0.90, 0.95]) if len(a) else (np.nan, np.nan)
    top10 = a >= q90
    top5 = a >= q95
    max_idx = int(np.argmax(a)) if len(a) else 0
    return {
        "model_name": model_name,
        "split": split,
        "MAE": mae(a, p),
        "RMSE": rmse(a, p),
        "R2": r2(a, p),
        "MBE": float(np.mean(p - a)) if len(a) else np.nan,
        "underestimation_rate": rate(p < a),
        "overestimation_rate": rate(p > a),
        "peak_MAE": mae(a[peak], p[peak]),
        "high_peak_MAE": mae(a[high], p[high]),
        "peak_RMSE": rmse(a[peak], p[peak]),
        "high_peak_RMSE": rmse(a[high], p[high]),
        "peak_underestimation_rate": rate(p[peak] < a[peak]),
        "high_peak_underestimation_rate": rate(p[high] < a[high]),
        "peak_bias": float(np.mean(p[peak] - a[peak])) if peak.any() else np.nan,
        "high_peak_bias": float(np.mean(p[high] - a[high])) if high.any() else np.nan,
        "peak_overestimation_rate": rate(p[peak] > a[peak]),
        "high_peak_overestimation_rate": rate(p[high] > a[high]),
        "top_10_percent_actual_peak_MAE": mae(a[top10], p[top10]),
        "top_5_percent_actual_peak_MAE": mae(a[top5], p[top5]),
        "actual_max_load_kw": float(a[max_idx]) if len(a) else np.nan,
        "predicted_load_at_actual_max_kw": float(p[max_idx]) if len(a) else np.nan,
        "actual_max_underprediction_kw": float(a[max_idx] - p[max_idx]) if len(a) else np.nan,
        "row_count": len(df),
        "peak_row_count": int(peak.sum()),
        "high_peak_row_count": int(high.sum()),
    }


def load_features() -> pd.DataFrame:
    df = pd.read_csv(FEATURE_FILE)
    df["timestamp"] = df["timestamp"].astype(str)
    if "actual_load_kw" not in df.columns:
        df["actual_load_kw"] = df["target_load_kw"]
    if "site_id_encoded" not in df.columns:
        df["site_id_encoded"] = pd.factorize(df["site_id"])[0]
    if "peak_threshold_90_train_kw" not in df.columns or "peak_threshold_95_train_kw" not in df.columns:
        train = df[df["split"] == "train"]
        p90 = train.groupby("site_id")["target_load_kw"].quantile(0.90).to_dict()
        p95 = train.groupby("site_id")["target_load_kw"].quantile(0.95).to_dict()
        df["peak_threshold_90_train_kw"] = df["site_id"].map(p90).fillna(train["target_load_kw"].quantile(0.90))
        df["peak_threshold_95_train_kw"] = df["site_id"].map(p95).fillna(train["target_load_kw"].quantile(0.95))
    return df[df["split"].isin(["validation", "test"])].copy()


def align_predictions(features: pd.DataFrame, path: Path, selected_col: str | None, source: str) -> tuple[pd.DataFrame | None, dict[str, Any]]:
    row = {
        "source": source,
        "path": str(path),
        "file_exists": path.exists(),
        "rows": 0,
        "prediction_columns": "",
        "selected_column": selected_col or "",
        "matched_rows": 0,
        "notes": "",
    }
    if not path.exists():
        row["notes"] = "missing"
        return None, row
    pred = pd.read_csv(path)
    pred["timestamp"] = pred["timestamp"].astype(str)
    if "target_load_kw" in pred.columns and "actual_load_kw" not in pred.columns:
        pred["actual_load_kw"] = pred["target_load_kw"]
    cols = prediction_cols(pred)
    row["rows"] = len(pred)
    row["prediction_columns"] = ", ".join(cols)
    if selected_col is None:
        selected_col = cols[0] if cols else None
    if selected_col not in cols:
        row["notes"] = "selected prediction column missing"
        return None, row
    out = features[KEYS + ["split"]].merge(pred[KEYS + [selected_col]], on=KEYS, how="left")
    row["matched_rows"] = int(out[selected_col].notna().sum())
    row["notes"] = "loaded"
    return out[KEYS + ["split", selected_col]], row


def build_data() -> tuple[pd.DataFrame, pd.DataFrame, list[dict[str, Any]], str]:
    features = load_features()
    selected_name, eahpa_col = selected_eahpa_column()
    rows = []
    merged = features.copy()

    for path, split, source, col, out_col in [
        (EAHPA_VAL_FILE, "validation", "08D E-AHPA validation", eahpa_col, "eahpa_pred"),
        (EAHPA_TEST_FILE, "test", "08D E-AHPA test", eahpa_col, "eahpa_pred"),
        (ML_VAL_FILE, "validation", "07 LGBM validation", "prediction_LGBMRegressor", "lgbm_pred"),
        (ML_TEST_FILE, "test", "07 LGBM test", "prediction_LGBMRegressor", "lgbm_pred"),
        (ML_VAL_FILE, "validation", "07 CatBoost validation", "prediction_CatBoostRegressor", "catboost_pred"),
        (ML_TEST_FILE, "test", "07 CatBoost test", "prediction_CatBoostRegressor", "catboost_pred"),
    ]:
        subset = features[features["split"] == split].copy()
        aligned, row = align_predictions(subset, path, col, source)
        rows.append(row)
        if aligned is not None:
            aligned = aligned.rename(columns={col: out_col})
            merged = merged.merge(aligned[KEYS + ["split", out_col]], on=KEYS + ["split"], how="left", suffixes=("", "_dup"))
            dup = f"{out_col}_dup"
            if dup in merged.columns:
                merged[out_col] = merged[out_col].fillna(merged[dup])
                merged = merged.drop(columns=[dup])

    base_col = "prediction_Linear_Regression_All_Features"
    for path, split in [(BASELINE_TEST_FILE, "test")]:
        subset = features[features["split"] == split].copy()
        aligned, row = align_predictions(subset, path, base_col, "06 baseline test")
        rows.append(row)
        if aligned is not None:
            merged = merged.merge(aligned.rename(columns={base_col: "baseline_pred"})[KEYS + ["split", "baseline_pred"]], on=KEYS + ["split"], how="left")

    merged = create_risk_features(merged)
    return merged[merged["split"] == "validation"].copy(), merged[merged["split"] == "test"].copy(), rows, selected_name


def create_risk_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    defaults = {
        "rolling_max_24h": "rolling_q95_24h",
        "rolling_max_168h": "rolling_q95_168h",
        "rolling_q75_24h": "rolling_q90_24h",
        "rolling_q75_168h": "rolling_q90_168h",
        "recent_peak_24h_count": None,
        "recent_peak_168h_count": None,
        "recent_peak_24h_flag": None,
        "recent_peak_168h_flag": None,
    }
    for col, fallback in defaults.items():
        if col not in out.columns:
            out[col] = out[fallback] if fallback and fallback in out.columns else 0.0
    required_zero = [
        "lag_1h",
        "lag_24h",
        "lag_168h",
        "rolling_mean_24h",
        "rolling_mean_168h",
        "rolling_q90_24h",
        "rolling_q95_24h",
        "rolling_q90_168h",
        "rolling_q95_168h",
        "hour",
        "day_of_week",
        "is_weekend",
        "is_business_hour",
        "is_morning_arrival_period",
        "is_evening_departure_period",
    ]
    for col in required_zero:
        if col not in out.columns:
            out[col] = 0.0
    p90 = out["peak_threshold_90_train_kw"].replace(0, np.nan)
    p95 = out["peak_threshold_95_train_kw"].replace(0, np.nan)
    out["risk_pred_vs_p90"] = safe_div(out["eahpa_pred"], p90)
    out["risk_pred_vs_p95"] = safe_div(out["eahpa_pred"], p95)
    out["risk_lag24_vs_p90"] = safe_div(out["lag_24h"], p90)
    out["risk_lag168_vs_p90"] = safe_div(out["lag_168h"], p90)
    out["risk_rollmax24_vs_p90"] = safe_div(out["rolling_max_24h"], p90)
    out["risk_rollq90_24_vs_p90"] = safe_div(out["rolling_q90_24h"], p90)
    out["risk_rollq90_168_vs_p90"] = safe_div(out["rolling_q90_168h"], p90)
    out["risk_recent_peak24_norm"] = out["recent_peak_24h_count"].astype(float) / 24.0
    out["risk_recent_peak168_norm"] = out["recent_peak_168h_count"].astype(float) / 168.0
    ratio_cols = [
        "risk_pred_vs_p90",
        "risk_pred_vs_p95",
        "risk_lag24_vs_p90",
        "risk_lag168_vs_p90",
        "risk_rollmax24_vs_p90",
        "risk_rollq90_24_vs_p90",
        "risk_rollq90_168_vs_p90",
        "risk_recent_peak24_norm",
        "risk_recent_peak168_norm",
        "recent_peak_24h_flag",
        "recent_peak_168h_flag",
    ]
    out["risk_combined_mean"] = out[ratio_cols].replace([np.inf, -np.inf], np.nan).fillna(0).mean(axis=1)
    out["risk_business_interaction"] = out["risk_combined_mean"] * out["is_business_hour"]
    out["risk_morning_interaction"] = out["risk_combined_mean"] * out["is_morning_arrival_period"]
    for col in RISK_MODEL_FEATURES:
        if col in out.columns:
            out[col] = out[col].replace([np.inf, -np.inf], np.nan).fillna(0)
    return out


def residual_diagnostics(val: pd.DataFrame) -> pd.DataFrame:
    work = val.copy()
    work["residual"] = work[TARGET] - work["eahpa_pred"]
    work["positive_residual"] = np.maximum(work["residual"], 0)
    work["abs_error"] = work["residual"].abs()
    rows = []
    for group_name, keys in [
        ("site", ["site_id"]),
        ("business_hour", ["is_business_hour"]),
        ("recent_peak_flag", ["recent_peak_24h_flag"]),
        ("predicted_peak_group", ["predicted_peak_group"]),
    ]:
        if keys[0] not in work.columns:
            continue
        for vals, sdf in work.groupby(keys, dropna=False):
            rows.append(
                {
                    "diagnostic_group": group_name,
                    "group_value": str(vals),
                    "row_count": len(sdf),
                    "mean_residual": sdf["residual"].mean(),
                    "median_residual": sdf["residual"].median(),
                    "mean_positive_residual": sdf["positive_residual"].mean(),
                    "mean_abs_error": sdf["abs_error"].mean(),
                    "underestimation_rate": rate(sdf["residual"].to_numpy(float) > 0),
                }
            )
    for risk_col, bins in RISK_BINS.items():
        work[f"{risk_col}_bin"] = pd.cut(work[risk_col], bins=bins, include_lowest=True)
        for val_bin, sdf in work.groupby(f"{risk_col}_bin", dropna=False):
            rows.append(
                {
                    "diagnostic_group": f"{risk_col}_bin",
                    "group_value": str(val_bin),
                    "row_count": len(sdf),
                    "mean_residual": sdf["residual"].mean(),
                    "median_residual": sdf["residual"].median(),
                    "mean_positive_residual": sdf["positive_residual"].mean(),
                    "mean_abs_error": sdf["abs_error"].mean(),
                    "underestimation_rate": rate(sdf["residual"].to_numpy(float) > 0),
                }
            )
    return pd.DataFrame(rows)


def with_predicted_group(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    p90 = out["peak_threshold_90_train_kw"].to_numpy(float)
    p95 = out["peak_threshold_95_train_kw"].to_numpy(float)
    pred = out["eahpa_pred"].to_numpy(float)
    out["predicted_peak_group"] = np.where(pred >= p95, "predicted_high_peak", np.where(pred >= p90, "predicted_peak", "predicted_normal"))
    return out


def candidate_metrics(val: pd.DataFrame, name: str, pred: np.ndarray, strategy: str, params: dict[str, Any], base: dict[str, float]) -> dict[str, Any]:
    tmp = val.copy()
    tmp["candidate_pred"] = clip(pred)
    m = evaluate(tmp, name, "candidate_pred", "validation")
    over_inc = m["overestimation_rate"] - base["overestimation_rate"]
    m.update(
        {
            "candidate_name": name,
            "strategy": strategy,
            "parameter_json": json.dumps(params, sort_keys=True),
            "selection_score": m["MAE"] + 0.20 * m["peak_MAE"] + 0.10 * m["high_peak_MAE"] + 0.02 * abs(m["peak_bias"]),
            "base_MAE": base["MAE"],
            "base_peak_MAE": base["peak_MAE"],
            "base_high_peak_MAE": base["high_peak_MAE"],
            "delta_MAE_vs_base": m["MAE"] - base["MAE"],
            "delta_peak_MAE_vs_base": m["peak_MAE"] - base["peak_MAE"],
            "delta_high_peak_MAE_vs_base": m["high_peak_MAE"] - base["high_peak_MAE"],
            "overestimation_rate_increase": over_inc,
            "acceptable": bool((m["MAE"] <= base["MAE"] * 1.01 or m["MAE"] < base["MAE"]) and (m["peak_MAE"] < base["peak_MAE"] or m["high_peak_MAE"] < base["high_peak_MAE"]) and over_inc <= 5.0),
        }
    )
    return m


def generate_candidates(val: pd.DataFrame, test: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Callable[[pd.DataFrame], np.ndarray]], dict[str, Any]]:
    val = with_predicted_group(val)
    test = with_predicted_group(test)
    base_tmp = val.copy()
    base_tmp["base_pred"] = base_tmp["eahpa_pred"]
    base = evaluate(base_tmp, "E-AHPA", "base_pred", "validation")
    residual = val[TARGET] - val["eahpa_pred"]
    pos_resid = residual[residual > 0]
    mean_pos = float(pos_resid.mean()) if len(pos_resid) else 0.0
    quant_pos = {q: float(pos_resid.quantile(q)) if len(pos_resid) else 0.0 for q in [0.60, 0.70, 0.80]}
    rows: list[dict[str, Any]] = []
    funcs: dict[str, Callable[[pd.DataFrame], np.ndarray]] = {}

    def add(name: str, strategy: str, params: dict[str, Any], func: Callable[[pd.DataFrame], np.ndarray]) -> None:
        funcs[name] = func
        rows.append(candidate_metrics(val, name, func(val), strategy, params, base))

    add("base_E_AHPA_no_correction", "base", {}, lambda df: df["eahpa_pred"].to_numpy(float))

    for frac in [0.10, 0.20, 0.30, 0.50]:
        for th in [0.75, 0.90, 1.00, 1.10, 1.25]:
            corr = frac * mean_pos
            name = f"global_positive_frac{frac}_risk{th}"
            add(name, "global_positive_residual", {"fraction": frac, "threshold": th, "correction": corr}, lambda df, corr=corr, th=th: df["eahpa_pred"].to_numpy(float) + (df["risk_combined_mean"].to_numpy(float) >= th) * corr)

    for risk_col, bins in RISK_BINS.items():
        val_bins = pd.cut(val[risk_col], bins=bins, include_lowest=True)
        global_corr = residual.groupby(val_bins).median().clip(lower=0).to_dict()
        for lam in [0.25, 0.50, 0.75, 1.00]:
            name = f"risk_bin_{risk_col}_lambda{lam}"

            def func(df: pd.DataFrame, risk_col=risk_col, bins=bins, global_corr=global_corr, lam=lam) -> np.ndarray:
                cats = pd.cut(df[risk_col], bins=bins, include_lowest=True)
                corr = cats.map(global_corr).astype(float).fillna(0).to_numpy()
                return df["eahpa_pred"].to_numpy(float) + lam * corr

            add(name, "risk_bin_median_residual", {"risk_feature": risk_col, "lambda": lam}, func)

            site_corr = residual.groupby([val["site_id"], val_bins]).median().clip(lower=0)
            site_count = residual.groupby([val["site_id"], val_bins]).size()
            name = f"site_risk_bin_{risk_col}_lambda{lam}"

            def site_func(df: pd.DataFrame, risk_col=risk_col, bins=bins, site_corr=site_corr, site_count=site_count, global_corr=global_corr, lam=lam) -> np.ndarray:
                cats = pd.cut(df[risk_col], bins=bins, include_lowest=True)
                corrections = []
                for site, cat in zip(df["site_id"], cats):
                    key = (site, cat)
                    if key in site_corr.index and site_count.loc[key] >= 30:
                        corrections.append(float(site_corr.loc[key]))
                    else:
                        corrections.append(float(global_corr.get(cat, 0.0)))
                return df["eahpa_pred"].to_numpy(float) + lam * np.asarray(corrections)

            add(name, "site_risk_bin_median_residual", {"risk_feature": risk_col, "lambda": lam, "min_site_bin_count": 30}, site_func)

    group_corr = residual.groupby(val["predicted_peak_group"]).apply(lambda s: np.maximum(s, 0).median()).to_dict()
    site_group_corr = residual.groupby([val["site_id"], val["predicted_peak_group"]]).apply(lambda s: np.maximum(s, 0).median())
    site_group_count = residual.groupby([val["site_id"], val["predicted_peak_group"]]).size()
    for lam in [0.25, 0.50, 0.75, 1.00]:
        name = f"predicted_group_lambda{lam}"
        add(name, "predicted_peak_group_correction", {"lambda": lam}, lambda df, lam=lam: df["eahpa_pred"].to_numpy(float) + lam * df["predicted_peak_group"].map(group_corr).fillna(0).to_numpy(float))
        name = f"site_predicted_group_lambda{lam}"

        def sg_func(df: pd.DataFrame, lam=lam) -> np.ndarray:
            corrections = []
            for site, group in zip(df["site_id"], df["predicted_peak_group"]):
                key = (site, group)
                if key in site_group_corr.index and site_group_count.loc[key] >= 30:
                    corrections.append(float(site_group_corr.loc[key]))
                else:
                    corrections.append(float(group_corr.get(group, 0.0)))
            return df["eahpa_pred"].to_numpy(float) + lam * np.asarray(corrections)

        add(name, "site_predicted_peak_group_correction", {"lambda": lam, "min_site_group_count": 30}, sg_func)

    for q, corr in quant_pos.items():
        for th in [0.90, 1.00, 1.10, 1.25]:
            name = f"upper_quantile_q{int(q*100)}_risk{th}"
            add(name, "quantile_upper_correction", {"positive_residual_quantile": q, "threshold": th, "correction": corr}, lambda df, corr=corr, th=th: df["eahpa_pred"].to_numpy(float) + (df["risk_combined_mean"].to_numpy(float) >= th) * corr)

    build_model_candidates(val, test, residual, funcs, rows, base)
    return pd.DataFrame(rows), funcs, base


def build_model_candidates(val: pd.DataFrame, test: pd.DataFrame, residual: pd.Series, funcs: dict[str, Callable[[pd.DataFrame], np.ndarray]], rows: list[dict[str, Any]], base: dict[str, float]) -> None:
    try:
        from sklearn.ensemble import GradientBoostingRegressor, HistGradientBoostingRegressor
        from sklearn.linear_model import Ridge
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
    except Exception:
        return
    X = val[RISK_MODEL_FEATURES].replace([np.inf, -np.inf], np.nan).fillna(0)
    models = [
        ("ridge_residual", make_pipeline(StandardScaler(), Ridge(alpha=1.0)), residual.to_numpy(float)),
        ("ridge_positive_residual", make_pipeline(StandardScaler(), Ridge(alpha=1.0)), np.maximum(residual.to_numpy(float), 0)),
        ("gbr_positive_residual", GradientBoostingRegressor(n_estimators=100, max_depth=2, learning_rate=0.03, subsample=0.8, random_state=RANDOM_STATE), np.maximum(residual.to_numpy(float), 0)),
        ("histgb_positive_residual", HistGradientBoostingRegressor(max_iter=100, learning_rate=0.03, max_leaf_nodes=15, l2_regularization=0.1, random_state=RANDOM_STATE), np.maximum(residual.to_numpy(float), 0)),
    ]
    joblib_ok, _ = package_version("joblib")
    joblib = importlib.import_module("joblib") if joblib_ok else None
    for model_name, model, y in models:
        try:
            model.fit(X, y)
            if joblib is not None:
                joblib.dump(model, MODELS_DIR / f"08E_{model_name}.joblib")
        except Exception:
            continue
        for lam in [0.25, 0.50, 0.75, 1.00]:
            for positive_only in [False, True]:
                name = f"model_{model_name}_lambda{lam}_{'positive_only' if positive_only else 'signed'}"

                def func(df: pd.DataFrame, model=model, lam=lam, positive_only=positive_only) -> np.ndarray:
                    Xd = df[RISK_MODEL_FEATURES].replace([np.inf, -np.inf], np.nan).fillna(0)
                    corr = model.predict(Xd)
                    if positive_only:
                        corr = np.maximum(corr, 0)
                    return df["eahpa_pred"].to_numpy(float) + lam * corr

                funcs[name] = func
                rows.append(candidate_metrics(val, name, "residual_model_correction", func(val), {"model": model_name, "lambda": lam, "positive_only": positive_only}, base) if False else candidate_metrics(val, name, func(val), "residual_model_correction", {"model": model_name, "lambda": lam, "positive_only": positive_only}, base))


def select_candidate(candidates: pd.DataFrame) -> tuple[pd.Series, pd.DataFrame]:
    acceptable = candidates[candidates["acceptable"]].copy()
    if acceptable.empty:
        selected = candidates[candidates["candidate_name"] == "base_E_AHPA_no_correction"].iloc[0]
        rule = "base selected because no correction candidate met validation constraints"
    else:
        selected = acceptable.sort_values(["selection_score", "MAE", "peak_MAE", "high_peak_MAE"]).iloc[0]
        rule = "lowest validation selection_score among acceptable correction candidates"
    summaries = []
    for role, sort_col in [
        ("primary_selected", None),
        ("best_validation_MAE", "MAE"),
        ("best_validation_peak_MAE", "peak_MAE"),
        ("best_validation_high_peak_MAE", "high_peak_MAE"),
        ("best_validation_selection_score", "selection_score"),
    ]:
        row = selected if sort_col is None else candidates.sort_values(sort_col).iloc[0]
        d = row.to_dict()
        d["selection_role"] = role
        d["selection_rule_used"] = rule
        summaries.append(d)
    return selected, pd.DataFrame(summaries)


def row_bootstrap_ci(delta: np.ndarray, n_boot: int = N_BOOTSTRAP, seed: int = 42) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    delta = np.asarray(delta, dtype=float)
    delta = delta[np.isfinite(delta)]
    if len(delta) == 0:
        return np.nan, np.nan
    vals = np.empty(n_boot)
    n = len(delta)
    for i in range(n_boot):
        vals[i] = float(np.mean(delta[rng.integers(0, n, n)]))
    return float(np.quantile(vals, 0.025)), float(np.quantile(vals, 0.975))


def block_bootstrap_ci(df: pd.DataFrame, delta_col: str, block_size: int) -> tuple[float, float]:
    rng = np.random.default_rng(100 + block_size)
    ordered = df.reset_index(drop=False).sort_values(["site_id", "timestamp"])
    blocks = []
    for _, sdf in ordered.groupby("site_id", sort=False):
        idx = sdf["index"].to_numpy()
        for start in range(0, len(idx), block_size):
            blocks.append(idx[start : start + block_size])
    if not blocks:
        return np.nan, np.nan
    vals = np.empty(N_BOOTSTRAP)
    n = len(df)
    for i in range(N_BOOTSTRAP):
        sample: list[int] = []
        while len(sample) < n:
            sample.extend(blocks[int(rng.integers(0, len(blocks)))].tolist())
        vals[i] = float(np.nanmean(df.loc[sample[:n], delta_col]))
    return float(np.nanquantile(vals, 0.025)), float(np.nanquantile(vals, 0.975))


def statistical_test(df: pd.DataFrame, proposed_col: str, comparator_col: str, comparator_name: str, subset: str, stats_ok: bool, stats: Any) -> dict[str, Any]:
    a = df[TARGET].to_numpy(float)
    prop = clip(df[proposed_col])
    comp = clip(df[comparator_col])
    delta = np.abs(prop - a) - np.abs(comp - a)
    work = df[["timestamp", "site_id"]].copy()
    work["delta"] = delta
    rb = row_bootstrap_ci(delta)
    b24 = block_bootstrap_ci(work, "delta", 24)
    b168 = block_bootstrap_ci(work, "delta", 168)
    wins = int(np.sum(np.abs(prop - a) < np.abs(comp - a)))
    losses = int(np.sum(np.abs(prop - a) > np.abs(comp - a)))
    wilcoxon_p = np.nan
    sign_p = np.nan
    if stats_ok:
        try:
            nz = delta[delta != 0]
            wilcoxon_p = float(stats.wilcoxon(nz, alternative="less").pvalue) if len(nz) else np.nan
        except Exception:
            pass
        try:
            sign_p = float(stats.binomtest(wins, wins + losses, 0.5, alternative="greater").pvalue) if wins + losses else np.nan
        except Exception:
            pass
    return {
        "comparison": f"PRC-E-AHPA_vs_{comparator_name}",
        "subset": subset,
        "observed_difference": float(np.mean(delta)),
        "row_bootstrap_ci_lower": rb[0],
        "row_bootstrap_ci_upper": rb[1],
        "block24_ci_lower": b24[0],
        "block24_ci_upper": b24[1],
        "block168_ci_lower": b168[0],
        "block168_ci_upper": b168[1],
        "wilcoxon_p_value": wilcoxon_p,
        "sign_test_p_value": sign_p,
        "win_rate": 100 * wins / (wins + losses) if wins + losses else np.nan,
        "row_count": len(df),
        "significant_row_bootstrap": rb[1] < 0,
        "significant_block24": b24[1] < 0,
        "significant_block168": b168[1] < 0,
    }


def site_metrics(df: pd.DataFrame, model_name: str, pred_col: str, split: str) -> list[dict[str, Any]]:
    return [evaluate(sdf, model_name, pred_col, split) | {"site_id": site} for site, sdf in df.groupby("site_id", sort=True)]


def save_figures(candidates: pd.DataFrame, metrics: pd.DataFrame, val: pd.DataFrame, test: pd.DataFrame, selected: pd.Series, stats: pd.DataFrame) -> None:
    plt.figure(figsize=(8, 5))
    plt.scatter(candidates["MAE"], candidates["peak_MAE"], s=18, alpha=0.5)
    plt.xlabel("Validation MAE")
    plt.ylabel("Validation peak_MAE")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08E_fig1_correction_validation_tradeoff.png", dpi=300)
    plt.close()

    test_metrics = metrics[metrics["split"] == "test"].copy()
    for fname, metric, title in [
        ("08E_fig2_test_mae_comparison.png", "MAE", "Test MAE"),
        ("08E_fig3_test_peak_mae_comparison.png", "peak_MAE", "Test peak_MAE"),
        ("08E_fig4_test_high_peak_mae_comparison.png", "high_peak_MAE", "Test high_peak_MAE"),
        ("08E_fig5_peak_underestimation_comparison.png", "peak_underestimation_rate", "Peak underestimation"),
    ]:
        plt.figure(figsize=(7, 5))
        plot = test_metrics.sort_values(metric)
        plt.bar(plot["model_name"], plot[metric])
        plt.xticks(rotation=35, ha="right", fontsize=8)
        plt.ylabel(metric)
        plt.title(title)
        plt.tight_layout()
        plt.savefig(FIGURES_DIR / fname, dpi=300)
        plt.close()

    sample = test.sort_values(["site_id", "timestamp"]).head(24 * 7)
    plt.figure(figsize=(10, 5))
    plt.plot(sample[TARGET].to_numpy(), label="Actual")
    plt.plot(sample["eahpa_pred"].to_numpy(), label="E-AHPA")
    plt.plot(sample["prc_eahpa_pred"].to_numpy(), label="PRC-E-AHPA")
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08E_fig6_actual_vs_eahpa_vs_prc_test_sample.png", dpi=300)
    plt.close()

    peak = test[test["is_peak_hour"] == 1]
    plt.figure(figsize=(8, 5))
    plt.hist(np.abs(peak["eahpa_pred"] - peak[TARGET]), bins=40, alpha=0.55, label="E-AHPA")
    plt.hist(np.abs(peak["prc_eahpa_pred"] - peak[TARGET]), bins=40, alpha=0.55, label="PRC-E-AHPA")
    plt.legend()
    plt.xlabel("Peak-row absolute error")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08E_fig7_peak_error_distribution.png", dpi=300)
    plt.close()

    site_rows = []
    for model, col in [("LGBM", "lgbm_pred"), ("E-AHPA", "eahpa_pred"), ("PRC-E-AHPA", "prc_eahpa_pred")]:
        for site, sdf in test.groupby("site_id"):
            site_rows.append({"site_id": site, "model": model, "peak_MAE": evaluate(sdf, model, col, "test")["peak_MAE"]})
    site_df = pd.DataFrame(site_rows)
    pivot = site_df.pivot(index="site_id", columns="model", values="peak_MAE")
    pivot.plot(kind="bar", figsize=(10, 5))
    plt.ylabel("Peak MAE")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08E_fig8_site_level_peak_mae.png", dpi=300)
    plt.close()

    diag = pd.read_csv(RESULTS_DIR / "08E_validation_residual_diagnostics.csv")
    rb = diag[diag["diagnostic_group"] == "risk_combined_mean_bin"].copy()
    plt.figure(figsize=(8, 5))
    plt.bar(rb["group_value"], rb["median_residual"].clip(lower=0))
    plt.xticks(rotation=35, ha="right")
    plt.ylabel("Positive median residual")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08E_fig9_risk_bin_residual_correction.png", dpi=300)
    plt.close()

    peak_stats = stats[stats["subset"] == "peak_rows"]
    plt.figure(figsize=(7, 4))
    x = np.arange(len(peak_stats))
    y = peak_stats["observed_difference"].to_numpy(float)
    plt.errorbar(x, y, yerr=[y - peak_stats["row_bootstrap_ci_lower"].to_numpy(float), peak_stats["row_bootstrap_ci_upper"].to_numpy(float) - y], fmt="o")
    plt.axhline(0, color="black", linewidth=0.8)
    plt.xticks(x, peak_stats["comparison"], rotation=35, ha="right", fontsize=8)
    plt.ylabel("PRC MAE - comparator MAE")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08E_fig10_bootstrap_ci_peak_mae.png", dpi=300)
    plt.close()


def write_reports(selected: pd.Series, metrics: pd.DataFrame, stats: pd.DataFrame, use_prc: bool) -> None:
    test = metrics[metrics["split"] == "test"].set_index("model_name")
    lgbm = test.loc["LGBMRegressor"]
    eahpa = test.loc["E-AHPA"]
    prc = test.loc["PRC-E-AHPA"]
    peak_support = bool(stats[(stats["comparison"] == "PRC-E-AHPA_vs_LGBMRegressor") & (stats["subset"] == "peak_rows")]["significant_row_bootstrap"].iloc[0])
    recommendation = "PRC-E-AHPA" if use_prc else "E-AHPA"
    method = """Step 08E method report
==========================
PRC-E-AHPA is Peak-Risk Calibrated Enhanced Adaptive Hybrid Peak-Aware Ensemble.
Step 09 showed that E-AHPA's overall MAE improvement was robust, but its peak_MAE improvement was small and not statistically conclusive.
Step 08E therefore adds a validation-calibrated residual correction layer on top of the fixed Step 08D E-AHPA point forecast.
The correction candidates use only validation residuals and test-time-available peak-risk features such as lagged load, rolling maxima, rolling quantiles, recent peak counts, calendar flags, and train-derived site peak thresholds.
This differs from Step 08D because the main forecaster is fixed; only a residual calibration rule is selected on validation data.
"""
    leakage = """Step 08E leakage safety report
===============================
- The main E-AHPA forecasting model is not retrained.
- Correction rules are fitted and selected using validation residuals only.
- Test labels are not used for selecting correction parameters.
- Actual test peak labels are not used to apply corrections.
- Peak-risk features use only past load, calendar indicators, and train-derived site thresholds.
- No future load, future sessions, weather, traffic, price, or scheduling information is used.
"""
    novelty = """Step 08E novelty contribution report
=====================================
This study extends E-AHPA with a peak-risk calibration layer for EV charging load forecasting.
The contribution separates average-load forecasting from peak-risk residual calibration.
E-AHPA provides the strong base forecast, while PRC uses validation-constrained residual rules to address systematic underprediction in high-risk operating conditions.
The method is designed to improve scheduling relevance by reducing peak-risk error without sacrificing ordinary-hour accuracy.
All peak and average tradeoffs are statistically assessed before any scheduling step is attempted.
"""
    results = f"""Step 08E results report
========================
Selected correction strategy: {selected['strategy']}.
Selected correction candidate: {selected['candidate_name']}.
Validation MAE: {selected['MAE']:.4f} kW; validation peak_MAE: {selected['peak_MAE']:.4f} kW; validation high_peak_MAE: {selected['high_peak_MAE']:.4f} kW.

Test metrics:
- LGBMRegressor: MAE {lgbm['MAE']:.4f}, peak_MAE {lgbm['peak_MAE']:.4f}, high_peak_MAE {lgbm['high_peak_MAE']:.4f}.
- E-AHPA: MAE {eahpa['MAE']:.4f}, peak_MAE {eahpa['peak_MAE']:.4f}, high_peak_MAE {eahpa['high_peak_MAE']:.4f}.
- PRC-E-AHPA: MAE {prc['MAE']:.4f}, peak_MAE {prc['peak_MAE']:.4f}, high_peak_MAE {prc['high_peak_MAE']:.4f}.

PRC improves overall MAE over E-AHPA: {prc['MAE'] < eahpa['MAE']}.
PRC improves peak_MAE over E-AHPA: {prc['peak_MAE'] < eahpa['peak_MAE']}.
PRC improves high_peak_MAE over E-AHPA: {prc['high_peak_MAE'] < eahpa['high_peak_MAE']}.
Peak bootstrap support versus LGBM: {peak_support}.
Recommended model for paper: {recommendation}.
"""
    paper = f"""The PRC-E-AHPA calibration layer selected {selected['strategy']} using validation residuals only. On the test set, PRC-E-AHPA achieved MAE = {prc['MAE']:.4f} kW, peak_MAE = {prc['peak_MAE']:.4f} kW, and high_peak_MAE = {prc['high_peak_MAE']:.4f} kW, compared with E-AHPA MAE = {eahpa['MAE']:.4f} kW and peak_MAE = {eahpa['peak_MAE']:.4f} kW. The recommended forecasting model is {recommendation}. This result should be reported cautiously if the peak-specific bootstrap intervals still cross zero."""
    captions = """Figure captions for Step 08E
============================
Fig. 1. Validation MAE versus peak_MAE for peak-risk correction candidates.
Fig. 2. Test MAE comparison for LGBM, E-AHPA, and PRC-E-AHPA.
Fig. 3. Test peak_MAE comparison.
Fig. 4. Test high_peak_MAE comparison.
Fig. 5. Peak underestimation comparison.
Fig. 6. Representative test-window actual load, E-AHPA prediction, and PRC-E-AHPA prediction.
Fig. 7. Peak-row absolute error distribution.
Fig. 8. Site-level peak_MAE comparison.
Fig. 9. Learned validation residual correction by risk bin.
Fig. 10. Peak-row bootstrap confidence intervals for PRC-E-AHPA differences.
"""
    (RESULTS_DIR / "08E_method_report.txt").write_text(method, encoding="utf-8")
    (RESULTS_DIR / "08E_leakage_safety_report.txt").write_text(leakage, encoding="utf-8")
    (RESULTS_DIR / "08E_novelty_contribution_report.txt").write_text(novelty, encoding="utf-8")
    (RESULTS_DIR / "08E_results_report.txt").write_text(results, encoding="utf-8")
    (RESULTS_DIR / "08E_paper_ready_results_paragraph.txt").write_text(paper, encoding="utf-8")
    (RESULTS_DIR / "08E_figure_captions.txt").write_text(captions, encoding="utf-8")


def main() -> None:
    ensure_dirs()
    stats_ok, stats_mod = scipy_tools()
    val, test, alignment_rows, selected_eahpa_name = build_data()
    pd.DataFrame(alignment_rows).to_csv(RESULTS_DIR / "08E_alignment_report.csv", index=False)
    val = with_predicted_group(val)
    test = with_predicted_group(test)
    val = val.dropna(subset=["eahpa_pred", "lgbm_pred"])
    test = test.dropna(subset=["eahpa_pred", "lgbm_pred"])

    pd.DataFrame({"feature": RISK_MODEL_FEATURES, "validation_mean": [val[c].mean() for c in RISK_MODEL_FEATURES], "test_mean": [test[c].mean() for c in RISK_MODEL_FEATURES]}).to_csv(RESULTS_DIR / "08E_peak_risk_feature_summary.csv", index=False)
    residual_diagnostics(val).to_csv(RESULTS_DIR / "08E_validation_residual_diagnostics.csv", index=False)

    candidates, funcs, base_val_metrics = generate_candidates(val, test)
    candidates.to_csv(RESULTS_DIR / "08E_correction_candidate_validation_results.csv", index=False)
    selected, summary = select_candidate(candidates)
    summary.to_csv(RESULTS_DIR / "08E_selected_correction_summary.csv", index=False)
    selected_func = funcs[selected["candidate_name"]]
    val["prc_eahpa_pred"] = clip(selected_func(val))
    test["prc_eahpa_pred"] = clip(selected_func(test))
    val["base_eahpa_pred"] = val["eahpa_pred"]
    test["base_eahpa_pred"] = test["eahpa_pred"]

    val_out = val[["timestamp", "site_id", TARGET, "split", "is_peak_hour", "is_high_peak_hour", "lgbm_pred", "eahpa_pred", "prc_eahpa_pred"]].copy()
    test_out = test[["timestamp", "site_id", TARGET, "split", "is_peak_hour", "is_high_peak_hour", "lgbm_pred", "eahpa_pred", "prc_eahpa_pred"]].copy()
    if "catboost_pred" in val.columns:
        val_out["catboost_pred"] = val["catboost_pred"]
        test_out["catboost_pred"] = test["catboost_pred"]
    if "baseline_pred" in test.columns:
        test_out["baseline_pred"] = test["baseline_pred"]
    val_out.to_csv(RESULTS_DIR / "08E_validation_predictions.csv", index=False)
    test_out.to_csv(RESULTS_DIR / "08E_test_predictions.csv", index=False)

    metric_rows = []
    for split, frame in [("validation", val), ("test", test)]:
        metric_rows.append(evaluate(frame.assign(tmp=frame["lgbm_pred"]), "LGBMRegressor", "tmp", split))
        if "catboost_pred" in frame.columns:
            metric_rows.append(evaluate(frame.assign(tmp=frame["catboost_pred"]), "CatBoostRegressor", "tmp", split))
        metric_rows.append(evaluate(frame.assign(tmp=frame["eahpa_pred"]), "E-AHPA", "tmp", split))
        metric_rows.append(evaluate(frame.assign(tmp=frame["prc_eahpa_pred"]), "PRC-E-AHPA", "tmp", split))
        if split == "test" and "baseline_pred" in frame.columns:
            metric_rows.append(evaluate(frame.assign(tmp=frame["baseline_pred"]), "Linear_Regression_All_Features", "tmp", split))
    metrics = pd.DataFrame(metric_rows)
    metrics.to_csv(RESULTS_DIR / "08E_prc_eahpa_overall_metrics.csv", index=False)

    site_rows = []
    for split, frame in [("validation", val), ("test", test)]:
        for model, col in [("LGBMRegressor", "lgbm_pred"), ("E-AHPA", "eahpa_pred"), ("PRC-E-AHPA", "prc_eahpa_pred")]:
            site_rows.extend(site_metrics(frame, model, col, split))
    pd.DataFrame(site_rows).to_csv(RESULTS_DIR / "08E_prc_eahpa_site_metrics.csv", index=False)

    comp = metrics[(metrics["split"] == "test") & (metrics["model_name"].isin(["LGBMRegressor", "E-AHPA", "PRC-E-AHPA", "CatBoostRegressor", "Linear_Regression_All_Features"]))].copy()
    comp["delta_MAE_vs_E_AHPA"] = comp["MAE"] - float(comp.loc[comp["model_name"] == "E-AHPA", "MAE"].iloc[0])
    comp["delta_peak_MAE_vs_E_AHPA"] = comp["peak_MAE"] - float(comp.loc[comp["model_name"] == "E-AHPA", "peak_MAE"].iloc[0])
    comp.to_csv(RESULTS_DIR / "08E_prc_vs_lgbm_eahpa_comparison.csv", index=False)
    comp.sort_values(["MAE", "peak_MAE"]).to_csv(RESULTS_DIR / "08E_final_forecasting_summary.csv", index=False)

    stat_rows = []
    for comp_name, comp_col in [("LGBMRegressor", "lgbm_pred"), ("E-AHPA", "eahpa_pred")]:
        stat_rows.append(statistical_test(test, "prc_eahpa_pred", comp_col, comp_name, "overall", stats_ok, stats_mod))
        stat_rows.append(statistical_test(test[test["is_peak_hour"] == 1], "prc_eahpa_pred", comp_col, comp_name, "peak_rows", stats_ok, stats_mod))
        stat_rows.append(statistical_test(test[test["is_high_peak_hour"] == 1], "prc_eahpa_pred", comp_col, comp_name, "high_peak_rows", stats_ok, stats_mod))
    stat_df = pd.DataFrame(stat_rows)
    stat_df.to_csv(RESULTS_DIR / "08E_statistical_tests.csv", index=False)

    selected_config = selected.to_dict()
    (MODELS_DIR / "08E_selected_correction_config.json").write_text(json.dumps(selected_config, indent=2, default=str), encoding="utf-8")
    save_figures(candidates, metrics, val, test, selected, stat_df)

    prc_test = metrics[(metrics["split"] == "test") & (metrics["model_name"] == "PRC-E-AHPA")].iloc[0]
    eahpa_test = metrics[(metrics["split"] == "test") & (metrics["model_name"] == "E-AHPA")].iloc[0]
    lgbm_test = metrics[(metrics["split"] == "test") & (metrics["model_name"] == "LGBMRegressor")].iloc[0]
    peak_lgbm = stat_df[(stat_df["comparison"] == "PRC-E-AHPA_vs_LGBMRegressor") & (stat_df["subset"] == "peak_rows")].iloc[0]
    use_prc = bool(prc_test["MAE"] <= eahpa_test["MAE"] * 1.01 and (prc_test["peak_MAE"] < eahpa_test["peak_MAE"] or prc_test["high_peak_MAE"] < eahpa_test["high_peak_MAE"]))
    write_reports(selected, metrics, stat_df, use_prc)

    print("Step 08E peak-risk calibrated E-AHPA complete")
    print(f"Base LGBM test MAE and peak_MAE: {lgbm_test['MAE']:.4f}, {lgbm_test['peak_MAE']:.4f}")
    print(f"Base E-AHPA test MAE and peak_MAE: {eahpa_test['MAE']:.4f}, {eahpa_test['peak_MAE']:.4f}")
    print(f"Selected PRC-E-AHPA strategy: {selected['strategy']}")
    print(f"Selected PRC-E-AHPA validation MAE and peak_MAE: {selected['MAE']:.4f}, {selected['peak_MAE']:.4f}")
    print(f"Selected PRC-E-AHPA test MAE and peak_MAE: {prc_test['MAE']:.4f}, {prc_test['peak_MAE']:.4f}")
    print(f"Selected PRC-E-AHPA high_peak_MAE: {prc_test['high_peak_MAE']:.4f}")
    print(f"Selected PRC-E-AHPA peak underestimation rate: {prc_test['peak_underestimation_rate']:.4f}")
    print(f"PRC improves MAE over E-AHPA: {prc_test['MAE'] < eahpa_test['MAE']}")
    print(f"PRC improves peak_MAE over E-AHPA: {prc_test['peak_MAE'] < eahpa_test['peak_MAE']}")
    print(f"PRC improves peak_MAE over LGBM: {prc_test['peak_MAE'] < lgbm_test['peak_MAE']}")
    print(f"Peak bootstrap CI supports improvement vs LGBM: {peak_lgbm['row_bootstrap_ci_upper'] < 0}")
    print(f"Final recommendation: {'PRC-E-AHPA' if use_prc else 'E-AHPA'}")
    print(f"Results folder: {RESULTS_DIR}")
    print(f"Figures folder: {FIGURES_DIR}")


if __name__ == "__main__":
    main()
