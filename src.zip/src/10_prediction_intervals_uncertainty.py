"""
Step 10: Prediction intervals and uncertainty-aware forecasts.

Run from the project root:
    python src/10_prediction_intervals_uncertainty.py

This step calibrates conformal-style intervals from validation residuals only.
It does not retrain forecasting models or tune using test labels.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import re
import sys
import types
import warnings

import numpy as np


if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
FEATURE_FILE = PROJECT_ROOT / "data" / "processed" / "05B_forecasting_features.csv"
EAHPA_VAL_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_validation_predictions.csv"
EAHPA_TEST_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_test_predictions.csv"
EAHPA_SUMMARY_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_selected_hybrid_summary.csv"
PRC_VAL_FILE = PROJECT_ROOT / "results" / "08E_peak_risk_calibrated_eahpa" / "08E_validation_predictions.csv"
PRC_TEST_FILE = PROJECT_ROOT / "results" / "08E_peak_risk_calibrated_eahpa" / "08E_test_predictions.csv"
DECISION_FILE = PROJECT_ROOT / "results" / "09B_statistical_validation_with_prc" / "09B_final_model_decision.csv"
METRICS09B_FILE = PROJECT_ROOT / "results" / "09B_statistical_validation_with_prc" / "09B_test_metrics_recomputed.csv"
LGBM_VAL_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_validation_predictions.csv"
LGBM_TEST_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_test_predictions.csv"

RESULTS_DIR = PROJECT_ROOT / "results" / "10_prediction_intervals"
FIGURES_DIR = PROJECT_ROOT / "figures" / "10_prediction_intervals"
SCHEDULING_FILE = PROJECT_ROOT / "data" / "processed" / "10_uncertainty_forecasts_for_scheduling.csv"

ACTUAL = "actual_load_kw"
KEYS = ["timestamp", "site_id"]
COVERAGES = [0.80, 0.90, 0.95]


def ensure_dirs() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    SCHEDULING_FILE.parent.mkdir(parents=True, exist_ok=True)


def prediction_cols(df: pd.DataFrame) -> list[str]:
    return [c for c in df.columns if c.startswith("prediction_")]


def clip(values: Any) -> np.ndarray:
    return np.maximum(np.asarray(values, dtype=float), 0.0)


def rate(mask: np.ndarray) -> float:
    return float(np.mean(mask) * 100) if len(mask) else np.nan


def selected_eahpa_col() -> str:
    summary = pd.read_csv(EAHPA_SUMMARY_FILE)
    primary = summary[summary["selection_role"] == "primary_selected_AHPA_Ensemble"]
    if primary.empty:
        primary = summary.head(1)
    return "prediction_" + str(primary.iloc[0]["selected_model_name"])


def load_base() -> pd.DataFrame:
    df = pd.read_csv(FEATURE_FILE)
    df["timestamp"] = df["timestamp"].astype(str)
    if ACTUAL not in df.columns:
        df[ACTUAL] = df["target_load_kw"]
    if "peak_threshold_90_train_kw" not in df.columns or "peak_threshold_95_train_kw" not in df.columns:
        train = df[df["split"] == "train"]
        p90 = train.groupby("site_id")["target_load_kw"].quantile(0.90).to_dict()
        p95 = train.groupby("site_id")["target_load_kw"].quantile(0.95).to_dict()
        df["peak_threshold_90_train_kw"] = df["site_id"].map(p90).fillna(train["target_load_kw"].quantile(0.90))
        df["peak_threshold_95_train_kw"] = df["site_id"].map(p95).fillna(train["target_load_kw"].quantile(0.95))
    keep = ["timestamp", "site_id", ACTUAL, "target_load_kw", "split", "is_peak_hour", "is_high_peak_hour", "peak_threshold_90_train_kw", "peak_threshold_95_train_kw"]
    return df[df["split"].isin(["validation", "test"])][[c for c in keep if c in df.columns]].copy()


def align(base: pd.DataFrame, path: Path, source: str, col: str, out_col: str, split: str) -> tuple[pd.DataFrame, dict[str, Any]]:
    row = {
        "source": source,
        "file": str(path),
        "split": split,
        "file_exists": path.exists(),
        "requested_column": col,
        "prediction_columns_found": "",
        "rows": 0,
        "matched_rows": 0,
        "notes": "",
    }
    if not path.exists():
        row["notes"] = "missing"
        return base, row
    pred = pd.read_csv(path)
    pred["timestamp"] = pred["timestamp"].astype(str)
    row["rows"] = len(pred)
    row["prediction_columns_found"] = ", ".join(prediction_cols(pred) + [c for c in pred.columns if c.endswith("_pred")])
    if col not in pred.columns:
        row["notes"] = "requested column missing"
        return base, row
    sub_base = base[base["split"] == split].copy()
    sub_other = base[base["split"] != split].copy()
    sub_base = sub_base.merge(pred[KEYS + [col]].rename(columns={col: out_col}), on=KEYS, how="left")
    if out_col not in sub_base.columns:
        x_col = f"{out_col}_x"
        y_col = f"{out_col}_y"
        if y_col in sub_base.columns:
            sub_base[out_col] = sub_base[y_col]
            if x_col in sub_base.columns:
                sub_base[out_col] = sub_base[out_col].fillna(sub_base[x_col])
            sub_base = sub_base.drop(columns=[c for c in [x_col, y_col] if c in sub_base.columns])
    row["matched_rows"] = int(sub_base[out_col].notna().sum())
    row["notes"] = "loaded"
    return pd.concat([sub_base, sub_other], ignore_index=True), row


def load_data() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, str, str]:
    data = load_base()
    e_col = selected_eahpa_col()
    rows = []
    for path, source, col, out_col, split in [
        (EAHPA_VAL_FILE, "E-AHPA validation", e_col, "main_point_forecast_kw", "validation"),
        (EAHPA_TEST_FILE, "E-AHPA test", e_col, "main_point_forecast_kw", "test"),
        (PRC_VAL_FILE, "PRC-E-AHPA validation", "prc_eahpa_pred", "peak_sensitive_point_forecast_kw", "validation"),
        (PRC_TEST_FILE, "PRC-E-AHPA test", "prc_eahpa_pred", "peak_sensitive_point_forecast_kw", "test"),
        (LGBM_VAL_FILE, "LGBM validation optional", "prediction_LGBMRegressor", "lgbm_pred", "validation"),
        (LGBM_TEST_FILE, "LGBM test optional", "prediction_LGBMRegressor", "lgbm_pred", "test"),
    ]:
        data, row = align(data, path, source, col, out_col, split)
        rows.append(row)
    report = pd.DataFrame(rows)
    report.to_csv(RESULTS_DIR / "10_prediction_alignment_report.csv", index=False)
    data = data.dropna(subset=["main_point_forecast_kw", "peak_sensitive_point_forecast_kw"])
    return data[data["split"] == "validation"].copy(), data[data["split"] == "test"].copy(), report, e_col, "prc_eahpa_pred"


def risk_group(df: pd.DataFrame, pred_col: str) -> pd.Series:
    pred = df[pred_col].to_numpy(float)
    p90 = df["peak_threshold_90_train_kw"].to_numpy(float)
    p95 = df["peak_threshold_95_train_kw"].to_numpy(float)
    return pd.Series(np.where(pred >= p95, "high_peak_risk", np.where(pred >= p90, "peak_risk", "normal_risk")), index=df.index)


def q_abs(resid: pd.Series, coverage: float) -> float:
    return float(np.quantile(np.abs(resid.dropna()), coverage)) if resid.notna().any() else 0.0


def quantile_rows(val: pd.DataFrame, track: str) -> list[dict[str, Any]]:
    rows = []
    resid = val[ACTUAL] - val[track]
    val = val.copy()
    val["risk_group"] = risk_group(val, track)
    for cov in COVERAGES:
        rows.append({"forecast_track": track, "method": "global_abs", "site_id": "", "risk_group": "", "nominal_coverage": cov, "quantile_value": q_abs(resid, cov), "lower_quantile": np.nan, "upper_quantile": np.nan, "validation_sample_count": len(val), "fallback_used": ""})
        lo = float(np.quantile(resid, (1 - cov) / 2))
        hi = float(np.quantile(resid, 1 - (1 - cov) / 2))
        rows.append({"forecast_track": track, "method": "asymmetric", "site_id": "", "risk_group": "", "nominal_coverage": cov, "quantile_value": np.nan, "lower_quantile": lo, "upper_quantile": hi, "validation_sample_count": len(val), "fallback_used": ""})
        upper = float(np.quantile(resid, cov))
        rows.append({"forecast_track": track, "method": "conservative_upper", "site_id": "", "risk_group": "", "nominal_coverage": cov, "quantile_value": np.nan, "lower_quantile": 0.0, "upper_quantile": upper, "validation_sample_count": len(val), "fallback_used": ""})
        for site, sdf in val.groupby("site_id"):
            r = sdf[ACTUAL] - sdf[track]
            rows.append({"forecast_track": track, "method": "site_abs", "site_id": site, "risk_group": "", "nominal_coverage": cov, "quantile_value": q_abs(r, cov), "lower_quantile": np.nan, "upper_quantile": np.nan, "validation_sample_count": len(sdf), "fallback_used": "" if len(sdf) >= 30 else "global"})
        for group, sdf in val.groupby("risk_group"):
            r = sdf[ACTUAL] - sdf[track]
            lo_g = float(np.quantile(r, (1 - cov) / 2)) if len(sdf) else lo
            hi_g = float(np.quantile(r, 1 - (1 - cov) / 2)) if len(sdf) else hi
            rows.append({"forecast_track": track, "method": "risk_asymmetric", "site_id": "", "risk_group": group, "nominal_coverage": cov, "quantile_value": np.nan, "lower_quantile": lo_g, "upper_quantile": hi_g, "validation_sample_count": len(sdf), "fallback_used": "" if len(sdf) >= 30 else "global"})
        for (site, group), sdf in val.groupby(["site_id", "risk_group"]):
            r = sdf[ACTUAL] - sdf[track]
            lo_sg = float(np.quantile(r, (1 - cov) / 2)) if len(sdf) >= 30 else lo
            hi_sg = float(np.quantile(r, 1 - (1 - cov) / 2)) if len(sdf) >= 30 else hi
            rows.append({"forecast_track": track, "method": "site_risk_asymmetric", "site_id": site, "risk_group": group, "nominal_coverage": cov, "quantile_value": np.nan, "lower_quantile": lo_sg, "upper_quantile": hi_sg, "validation_sample_count": len(sdf), "fallback_used": "" if len(sdf) >= 30 else "global"})
    return rows


def get_quant(qdf: pd.DataFrame, track: str, method: str, cov: float, site: str = "", group: str = "") -> pd.Series:
    sub = qdf[(qdf["forecast_track"] == track) & (qdf["method"] == method) & (np.isclose(qdf["nominal_coverage"], cov))]
    if site:
        sub2 = sub[sub["site_id"] == site]
        if not sub2.empty and sub2.iloc[0]["fallback_used"] != "global":
            return sub2.iloc[0]
    if group:
        sub2 = sub[sub["risk_group"] == group]
        if not sub2.empty:
            return sub2.iloc[0]
    return sub.iloc[0]


def make_interval(test: pd.DataFrame, qdf: pd.DataFrame, track: str, method: str, cov: float) -> tuple[np.ndarray, np.ndarray]:
    pred = test[track].to_numpy(float)
    lower = np.zeros(len(test))
    upper = np.zeros(len(test))
    groups = risk_group(test, track)
    if method == "global_abs":
        q = get_quant(qdf, track, method, cov)["quantile_value"]
        lower, upper = pred - q, pred + q
    elif method == "site_abs":
        for i, (_, row) in enumerate(test.iterrows()):
            q = get_quant(qdf, track, method, cov, site=row["site_id"])["quantile_value"]
            lower[i], upper[i] = pred[i] - q, pred[i] + q
    elif method == "asymmetric":
        q = get_quant(qdf, track, method, cov)
        lower, upper = pred + q["lower_quantile"], pred + q["upper_quantile"]
    elif method == "risk_asymmetric":
        for i, (_, row) in enumerate(test.iterrows()):
            q = get_quant(qdf, track, method, cov, group=groups.iloc[i])
            lower[i], upper[i] = pred[i] + q["lower_quantile"], pred[i] + q["upper_quantile"]
    elif method == "site_risk_asymmetric":
        for i, (_, row) in enumerate(test.iterrows()):
            q = get_quant(qdf, track, method, cov, site=row["site_id"], group=groups.iloc[i])
            lower[i], upper[i] = pred[i] + q["lower_quantile"], pred[i] + q["upper_quantile"]
    elif method == "conservative_upper":
        q = get_quant(qdf, track, method, cov)
        lower, upper = pred + q["lower_quantile"], pred + q["upper_quantile"]
    return clip(lower), clip(upper)


def interval_score(a: np.ndarray, lo: np.ndarray, hi: np.ndarray, alpha: float) -> float:
    width = hi - lo
    below = a < lo
    above = a > hi
    score = width + (2 / alpha) * (lo - a) * below + (2 / alpha) * (a - hi) * above
    return float(np.mean(score))


def eval_interval(df: pd.DataFrame, track: str, method: str, cov: float, lo: np.ndarray, hi: np.ndarray) -> dict[str, Any]:
    a = df[ACTUAL].to_numpy(float)
    pred = df[track].to_numpy(float)
    peak = df["is_peak_hour"].to_numpy(int) == 1
    high = df["is_high_peak_hour"].to_numpy(int) == 1
    covered = (a >= lo) & (a <= hi)
    width = hi - lo
    point_under = pred < a
    upper_under = hi < a
    alpha = 1 - cov
    return {
        "forecast_track": track,
        "method": method,
        "nominal_coverage": cov,
        "empirical_coverage": rate(covered) / 100,
        "coverage_gap": rate(covered) / 100 - cov,
        "average_interval_width": float(np.mean(width)),
        "median_interval_width": float(np.median(width)),
        "normalized_average_width_by_mean_load": float(np.mean(width) / np.mean(a)) if np.mean(a) else np.nan,
        "lower_violation_rate": rate(a < lo),
        "upper_violation_rate": rate(a > hi),
        "winkler_score": interval_score(a, lo, hi, alpha),
        "interval_score": interval_score(a, lo, hi, alpha),
        "peak_coverage": rate(covered[peak]) / 100,
        "high_peak_coverage": rate(covered[high]) / 100,
        "peak_average_interval_width": float(np.mean(width[peak])) if peak.any() else np.nan,
        "high_peak_average_interval_width": float(np.mean(width[high])) if high.any() else np.nan,
        "peak_upper_violation_rate": rate((a > hi)[peak]),
        "high_peak_upper_violation_rate": rate((a > hi)[high]),
        "point_underestimation_rate": rate(point_under),
        "upper_bound_underestimation_rate": rate(upper_under),
        "underestimation_risk_reduction": rate(point_under) - rate(upper_under),
        "row_count": len(df),
    }


def by_group_metrics(df: pd.DataFrame, group_col: str, track: str, method: str, cov: float, lo: np.ndarray, hi: np.ndarray) -> list[dict[str, Any]]:
    work = df.copy()
    work["lo"] = lo
    work["hi"] = hi
    if group_col == "month":
        work["month"] = work["timestamp"].astype(str).str.slice(0, 7)
    rows = []
    for g, sdf in work.groupby(group_col):
        a = sdf[ACTUAL].to_numpy(float)
        covered = (a >= sdf["lo"].to_numpy(float)) & (a <= sdf["hi"].to_numpy(float))
        width = sdf["hi"].to_numpy(float) - sdf["lo"].to_numpy(float)
        peak = sdf["is_peak_hour"].to_numpy(int) == 1
        rows.append({"group": g, "forecast_track": track, "method": method, "nominal_coverage": cov, "coverage": rate(covered) / 100, "peak_coverage": rate(covered[peak]) / 100 if peak.any() else np.nan, "average_width": float(np.mean(width)), "row_count": len(sdf), "peak_row_count": int(peak.sum())})
    return rows


def evaluate_all(val: pd.DataFrame, test: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[tuple[str, str, float], tuple[np.ndarray, np.ndarray]]]:
    qrows = []
    for track in ["main_point_forecast_kw", "peak_sensitive_point_forecast_kw"]:
        qrows.extend(quantile_rows(val, track))
    qdf = pd.DataFrame(qrows)
    qdf.to_csv(RESULTS_DIR / "10_interval_calibration_quantiles.csv", index=False)
    metrics, site_rows, month_rows = [], [], []
    intervals = {}
    methods = ["global_abs", "site_abs", "asymmetric", "risk_asymmetric", "site_risk_asymmetric", "conservative_upper"]
    for track in ["main_point_forecast_kw", "peak_sensitive_point_forecast_kw"]:
        for method in methods:
            for cov in COVERAGES:
                lo, hi = make_interval(test, qdf, track, method, cov)
                intervals[(track, method, cov)] = (lo, hi)
                metrics.append(eval_interval(test, track, method, cov, lo, hi))
                site_rows.extend(by_group_metrics(test, "site_id", track, method, cov, lo, hi))
                month_rows.extend(by_group_metrics(test, "month", track, method, cov, lo, hi))
    overall = pd.DataFrame(metrics)
    site = pd.DataFrame(site_rows).rename(columns={"group": "site_id"})
    month = pd.DataFrame(month_rows).rename(columns={"group": "month"})
    overall.to_csv(RESULTS_DIR / "10_interval_metrics_overall.csv", index=False)
    site.to_csv(RESULTS_DIR / "10_interval_metrics_by_site.csv", index=False)
    month.to_csv(RESULTS_DIR / "10_interval_metrics_by_month.csv", index=False)
    return overall, site, month, intervals


def select_interval(overall: pd.DataFrame) -> pd.Series:
    cand = overall[(overall["forecast_track"] == "main_point_forecast_kw") & (np.isclose(overall["nominal_coverage"], 0.90))].copy()
    cand["acceptable"] = (
        (cand["empirical_coverage"] >= cand["nominal_coverage"] - 0.03)
        & (cand["peak_coverage"] >= 0.80)
        & (cand["high_peak_coverage"] >= 0.80)
        & (cand["upper_bound_underestimation_rate"] < cand["point_underestimation_rate"])
    )
    if cand["acceptable"].any():
        sel = cand[cand["acceptable"]].sort_values(["average_interval_width", "upper_bound_underestimation_rate"]).iloc[0]
        reason = "90% E-AHPA interval meets coverage, peak coverage, and underestimation reduction constraints with narrowest width"
    else:
        sel = cand.sort_values(["upper_bound_underestimation_rate", "average_interval_width"]).iloc[0]
        reason = "fallback to best 90% E-AHPA interval by upper-bound underestimation and width"
    out = sel.to_dict()
    out["selected_forecast_track"] = out.pop("forecast_track")
    out["selected_method"] = out.pop("method")
    out["selected_nominal_coverage"] = out.pop("nominal_coverage")
    out["reason_selected"] = reason
    pd.DataFrame([out]).to_csv(RESULTS_DIR / "10_selected_interval_method.csv", index=False)
    return pd.Series(out)


def save_scheduling_file(test: pd.DataFrame, selected: pd.Series, intervals: dict[tuple[str, str, float], tuple[np.ndarray, np.ndarray]]) -> pd.DataFrame:
    key = (selected["selected_forecast_track"], selected["selected_method"], float(selected["selected_nominal_coverage"]))
    lo, hi = intervals[key]
    out = test[["timestamp", "site_id", ACTUAL, "is_peak_hour", "is_high_peak_hour"]].copy()
    out["main_point_forecast_kw"] = test["main_point_forecast_kw"].to_numpy(float)
    out["peak_sensitive_point_forecast_kw"] = test["peak_sensitive_point_forecast_kw"].to_numpy(float)
    out["lower_forecast_kw"] = lo
    out["upper_forecast_kw"] = hi
    out["selected_interval_method"] = selected["selected_method"]
    out["selected_nominal_coverage"] = selected["selected_nominal_coverage"]
    out.to_csv(SCHEDULING_FILE, index=False)
    return out


def save_figures(test: pd.DataFrame, scheduling: pd.DataFrame, overall: pd.DataFrame, site: pd.DataFrame, month: pd.DataFrame, selected: pd.Series, intervals: dict[tuple[str, str, float], tuple[np.ndarray, np.ndarray]]) -> None:
    sample = scheduling.sort_values(["site_id", "timestamp"]).head(24 * 7)
    plt.figure(figsize=(10, 5))
    plt.plot(sample[ACTUAL].to_numpy(), label="Actual")
    plt.plot(sample["main_point_forecast_kw"].to_numpy(), label="E-AHPA")
    plt.fill_between(np.arange(len(sample)), sample["lower_forecast_kw"], sample["upper_forecast_kw"], alpha=0.25, label="Selected interval")
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "10_fig1_interval_sample_eahpa.png", dpi=300)
    plt.close()
    plt.figure(figsize=(10, 5))
    plt.plot(sample[ACTUAL].to_numpy(), label="Actual")
    plt.plot(sample["peak_sensitive_point_forecast_kw"].to_numpy(), label="PRC-E-AHPA")
    plt.fill_between(np.arange(len(sample)), sample["lower_forecast_kw"], sample["upper_forecast_kw"], alpha=0.25, label="Selected interval")
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "10_fig2_interval_sample_prc.png", dpi=300)
    plt.close()
    plt.figure(figsize=(8, 5))
    x = overall["empirical_coverage"]
    y = overall["average_interval_width"]
    plt.scatter(x, y, alpha=0.65)
    plt.xlabel("Empirical coverage")
    plt.ylabel("Average interval width")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "10_fig3_coverage_vs_width.png", dpi=300)
    plt.close()
    plt.figure(figsize=(9, 5))
    subset = overall[np.isclose(overall["nominal_coverage"], 0.90)].copy()
    labels = subset["forecast_track"] + "\n" + subset["method"]
    idx = np.arange(len(subset))
    plt.bar(idx - 0.2, subset["peak_coverage"], width=0.4, label="Peak")
    plt.bar(idx + 0.2, subset["high_peak_coverage"], width=0.4, label="High peak")
    plt.xticks(idx, labels, rotation=60, ha="right", fontsize=7)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "10_fig4_peak_coverage_comparison.png", dpi=300)
    plt.close()
    sel_site = site[(site["forecast_track"] == selected["selected_forecast_track"]) & (site["method"] == selected["selected_method"]) & (np.isclose(site["nominal_coverage"], selected["selected_nominal_coverage"]))]
    plt.figure(figsize=(8, 5))
    plt.bar(sel_site["site_id"], sel_site["coverage"])
    plt.axhline(selected["selected_nominal_coverage"], color="black", linewidth=0.8)
    plt.xticks(rotation=45, ha="right")
    plt.ylabel("Coverage")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "10_fig5_site_level_coverage.png", dpi=300)
    plt.close()
    plt.figure(figsize=(9, 5))
    subset = overall[np.isclose(overall["nominal_coverage"], 0.90)].copy()
    labels = subset["forecast_track"] + "\n" + subset["method"]
    idx = np.arange(len(subset))
    plt.bar(idx - 0.2, subset["point_underestimation_rate"], width=0.4, label="Point")
    plt.bar(idx + 0.2, subset["upper_bound_underestimation_rate"], width=0.4, label="Upper bound")
    plt.xticks(idx, labels, rotation=60, ha="right", fontsize=7)
    plt.ylabel("Underestimation rate (%)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "10_fig6_upper_bound_underestimation_reduction.png", dpi=300)
    plt.close()
    sel_month = month[(month["forecast_track"] == selected["selected_forecast_track"]) & (month["method"] == selected["selected_method"]) & (np.isclose(month["nominal_coverage"], selected["selected_nominal_coverage"]))]
    plt.figure(figsize=(8, 5))
    plt.plot(sel_month["month"], sel_month["coverage"], marker="o")
    plt.axhline(selected["selected_nominal_coverage"], color="black", linewidth=0.8)
    plt.xticks(rotation=45, ha="right")
    plt.ylabel("Monthly coverage")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "10_fig7_monthly_coverage_selected_method.png", dpi=300)
    plt.close()


def write_reports(selected: pd.Series, overall: pd.DataFrame, scheduling: pd.DataFrame) -> None:
    sel = selected
    report = f"""Step 10 prediction interval report
==================================
Purpose: create uncertainty-aware forecasts before constrained EV charging scheduling.

Why intervals are needed:
Point forecasts can underestimate uncertain EV charging peaks. Upper-bound forecasts give the scheduler a safer load estimate.

Forecast tracks:
- main_point_forecast_kw: E-AHPA, the statistically supported main forecasting model.
- peak_sensitive_point_forecast_kw: PRC-E-AHPA, the peak-risk calibrated operational variant.

Calibration:
All interval methods use validation residuals only. Test labels are used only for final interval evaluation.

Methods tested:
global_abs, site_abs, asymmetric, risk_asymmetric, site_risk_asymmetric, conservative_upper across 80%, 90%, and 95% nominal coverage.

Selected scheduling interval:
Forecast track: {sel['selected_forecast_track']}.
Method: {sel['selected_method']}.
Nominal coverage: {sel['selected_nominal_coverage']}.
Empirical coverage: {sel['empirical_coverage']:.4f}.
Average interval width: {sel['average_interval_width']:.4f} kW.
Peak coverage: {sel['peak_coverage']:.4f}.
High-peak coverage: {sel['high_peak_coverage']:.4f}.
Upper-bound underestimation rate: {sel['upper_bound_underestimation_rate']:.4f}%.
Underestimation risk reduction: {sel['underestimation_risk_reduction']:.4f} percentage points.

Limitations:
Intervals are calibrated from historical validation residuals and assume similar residual behavior in test/future periods. Peak coverage should still be monitored in deployment.

Next step:
Use data/processed/10_uncertainty_forecasts_for_scheduling.csv in constrained scheduling.
"""
    leakage = """Step 10 leakage safety report
==============================
- No forecasting model is retrained.
- Validation residuals only are used for interval calibration.
- Test labels are used only for interval evaluation.
- Actual test peak labels are not used for risk-group interval selection.
- Risk groups use point forecasts and train-derived site p90/p95 thresholds only.
- No future information is used.
"""
    novelty = """Step 10 novelty contribution report
====================================
E-AHPA provides statistically supported point forecasting, while PRC-E-AHPA provides a peak-risk operational forecast.
Conformal prediction intervals add uncertainty awareness to the forecast-to-schedule framework.
The selected upper-bound forecast supports safer constrained scheduling by reducing load underestimation risk.
This strengthens the transition from point prediction to operational EV charging control.
"""
    paper = f"""Prediction intervals were calibrated using validation residuals from the fixed E-AHPA and PRC-E-AHPA forecasts. The selected scheduling interval used {sel['selected_method']} at {sel['selected_nominal_coverage']:.0%} nominal coverage on {sel['selected_forecast_track']}, achieving empirical coverage of {sel['empirical_coverage']:.3f}, peak coverage of {sel['peak_coverage']:.3f}, and high-peak coverage of {sel['high_peak_coverage']:.3f} on the test set. The average interval width was {sel['average_interval_width']:.2f} kW, and the upper-bound forecast reduced underestimation risk by {sel['underestimation_risk_reduction']:.2f} percentage points relative to the point forecast. These intervals provide uncertainty-aware load estimates for the subsequent constrained scheduling stage."""
    captions = """Figure captions for Step 10
============================
Fig. 1. Representative E-AHPA point forecast with selected lower and upper interval.
Fig. 2. Representative PRC-E-AHPA point forecast with selected interval.
Fig. 3. Empirical coverage versus average interval width across interval methods.
Fig. 4. Peak and high-peak coverage comparison across 90% interval methods.
Fig. 5. Site-level coverage for the selected interval method.
Fig. 6. Point forecast versus upper-bound underestimation rates.
Fig. 7. Monthly coverage for the selected interval method.
"""
    (RESULTS_DIR / "10_prediction_interval_report.txt").write_text(report, encoding="utf-8")
    (RESULTS_DIR / "10_leakage_safety_report.txt").write_text(leakage, encoding="utf-8")
    (RESULTS_DIR / "10_novelty_contribution_report.txt").write_text(novelty, encoding="utf-8")
    (RESULTS_DIR / "10_paper_ready_interval_paragraph.txt").write_text(paper, encoding="utf-8")
    (RESULTS_DIR / "10_figure_captions.txt").write_text(captions, encoding="utf-8")


def main() -> None:
    ensure_dirs()
    val, test, align_report, e_col, p_col = load_data()
    overall, site, month, intervals = evaluate_all(val, test)
    selected = select_interval(overall)
    scheduling = save_scheduling_file(test, selected, intervals)
    save_figures(test, scheduling, overall, site, month, selected, intervals)
    write_reports(selected, overall, scheduling)
    print("Step 10 prediction intervals complete")
    print(f"Validation rows: {len(val)}")
    print(f"Test rows: {len(test)}")
    print(f"Detected E-AHPA column: {e_col}")
    print(f"Detected PRC-E-AHPA column: {p_col}")
    print("Interval methods evaluated: global_abs, site_abs, asymmetric, risk_asymmetric, site_risk_asymmetric, conservative_upper")
    print(f"Selected forecast track: {selected['selected_forecast_track']}")
    print(f"Selected interval method: {selected['selected_method']}")
    print(f"Selected nominal coverage: {selected['selected_nominal_coverage']}")
    print(f"Empirical coverage: {selected['empirical_coverage']:.4f}")
    print(f"Average interval width: {selected['average_interval_width']:.4f}")
    print(f"Peak coverage: {selected['peak_coverage']:.4f}")
    print(f"High-peak coverage: {selected['high_peak_coverage']:.4f}")
    print(f"Upper-bound underestimation risk reduction: {selected['underestimation_risk_reduction']:.4f}")
    print(f"Scheduling forecast file: {SCHEDULING_FILE}")
    print(f"Reports folder: {RESULTS_DIR}")
    print(f"Figures folder: {FIGURES_DIR}")


if __name__ == "__main__":
    main()
