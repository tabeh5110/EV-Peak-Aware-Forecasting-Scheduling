"""
Step 05B: corrected leakage-free, calendar-enhanced, peak-aware features.

Run from the project root:
    python src/05B_fix_feature_engineering.py

This script fixes unnecessary row loss from Step 05 by treating zero-load ratio
denominators as valid EV charging observations. It does not train models,
create prediction intervals, or run scheduling optimization.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import re
import sys
import types

import numpy as np


# Environment guard for this workstation: the Python standard-library
# _strptime.py has been overwritten by old project code. Pandas needs a small
# import-time API from _strptime, so provide it locally without editing Python.
if "_strptime" not in sys.modules:
    _strptime_stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    _strptime_stub.LocaleTime = LocaleTime
    _strptime_stub.TimeRE = TimeRE
    _strptime_stub._TimeRE_cache = TimeRE()
    _strptime_stub._regex_cache = {}
    _strptime_stub._getlang = _getlang
    _strptime_stub._strptime = _strptime
    _strptime_stub._strptime_time = _strptime
    _strptime_stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = _strptime_stub

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
INPUT_FILE = PROJECT_ROOT / "data" / "processed" / "03_hourly_load_all_sites.csv"
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "05B_fix_feature_engineering"
OLD_STEP05_FEATURE_FILE = PROCESSED_DIR / "05_forecasting_features.csv"

FEATURE_OUTPUT = PROCESSED_DIR / "05B_forecasting_features.csv"
TRAIN_OUTPUT = PROCESSED_DIR / "05B_train_features.csv"
VALIDATION_OUTPUT = PROCESSED_DIR / "05B_validation_features.csv"
TEST_OUTPUT = PROCESSED_DIR / "05B_test_features.csv"

SITE_MAPPING_FILE = RESULTS_DIR / "05B_site_id_mapping.csv"
FEATURE_LIST_FILE = RESULTS_DIR / "05B_feature_list.csv"
MODELING_COLUMNS_FILE = RESULTS_DIR / "05B_modeling_feature_columns.txt"
SPLIT_SUMMARY_FILE = RESULTS_DIR / "05B_split_summary.csv"
FE_SUMMARY_FILE = RESULTS_DIR / "05B_feature_engineering_summary.csv"
FEATURE_GROUP_SUMMARY_FILE = RESULTS_DIR / "05B_feature_group_summary.csv"
ROW_LOSS_DIAGNOSTICS_FILE = RESULTS_DIR / "05B_row_loss_diagnostics.csv"
PEAK_DIAGNOSTICS_FILE = RESULTS_DIR / "05B_peak_label_diagnostics.csv"
LEAKAGE_REPORT_FILE = RESULTS_DIR / "05B_leakage_safety_report.txt"
NOVELTY_REPORT_FILE = RESULTS_DIR / "05B_novelty_support_report.txt"
FULL_REPORT_FILE = RESULTS_DIR / "05B_feature_engineering_report.txt"

LAGS = [1, 2, 3, 6, 12, 24, 48, 72, 96, 120, 144, 168, 336]
ROLLING_MEAN_WINDOWS = [3, 6, 12, 24, 48, 72, 168, 336]
ROLLING_STD_WINDOWS = [6, 24, 168]
ROLLING_MIN_MAX_WINDOWS = [24, 168, 336]
ROLLING_QUANTILES = [(24, 0.75), (24, 0.90), (24, 0.95), (168, 0.75), (168, 0.90), (168, 0.95)]
EWM_SPANS = [6, 24, 168]
CORE_HISTORY_FEATURES = [
    "lag_1h",
    "lag_24h",
    "lag_168h",
    "lag_336h",
    "rolling_mean_24h",
    "rolling_mean_168h",
    "rolling_mean_336h",
]
EXCLUDED_MODEL_COLUMNS = {
    "target_load_kw",
    "timestamp",
    "load_kw",
    "load_kw_observed",
    "source_file",
    "split",
    "is_peak_hour",
    "is_high_peak_hour",
    "peak_sample_weight",
    "peak_threshold_90_train_kw",
    "peak_threshold_95_train_kw",
    "target_load_kw_normalized_by_train_mean",
    "row_number_by_site",
    "site_total_rows",
}


def parse_datetime(series: pd.Series) -> pd.Series:
    try:
        return pd.to_datetime(series, errors="coerce", format="mixed")
    except TypeError:
        return pd.to_datetime(series, errors="coerce")


def safe_divide_zero_ok(numerator: pd.Series, denominator: pd.Series) -> pd.Series:
    """Divide while preserving zero-load hours as valid observations.

    If denominator is NaN, return NaN. If denominator is zero, return 0 rather
    than NaN/inf and pair the ratio with an explicit denominator-zero flag.
    """
    result = numerator / denominator.replace(0, np.nan)
    result = result.mask(denominator.eq(0) & denominator.notna(), 0)
    return result


def hours_since_past_peak(load_values: pd.Series, threshold: float) -> pd.Series:
    values = load_values.to_numpy()
    output: list[float] = []
    last_peak_position: int | None = None
    for position, value in enumerate(values):
        output.append(np.nan if last_peak_position is None else float(position - last_peak_position))
        if pd.notna(value) and value >= threshold:
            last_peak_position = position
    return pd.Series(output, index=load_values.index)


def add_feature(
    feature_rows: list[dict[str, Any]],
    name: str,
    group: str,
    description: str,
    use_as_model_input: bool,
    leakage_safe_explanation: str,
) -> None:
    feature_rows.append(
        {
            "feature_name": name,
            "feature_group": group,
            "description": description,
            "use_as_model_input": use_as_model_input,
            "leakage_safe_explanation": leakage_safe_explanation,
        }
    )


def build_feature_catalog(modeling_features: list[str], all_columns: list[str]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    modeling_set = set(modeling_features)

    descriptions = {
        "calendar": "Known-in-advance calendar feature.",
        "cyclical_calendar": "Sine/cosine encoding of a known calendar cycle.",
        "business_period": "Known-in-advance operational period indicator.",
        "lag": "Past load value from the same site.",
        "same_hour_history": "Same-hour daily or weekly historical load relationship.",
        "rolling_mean": "Shifted rolling mean using only previous load values.",
        "rolling_volatility": "Shifted rolling spread or volatility summary.",
        "rolling_min_max": "Shifted rolling minimum or maximum summary.",
        "rolling_quantile": "Shifted rolling upper quantile for recent high-load behavior.",
        "ewm": "Shifted exponential moving average of past load.",
        "ramp": "Change/ramp feature computed from lagged values.",
        "ratio": "Safe ratio using lagged or shifted rolling features.",
        "peak_memory": "Recent peak memory based on train-only peak thresholds and past loads.",
        "missing_indicator": "Past or current missing-hour indicator from the standardized hourly data.",
        "site_identity": "Deterministic encoded site identifier.",
        "interaction": "Interaction among known calendar/operation variables and past-load features.",
        "normalized_by_site": "Train-only site-normalized load history feature.",
        "metadata": "Tracking or provenance column; not used as a model input.",
        "label_or_weight": "Target-derived label, threshold, or sample weight; not a predictor.",
    }

    def group_for_feature(name: str) -> str:
        if name in {"hour", "day_of_week", "is_weekend", "month", "day_of_month", "day_of_year", "week_of_year", "quarter", "is_month_start", "is_month_end"}:
            return "calendar"
        if name.endswith("_sin") or name.endswith("_cos"):
            return "cyclical_calendar"
        if name in {"is_business_hour", "is_morning_arrival_period", "is_midday_period", "is_evening_departure_period", "is_night"}:
            return "business_period"
        if "_x_" in name:
            return "interaction"
        if name.startswith("lag_"):
            return "lag"
        if name.startswith("same_hour_"):
            return "same_hour_history"
        if name.startswith("rolling_mean_"):
            return "rolling_mean"
        if name.startswith("rolling_std_") or name.startswith("rolling_range_"):
            return "rolling_volatility"
        if name.startswith("rolling_max_") or name.startswith("rolling_min_"):
            return "rolling_min_max"
        if name.startswith("rolling_q"):
            return "rolling_quantile"
        if name.startswith("ewm_"):
            return "ewm"
        if name.startswith("diff_") or name.startswith("abs_diff_") or name.startswith("ramp_rate_"):
            return "ramp"
        if name.startswith("ratio_") or name.startswith("denom_zero_"):
            return "ratio"
        if name.startswith("recent_peak_") or name in {"hours_since_recent_peak_90", "no_previous_peak_flag"}:
            return "peak_memory"
        if name.startswith("missing_hour_") or name == "was_missing_hour":
            return "missing_indicator"
        if name == "site_id_encoded":
            return "site_identity"
        if name.endswith("_normalized_by_train_mean"):
            return "normalized_by_site"
        if name in {"timestamp", "site_id", "source_file", "split", "row_number_by_site", "site_total_rows", "load_kw", "load_kw_observed"}:
            return "metadata"
        if name in {"target_load_kw", "target_load_kw_normalized_by_train_mean", "is_peak_hour", "is_high_peak_hour", "peak_threshold_90_train_kw", "peak_threshold_95_train_kw", "peak_sample_weight"}:
            return "label_or_weight"
        return "metadata"

    for column in all_columns:
        group = group_for_feature(column)
        use_as_input = column in modeling_set
        add_feature(
            rows,
            column,
            group,
            descriptions[group],
            use_as_input,
            "Known in advance or computed only from past/site training data."
            if use_as_input
            else "Excluded from model inputs because it is target, provenance, split, threshold, label, or weight metadata.",
        )

    return pd.DataFrame(rows)


def scientific_purpose_for_group(group: str) -> str:
    purposes = {
        "calendar": "Captures known daily, weekly, monthly, and seasonal EV charging rhythms.",
        "cyclical_calendar": "Represents periodic calendar cycles without artificial discontinuities.",
        "business_period": "Encodes workplace arrival, midday, departure, and night operating periods.",
        "lag": "Captures short-term dynamics plus daily and weekly recurrence.",
        "same_hour_history": "Targets same-hour periodic structure important for load forecasting.",
        "rolling_mean": "Summarizes recent average demand using past observations only.",
        "rolling_volatility": "Captures recent variability and rampiness in demand.",
        "rolling_min_max": "Summarizes recent lower and upper load envelopes.",
        "rolling_quantile": "Supports peak-aware prediction by describing recent high-load behavior.",
        "ewm": "Provides smoothed memory of recent past demand.",
        "ramp": "Captures recent changes in load and ramp direction.",
        "ratio": "Compares recent demand against daily/weekly baselines.",
        "peak_memory": "Adds leakage-free memory of recent peak conditions using train-only thresholds.",
        "missing_indicator": "Preserves transparency about zero-filled missing hours.",
        "site_identity": "Allows models to learn site-specific baselines.",
        "interaction": "Allows calendar and historical effects to vary across operating periods.",
        "normalized_by_site": "Supports cross-site learning by scaling histories with train-only site statistics.",
        "metadata": "Documents provenance and split assignment.",
        "label_or_weight": "Supports peak-aware training/evaluation without being used as predictors.",
    }
    return purposes[group]


def main() -> None:
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"Input file not found: {INPUT_FILE}")

    df = pd.read_csv(INPUT_FILE)
    original_shape = df.shape
    required = {"timestamp", "site_id", "load_kw", "load_kw_observed", "was_missing_hour", "source_file"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise ValueError(f"Input file is missing required columns: {missing}")

    df["timestamp"] = parse_datetime(df["timestamp"])
    df = df.dropna(subset=["timestamp"]).copy()
    df["load_kw"] = pd.to_numeric(df["load_kw"], errors="coerce")
    df["load_kw_observed"] = pd.to_numeric(df["load_kw_observed"], errors="coerce")
    df["was_missing_hour"] = df["was_missing_hour"].astype(bool).astype(int)
    df = df.sort_values(["site_id", "timestamp"]).reset_index(drop=True)
    df["target_load_kw"] = df["load_kw"]
    df["row_number_by_site"] = df.groupby("site_id").cumcount() + 1
    df["site_total_rows"] = df.groupby("site_id")["site_id"].transform("size")
    zero_based_position = df["row_number_by_site"] - 1
    train_end = np.floor(df["site_total_rows"] * 0.70)
    validation_end = np.floor(df["site_total_rows"] * 0.85)
    df["split"] = np.where(
        zero_based_position < train_end,
        "train",
        np.where(zero_based_position < validation_end, "validation", "test"),
    )

    # Calendar features are known at prediction time.
    dt = df["timestamp"].dt
    df["hour"] = dt.hour
    df["day_of_week"] = dt.dayofweek
    df["is_weekend"] = df["day_of_week"].isin([5, 6]).astype(int)
    df["month"] = dt.month
    df["day_of_month"] = dt.day
    df["day_of_year"] = dt.dayofyear
    df["week_of_year"] = dt.isocalendar().week.astype(int)
    df["quarter"] = dt.quarter
    df["is_month_start"] = dt.is_month_start.astype(int)
    df["is_month_end"] = dt.is_month_end.astype(int)

    df["hour_sin"] = np.sin(2 * np.pi * df["hour"] / 24)
    df["hour_cos"] = np.cos(2 * np.pi * df["hour"] / 24)
    df["day_of_week_sin"] = np.sin(2 * np.pi * df["day_of_week"] / 7)
    df["day_of_week_cos"] = np.cos(2 * np.pi * df["day_of_week"] / 7)
    df["month_sin"] = np.sin(2 * np.pi * df["month"] / 12)
    df["month_cos"] = np.cos(2 * np.pi * df["month"] / 12)
    df["day_of_year_sin"] = np.sin(2 * np.pi * df["day_of_year"] / 365.25)
    df["day_of_year_cos"] = np.cos(2 * np.pi * df["day_of_year"] / 365.25)

    df["is_business_hour"] = df["hour"].between(8, 18).astype(int)
    df["is_morning_arrival_period"] = df["hour"].between(7, 10).astype(int)
    df["is_midday_period"] = df["hour"].between(11, 14).astype(int)
    df["is_evening_departure_period"] = df["hour"].between(16, 20).astype(int)
    df["is_night"] = ((df["hour"] <= 6) | (df["hour"] >= 22)).astype(int)

    grouped_load = df.groupby("site_id")["load_kw"]
    for lag in LAGS:
        df[f"lag_{lag}h"] = grouped_load.shift(lag)

    df["same_hour_yesterday"] = df["lag_24h"]
    df["same_hour_2days_ago"] = df["lag_48h"]
    df["same_hour_3days_ago"] = df["lag_72h"]
    df["same_hour_last_week"] = df["lag_168h"]
    df["same_hour_2weeks_ago"] = df["lag_336h"]
    df["same_hour_yesterday_minus_last_week"] = df["lag_24h"] - df["lag_168h"]
    df["denom_zero_lag_24h"] = df["lag_24h"].eq(0) & df["lag_24h"].notna()
    df["denom_zero_lag_168h"] = df["lag_168h"].eq(0) & df["lag_168h"].notna()
    df["same_hour_yesterday_ratio_last_week"] = safe_divide_zero_ok(df["lag_24h"], df["lag_168h"])

    past_load = grouped_load.shift(1)
    for window in ROLLING_MEAN_WINDOWS:
        df[f"rolling_mean_{window}h"] = (
            past_load.groupby(df["site_id"]).rolling(window=window, min_periods=window).mean().reset_index(level=0, drop=True)
        )
    for window in ROLLING_STD_WINDOWS:
        df[f"rolling_std_{window}h"] = (
            past_load.groupby(df["site_id"]).rolling(window=window, min_periods=window).std().reset_index(level=0, drop=True)
        )
    for window in ROLLING_MIN_MAX_WINDOWS:
        rolling = past_load.groupby(df["site_id"]).rolling(window=window, min_periods=window)
        df[f"rolling_max_{window}h"] = rolling.max().reset_index(level=0, drop=True)
        df[f"rolling_min_{window}h"] = rolling.min().reset_index(level=0, drop=True)

    df["rolling_range_24h"] = df["rolling_max_24h"] - df["rolling_min_24h"]
    df["rolling_range_168h"] = df["rolling_max_168h"] - df["rolling_min_168h"]

    for window, quantile in ROLLING_QUANTILES:
        suffix = int(quantile * 100)
        df[f"rolling_q{suffix}_{window}h"] = (
            past_load.groupby(df["site_id"])
            .rolling(window=window, min_periods=window)
            .quantile(quantile)
            .reset_index(level=0, drop=True)
        )

    for span in EWM_SPANS:
        df[f"ewm_mean_{span}h"] = (
            past_load.groupby(df["site_id"], group_keys=False)
            .apply(lambda s: s.ewm(span=span, adjust=False, min_periods=span).mean())
        )

    df["diff_1h"] = df["lag_1h"] - df["lag_2h"]
    df["diff_3h"] = df["lag_1h"] - df["lag_3h"]
    df["diff_24h"] = df["lag_24h"] - df["lag_48h"]
    df["diff_168h"] = df["lag_168h"] - df["lag_336h"]
    df["abs_diff_1h"] = df["diff_1h"].abs()
    df["abs_diff_24h"] = df["diff_24h"].abs()
    df["ramp_rate_1h"] = df["diff_1h"]
    df["ramp_rate_24h"] = df["diff_24h"] / 24

    df["denom_zero_rolling_mean_24h"] = df["rolling_mean_24h"].eq(0) & df["rolling_mean_24h"].notna()
    df["denom_zero_rolling_mean_168h"] = df["rolling_mean_168h"].eq(0) & df["rolling_mean_168h"].notna()
    df["denom_zero_rolling_max_24h"] = df["rolling_max_24h"].eq(0) & df["rolling_max_24h"].notna()
    df["ratio_lag_1h_to_24h"] = safe_divide_zero_ok(df["lag_1h"], df["lag_24h"])
    df["ratio_lag_24h_to_168h"] = safe_divide_zero_ok(df["lag_24h"], df["lag_168h"])
    df["ratio_rolling_mean_24h_to_168h"] = safe_divide_zero_ok(df["rolling_mean_24h"], df["rolling_mean_168h"])
    df["ratio_lag_1h_to_rolling_mean_24h"] = safe_divide_zero_ok(df["lag_1h"], df["rolling_mean_24h"])
    df["ratio_lag_1h_to_rolling_max_24h"] = safe_divide_zero_ok(df["lag_1h"], df["rolling_max_24h"])

    threshold_rows: list[dict[str, Any]] = []
    train_stats: dict[str, dict[str, float]] = {}
    for site_id, site_df in df.groupby("site_id", sort=True):
        train_load = site_df.loc[site_df["split"] == "train", "target_load_kw"]
        threshold_90 = float(train_load.quantile(0.90))
        threshold_95 = float(train_load.quantile(0.95))
        train_mean = float(train_load.mean())
        train_std = float(train_load.std())
        train_max = float(train_load.max())
        train_stats[site_id] = {
            "peak_threshold_90_train_kw": threshold_90,
            "peak_threshold_95_train_kw": threshold_95,
            "train_mean_load_kw": train_mean,
            "train_std_load_kw": train_std,
            "train_max_load_kw": train_max,
        }
        threshold_rows.append({"site_id": site_id, **train_stats[site_id]})

    threshold_df = pd.DataFrame(threshold_rows)
    df = df.merge(threshold_df, on="site_id", how="left")
    df["is_peak_hour"] = (df["target_load_kw"] >= df["peak_threshold_90_train_kw"]).astype(int)
    df["is_high_peak_hour"] = (df["target_load_kw"] >= df["peak_threshold_95_train_kw"]).astype(int)
    df["peak_sample_weight"] = 1.0
    df.loc[df["is_peak_hour"] == 1, "peak_sample_weight"] = 2.0
    df.loc[df["is_high_peak_hour"] == 1, "peak_sample_weight"] = 3.0

    peak_memory_frames: list[pd.DataFrame] = []
    for site_id, site_df in df.groupby("site_id", sort=True):
        threshold_90 = train_stats[site_id]["peak_threshold_90_train_kw"]
        past_peak = site_df["target_load_kw"].shift(1).ge(threshold_90).astype(int)
        peak_memory = pd.DataFrame(index=site_df.index)
        peak_memory["recent_peak_24h_count"] = past_peak.rolling(window=24, min_periods=24).sum()
        peak_memory["recent_peak_168h_count"] = past_peak.rolling(window=168, min_periods=168).sum()
        peak_memory["recent_peak_24h_flag"] = peak_memory["recent_peak_24h_count"].gt(0).astype(int)
        peak_memory["recent_peak_168h_flag"] = peak_memory["recent_peak_168h_count"].gt(0).astype(int)
        peak_memory["hours_since_recent_peak_90"] = hours_since_past_peak(site_df["target_load_kw"], threshold_90)
        peak_memory_frames.append(peak_memory)
    df = pd.concat([df, pd.concat(peak_memory_frames).sort_index()], axis=1)
    for column in ["recent_peak_24h_count", "recent_peak_168h_count"]:
        df[column] = df[column].fillna(0)
    for column in ["recent_peak_24h_flag", "recent_peak_168h_flag"]:
        df[column] = df[column].fillna(0).astype(int)
    df["no_previous_peak_flag"] = df["hours_since_recent_peak_90"].isna().astype(int)
    df["hours_since_recent_peak_90"] = df["hours_since_recent_peak_90"].fillna(9999)

    grouped_missing = df.groupby("site_id")["was_missing_hour"]
    df["missing_hour_lag_1h"] = grouped_missing.shift(1)
    df["missing_hour_lag_24h"] = grouped_missing.shift(24)
    df["missing_hour_lag_168h"] = grouped_missing.shift(168)
    shifted_missing = grouped_missing.shift(1)
    df["missing_hour_rolling_count_24h"] = (
        shifted_missing.groupby(df["site_id"]).rolling(window=24, min_periods=24).sum().reset_index(level=0, drop=True)
    )
    df["missing_hour_rolling_count_168h"] = (
        shifted_missing.groupby(df["site_id"]).rolling(window=168, min_periods=168).sum().reset_index(level=0, drop=True)
    )
    for column in [
        "missing_hour_lag_1h",
        "missing_hour_lag_24h",
        "missing_hour_lag_168h",
        "missing_hour_rolling_count_24h",
        "missing_hour_rolling_count_168h",
    ]:
        df[column] = df[column].fillna(0)

    site_mapping = pd.DataFrame(
        {"site_id": sorted(df["site_id"].unique())}
    )
    site_mapping["site_id_encoded"] = np.arange(len(site_mapping))
    df = df.merge(site_mapping, on="site_id", how="left")

    df["hour_x_weekend"] = df["hour"] * df["is_weekend"]
    df["hour_x_business_hour"] = df["hour"] * df["is_business_hour"]
    df["day_of_week_x_business_hour"] = df["day_of_week"] * df["is_business_hour"]
    df["lag_24h_x_weekend"] = df["lag_24h"] * df["is_weekend"]
    df["lag_168h_x_weekend"] = df["lag_168h"] * df["is_weekend"]
    df["same_hour_last_week_x_business_hour"] = df["same_hour_last_week"] * df["is_business_hour"]
    df["rolling_mean_24h_x_business_hour"] = df["rolling_mean_24h"] * df["is_business_hour"]

    df["target_load_kw_normalized_by_train_mean"] = safe_divide_zero_ok(df["target_load_kw"], df["train_mean_load_kw"])
    for column in ["lag_1h", "lag_24h", "lag_168h", "rolling_mean_24h", "rolling_mean_168h"]:
        df[f"{column}_normalized_by_train_mean"] = safe_divide_zero_ok(df[column], df["train_mean_load_kw"])

    for column in [
        "denom_zero_lag_24h",
        "denom_zero_lag_168h",
        "denom_zero_rolling_mean_24h",
        "denom_zero_rolling_mean_168h",
        "denom_zero_rolling_max_24h",
    ]:
        df[column] = df[column].astype(int)

    model_feature_candidates = [
        column
        for column in df.columns
        if column not in EXCLUDED_MODEL_COLUMNS
        and column not in {"site_id", "train_mean_load_kw", "train_std_load_kw", "train_max_load_kw"}
        and pd.api.types.is_numeric_dtype(df[column])
    ]
    modeling_features = sorted(model_feature_candidates)

    rows_before_drop = len(df)
    core_history_nan_mask = df[CORE_HISTORY_FEATURES].isna().any(axis=1)
    usable = df.loc[~core_history_nan_mask].copy()
    final_shape = usable.shape

    ordered_columns = [
        "timestamp",
        "site_id",
        "target_load_kw",
        "split",
        "row_number_by_site",
        "site_total_rows",
        *modeling_features,
        "is_peak_hour",
        "is_high_peak_hour",
        "peak_threshold_90_train_kw",
        "peak_threshold_95_train_kw",
        "peak_sample_weight",
        "target_load_kw_normalized_by_train_mean",
        "train_mean_load_kw",
        "train_std_load_kw",
        "train_max_load_kw",
        "source_file",
    ]
    ordered_columns = list(dict.fromkeys([column for column in ordered_columns if column in usable.columns]))
    usable = usable[ordered_columns]

    usable.to_csv(FEATURE_OUTPUT, index=False)
    usable.loc[usable["split"] == "train"].to_csv(TRAIN_OUTPUT, index=False)
    usable.loc[usable["split"] == "validation"].to_csv(VALIDATION_OUTPUT, index=False)
    usable.loc[usable["split"] == "test"].to_csv(TEST_OUTPUT, index=False)
    site_mapping.to_csv(SITE_MAPPING_FILE, index=False)
    MODELING_COLUMNS_FILE.write_text("\n".join(modeling_features) + "\n", encoding="utf-8")

    feature_list = build_feature_catalog(modeling_features, ordered_columns)
    feature_list.to_csv(FEATURE_LIST_FILE, index=False)

    split_summary = (
        usable.groupby(["site_id", "split"], as_index=False)
        .agg(
            row_count=("target_load_kw", "size"),
            start_time=("timestamp", "min"),
            end_time=("timestamp", "max"),
            mean_target_load_kw=("target_load_kw", "mean"),
            median_target_load_kw=("target_load_kw", "median"),
            max_target_load_kw=("target_load_kw", "max"),
            peak_threshold_90_train_kw=("peak_threshold_90_train_kw", "first"),
            peak_threshold_95_train_kw=("peak_threshold_95_train_kw", "first"),
            peak_hour_count=("is_peak_hour", "sum"),
            high_peak_hour_count=("is_high_peak_hour", "sum"),
            mean_peak_sample_weight=("peak_sample_weight", "mean"),
        )
        .sort_values(["site_id", "split"])
    )
    split_summary.to_csv(SPLIT_SUMMARY_FILE, index=False)

    fe_summary_rows: list[dict[str, Any]] = []
    row_loss_rows: list[dict[str, Any]] = []
    for site_id, site_df in df.groupby("site_id", sort=True):
        site_original = len(site_df)
        site_removed = int(core_history_nan_mask.loc[site_df.index].sum())
        site_usable = usable.loc[usable["site_id"] == site_id]
        stats = train_stats[site_id]
        expected_loss = min(336, site_original)
        excessive = site_removed > expected_loss + 24
        fe_summary_rows.append(
            {
                "site_id": site_id,
                "original_rows": site_original,
                "rows_after_feature_creation": site_original,
                "rows_removed_due_to_missing_features": site_removed,
                "final_rows": len(site_usable),
                "train_rows": int((site_usable["split"] == "train").sum()),
                "validation_rows": int((site_usable["split"] == "validation").sum()),
                "test_rows": int((site_usable["split"] == "test").sum()),
                "start_time_final": site_usable["timestamp"].min() if len(site_usable) else "",
                "end_time_final": site_usable["timestamp"].max() if len(site_usable) else "",
                "number_of_modeling_features": len(modeling_features),
                **stats,
            }
        )
        row_loss_rows.append(
            {
                "site_id": site_id,
                "original_rows": site_original,
                "expected_minimum_loss_due_to_336h_history": expected_loss,
                "actual_rows_removed": site_removed,
                "final_rows": len(site_usable),
                "removal_percentage": round(site_removed / site_original * 100, 4) if site_original else 0.0,
                "warning_if_excessive_loss": (
                    "actual loss exceeds 336 by more than 24 hours; inspect rolling/history availability"
                    if excessive
                    else "none; loss is consistent with required 336-hour core history"
                ),
            }
        )

    fe_summary = pd.DataFrame(fe_summary_rows)
    row_loss_summary = pd.DataFrame(row_loss_rows)
    fe_summary.to_csv(FE_SUMMARY_FILE, index=False)
    row_loss_summary.to_csv(ROW_LOSS_DIAGNOSTICS_FILE, index=False)

    peak_diagnostics = (
        usable.groupby(["site_id", "split"], as_index=False)
        .agg(
            row_count=("target_load_kw", "size"),
            peak_hour_count=("is_peak_hour", "sum"),
            high_peak_hour_count=("is_high_peak_hour", "sum"),
        )
        .sort_values(["site_id", "split"])
    )
    peak_diagnostics["peak_hour_percentage"] = (
        peak_diagnostics["peak_hour_count"] / peak_diagnostics["row_count"] * 100
    ).round(4)
    peak_diagnostics["high_peak_hour_percentage"] = (
        peak_diagnostics["high_peak_hour_count"] / peak_diagnostics["row_count"] * 100
    ).round(4)
    peak_diagnostics = peak_diagnostics[
        [
            "site_id",
            "split",
            "row_count",
            "peak_hour_count",
            "peak_hour_percentage",
            "high_peak_hour_count",
            "high_peak_hour_percentage",
        ]
    ]
    peak_diagnostics.to_csv(PEAK_DIAGNOSTICS_FILE, index=False)

    feature_group_summary = (
        feature_list.loc[feature_list["use_as_model_input"] == True]
        .groupby("feature_group", as_index=False)
        .agg(
            number_of_features=("feature_name", "size"),
            example_features=("feature_name", lambda s: " | ".join(list(s.head(8)))),
        )
    )
    feature_group_summary["scientific_purpose"] = feature_group_summary["feature_group"].map(scientific_purpose_for_group)
    feature_group_summary.to_csv(FEATURE_GROUP_SUMMARY_FILE, index=False)

    train_validation_test_counts = usable["split"].value_counts().reindex(["train", "validation", "test"], fill_value=0)
    old_step05_shape: tuple[int, int] | str = "not available"
    old_step05_rows: int | None = None
    if OLD_STEP05_FEATURE_FILE.exists():
        old_step05 = pd.read_csv(OLD_STEP05_FEATURE_FILE)
        old_step05_shape = old_step05.shape
        old_step05_rows = len(old_step05)
    preserved_vs_old = len(usable) - old_step05_rows if old_step05_rows is not None else "not available"

    LEAKAGE_REPORT_FILE.write_text(
        "\n".join(
            [
                "Step 05B leakage safety report",
                "=" * 29,
                "",
                "Target variable:",
                "- target_load_kw is the current-hour load_kw from the standardized hourly dataset.",
                "",
                "Calendar features:",
                "- Calendar variables are allowed because timestamp-derived hour, weekday, month, and related indicators are known before prediction time.",
                "",
                "Lag features:",
                "- Lag features are computed separately within each site_id using groupby(site_id).shift(k), so each row uses only older observations from the same site.",
                "",
                "Rolling features:",
                "- Rolling means, standard deviations, ranges, min/max values, and quantiles are computed from past_load = groupby(site_id)['load_kw'].shift(1) before rolling.",
                "- This shift prevents the current target_load_kw from entering any current-row rolling feature.",
                "",
                "EWM features:",
                "- EWM features are also computed from shifted past_load, so the current target is excluded.",
                "",
                "Missing-hour features:",
                "- Missing-hour lag and rolling-count features are shifted within each site, preserving only past missingness information.",
                "",
                "Chronological split:",
                "- The split is assigned independently inside each site: first 70% train, next 15% validation, final 15% test.",
                "- No random shuffling is used.",
                "",
                "Peak thresholds:",
                "- Site-specific 90th and 95th percentile peak thresholds are computed only from rows labeled train for that site.",
                "- Peak labels and peak sample weights can support training/evaluation but are excluded from model input columns.",
                "",
                "Train-only normalization:",
                "- Site normalization statistics are computed only from each site's training target_load_kw values.",
                "- Normalized lag/rolling features divide past-load features by the train-only site mean.",
                "",
                "Columns excluded from model inputs:",
                "- target_load_kw, timestamp, raw load_kw/load_kw_observed, source_file, split, peak labels, peak thresholds, peak_sample_weight, and current-target normalized labels are excluded.",
                "",
                "Safe ratio handling:",
                "- Ratio features return NaN only when denominator history is unavailable.",
                "- If a denominator is exactly zero, the ratio is set to 0 and a denominator-zero flag records that valid zero-load condition.",
                "- Zero-load EV charging hours are not dropped solely because they appear in ratio denominators.",
                "",
                "Conclusion:",
                "- The saved modeling feature list contains only known-in-advance calendar variables, deterministic site identity, past-load summaries, shifted missingness, train-only peak memory, and train-only normalized past features.",
                "- Therefore the feature dataset is designed to be leakage-free for chronological forecasting experiments.",
                "",
            ]
        ),
        encoding="utf-8",
    )

    NOVELTY_REPORT_FILE.write_text(
        "\n".join(
            [
                "Step 05B novelty support report",
                "=" * 30,
                "",
                "Old lag-only weakness:",
                "- The rejected version relied too heavily on simple lag-only forecasting signals and removed calendar context.",
                "",
                "New calendar-enhanced design:",
                "- This dataset includes calendar, cyclical calendar, business-period, and interaction features that reflect known operational rhythms.",
                "",
                "New weekly-lag design:",
                "- Daily, multi-day, weekly, and two-week lags explicitly support daily and weekly periodicity.",
                "",
                "New peak-memory features:",
                "- Rolling high-load quantiles and recent train-threshold peak memory features summarize recent peak behavior without future information.",
                "",
                "New peak-weighting support:",
                "- is_peak_hour, is_high_peak_hour, and peak_sample_weight support later PA-CatBoost / PA-LightGBM experiments with higher emphasis on peak-load hours.",
                "",
                "Denominator-zero flags for EV zero-load periods:",
                "- Corrected ratio handling preserves valid zero-load hours and exposes denominator-zero flags so models can learn from inactive charging periods.",
                "",
                "Uncertainty and scheduling support:",
                "- Leakage-free chronological splits, peak labels, and transparent missing-hour indicators create a reliable foundation for later prediction intervals and constrained EV charging scheduling.",
                "",
                "Suitability for PA-CatBoost / PA-LightGBM:",
                f"- The final dataset includes {len(modeling_features)} modeling features across {feature_group_summary['feature_group'].nunique()} input feature groups.",
                "- These inputs support calendar-aware, peak-aware gradient boosting without using future sessions, future arrivals, weather, prices, or future target information.",
                "",
            ]
        ),
        encoding="utf-8",
    )

    FULL_REPORT_FILE.write_text(
        "\n".join(
            [
                "Step 05B corrected feature engineering report",
                "=" * 34,
                "",
                f"Input file used: {INPUT_FILE}",
                "",
                "Output files generated:",
                f"- {FEATURE_OUTPUT}",
                f"- {TRAIN_OUTPUT}",
                f"- {VALIDATION_OUTPUT}",
                f"- {TEST_OUTPUT}",
                f"- {SITE_MAPPING_FILE}",
                f"- {FEATURE_LIST_FILE}",
                f"- {MODELING_COLUMNS_FILE}",
                f"- {SPLIT_SUMMARY_FILE}",
                f"- {FE_SUMMARY_FILE}",
                f"- {FEATURE_GROUP_SUMMARY_FILE}",
                f"- {ROW_LOSS_DIAGNOSTICS_FILE}",
                f"- {PEAK_DIAGNOSTICS_FILE}",
                f"- {LEAKAGE_REPORT_FILE}",
                f"- {NOVELTY_REPORT_FILE}",
                "",
                f"Number of sites: {df['site_id'].nunique()}",
                f"Original input shape: {original_shape}",
                f"Final feature dataset shape: {final_shape}",
                f"Old Step 05 final shape: {old_step05_shape}",
                f"Train rows: {int(train_validation_test_counts['train'])}",
                f"Validation rows: {int(train_validation_test_counts['validation'])}",
                f"Test rows: {int(train_validation_test_counts['test'])}",
                f"Number of modeling features: {len(modeling_features)}",
                f"Rows removed due to missing core history only: {rows_before_drop - len(usable)}",
                f"Rows preserved compared with old Step 05: {preserved_vs_old}",
                "",
                "Feature groups created:",
                *(
                    f"- {row.feature_group}: {row.number_of_features} modeling features"
                    for row in feature_group_summary.itertuples(index=False)
                ),
                "",
                "Peak thresholds and train-only normalization statistics per site:",
                *(
                    f"- {row.site_id}: p90={row.peak_threshold_90_train_kw:.3f} kW, "
                    f"p95={row.peak_threshold_95_train_kw:.3f} kW, "
                    f"train mean={row.train_mean_load_kw:.3f} kW, "
                    f"train std={row.train_std_load_kw:.3f} kW, "
                    f"train max={row.train_max_load_kw:.3f} kW"
                    for row in fe_summary.itertuples(index=False)
                ),
                "",
                "Row-loss diagnostics:",
                *(
                    f"- {row.site_id}: removed {row.actual_rows_removed} of {row.original_rows} rows "
                    f"({row.removal_percentage:.2f}%); {row.warning_if_excessive_loss}"
                    for row in row_loss_summary.itertuples(index=False)
                ),
                "",
                "Peak-label diagnostics:",
                *(
                    f"- {row.site_id} {row.split}: {row.peak_hour_percentage:.2f}% peak hours, "
                    f"{row.high_peak_hour_percentage:.2f}% high-peak hours"
                    for row in peak_diagnostics.itertuples(index=False)
                ),
                "",
                "Recommended next step:",
                "- Create the next numbered script for baseline forecasting experiments using the saved modeling feature list. Do not create prediction intervals or scheduling optimization yet.",
                "",
            ]
        ),
        encoding="utf-8",
    )

    output_files = [
        FEATURE_OUTPUT,
        TRAIN_OUTPUT,
        VALIDATION_OUTPUT,
        TEST_OUTPUT,
        SITE_MAPPING_FILE,
        FEATURE_LIST_FILE,
        MODELING_COLUMNS_FILE,
        SPLIT_SUMMARY_FILE,
        FE_SUMMARY_FILE,
        FEATURE_GROUP_SUMMARY_FILE,
        ROW_LOSS_DIAGNOSTICS_FILE,
        PEAK_DIAGNOSTICS_FILE,
        LEAKAGE_REPORT_FILE,
        NOVELTY_REPORT_FILE,
        FULL_REPORT_FILE,
    ]

    print("Step 05B corrected feature engineering complete")
    print("====================================")
    print(f"Input shape: {original_shape}")
    print(f"Final feature shape: {final_shape}")
    print(f"Rows preserved compared with old Step 05: {preserved_vs_old}")
    print(f"Number of modeling features: {len(modeling_features)}")
    print(
        "Train/validation/test counts: "
        f"{int(train_validation_test_counts['train'])}/"
        f"{int(train_validation_test_counts['validation'])}/"
        f"{int(train_validation_test_counts['test'])}"
    )
    print(f"Number of feature groups: {feature_group_summary['feature_group'].nunique()}")
    print("")
    print("Output files saved:")
    for path in output_files:
        print(f"- {path}")
    print("")
    print("Report locations:")
    print(f"- {FULL_REPORT_FILE}")
    print(f"- {LEAKAGE_REPORT_FILE}")
    print(f"- {NOVELTY_REPORT_FILE}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(1)
