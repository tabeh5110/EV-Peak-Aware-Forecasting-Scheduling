"""
Step 13: Build the first complete manuscript draft.

Run from the project root:
    python src/13_build_manuscript_draft.py

This script uses Step 12 as the source layer. It does not run experiments or
invent new results.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import re
import shutil
import sys
import types
import warnings

if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import pandas as pd

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
STEP12_RESULTS = PROJECT_ROOT / "results" / "12_final_paper_results_pack"
STEP12_TABLES = PROJECT_ROOT / "tables" / "12_final_paper_results_pack"
STEP12_FIGURES = PROJECT_ROOT / "figures" / "12_final_paper_results_pack"
STEP12_MANUSCRIPT = PROJECT_ROOT / "manuscript" / "12_final_paper_results_pack"

OUT_MANUSCRIPT = PROJECT_ROOT / "manuscript" / "13_manuscript_draft"
OUT_RESULTS = PROJECT_ROOT / "results" / "13_manuscript_draft"

TITLE = "Forecast-Informed Peak-Aware Electric Vehicle Charging Load Prediction and Constrained Scheduling Using an Adaptive Hybrid Ensemble"

TEXT_INPUTS = {
    "abstract": STEP12_MANUSCRIPT / "12_abstract_draft.txt",
    "contributions": STEP12_MANUSCRIPT / "12_final_contributions.txt",
    "limitations": STEP12_MANUSCRIPT / "12_limitations_and_validity_notes.txt",
    "results_narrative": STEP12_MANUSCRIPT / "12_results_narrative.txt",
    "method_outline": STEP12_MANUSCRIPT / "12_method_section_outline.txt",
    "figure_captions": STEP12_MANUSCRIPT / "12_final_figure_captions.txt",
    "table_captions": STEP12_MANUSCRIPT / "12_final_table_captions.txt",
    "title_options": STEP12_MANUSCRIPT / "12_title_options.txt",
}

TABLE_INPUTS = {
    "table1": STEP12_TABLES / "12_table1_dataset_summary.csv",
    "table2": STEP12_TABLES / "12_table2_site_summary.csv",
    "table3": STEP12_TABLES / "12_table3_feature_engineering_summary.csv",
    "table4": STEP12_TABLES / "12_table4_forecasting_model_comparison.csv",
    "table5": STEP12_TABLES / "12_table5_statistical_validation_summary.csv",
    "table6": STEP12_TABLES / "12_table6_prediction_interval_summary.csv",
    "table7": STEP12_TABLES / "12_table7_real_session_scheduling_summary.csv",
    "table8": STEP12_TABLES / "12_table8_synthetic_multisite_scheduling_summary.csv",
    "table9": STEP12_TABLES / "12_table9_ablation_summary.csv",
}

FIGURE_INPUTS = {
    "Figure 1": STEP12_FIGURES / "12_fig1_framework_overview.png",
    "Figure 2": STEP12_FIGURES / "12_fig2_load_patterns.png",
    "Figure 3": STEP12_FIGURES / "12_fig3_forecasting_comparison.png",
    "Figure 4": STEP12_FIGURES / "12_fig4_statistical_validation.png",
    "Figure 5": STEP12_FIGURES / "12_fig5_prediction_intervals.png",
    "Figure 6": STEP12_FIGURES / "12_fig6_real_session_scheduling.png",
    "Figure 7": STEP12_FIGURES / "12_fig7_synthetic_multisite_scheduling.png",
    "Figure 8": STEP12_FIGURES / "12_fig8_site_level_scheduling.png",
}


def ensure_dirs() -> None:
    OUT_MANUSCRIPT.mkdir(parents=True, exist_ok=True)
    OUT_RESULTS.mkdir(parents=True, exist_ok=True)


def read_text(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="replace").strip()


def read_table(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path)


def fmt(value: Any, digits: int = 4) -> str:
    if pd.isna(value):
        return ""
    if isinstance(value, float):
        return f"{value:.{digits}f}"
    return str(value)


def compact_markdown_table(df: pd.DataFrame, max_rows: int = 8, max_col_width: int = 42) -> str:
    if df.empty:
        return "_Table source file was unavailable._"
    display = df.head(max_rows).copy()
    display = display.fillna("")
    for column in display.columns:
        display[column] = display[column].astype(str).map(
            lambda x: x if len(x) <= max_col_width else x[: max_col_width - 3] + "..."
        )
    headers = list(display.columns)
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for _, row in display.iterrows():
        lines.append("| " + " | ".join(str(row[h]).replace("\n", " ") for h in headers) + " |")
    if len(df) > max_rows:
        lines.append(f"\n_Table truncated for readability. Full CSV contains {len(df)} rows._")
    return "\n".join(lines)


def load_sources() -> tuple[dict[str, str], dict[str, pd.DataFrame], list[str]]:
    warnings_list: list[str] = []
    texts = {}
    for key, path in TEXT_INPUTS.items():
        texts[key] = read_text(path)
        if not path.exists():
            warnings_list.append(f"Missing text input: {path}")
    tables = {}
    for key, path in TABLE_INPUTS.items():
        tables[key] = read_table(path)
        if not path.exists():
            warnings_list.append(f"Missing table input: {path}")
    for label, path in FIGURE_INPUTS.items():
        if not path.exists():
            warnings_list.append(f"Missing figure input for {label}: {path}")
    return texts, tables, warnings_list


def row_by_value(df: pd.DataFrame, column: str, value: str) -> pd.Series:
    if df.empty or column not in df.columns:
        return pd.Series(dtype=object)
    subset = df.loc[df[column].astype(str) == value]
    if subset.empty:
        return pd.Series(dtype=object)
    return subset.iloc[0]


def metric_context(tables: dict[str, pd.DataFrame]) -> dict[str, Any]:
    table4 = tables["table4"]
    table6 = tables["table6"]
    table7 = tables["table7"]
    table8 = tables["table8"]
    eahpa = row_by_value(table4, "model", "E-AHPA")
    lgbm = row_by_value(table4, "model", "LGBMRegressor")
    prc = row_by_value(table4, "model", "PRC-E-AHPA")
    interval = table6.iloc[0] if not table6.empty else pd.Series(dtype=object)
    real_sched = table7.iloc[0] if not table7.empty else pd.Series(dtype=object)
    synth_sched = table8.iloc[0] if not table8.empty else pd.Series(dtype=object)
    return {
        "eahpa_mae": float(eahpa.get("MAE", 4.1909)),
        "lgbm_mae": float(lgbm.get("MAE", 4.3504)),
        "eahpa_rmse": float(eahpa.get("RMSE", 9.9061)),
        "eahpa_r2": float(eahpa.get("R2", 0.6051)),
        "prc_peak_mae": float(prc.get("peak_MAE", 18.5486)),
        "prc_high_peak_mae": float(prc.get("high_peak_MAE", 27.2268)),
        "interval_risk_reduction": float(interval.get("underestimation_risk_reduction", 13.723)),
        "interval_coverage": float(interval.get("empirical_coverage", 0.8682)),
        "interval_width": float(interval.get("average_width", 19.6965)),
        "peak_coverage": float(interval.get("peak_coverage", 0.7829)),
        "high_peak_coverage": float(interval.get("high_peak_coverage", 0.7624)),
        "upper_under_rate": float(interval.get("upper_bound_underestimation_rate", 5.1795)),
        "real_peak_reduction": float(real_sched.get("peak_reduction_percent", 41.84)),
        "real_capacity_reduction": float(real_sched.get("capacity_violation_reduction_hours", 164)),
        "real_unserved": float(real_sched.get("unserved_energy_percent", 0.04)),
        "synth_real_sessions": int(synth_sched.get("real_sessions_used", 9079)),
        "synth_synthetic_sessions": int(synth_sched.get("synthetic_sessions_used", 12256)),
        "synth_total_sessions": int(synth_sched.get("total_sessions", 21335)),
        "synth_peak_reduction": float(synth_sched.get("uncertainty_aware_peak_reduction_percent", 34.19)),
        "synth_capacity_reduction": float(synth_sched.get("uncertainty_aware_capacity_violation_reduction_hours", 476)),
        "synth_unserved": float(synth_sched.get("uncertainty_aware_unserved_energy_percent", 0.001)),
        "recommended_strategy": str(synth_sched.get("recommended_strategy", "hybrid_uncertainty_peak")),
        "claim_strength": str(synth_sched.get("claim_strength", "strong scenario evidence")),
    }


def polished_abstract(ctx: dict[str, Any]) -> str:
    return (
        "Accurate electric vehicle (EV) charging load forecasting is increasingly important for "
        "operating charging sites under local capacity constraints. This paper develops a "
        "forecast-to-schedule framework that combines leakage-free feature engineering, peak-aware "
        "adaptive hybrid forecasting, conformal prediction intervals, and constrained EV charging "
        "scheduling. The proposed E-AHPA adaptive hybrid ensemble is selected as the main forecasting "
        f"model, achieving test MAE {ctx['eahpa_mae']:.4f} compared with {ctx['lgbm_mae']:.4f} for "
        "LGBM, with statistically supported overall MAE improvement. A PRC-E-AHPA peak-risk "
        f"calibrated variant is retained for operational use, with peak_MAE {ctx['prc_peak_mae']:.4f} "
        f"and high_peak_MAE {ctx['prc_high_peak_mae']:.4f}. Validation-calibrated conformal-style "
        "prediction intervals provide upper-bound forecasts for scheduling and reduce upper-bound "
        f"underestimation risk by {ctx['interval_risk_reduction']:.3f} percentage points. These "
        "forecasts are used in a constrained scheduler that respects vehicle arrival, departure, "
        "energy, charger-power, and site-capacity limits. In the synthetic empirical six-site "
        f"scalability scenario, uncertainty-aware scheduling reduced peak load by {ctx['synth_peak_reduction']:.2f}% "
        f"and capacity violation hours from 484 to 8, with approximately {ctx['synth_unserved']:.3f}% "
        "unserved energy. Synthetic multi-site sessions are used only for scenario analysis and are "
        "not presented as real six-site session logs."
    )


def table_block(number: int, title: str, key: str, tables: dict[str, pd.DataFrame], max_rows: int = 8) -> str:
    path = TABLE_INPUTS[key]
    return (
        f"\n[Insert Table {number} here: {title}]\n\n"
        f"_Source CSV: `{path}`_\n\n"
        f"{compact_markdown_table(tables[key], max_rows=max_rows)}\n"
    )


def figure_block(number: int, title: str, filename: str) -> str:
    path = STEP12_FIGURES / filename
    return f"\n[Insert Figure {number} here: {title}]\n\n![Figure {number}: {title}]({path})\n"


def build_manuscript(texts: dict[str, str], tables: dict[str, pd.DataFrame], ctx: dict[str, Any]) -> str:
    contributions = texts.get("contributions", "").strip()
    limitations = texts.get("limitations", "").strip()
    abstract = polished_abstract(ctx)
    md = f"""# {TITLE}

## Abstract

{abstract}

## Keywords

electric vehicle charging; load forecasting; adaptive hybrid ensemble; peak-aware forecasting; conformal prediction; uncertainty-aware scheduling; constrained scheduling

## 1. Introduction

Electric vehicle (EV) adoption is increasing the temporal variability and peak intensity of electricity demand at charging sites. Charging loads can concentrate around commute patterns, workplace dwell times, and site-specific operating rhythms, creating localized peaks that are difficult to manage with static planning assumptions [REF].

Short-term EV charging load forecasting is therefore essential for grid-aware operation. However, optimizing only average error is not sufficient. A model with acceptable overall MAE can still underestimate high-load periods, and such underestimation can lead to transformer overload, unmet charging demand, or overly optimistic scheduling decisions.

Peak underestimation is especially important in EV charging because operational risk is asymmetric. Overestimation may lead to conservative schedules, but underestimation during peak-risk hours can produce capacity violations. This paper therefore treats peak-aware forecasting and uncertainty-aware upper bounds as operational requirements, not optional diagnostics.

Scheduling adds another layer of realism. A useful charging scheduler must respect vehicle arrival times, departure deadlines, requested energy, charger power limits, and site capacity. Peak reduction claims are not meaningful if they ignore energy delivery or quietly drop difficult sessions.

Prior and standard approaches often compare forecasting models without fully documenting leakage control, peak-risk behavior, statistical validation, or downstream scheduling feasibility [REF]. Many scheduling demonstrations also use simplified load profiles rather than session-level constraints [REF].

This paper proposes a forecast-to-schedule framework for EV charging load management. The framework combines leakage-free calendar-enhanced features, the E-AHPA adaptive hybrid forecasting model, PRC-E-AHPA peak-risk calibration, conformal-style prediction intervals, and constrained scheduling with both real/session-limited and synthetic empirical multi-site scenario evaluation.

The contributions are:

{contributions}

## 2. Related Work

### 2.1 EV Charging Load Forecasting

EV charging load forecasting has been studied using statistical models, machine learning models, and deep learning architectures [REF]. Prior work highlights strong temporal structure in charging behavior, including hour-of-day, day-of-week, and site-specific demand patterns. Citations should be added here for EV charging load forecasting surveys and site-level forecasting studies.

### 2.2 Machine Learning and Ensemble Methods for Load Forecasting

Tree-based machine learning models and ensemble methods are widely used in load forecasting because they can capture nonlinear relationships and interactions among calendar and historical load features [REF]. Hybrid ensembles can further exploit complementary model strengths, but must be validated carefully to avoid tuning on future data.

### 2.3 Peak-Aware and Uncertainty-Aware Forecasting

Peak-aware forecasting addresses the operational asymmetry between average error and high-load underestimation [REF]. Uncertainty quantification, including conformal prediction, provides calibrated intervals or upper-bound forecasts that can support conservative operational decisions [REF]. References must be added for conformal prediction and uncertainty-aware load forecasting.

### 2.4 EV Charging Scheduling and Demand Management

EV charging scheduling typically aims to reduce peak load, manage capacity constraints, or shift energy delivery while satisfying vehicle deadlines and energy requests [REF]. Realistic scheduling should report feasibility, unserved energy, and capacity violations, not only peak reduction. References must be added manually from related papers.

## 3. Data Description and Preprocessing

The dataset contains hourly EV charging load data across six sites and session-level charging records used for constrained scheduling. Hourly load data provide the forecasting target, while session records provide arrival times, departure times, requested energy, station/space identifiers, and charging feasibility information.

The forecasting target is site-level hourly charging load. Data are split chronologically into train, validation, and test periods, preserving temporal order and avoiding random leakage across time. The processed session file contains scheduling-ready sessions, but complete real session coverage is available only for limited site coverage.

This limitation affects scheduling validation. The real/session-limited scheduling experiment is therefore reported as a one-site calendar-aligned case study. To evaluate scalability across all six forecast sites, Step 11D generated synthetic empirical sessions from observed real-session distributions. These synthetic sessions are scenario data only and are not real six-site charging logs.

{table_block(1, "Dataset summary", "table1", tables, max_rows=4)}

{table_block(2, "Site summary", "table2", tables, max_rows=8)}

## 4. Leakage-Free Feature Engineering

Feature engineering uses calendar, cyclic, lag, rolling, exponentially weighted, and peak-memory features. Calendar features encode hour, day, week, month, weekend status, and business-period structure. Cyclic encodings represent hour and seasonal cycles without artificial discontinuities.

Historical lag and rolling features are computed within each site using past observations only. Weekly memory features capture recurring charging behavior, while train-derived peak thresholds identify peak-risk regimes without using future test labels. This design ensures that every forecast row uses only information that would have been available at prediction time.

{table_block(3, "Feature engineering summary", "table3", tables, max_rows=10)}

## 5. Proposed Forecasting Framework

### 5.1 Standard ML Benchmark

The benchmark suite includes linear and regularized baselines, persistence-style baselines, and standard machine learning models such as LGBM, CatBoost, and XGBoost. LGBMRegressor serves as the primary standard ML comparator because it produced the strongest conventional benchmark in the final validation.

### 5.2 E-AHPA Model

E-AHPA is the main adaptive hybrid peak-aware forecasting model. It combines complementary behavior from standard and peak-risk-aware candidate models, using validation-constrained selection to balance overall accuracy and peak robustness. The final decision identifies E-AHPA as the main point forecasting model because it improves overall MAE with statistical support.

On the test set, E-AHPA achieved MAE {ctx['eahpa_mae']:.4f}, RMSE {ctx['eahpa_rmse']:.4f}, and R2 {ctx['eahpa_r2']:.4f}, compared with LGBM MAE {ctx['lgbm_mae']:.4f}.

### 5.3 PRC-E-AHPA Peak-Risk Calibration

PRC-E-AHPA adds a peak-risk calibrated correction layer to the E-AHPA forecast. The correction uses validation residual behavior and peak-risk features, and is retained as an operational variant for peak-sensitive scheduling. PRC-E-AHPA achieved peak_MAE {ctx['prc_peak_mae']:.4f} and high_peak_MAE {ctx['prc_high_peak_mae']:.4f}. The manuscript should describe these as observed peak/high-peak improvements and avoid claiming statistically dominant peak superiority for every peak-row comparison.

### 5.4 Statistical Validation

Statistical validation uses paired row bootstrap, block bootstrap where applicable, Wilcoxon tests, sign tests, and robustness checks. The supported headline claim is that E-AHPA improves overall MAE over LGBM. Peak-risk results are useful and operationally meaningful, but are worded cautiously where confidence intervals cross zero.

{table_block(4, "Forecasting model comparison", "table4", tables, max_rows=8)}

{table_block(5, "Statistical validation summary", "table5", tables, max_rows=8)}

{figure_block(3, "Forecasting comparison", "12_fig3_forecasting_comparison.png")}

{figure_block(4, "Statistical validation", "12_fig4_statistical_validation.png")}

## 6. Prediction Intervals and Uncertainty-Aware Forecasting

Prediction intervals are calibrated from validation residuals without retraining the forecasting model. The selected Step 10 interval uses the site_risk_asymmetric method on the main_point_forecast_kw track with nominal 90% coverage.

The selected interval achieved empirical coverage {ctx['interval_coverage']:.4f}, average interval width {ctx['interval_width']:.4f} kW, peak coverage {ctx['peak_coverage']:.4f}, and high-peak coverage {ctx['high_peak_coverage']:.4f}. The upper-bound underestimation rate was {ctx['upper_under_rate']:.4f}%, reducing underestimation risk by {ctx['interval_risk_reduction']:.3f} percentage points. Because coverage is below nominal, the interval result is framed as an operational underestimation-risk reduction tool rather than a perfect coverage guarantee.

{table_block(6, "Prediction interval summary", "table6", tables, max_rows=5)}

{figure_block(5, "Prediction intervals", "12_fig5_prediction_intervals.png")}

## 7. Constrained EV Charging Scheduling

### 7.1 Scheduling Problem Formulation

Each charging session is represented by an arrival time, departure time, requested energy, and charger power limit. The scheduler assigns energy only within the feasible session window. Site-level capacity constraints are applied, and the scheduler reports delivered energy, unserved energy, capacity violation hours, and peak load.

The objective is to reduce peak and capacity risk while maintaining high energy service. Strategies include uncontrolled charging, valley filling, point-forecast scheduling, peak-sensitive scheduling, uncertainty-aware scheduling, and a hybrid uncertainty/peak strategy.

### 7.2 Real/Session-Limited Scheduling Scenario

The real/session-limited case study uses a calendar-aligned scenario because complete real session logs were available only for limited site coverage. In this setting, uncertainty-aware scheduling reduced peak load by {ctx['real_peak_reduction']:.2f}%, reduced capacity violation hours by {ctx['real_capacity_reduction']:.0f}, and left {ctx['real_unserved']:.3f}% unserved energy. The claim is moderate because of the one-site/session-limited coverage.

{table_block(7, "Real-session scheduling summary", "table7", tables, max_rows=5)}

{figure_block(6, "Real-session scheduling", "12_fig6_real_session_scheduling.png")}

### 7.3 Synthetic Empirical Multi-Site Scenario

To test scalability across six forecast sites, synthetic sessions were generated from empirical real-session distributions. The scenario includes {ctx['synth_real_sessions']} calendar-aligned real empirical sessions and {ctx['synth_synthetic_sessions']} schedulable synthetic empirical sessions, for {ctx['synth_total_sessions']} total sessions. All synthetic rows are labeled and are not real six-site session logs.

In the main capacity setting, uncertainty-aware scheduling reduced peak load by {ctx['synth_peak_reduction']:.2f}%, reduced capacity violation hours from 484 to 8, and left approximately {ctx['synth_unserved']:.4f}% unserved energy. The recommended scheduling strategy for paper discussion is {ctx['recommended_strategy']}. The scheduling claim is {ctx['claim_strength']}, but only as synthetic multi-site scenario evidence.

{table_block(8, "Synthetic multi-site scheduling summary", "table8", tables, max_rows=5)}

{figure_block(7, "Synthetic multi-site scheduling", "12_fig7_synthetic_multisite_scheduling.png")}

{figure_block(8, "Site-level scheduling", "12_fig8_site_level_scheduling.png")}

## 8. Ablation and Development Summary

The experimental sequence was not random trial-and-error. Each step addressed a specific weakness: standard ML established a benchmark, E-AHPA improved overall accuracy, PRC-E-AHPA addressed peak-risk behavior, prediction intervals reduced underestimation risk, and scheduling experiments tested feasibility under realistic constraints.

{table_block(9, "Ablation summary", "table9", tables, max_rows=8)}

## 9. Discussion

E-AHPA provides the strongest supported forecasting contribution: statistically validated overall MAE improvement over LGBM. This matters because accurate site-level forecasts are the foundation for operational scheduling.

Peak-risk behavior requires careful interpretation. PRC-E-AHPA improves observed peak and high-peak metrics and is useful as an operational variant, but the manuscript should avoid overstating statistical dominance where peak-row uncertainty remains mixed.

Prediction intervals strengthen the operational value of the forecasts. Although coverage is below nominal, the upper-bound forecast substantially reduces underestimation risk, which is directly relevant to capacity-constrained scheduling.

Scheduling results show that forecast-informed and uncertainty-aware signals can be used inside realistic session constraints. Valley filling can produce strong peak reduction, but the hybrid uncertainty/peak strategy is recommended because it ties the scheduling decision more directly to the forecast contribution while maintaining excellent energy service.

The synthetic multi-site scenario broadens scalability analysis, but it does not replace real session logs. Its value is to test whether the scheduling framework remains feasible across all forecast sites under empirically generated demand.

## 10. Limitations and Validity Threats

{limitations}

## 11. Conclusion

This paper presents an end-to-end EV charging load prediction and constrained scheduling framework. The forecasting contribution centers on E-AHPA, an adaptive hybrid peak-aware model with statistically supported overall MAE improvement, and PRC-E-AHPA, a peak-risk calibrated operational variant.

The uncertainty component provides conformal-style prediction intervals and upper-bound forecasts for scheduling. These intervals are not perfectly nominal, but they materially reduce underestimation risk and provide a conservative scheduling signal.

The scheduling component demonstrates realistic energy allocation under arrival, departure, energy, charger-power, and capacity constraints. Real/session-limited scheduling is reported as a calendar-aligned case study, while the synthetic empirical six-site scenario is reported strictly as scalability evidence.

Future work should validate the framework on real multi-site session logs, incorporate weather, traffic, price, and event features, compare against optimization-based MILP scheduling, and test external datasets.

## References

[REF] EV charging load forecasting paper.

[REF] ML ensemble load forecasting.

[REF] Conformal prediction.

[REF] EV charging scheduling.

[REF] Peak-aware demand management.

References must be added manually from related papers.

## Appendix A. Feature Groups

Additional feature-group details are provided in Table 3 and the Step 05B feature engineering outputs.

## Appendix B. Additional Scheduling Sensitivity

Additional scheduling sensitivity outputs are available in the Step 11B and Step 11E result folders.

## Appendix C. Synthetic Session Generation Details

Synthetic session generation details are available in Step 11D. Synthetic sessions are empirical scenario data and are not real charging logs.
"""
    return md


def build_claims_audit(ctx: dict[str, Any]) -> str:
    return f"""# Claims Audit

- Claim: E-AHPA improves MAE over LGBM.
  Source: Table 4 and Table 5.
  Status: supported. E-AHPA MAE {ctx['eahpa_mae']:.4f}; LGBM MAE {ctx['lgbm_mae']:.4f}.

- Claim: E-AHPA has statistically supported overall MAE improvement.
  Source: Table 5 and Step 09B statistical validation.
  Status: supported for overall MAE.

- Claim: PRC-E-AHPA improves observed peak/high-peak metrics.
  Source: Table 4.
  Status: supported descriptively. Wording must remain statistically cautious for peak rows where intervals cross zero.

- Claim: Prediction intervals reduce upper-bound underestimation risk.
  Source: Table 6.
  Status: supported. Risk reduction {ctx['interval_risk_reduction']:.3f} percentage points.

- Claim: Real/session-limited scheduling reduces peak/capacity violations.
  Source: Table 7.
  Status: supported for one-site calendar-aligned case study only.

- Claim: Synthetic six-site scheduling scenario demonstrates scalability.
  Source: Table 8 and Step 11E.
  Status: supported as synthetic scenario evidence.

- Claim: Synthetic six-site scheduling is real validation.
  Source: none.
  Status: not allowed.

- Claim: Greedy scheduling is globally optimal.
  Source: none.
  Status: not allowed.
"""


def build_reviewer_risks() -> str:
    return """# Response to Old Reviewer Risks

- Unclear novelty:
  The manuscript now presents an end-to-end forecast-to-schedule framework with E-AHPA, PRC-E-AHPA, uncertainty intervals, and constrained scheduling.

- Leakage-free setup:
  The draft explicitly describes chronological splitting, site-wise past-only lags, rolling features, and train-derived peak thresholds.

- Weak feature design:
  Feature groups are organized and documented in Table 3, including calendar, cyclic, lag, rolling, weekly memory, and peak-memory features.

- Peak underestimation:
  PRC-E-AHPA and conformal-style upper-bound intervals are included, with cautious language about peak statistical support.

- Unrealistic scheduling:
  Scheduling is now session-constrained with arrival, departure, energy, charger power, and capacity constraints. Energy delivery and unserved energy are reported.

- Missing statistical validation:
  Step 09B statistical validation is summarized in Table 5 and discussed in the forecasting framework section.

- Figure/table inconsistency:
  Step 12 created a final figure inventory and nine final tables that are referenced consistently in the draft.

- Synthetic data caveat:
  The draft repeatedly states that synthetic empirical sessions are scenario data only and not real six-site logs.
"""


def build_missing_items() -> str:
    return """# Missing Items for Submission

- Add real references and replace all `[REF]` placeholders.
- Check the target conference or journal template.
- Convert wide CSV tables into the required publication table format.
- Verify figure resolution, font sizes, and color accessibility.
- Add author names and affiliations.
- Add data and code availability statement.
- Check word limit, page limit, and supplemental material rules.
- Add ethics, conflict-of-interest, and funding statements if required.
- Decide whether to move detailed sensitivity tables to appendix or supplement.
- Proofread all synthetic-scenario caveats before submission.
"""


def build_author_checklist() -> str:
    return """# Author Checklist

- [ ] Confirm title and author list.
- [ ] Add real citations for every `[REF]` placeholder.
- [ ] Verify all numerical claims against Step 12 tables.
- [ ] Confirm synthetic sessions are never described as real logs.
- [ ] Check all figure paths and captions.
- [ ] Convert tables to the target venue format.
- [ ] Add acknowledgments, funding, conflict, ethics, data, and code statements.
- [ ] Run final grammar and consistency pass.
"""


def write_docx(markdown_text: str, tables: dict[str, pd.DataFrame], output_path: Path) -> bool:
    try:
        from docx import Document  # type: ignore
    except Exception:
        return False

    doc = Document()
    for line in markdown_text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("# "):
            doc.add_heading(stripped[2:], level=0)
        elif stripped.startswith("## "):
            doc.add_heading(stripped[3:], level=1)
        elif stripped.startswith("### "):
            doc.add_heading(stripped[4:], level=2)
        elif stripped.startswith("- "):
            doc.add_paragraph(stripped[2:], style="List Bullet")
        elif stripped.startswith("[Insert Table"):
            doc.add_paragraph(stripped)
        elif stripped.startswith("[Insert Figure") or stripped.startswith("![Figure"):
            doc.add_paragraph(stripped)
        elif stripped.startswith("|"):
            continue
        else:
            doc.add_paragraph(stripped)

    doc.add_heading("Compact Table Appendix", level=1)
    for key, df in tables.items():
        doc.add_heading(key, level=2)
        if df.empty:
            doc.add_paragraph("Table unavailable.")
            continue
        subset = df.head(8).fillna("")
        table = doc.add_table(rows=1, cols=len(subset.columns))
        hdr = table.rows[0].cells
        for idx, col in enumerate(subset.columns):
            hdr[idx].text = str(col)
        for _, row in subset.iterrows():
            cells = table.add_row().cells
            for idx, col in enumerate(subset.columns):
                cells[idx].text = str(row[col])[:80]
    doc.save(output_path)
    return True


def main() -> None:
    ensure_dirs()
    texts, tables, warnings_list = load_sources()
    ctx = metric_context(tables)
    manuscript = build_manuscript(texts, tables, ctx)

    md_path = OUT_MANUSCRIPT / "13_full_manuscript_draft.md"
    docx_path = OUT_MANUSCRIPT / "13_full_manuscript_draft.docx"
    checklist_path = OUT_MANUSCRIPT / "13_author_checklist.md"
    risks_path = OUT_MANUSCRIPT / "13_response_to_old_reviewer_risks.md"
    audit_path = OUT_MANUSCRIPT / "13_claims_audit.md"
    missing_path = OUT_MANUSCRIPT / "13_missing_items_for_submission.md"
    report_path = OUT_RESULTS / "13_manuscript_build_report.txt"

    md_path.write_text(manuscript, encoding="utf-8")
    checklist_path.write_text(build_author_checklist(), encoding="utf-8")
    risks_path.write_text(build_reviewer_risks(), encoding="utf-8")
    audit_path.write_text(build_claims_audit(ctx), encoding="utf-8")
    missing_path.write_text(build_missing_items(), encoding="utf-8")
    docx_created = write_docx(manuscript, tables, docx_path)

    sections = [line for line in manuscript.splitlines() if line.startswith("## ")]
    report = f"""Step 13 manuscript build report
================================
Files loaded:
- Text inputs checked: {len(TEXT_INPUTS)}
- Tables checked: {len(TABLE_INPUTS)}
- Figures checked: {len(FIGURE_INPUTS)}

Manuscript sections generated:
{chr(10).join('- ' + s.replace('## ', '') for s in sections)}

Tables included:
{chr(10).join('- ' + path.name for path in TABLE_INPUTS.values())}

Figures referenced:
{chr(10).join('- ' + path.name for path in FIGURE_INPUTS.values())}

Outputs:
- Markdown draft: {md_path}
- DOCX draft: {docx_path if docx_created else 'not created; python-docx unavailable'}
- Claims audit: {audit_path}
- Reviewer risk response: {risks_path}
- Missing items checklist: {missing_path}

Warnings:
{chr(10).join('- ' + w for w in warnings_list) if warnings_list else '- none'}

Next action:
Add real citations, adapt formatting to the target venue, and perform a careful author review of all claims and caveats.
"""
    report_path.write_text(report, encoding="utf-8")
    (OUT_RESULTS / "13_run_summary.json").write_text(
        json.dumps(
            {
                "markdown_draft": str(md_path),
                "docx_created": docx_created,
                "docx_path": str(docx_path) if docx_created else "",
                "claims_audit": str(audit_path),
                "reviewer_risks": str(risks_path),
                "missing_items": str(missing_path),
                "warnings": warnings_list,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print("Step 13 manuscript draft build complete")
    print(f"Manuscript draft path: {md_path}")
    print(f"DOCX path: {docx_path if docx_created else 'not created; python-docx unavailable'}")
    print(f"Claims audit path: {audit_path}")
    print(f"Reviewer risk response path: {risks_path}")
    print(f"Missing items checklist path: {missing_path}")
    print(f"Build report path: {report_path}")
    print(f"Warnings: {'; '.join(warnings_list) if warnings_list else 'none'}")


if __name__ == "__main__":
    main()
