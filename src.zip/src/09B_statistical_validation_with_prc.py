"""
Step 09B: Statistical validation with PRC-E-AHPA.

Run from the project root:
    python src/09B_statistical_validation_with_prc.py

This step uses saved test predictions only. It does not train, tune, or modify
forecasting models.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import importlib
import json
import re
import sys
import types
import warnings

import numpy as np


if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
FEATURE_FILE = PROJECT_ROOT / "data" / "processed" / "05B_forecasting_features.csv"
ML_TEST_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_test_predictions.csv"
EAHPA_TEST_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_test_predictions.csv"
EAHPA_SUMMARY_FILE = PROJECT_ROOT / "results" / "08D_enhanced_ahpa_ensemble" / "08D_selected_hybrid_summary.csv"
PRC_TEST_FILE = PROJECT_ROOT / "results" / "08E_peak_risk_calibrated_eahpa" / "08E_test_predictions.csv"
PRC_METRICS_FILE = PROJECT_ROOT / "results" / "08E_peak_risk_calibrated_eahpa" / "08E_prc_eahpa_overall_metrics.csv"
STEP09_METRICS_FILE = PROJECT_ROOT / "results" / "09_statistical_validation" / "09_test_metrics_recomputed.csv"
BASELINE_TEST_FILE = PROJECT_ROOT / "results" / "06_baseline_forecasting" / "06_test_predictions.csv"
AHPA08C_TEST_FILE = PROJECT_ROOT / "results" / "08C_adaptive_hybrid_peak_aware_ensemble" / "08C_test_predictions.csv"

RESULTS_DIR = PROJECT_ROOT / "results" / "09B_statistical_validation_with_prc"
FIGURES_DIR = PROJECT_ROOT / "figures" / "09B_statistical_validation_with_prc"

ACTUAL = "actual_load_kw"
KEYS = ["timestamp", "site_id"]
N_BOOTSTRAP = 1000
RANDOM_STATE = 42


def ensure_dirs() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)


def scipy_tools() -> tuple[bool, Any]:
    try:
        return True, importlib.import_module("scipy.stats")
    except Exception:
        return False, None


def prediction_cols(df: pd.DataFrame) -> list[str]:
    return [c for c in df.columns if c.startswith("prediction_")]


def clip(values: Any) -> np.ndarray:
    return np.maximum(np.asarray(values, dtype=float), 0.0)


def mae(a: np.ndarray, p: np.ndarray) -> float:
    return float(np.mean(np.abs(p - a))) if len(a) else np.nan


def rmse(a: np.ndarray, p: np.ndarray) -> float:
    return float(np.sqrt(np.mean((p - a) ** 2))) if len(a) else np.nan


def r2(a: np.ndarray, p: np.ndarray) -> float:
    ss_res = float(np.sum((a - p) ** 2))
    ss_tot = float(np.sum((a - np.mean(a)) ** 2))
    return 1 - ss_res / ss_tot if ss_tot else np.nan


def rate(mask: np.ndarray) -> float:
    return float(np.mean(mask) * 100) if len(mask) else np.nan


def selected_eahpa_col() -> str:
    summary = pd.read_csv(EAHPA_SUMMARY_FILE)
    primary = summary[summary["selection_role"] == "primary_selected_AHPA_Ensemble"]
    if primary.empty:
        primary = summary.head(1)
    return "prediction_" + str(primary.iloc[0]["selected_model_name"])


def load_base() -> pd.DataFrame:
    df = pd.read_csv(FEATURE_FILE)
    df["timestamp"] = df["timestamp"].astype(str)
    if ACTUAL not in df.columns:
        df[ACTUAL] = df["target_load_kw"]
    test = df[df["split"] == "test"].copy()
    return test[["timestamp", "site_id", ACTUAL, "split", "is_peak_hour", "is_high_peak_hour"]].copy()


def align(base: pd.DataFrame, path: Path, source: str, col: str, out_col: str) -> tuple[pd.DataFrame, dict[str, Any]]:
    row = {
        "source": source,
        "file": str(path),
        "file_exists": path.exists(),
        "requested_column": col,
        "prediction_columns_found": "",
        "rows": 0,
        "matched_rows": 0,
        "notes": "",
    }
    if not path.exists():
        row["notes"] = "missing; ignored"
        return base, row
    pred = pd.read_csv(path)
    pred["timestamp"] = pred["timestamp"].astype(str)
    if ACTUAL not in pred.columns and "target_load_kw" in pred.columns:
        pred[ACTUAL] = pred["target_load_kw"]
    row["rows"] = len(pred)
    row["prediction_columns_found"] = ", ".join(prediction_cols(pred) + [c for c in pred.columns if c.endswith("_pred")])
    if col not in pred.columns:
        row["notes"] = "requested column missing"
        return base, row
    merged = base.merge(pred[KEYS + [col]], on=KEYS, how="left")
    if out_col in merged.columns and f"{out_col}_y" in merged.columns:
        merged[out_col] = merged[out_col].fillna(merged[f"{out_col}_y"])
        merged = merged.drop(columns=[f"{out_col}_y"])
    elif col in merged.columns:
        merged = merged.rename(columns={col: out_col})
    row["matched_rows"] = int(merged[out_col].notna().sum()) if out_col in merged.columns else 0
    row["notes"] = "loaded"
    return merged, row


def build_combined() -> tuple[pd.DataFrame, pd.DataFrame]:
    base = load_base()
    rows = []
    e_col = selected_eahpa_col()
    combined, row = align(base, ML_TEST_FILE, "Step07 LGBM", "prediction_LGBMRegressor", "lgbm_pred")
    rows.append(row)
    combined, row = align(combined, ML_TEST_FILE, "Step07 CatBoost", "prediction_CatBoostRegressor", "catboost_pred")
    rows.append(row)
    combined, row = align(combined, EAHPA_TEST_FILE, "Step08D E-AHPA", e_col, "eahpa_pred")
    rows.append(row)
    combined, row = align(combined, PRC_TEST_FILE, "Step08E PRC-E-AHPA", "prc_eahpa_pred", "prc_pred")
    rows.append(row)
    combined, row = align(combined, BASELINE_TEST_FILE, "Step06 baseline", "prediction_Linear_Regression_All_Features", "baseline_pred")
    rows.append(row)
    combined, row = align(combined, AHPA08C_TEST_FILE, "Step08C AHPA optional", "prediction_AHPA_gated_HistGB_Retry_plus_BPA_CatBoost_risk_lag168_vs_site_p90_t1.00_a0.15", "ahpa08c_pred")
    rows.append(row)
    report = pd.DataFrame(rows)
    report.to_csv(RESULTS_DIR / "09B_alignment_report.csv", index=False)
    return combined, report


def evaluate(df: pd.DataFrame, model: str, pred_col: str) -> dict[str, Any]:
    a = df[ACTUAL].to_numpy(float)
    p = clip(df[pred_col])
    peak = df["is_peak_hour"].to_numpy(int) == 1
    high = df["is_high_peak_hour"].to_numpy(int) == 1
    q90, q95 = np.nanquantile(a, [0.90, 0.95])
    top10 = a >= q90
    top5 = a >= q95
    max_idx = int(np.argmax(a))
    return {
        "model_name": model,
        "MAE": mae(a, p),
        "RMSE": rmse(a, p),
        "R2": r2(a, p),
        "MBE": float(np.mean(p - a)),
        "underestimation_rate": rate(p < a),
        "overestimation_rate": rate(p > a),
        "peak_MAE": mae(a[peak], p[peak]),
        "high_peak_MAE": mae(a[high], p[high]),
        "peak_underestimation_rate": rate(p[peak] < a[peak]),
        "high_peak_underestimation_rate": rate(p[high] < a[high]),
        "peak_bias": float(np.mean(p[peak] - a[peak])) if peak.any() else np.nan,
        "high_peak_bias": float(np.mean(p[high] - a[high])) if high.any() else np.nan,
        "peak_overestimation_rate": rate(p[peak] > a[peak]),
        "high_peak_overestimation_rate": rate(p[high] > a[high]),
        "top_10_percent_actual_peak_MAE": mae(a[top10], p[top10]),
        "top_5_percent_actual_peak_MAE": mae(a[top5], p[top5]),
        "actual_max_underprediction_kw": float(a[max_idx] - p[max_idx]),
        "row_count": len(df),
        "peak_row_count": int(peak.sum()),
        "high_peak_row_count": int(high.sum()),
    }


def row_ci(delta: np.ndarray) -> tuple[float, float]:
    rng = np.random.default_rng(RANDOM_STATE)
    delta = np.asarray(delta, dtype=float)
    vals = np.empty(N_BOOTSTRAP)
    n = len(delta)
    for i in range(N_BOOTSTRAP):
        vals[i] = float(np.mean(delta[rng.integers(0, n, n)]))
    return float(np.quantile(vals, 0.025)), float(np.quantile(vals, 0.975))


def block_ci(df: pd.DataFrame, delta_col: str, block_size: int) -> tuple[float, float]:
    rng = np.random.default_rng(RANDOM_STATE + block_size)
    ordered = df.reset_index(drop=False).sort_values(["site_id", "timestamp"])
    blocks = []
    for _, sdf in ordered.groupby("site_id", sort=False):
        idx = sdf["index"].to_numpy()
        for start in range(0, len(idx), block_size):
            blocks.append(idx[start : start + block_size])
    vals = np.empty(N_BOOTSTRAP)
    n = len(df)
    for i in range(N_BOOTSTRAP):
        sample = []
        while len(sample) < n:
            sample.extend(blocks[int(rng.integers(0, len(blocks)))].tolist())
        vals[i] = float(np.mean(df.loc[sample[:n], delta_col]))
    return float(np.quantile(vals, 0.025)), float(np.quantile(vals, 0.975))


def stat_compare(df: pd.DataFrame, proposed_col: str, comp_col: str, proposed_name: str, comp_name: str, subset: str, stats_ok: bool, stats: Any) -> dict[str, Any]:
    a = df[ACTUAL].to_numpy(float)
    prop = clip(df[proposed_col])
    comp = clip(df[comp_col])
    delta = np.abs(prop - a) - np.abs(comp - a)
    rb = row_ci(delta)
    b24 = block_ci(df.assign(delta=delta), "delta", 24) if subset == "overall" else (np.nan, np.nan)
    b168 = block_ci(df.assign(delta=delta), "delta", 168) if subset == "overall" else (np.nan, np.nan)
    wins = int(np.sum(np.abs(prop - a) < np.abs(comp - a)))
    losses = int(np.sum(np.abs(prop - a) > np.abs(comp - a)))
    wilcoxon_p = np.nan
    sign_p = np.nan
    if stats_ok:
        try:
            nz = delta[delta != 0]
            wilcoxon_p = float(stats.wilcoxon(nz, alternative="less").pvalue) if len(nz) else np.nan
        except Exception:
            pass
        try:
            sign_p = float(stats.binomtest(wins, wins + losses, 0.5, alternative="greater").pvalue) if wins + losses else np.nan
        except Exception:
            pass
    return {
        "comparison": f"{proposed_name}_vs_{comp_name}",
        "proposed_model": proposed_name,
        "comparator_model": comp_name,
        "subset": subset,
        "observed_MAE_difference": float(np.mean(delta)),
        "row_bootstrap_ci_lower": rb[0],
        "row_bootstrap_ci_upper": rb[1],
        "block24_ci_lower": b24[0],
        "block24_ci_upper": b24[1],
        "block168_ci_lower": b168[0],
        "block168_ci_upper": b168[1],
        "wilcoxon_p_value": wilcoxon_p,
        "sign_test_p_value": sign_p,
        "win_rate": 100 * wins / (wins + losses) if wins + losses else np.nan,
        "row_count": len(df),
        "significant_row_bootstrap": rb[1] < 0,
        "significant_block24": b24[1] < 0 if subset == "overall" else np.nan,
        "significant_block168": b168[1] < 0 if subset == "overall" else np.nan,
    }


def site_metrics(df: pd.DataFrame, models: dict[str, str]) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    for site, sdf in df.groupby("site_id", sort=True):
        for model, col in models.items():
            rows.append(evaluate(sdf, model, col) | {"site_id": site})
    site = pd.DataFrame(rows)
    comps = []
    for prop, comp in [("PRC-E-AHPA", "E-AHPA"), ("PRC-E-AHPA", "LGBMRegressor"), ("E-AHPA", "LGBMRegressor")]:
        p = site[site["model_name"] == prop].set_index("site_id")
        c = site[site["model_name"] == comp].set_index("site_id")
        for site_id in p.index.intersection(c.index):
            comps.append(
                {
                    "site_id": site_id,
                    "comparison": f"{prop}_vs_{comp}",
                    "delta_MAE": p.loc[site_id, "MAE"] - c.loc[site_id, "MAE"],
                    "delta_peak_MAE": p.loc[site_id, "peak_MAE"] - c.loc[site_id, "peak_MAE"],
                    "delta_high_peak_MAE": p.loc[site_id, "high_peak_MAE"] - c.loc[site_id, "high_peak_MAE"],
                    "improves_MAE": p.loc[site_id, "MAE"] < c.loc[site_id, "MAE"],
                    "improves_peak_MAE": p.loc[site_id, "peak_MAE"] < c.loc[site_id, "peak_MAE"],
                    "improves_high_peak_MAE": p.loc[site_id, "high_peak_MAE"] < c.loc[site_id, "high_peak_MAE"],
                }
            )
    return site, pd.DataFrame(comps)


def make_decision(metrics: pd.DataFrame, overall: pd.DataFrame, peak: pd.DataFrame, high: pd.DataFrame) -> pd.DataFrame:
    m = metrics.set_index("model_name")
    e_vs_l = overall[(overall["proposed_model"] == "E-AHPA") & (overall["comparator_model"] == "LGBMRegressor")].iloc[0]
    p_vs_l_peak = peak[(peak["proposed_model"] == "PRC-E-AHPA") & (peak["comparator_model"] == "LGBMRegressor")].iloc[0]
    p_vs_l_high = high[(high["proposed_model"] == "PRC-E-AHPA") & (high["comparator_model"] == "LGBMRegressor")].iloc[0]
    prc_mae_better_lgbm = m.loc["PRC-E-AHPA", "MAE"] < m.loc["LGBMRegressor", "MAE"]
    peak_sig = bool(p_vs_l_peak["significant_row_bootstrap"])
    high_sig = bool(p_vs_l_high["significant_row_bootstrap"])
    if peak_sig and high_sig and prc_mae_better_lgbm:
        final_sched = "PRC-E-AHPA"
        strength = "strong for peak-aware operational scheduling"
    else:
        final_sched = "E-AHPA for default scheduling; PRC-E-AHPA for peak-risk sensitivity analysis"
        strength = "strong overall, cautious peak"
    return pd.DataFrame(
        [
            {
                "main_forecasting_model": "E-AHPA",
                "peak_operational_variant": "PRC-E-AHPA",
                "final_recommended_point_forecast_for_scheduling": final_sched,
                "reason": "E-AHPA has statistically supported overall MAE improvement; PRC-E-AHPA reduces observed peak and high-peak errors but peak-row uncertainty remains mixed.",
                "can_claim_significant_MAE_improvement": bool(e_vs_l["significant_row_bootstrap"] and e_vs_l["significant_block24"] and e_vs_l["significant_block168"]),
                "can_claim_significant_peak_improvement": bool(peak_sig and high_sig),
                "can_claim_observed_peak_reduction": bool(m.loc["PRC-E-AHPA", "peak_MAE"] < m.loc["LGBMRegressor", "peak_MAE"] and m.loc["PRC-E-AHPA", "high_peak_MAE"] < m.loc["LGBMRegressor", "high_peak_MAE"]),
                "recommended_paper_claim_strength": strength,
                "warning_notes": "Do not claim statistically conclusive peak_MAE superiority if the peak-row bootstrap interval crosses zero. Report PRC as a peak-risk calibrated operational variant.",
            }
        ]
    )


def save_figures(metrics: pd.DataFrame, peak: pd.DataFrame, site_imp: pd.DataFrame, df: pd.DataFrame) -> None:
    for fname, metric in [
        ("09B_fig1_mae_comparison.png", "MAE"),
        ("09B_fig2_peak_mae_comparison.png", "peak_MAE"),
        ("09B_fig3_high_peak_mae_comparison.png", "high_peak_MAE"),
    ]:
        plt.figure(figsize=(8, 5))
        plot = metrics.sort_values(metric)
        plt.bar(plot["model_name"], plot[metric])
        plt.xticks(rotation=35, ha="right")
        plt.ylabel(metric)
        plt.tight_layout()
        plt.savefig(FIGURES_DIR / fname, dpi=300)
        plt.close()
    s = site_imp[site_imp["comparison"] == "PRC-E-AHPA_vs_E-AHPA"].sort_values("delta_peak_MAE")
    plt.figure(figsize=(8, 5))
    plt.bar(s["site_id"], s["delta_peak_MAE"])
    plt.axhline(0, color="black", linewidth=0.8)
    plt.xticks(rotation=45, ha="right")
    plt.ylabel("Delta peak_MAE")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "09B_fig4_eahpa_vs_prc_site_peak_improvement.png", dpi=300)
    plt.close()
    plt.figure(figsize=(8, 4))
    x = np.arange(len(peak))
    y = peak["observed_MAE_difference"].to_numpy(float)
    plt.errorbar(x, y, yerr=[y - peak["row_bootstrap_ci_lower"].to_numpy(float), peak["row_bootstrap_ci_upper"].to_numpy(float) - y], fmt="o")
    plt.axhline(0, color="black", linewidth=0.8)
    plt.xticks(x, peak["comparison"], rotation=35, ha="right", fontsize=8)
    plt.ylabel("Peak-row MAE difference")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "09B_fig5_bootstrap_ci_peak_difference.png", dpi=300)
    plt.close()
    sample = df[df["is_peak_hour"] == 1].sort_values(["site_id", "timestamp"]).head(168)
    plt.figure(figsize=(10, 5))
    plt.plot(sample[ACTUAL].to_numpy(), label="Actual")
    for col, lab in [("lgbm_pred", "LGBM"), ("eahpa_pred", "E-AHPA"), ("prc_pred", "PRC-E-AHPA")]:
        plt.plot(sample[col].to_numpy(), label=lab)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "09B_fig6_actual_vs_lgbm_eahpa_prc_peak_sample.png", dpi=300)
    plt.close()


def write_reports(metrics: pd.DataFrame, overall: pd.DataFrame, peak: pd.DataFrame, high: pd.DataFrame, decision: pd.DataFrame) -> None:
    d = decision.iloc[0]
    m = metrics.set_index("model_name")
    e_vs_l = overall[(overall["proposed_model"] == "E-AHPA") & (overall["comparator_model"] == "LGBMRegressor")].iloc[0]
    p_vs_l = peak[(peak["proposed_model"] == "PRC-E-AHPA") & (peak["comparator_model"] == "LGBMRegressor")].iloc[0]
    h_vs_l = high[(high["proposed_model"] == "PRC-E-AHPA") & (high["comparator_model"] == "LGBMRegressor")].iloc[0]
    report = f"""Step 09B statistical validation report
=======================================
Step 09B was needed because Step 08E introduced PRC-E-AHPA after Step 09 had already validated E-AHPA.

Comparison summary:
{metrics[['model_name', 'MAE', 'peak_MAE', 'high_peak_MAE', 'underestimation_rate', 'peak_underestimation_rate']].to_string(index=False)}

Overall MAE statistical result:
E-AHPA vs LGBM observed MAE difference = {e_vs_l['observed_MAE_difference']:.4f}; row CI [{e_vs_l['row_bootstrap_ci_lower']:.4f}, {e_vs_l['row_bootstrap_ci_upper']:.4f}], block24 CI [{e_vs_l['block24_ci_lower']:.4f}, {e_vs_l['block24_ci_upper']:.4f}], block168 CI [{e_vs_l['block168_ci_lower']:.4f}, {e_vs_l['block168_ci_upper']:.4f}].

Peak_MAE statistical result:
PRC-E-AHPA vs LGBM peak-row difference = {p_vs_l['observed_MAE_difference']:.4f}; row CI [{p_vs_l['row_bootstrap_ci_lower']:.4f}, {p_vs_l['row_bootstrap_ci_upper']:.4f}].

High-peak_MAE statistical result:
PRC-E-AHPA vs LGBM high-peak-row difference = {h_vs_l['observed_MAE_difference']:.4f}; row CI [{h_vs_l['row_bootstrap_ci_lower']:.4f}, {h_vs_l['row_bootstrap_ci_upper']:.4f}].

Site-level robustness:
Site-level metrics and improvement tables are saved. Use these to show whether PRC peak gains are distributed across sites.

Final model decision:
Main forecasting model: {d['main_forecasting_model']}.
Peak operational variant: {d['peak_operational_variant']}.
Scheduling forecast recommendation: {d['final_recommended_point_forecast_for_scheduling']}.
Claim strength: {d['recommended_paper_claim_strength']}.

Recommended paper wording:
E-AHPA should be presented as the main statistically supported forecasting model for average accuracy. PRC-E-AHPA should be presented as a peak-risk calibrated operational variant that reduces observed peak and high-peak errors, with cautious language about peak statistical significance if intervals cross zero.
"""
    leakage = """Step 09B leakage safety report
================================
- No model training or tuning is performed.
- Saved predictions are evaluated only.
- Test labels are used only for statistical evaluation.
- PRC-E-AHPA correction was selected earlier using validation only.
- No future information is used.
- Old deleted Step 08 and Step 08B files are not required.
"""
    paper = f"""In the final forecasting validation, E-AHPA achieved MAE = {m.loc['E-AHPA', 'MAE']:.4f} kW compared with {m.loc['LGBMRegressor', 'MAE']:.4f} kW for LGBMRegressor, supporting E-AHPA as the main forecasting model. PRC-E-AHPA achieved MAE = {m.loc['PRC-E-AHPA', 'MAE']:.4f} kW, peak_MAE = {m.loc['PRC-E-AHPA', 'peak_MAE']:.4f} kW, and high_peak_MAE = {m.loc['PRC-E-AHPA', 'high_peak_MAE']:.4f} kW, reducing the observed peak and high-peak errors relative to LGBMRegressor. Because peak-row confidence intervals may cross zero, PRC-E-AHPA should be described as a peak-risk calibrated operational variant rather than as a statistically conclusive peak-dominant model."""
    (RESULTS_DIR / "09B_statistical_validation_report.txt").write_text(report, encoding="utf-8")
    (RESULTS_DIR / "09B_leakage_safety_report.txt").write_text(leakage, encoding="utf-8")
    (RESULTS_DIR / "09B_paper_ready_final_forecasting_paragraph.txt").write_text(paper, encoding="utf-8")


def main() -> None:
    ensure_dirs()
    stats_ok, stats = scipy_tools()
    combined, _ = build_combined()
    models = {
        "LGBMRegressor": "lgbm_pred",
        "CatBoostRegressor": "catboost_pred",
        "E-AHPA": "eahpa_pred",
        "PRC-E-AHPA": "prc_pred",
    }
    if "baseline_pred" in combined.columns and combined["baseline_pred"].notna().any():
        models["Linear_Regression_All_Features"] = "baseline_pred"
    metrics = pd.DataFrame([evaluate(combined, model, col) for model, col in models.items() if col in combined.columns and combined[col].notna().any()])
    metrics.to_csv(RESULTS_DIR / "09B_test_metrics_recomputed.csv", index=False)
    comparisons = [
        ("E-AHPA", "eahpa_pred", "LGBMRegressor", "lgbm_pred"),
        ("PRC-E-AHPA", "prc_pred", "LGBMRegressor", "lgbm_pred"),
        ("PRC-E-AHPA", "prc_pred", "E-AHPA", "eahpa_pred"),
    ]
    if "catboost_pred" in combined.columns:
        comparisons.append(("PRC-E-AHPA", "prc_pred", "CatBoostRegressor", "catboost_pred"))
    rows_overall, rows_peak, rows_high = [], [], []
    peak_df = combined[combined["is_peak_hour"] == 1].copy()
    high_df = combined[combined["is_high_peak_hour"] == 1].copy()
    for prop, prop_col, comp, comp_col in comparisons:
        rows_overall.append(stat_compare(combined, prop_col, comp_col, prop, comp, "overall", stats_ok, stats))
        rows_peak.append(stat_compare(peak_df, prop_col, comp_col, prop, comp, "peak_rows", stats_ok, stats))
        rows_high.append(stat_compare(high_df, prop_col, comp_col, prop, comp, "high_peak_rows", stats_ok, stats))
    overall = pd.DataFrame(rows_overall)
    peak = pd.DataFrame(rows_peak)
    high = pd.DataFrame(rows_high)
    overall.to_csv(RESULTS_DIR / "09B_statistical_tests_overall.csv", index=False)
    peak.to_csv(RESULTS_DIR / "09B_statistical_tests_peak_rows.csv", index=False)
    high.to_csv(RESULTS_DIR / "09B_statistical_tests_high_peak_rows.csv", index=False)
    site, site_imp = site_metrics(combined, {k: v for k, v in models.items() if v in combined.columns and combined[v].notna().any()})
    site.to_csv(RESULTS_DIR / "09B_site_level_metrics.csv", index=False)
    site_imp.to_csv(RESULTS_DIR / "09B_site_level_improvement.csv", index=False)
    decision = make_decision(metrics, overall, peak, high)
    decision.to_csv(RESULTS_DIR / "09B_final_model_decision.csv", index=False)
    save_figures(metrics, peak, site_imp, combined)
    write_reports(metrics, overall, peak, high, decision)
    m = metrics.set_index("model_name")
    e_vs_l = overall[(overall["proposed_model"] == "E-AHPA") & (overall["comparator_model"] == "LGBMRegressor")].iloc[0]
    p_vs_l_peak = peak[(peak["proposed_model"] == "PRC-E-AHPA") & (peak["comparator_model"] == "LGBMRegressor")].iloc[0]
    p_vs_e_peak = peak[(peak["proposed_model"] == "PRC-E-AHPA") & (peak["comparator_model"] == "E-AHPA")].iloc[0]
    print("Step 09B statistical validation with PRC complete")
    print(f"LGBM MAE, peak_MAE, high_peak_MAE: {m.loc['LGBMRegressor','MAE']:.4f}, {m.loc['LGBMRegressor','peak_MAE']:.4f}, {m.loc['LGBMRegressor','high_peak_MAE']:.4f}")
    print(f"E-AHPA MAE, peak_MAE, high_peak_MAE: {m.loc['E-AHPA','MAE']:.4f}, {m.loc['E-AHPA','peak_MAE']:.4f}, {m.loc['E-AHPA','high_peak_MAE']:.4f}")
    print(f"PRC-E-AHPA MAE, peak_MAE, high_peak_MAE: {m.loc['PRC-E-AHPA','MAE']:.4f}, {m.loc['PRC-E-AHPA','peak_MAE']:.4f}, {m.loc['PRC-E-AHPA','high_peak_MAE']:.4f}")
    print(f"E-AHPA MAE statistically supported vs LGBM: {bool(e_vs_l['significant_row_bootstrap'] and e_vs_l['significant_block24'] and e_vs_l['significant_block168'])}")
    print(f"PRC peak_MAE statistically supported vs LGBM: {bool(p_vs_l_peak['significant_row_bootstrap'])}")
    print(f"PRC peak_MAE statistically supported vs E-AHPA: {bool(p_vs_e_peak['significant_row_bootstrap'])}")
    print(f"Final model decision: {decision.iloc[0]['final_recommended_point_forecast_for_scheduling']}")
    print(f"Reports: {RESULTS_DIR}")
    print(f"Figures: {FIGURES_DIR}")


if __name__ == "__main__":
    main()
