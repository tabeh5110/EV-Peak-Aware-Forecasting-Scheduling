"""
Step 15: Format final manuscript from previous manuscript style.

Run from the project root:
    python src/15_format_final_manuscript_from_previous_style.py

This step formats the Step 14 citation-ready manuscript. It does not change
experimental results or invent references.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import re
import sys
import types
import warnings

if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import pandas as pd

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SOURCE_MD = PROJECT_ROOT / "manuscript" / "14_reference_pack" / "14_full_manuscript_with_citations.md"
SOURCE_DOCX = PROJECT_ROOT / "manuscript" / "14_reference_pack" / "14_full_manuscript_with_citations.docx"
SOURCE_REFS = PROJECT_ROOT / "manuscript" / "14_reference_pack" / "14_references_ieee_style_draft.txt"
SOURCE_AUDIT = PROJECT_ROOT / "manuscript" / "14_reference_pack" / "14_citation_audit.md"
SOURCE_REMAINING = PROJECT_ROOT / "manuscript" / "14_reference_pack" / "14_remaining_submission_items.md"
TABLE_DIR = PROJECT_ROOT / "tables" / "12_final_paper_results_pack"
FIG_DIR = PROJECT_ROOT / "figures" / "12_final_paper_results_pack"

OUT_MANUSCRIPT = PROJECT_ROOT / "manuscript" / "15_final_submission_style"
OUT_RESULTS = PROJECT_ROOT / "results" / "15_final_submission_style"

TITLE = "Forecast-Informed Peak-Aware Electric Vehicle Charging Load Prediction and Constrained Scheduling Using an Adaptive Hybrid Ensemble"

DOCX_TABLES = [
    ("Table 1. Dataset summary", TABLE_DIR / "12_table1_dataset_summary.csv"),
    ("Table 4. Forecasting model comparison", TABLE_DIR / "12_table4_forecasting_model_comparison.csv"),
    ("Table 5. Statistical validation summary", TABLE_DIR / "12_table5_statistical_validation_summary.csv"),
    ("Table 6. Prediction interval summary", TABLE_DIR / "12_table6_prediction_interval_summary.csv"),
    ("Table 7. Real-session scheduling summary", TABLE_DIR / "12_table7_real_session_scheduling_summary.csv"),
    ("Table 8. Synthetic multi-site scheduling summary", TABLE_DIR / "12_table8_synthetic_multisite_scheduling_summary.csv"),
]

FIGURES = [
    ("Figure 1. Framework overview", FIG_DIR / "12_fig1_framework_overview.png"),
    ("Figure 3. Forecasting comparison", FIG_DIR / "12_fig3_forecasting_comparison.png"),
    ("Figure 4. Statistical validation", FIG_DIR / "12_fig4_statistical_validation.png"),
    ("Figure 5. Prediction intervals", FIG_DIR / "12_fig5_prediction_intervals.png"),
    ("Figure 6. Real-session scheduling", FIG_DIR / "12_fig6_real_session_scheduling.png"),
    ("Figure 7. Synthetic multi-site scheduling", FIG_DIR / "12_fig7_synthetic_multisite_scheduling.png"),
    ("Figure 8. Site-level scheduling", FIG_DIR / "12_fig8_site_level_scheduling.png"),
]


def ensure_dirs() -> None:
    OUT_MANUSCRIPT.mkdir(parents=True, exist_ok=True)
    OUT_RESULTS.mkdir(parents=True, exist_ok=True)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""


def extract_section(md: str, heading: str) -> str:
    pattern = rf"^## {re.escape(heading)}\s*$([\s\S]*?)(?=^## |\Z)"
    match = re.search(pattern, md, flags=re.MULTILINE)
    return match.group(1).strip() if match else ""


def extract_between(md: str, start: str, end_heading_regex: str) -> str:
    pattern = rf"{re.escape(start)}([\s\S]*?)(?={end_heading_regex})"
    match = re.search(pattern, md, flags=re.MULTILINE)
    return match.group(1).strip() if match else ""


def remove_embedded_references(section: str) -> str:
    return re.sub(r"## References[\s\S]*", "", section).strip()


def clean_markdown(md: str) -> str:
    md = re.sub(r"\n{3,}", "\n\n", md)
    md = md.replace("[REF]", "")
    return md.strip() + "\n"


def build_final_markdown(source: str, refs: str) -> str:
    abstract = extract_section(source, "Abstract")
    keywords = extract_section(source, "Keywords")
    intro = extract_section(source, "1. Introduction")
    related = extract_section(source, "2. Related Work")
    data = extract_section(source, "3. Data Description and Preprocessing")
    features = extract_section(source, "4. Leakage-Free Feature Engineering")
    framework = extract_section(source, "5. Proposed Forecasting Framework")
    intervals = extract_section(source, "6. Prediction Intervals and Uncertainty-Aware Forecasting")
    scheduling = extract_section(source, "7. Constrained EV Charging Scheduling")
    ablation = extract_section(source, "8. Ablation and Development Summary")
    discussion = extract_section(source, "9. Discussion")
    limitations = extract_section(source, "10. Limitations and Validity Threats")
    conclusion = extract_section(source, "11. Conclusion")
    appendix = "\n\n".join(
        [
            "## Appendix A. Feature Groups\n\n" + extract_section(source, "Appendix A. Feature Groups"),
            "## Appendix B. Additional Scheduling Sensitivity\n\n" + extract_section(source, "Appendix B. Additional Scheduling Sensitivity"),
            "## Appendix C. Synthetic Session Generation Details\n\n" + extract_section(source, "Appendix C. Synthetic Session Generation Details"),
        ]
    )

    methodology = "\n\n".join(
        [
            "### 4.1 Leakage-Free Feature Engineering\n\n" + features,
            "### 4.2 Proposed Forecasting Framework\n\n" + framework,
            "### 4.3 Prediction Intervals and Uncertainty-Aware Forecasting\n\n" + intervals,
            "### 4.4 Constrained Scheduling Formulation\n\n" + re.sub(r"^### 7\.2[\s\S]*", "", scheduling, flags=re.MULTILINE).strip(),
        ]
    )
    experimental_setup = (
        "The experimental setup follows the chronological train/validation/test design described above. "
        "Forecasting experiments compare baselines, standard machine learning models, E-AHPA, and PRC-E-AHPA. "
        "Scheduling experiments evaluate real/session-limited and synthetic empirical multi-site scenarios under explicit session and capacity constraints.\n\n"
        "The synthetic empirical multi-site scenario is used only for robustness and scalability analysis. It is not real six-site session-log validation."
    )
    results = "\n\n".join(
        [
            "### 6.1 Forecasting and Statistical Validation\n\n" + framework,
            "### 6.2 Prediction Intervals\n\n" + intervals,
            "### 6.3 Real/Session-Limited Scheduling\n\n" + extract_between(scheduling, "### 7.2 Real/Session-Limited Scheduling Scenario", r"^### 7\.3"),
            "### 6.4 Synthetic Empirical Multi-Site Scheduling\n\n" + extract_between(scheduling, "### 7.3 Synthetic Empirical Multi-Site Scenario", r"^## 8\.|^## "),
            "### 6.5 Ablation Summary\n\n" + ablation,
        ]
    )

    statements = """## Data Availability Statement

The manuscript is based on processed EV charging load and session data in the project workspace. Public dataset references and final processed result tables are cited in the manuscript. Final data-sharing details should be adapted to the target venue policy.

## Code Availability Statement

Analysis scripts are organized in the `src/` directory. Code availability wording should be finalized according to repository and venue requirements.

## Funding

Funding information should be added before submission.

## Competing Interests

The authors should declare any competing interests before submission.

## Acknowledgment

Acknowledgments should be added before submission.
"""

    references = "## References\n\n" + refs.strip()

    final_md = f"""# {TITLE}

## Abstract

{abstract}

## Keywords

{keywords}

## 1. Introduction

{intro}

## 2. Related Work

{related}

## 3. Data Description and Preprocessing

{data}

## 4. Methodology

{methodology}

## 5. Experimental Setup

{experimental_setup}

## 6. Results

{results}

## 7. Discussion

{discussion}

## 8. Limitations and Validity Threats

{limitations}

## 9. Conclusion

{conclusion}

{statements}

{references}

{appendix}
"""
    return clean_markdown(final_md)


def inspect_previous_style() -> tuple[str, bool]:
    candidates = list(PROJECT_ROOT.rglob("Manuscript.docx"))
    if not candidates:
        notes = """Previous manuscript style guide status: not found.

No file named Manuscript.docx was found in the project tree. The formatter used the known Step 13/14 academic structure as a fallback: title, abstract, keywords, numbered sections/subsections, table captions above tables, figure captions below figures, references at end, and end statements.
"""
        return notes, False
    path = candidates[0]
    try:
        from docx import Document  # type: ignore

        doc = Document(path)
        headings = []
        end_statements = []
        for para in doc.paragraphs:
            text = para.text.strip()
            if not text:
                continue
            style = para.style.name if para.style is not None else ""
            if "Heading" in style or re.match(r"^\d+\.?\s+[A-Z]", text):
                headings.append(f"{style}: {text}")
            if any(k in text.lower() for k in ["data availability", "code availability", "funding", "competing", "acknowledg"]):
                end_statements.append(text)
        notes = [
            f"Previous manuscript style guide status: read successfully.",
            f"Path: {path}",
            "Observed heading/section style examples:",
            *[f"- {h}" for h in headings[:20]],
            "Observed end statements:",
            *[f"- {e}" for e in end_statements[:10]],
            "Formatting decision: use title at top, abstract, keywords, numbered sections, numbered subsections, references at end, and end statements near the end.",
        ]
        return "\n".join(notes), True
    except Exception as exc:
        return f"Previous manuscript style guide found at {path}, but python-docx could not read it: {exc}\nFallback Step 13/14 style used.", False


def load_table(path: Path, max_rows: int = 8, max_cols: int = 6) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    df = pd.read_csv(path).fillna("")
    keep = list(df.columns[:max_cols])
    return df[keep].head(max_rows)


def add_docx_table(doc: Any, title: str, path: Path) -> None:
    doc.add_paragraph(title).bold = True
    df = load_table(path)
    if df.empty:
        doc.add_paragraph(f"Table source unavailable: {path}")
        return
    table = doc.add_table(rows=1, cols=len(df.columns))
    table.style = "Table Grid"
    for i, col in enumerate(df.columns):
        table.rows[0].cells[i].text = str(col)
    for _, row in df.iterrows():
        cells = table.add_row().cells
        for i, col in enumerate(df.columns):
            cells[i].text = str(row[col])[:90]
    doc.add_paragraph("Full table available in supplementary CSV.")


def add_docx_image_or_placeholder(doc: Any, caption: str, path: Path, image_log: list[str]) -> None:
    try:
        if path.exists():
            doc.add_picture(str(path), width=None)
            image_log.append(f"inserted: {path.name}")
        else:
            doc.add_paragraph(f"[Insert {caption} here: {path}]")
            image_log.append(f"missing placeholder: {path.name}")
    except Exception as exc:
        doc.add_paragraph(f"[Insert {caption} here: {path}]")
        image_log.append(f"placeholder due to insert failure for {path.name}: {exc}")
    doc.add_paragraph(caption)


def write_docx(final_md: str, output_path: Path) -> tuple[bool, list[str], list[str]]:
    table_log: list[str] = []
    image_log: list[str] = []
    try:
        from docx import Document  # type: ignore
        from docx.enum.section import WD_SECTION  # type: ignore
        from docx.enum.text import WD_ALIGN_PARAGRAPH  # type: ignore
        from docx.shared import Inches, Pt  # type: ignore
    except Exception:
        return False, table_log, image_log

    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.27)
    section.page_height = Inches(11.69)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    style = doc.styles["Normal"]
    style.font.name = "Times New Roman"
    style.font.size = Pt(11)
    style.paragraph_format.line_spacing = 1.15

    for line in final_md.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("# "):
            para = doc.add_paragraph()
            run = para.add_run(stripped[2:])
            run.bold = True
            run.font.size = Pt(15)
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif stripped.startswith("## "):
            doc.add_heading(stripped[3:], level=1)
        elif stripped.startswith("### "):
            doc.add_heading(stripped[4:], level=2)
        elif stripped.startswith("|"):
            continue
        elif stripped.startswith("![Figure"):
            continue
        elif stripped.startswith("[Insert Table") or stripped.startswith("_Source CSV"):
            continue
        elif stripped.startswith("[Insert Figure"):
            doc.add_paragraph(stripped)
        elif stripped.startswith("- "):
            doc.add_paragraph(stripped[2:], style="List Bullet")
        else:
            para = doc.add_paragraph(stripped)
            para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    doc.add_page_break()
    doc.add_heading("Selected Tables", level=1)
    for title, path in DOCX_TABLES:
        add_docx_table(doc, title, path)
        table_log.append(f"inserted compact: {path.name}")

    doc.add_page_break()
    doc.add_heading("Selected Figures", level=1)
    for caption, path in FIGURES:
        add_docx_image_or_placeholder(doc, caption, path, image_log)

    doc.save(output_path)
    return True, table_log, image_log


def write_references_file() -> tuple[Path, int]:
    refs = read_text(SOURCE_REFS)
    doi_count = refs.count("DOI_CHECK_REQUIRED")
    out = OUT_MANUSCRIPT / "15_final_references_ieee_style.txt"
    out.write_text("References with DOI_CHECK_REQUIRED must be verified before final submission.\n\n" + refs, encoding="utf-8")
    return out, doi_count


def checklist_text() -> str:
    return """# Final Author Submission Checklist

- [ ] Add author names.
- [ ] Add affiliations.
- [ ] Add corresponding author email.
- [ ] Verify all DOI_CHECK_REQUIRED references.
- [ ] Confirm conference/journal template.
- [ ] Check page limit.
- [ ] Check word limit.
- [ ] Check figure resolution.
- [ ] Check table readability.
- [ ] Confirm data availability statement.
- [ ] Confirm code availability statement.
- [ ] Confirm funding statement.
- [ ] Confirm conflict/competing interests statement.
- [ ] Confirm acknowledgment.
- [ ] Final grammar proofread.
- [ ] Export final PDF.
- [ ] Submit through conference system.
"""


def manual_edits_text(doi_keys: list[str]) -> str:
    return f"""# Final Manual Edits Needed

1. DOI_CHECK_REQUIRED references:
{chr(10).join('- ' + key for key in doi_keys) if doi_keys else '- none'}

2. Add author and affiliation placeholders:
- Author 1, Department, Institution, Email
- Author 2, Department, Institution, Email

3. Verify whether the target venue accepts arXiv/preprint references and very recent 2025/2026 references.

4. Manually check page count after applying the official template.

5. Check that all figures are readable after Word/PDF export.

6. Confirm that the synthetic scenario caveat appears in the abstract, scheduling section, discussion, and limitations.

7. Decide whether to include all eight figures or reduce the figure count for page limits.
"""


def claim_safety_audit(text: str) -> tuple[str, str]:
    checks = [
        ("real six-site session validation", "Do not claim real six-site validation; say synthetic six-site scenario evidence."),
        ("statistically significant peak superiority", "Qualify peak results cautiously unless tied to supported comparisons."),
        ("globally optimal scheduling", "Use greedy constrained scheduling, not globally optimal scheduling."),
        ("synthetic sessions are real", "State synthetic sessions are scenario data only."),
        ("weather/traffic/price", "Do not imply weather, traffic, or price features were used."),
        ("transfer MAE 9.256", "Remove old transfer-learning result."),
        ("MAE 12.41", "Remove old result."),
        ("cross-site transfer learning", "Do not present old transfer learning as main contribution."),
    ]
    findings = []
    lower = text.lower()
    for phrase, replacement in checks:
        idx = lower.find(phrase.lower())
        if idx >= 0:
            sentence = sentence_at(text, idx)
            findings.append({"phrase": phrase, "sentence": sentence, "suggested_replacement": replacement})
    if findings:
        status = "issues_found"
        lines = ["# Final Claim Safety Audit", "", "Potential unsafe claims found:"]
        for f in findings:
            lines.extend(["", f"- Phrase: `{f['phrase']}`", f"  Sentence: {f['sentence']}", f"  Suggested replacement: {f['suggested_replacement']}"])
    else:
        status = "passed"
        lines = ["# Final Claim Safety Audit", "", "Passed. No forbidden claims were detected in the final formatted manuscript."]
    audit = "\n".join(lines) + "\n"
    (OUT_RESULTS / "15_final_claim_safety_audit.md").write_text(audit, encoding="utf-8")
    return audit, status


def sentence_at(text: str, idx: int) -> str:
    start = max(text.rfind(".", 0, idx), text.rfind("\n", 0, idx)) + 1
    end = text.find(".", idx)
    if end < 0:
        end = min(len(text), idx + 240)
    return re.sub(r"\s+", " ", text[start : end + 1]).strip()


def doi_keys_from_audit() -> list[str]:
    audit = read_text(SOURCE_AUDIT)
    match = re.search(r"DOI_CHECK_REQUIRED keys:\s*(.+)", audit)
    if not match:
        return []
    return [x.strip() for x in match.group(1).split(",") if x.strip()]


def main() -> None:
    ensure_dirs()
    style_notes, style_read = inspect_previous_style()
    (OUT_RESULTS / "15_previous_manuscript_style_notes.txt").write_text(style_notes, encoding="utf-8")

    source = read_text(SOURCE_MD)
    refs = read_text(SOURCE_REFS)
    final_md = build_final_markdown(source, refs)
    md_path = OUT_MANUSCRIPT / "15_final_manuscript_submission_style.md"
    md_path.write_text(final_md, encoding="utf-8")

    docx_path = OUT_MANUSCRIPT / "15_final_manuscript_submission_style.docx"
    docx_created, table_log, image_log = write_docx(final_md, docx_path)

    refs_path, doi_count = write_references_file()
    doi_keys = doi_keys_from_audit()
    checklist_path = OUT_MANUSCRIPT / "15_final_author_submission_checklist.md"
    manual_path = OUT_MANUSCRIPT / "15_final_manual_edits_needed.md"
    checklist_path.write_text(checklist_text(), encoding="utf-8")
    manual_path.write_text(manual_edits_text(doi_keys), encoding="utf-8")
    audit_text, safety_status = claim_safety_audit(final_md)
    audit_path = OUT_RESULTS / "15_final_claim_safety_audit.md"

    warnings_list = []
    if not style_read:
        warnings_list.append("Previous Manuscript.docx style guide was not read; fallback Step 13/14 academic style used.")
    if "[REF]" in final_md:
        warnings_list.append("[REF] placeholder remains.")
    if doi_count:
        warnings_list.append(f"{doi_count} DOI_CHECK_REQUIRED entries remain.")
    if not docx_created:
        warnings_list.append("DOCX was not created because python-docx is unavailable.")

    report = f"""Step 15 formatting report
=========================
Previous manuscript style read status: {'read successfully' if style_read else 'not read; fallback style used'}
Source manuscript path: {SOURCE_MD}
Final markdown path: {md_path}
Final DOCX path: {docx_path if docx_created else 'not created'}

Tables inserted:
{chr(10).join('- ' + item for item in table_log) if table_log else '- none'}

Figures inserted or placeholdered:
{chr(10).join('- ' + item for item in image_log) if image_log else '- none'}

References appended: yes
DOI_CHECK_REQUIRED count: {doi_count}
Claim safety audit result: {safety_status}

Warnings:
{chr(10).join('- ' + w for w in warnings_list) if warnings_list else '- none'}

Final next step:
Apply the official venue template, verify DOI_CHECK_REQUIRED references, add author/funding/conflict statements, inspect page count, and export final PDF.
"""
    report_path = OUT_RESULTS / "15_formatting_report.txt"
    report_path.write_text(report, encoding="utf-8")
    (OUT_RESULTS / "15_run_summary.json").write_text(
        json.dumps(
            {
                "final_docx": str(docx_path) if docx_created else "",
                "final_markdown": str(md_path),
                "references": str(refs_path),
                "author_checklist": str(checklist_path),
                "manual_edits": str(manual_path),
                "claim_safety_audit": str(audit_path),
                "formatting_report": str(report_path),
                "doi_check_required_count": doi_count,
                "claim_safety_status": safety_status,
                "warnings": warnings_list,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print("Step 15 final submission-style formatting complete")
    print(f"Final DOCX path: {docx_path if docx_created else 'not created; python-docx unavailable'}")
    print(f"Final Markdown path: {md_path}")
    print(f"References path: {refs_path}")
    print(f"Author checklist path: {checklist_path}")
    print(f"Manual edits path: {manual_path}")
    print(f"Claim safety audit path: {audit_path}")
    print(f"Formatting report path: {report_path}")
    print(f"DOI_CHECK_REQUIRED count: {doi_count}")
    print(f"Claim safety status: {safety_status}")
    print("Final warning: This is formatted from the previous manuscript style, not an official venue template. If the venue requires a template, apply it before submission.")


if __name__ == "__main__":
    main()
