"""
Step 01B: move likely raw data files from data/ into data/raw/, then rerun
the Step 01 data audit.

Run from the project root:
    python src/01B_fix_data_location_and_rerun_audit.py

This script does not delete files and does not modify data content.
"""

from __future__ import annotations

import csv
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RAW_DIR = DATA_DIR / "raw"
INTERIM_DIR = DATA_DIR / "interim"
PROCESSED_DIR = DATA_DIR / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "01_data_audit"
AUDIT_SCRIPT = PROJECT_ROOT / "src" / "01_data_audit.py"

DATA_EXTENSIONS = {
    ".csv",
    ".xlsx",
    ".xls",
    ".json",
    ".zip",
    ".parquet",
    ".pkl",
    ".txt",
}


def ensure_directories() -> None:
    """Create required project folders if they are missing."""
    for directory in [RAW_DIR, INTERIM_DIR, PROCESSED_DIR, RESULTS_DIR]:
        directory.mkdir(parents=True, exist_ok=True)


def safe_duplicate_destination(destination: Path) -> Path:
    """Return a non-overwriting duplicate destination path in data/raw/."""
    renamed = destination.with_name(f"{destination.stem}_duplicate_from_data_root{destination.suffix}")
    if not renamed.exists():
        return renamed

    counter = 2
    while True:
        candidate = destination.with_name(
            f"{destination.stem}_duplicate_from_data_root_{counter}{destination.suffix}"
        )
        if not candidate.exists():
            return candidate
        counter += 1


def move_data_root_files() -> tuple[list[str], list[str], list[str]]:
    """Move likely raw data files directly under data/ into data/raw/."""
    moved: list[str] = []
    skipped: list[str] = []
    duplicates: list[str] = []

    for path in sorted(DATA_DIR.iterdir()):
        if path.is_dir():
            skipped.append(f"SKIPPED directory: {path.name}")
            continue

        if path.suffix.lower() not in DATA_EXTENSIONS:
            skipped.append(f"SKIPPED non-data extension: {path.name}")
            continue

        destination = RAW_DIR / path.name
        if destination.exists():
            source_size = path.stat().st_size
            destination_size = destination.stat().st_size
            if source_size == destination_size:
                message = (
                    f"DUPLICATE same size left in data/: {path.name} "
                    f"({source_size} bytes)"
                )
                duplicates.append(message)
                skipped.append(message)
                continue

            renamed_destination = safe_duplicate_destination(destination)
            shutil.move(str(path), str(renamed_destination))
            message = (
                f"DUPLICATE different size moved with safe name: "
                f"{path.name} -> {renamed_destination.name}"
            )
            moved.append(message)
            duplicates.append(message)
            continue

        shutil.move(str(path), str(destination))
        moved.append(f"MOVED: {path.name} -> raw/{destination.name}")

    return moved, skipped, duplicates


def write_location_fix_report(moved: list[str], skipped: list[str], duplicates: list[str]) -> Path:
    """Save a plain-text report for the data-location correction."""
    report_path = RESULTS_DIR / "01B_data_location_fix_report.txt"
    raw_files = sorted(path.name for path in RAW_DIR.iterdir() if path.is_file())

    lines = [
        "Step 01B data location fix report",
        "=" * 35,
        f"Timestamp: {datetime.now().isoformat(timespec='seconds')}",
        f"Project root: {PROJECT_ROOT}",
        f"Data directory scanned directly: {DATA_DIR}",
        f"Raw directory destination: {RAW_DIR}",
        "",
        "Files moved:",
        *(f"- {item}" for item in moved),
        *(["- None"] if not moved else []),
        "",
        "Files skipped:",
        *(f"- {item}" for item in skipped),
        *(["- None"] if not skipped else []),
        "",
        "Duplicates detected:",
        *(f"- {item}" for item in duplicates),
        *(["- None"] if not duplicates else []),
        "",
        f"Final number of files in data/raw/: {len(raw_files)}",
        "",
        "Final files in data/raw/:",
        *(f"- {name}" for name in raw_files),
        "",
    ]
    report_path.write_text("\n".join(lines), encoding="utf-8")
    return report_path


def summarize_csv(path: Path, max_rows: int = 5) -> str:
    """Create a compact human-readable CSV summary without pandas."""
    if not path.exists():
        return f"{path.name}: missing"

    try:
        with path.open("r", encoding="utf-8-sig", newline="") as file:
            reader = csv.reader(file)
            rows = list(reader)
    except UnicodeDecodeError:
        with path.open("r", encoding="latin-1", newline="") as file:
            reader = csv.reader(file)
            rows = list(reader)

    if not rows:
        return f"{path.name}: empty CSV"

    header = rows[0]
    body = rows[1:]
    preview = body[:max_rows]
    lines = [
        f"{path.name}",
        f"- Rows: {len(body)}",
        f"- Columns: {len(header)}",
        f"- Column names: {', '.join(header)}",
        "- First rows:",
    ]
    if preview:
        lines.append("  " + " | ".join(header))
        for row in preview:
            padded = row + [""] * max(0, len(header) - len(row))
            lines.append("  " + " | ".join(padded[: len(header)]))
    else:
        lines.append("  No data rows")
    return "\n".join(lines)


def create_full_audit_report(location_report_path: Path, audit_return_code: int) -> Path:
    """Combine Step 01B and Step 01 outputs into one readable report."""
    full_report_path = RESULTS_DIR / "01_full_audit_report.txt"
    audit_notes_path = RESULTS_DIR / "01_audit_notes.txt"
    generated_files = sorted(path.name for path in RESULTS_DIR.iterdir() if path.is_file())

    sections = [
        "Step 01 full audit report",
        "=" * 25,
        f"Timestamp: {datetime.now().isoformat(timespec='seconds')}",
        f"Audit script return code: {audit_return_code}",
        "",
        "01B data location fix report",
        "-" * 31,
        location_report_path.read_text(encoding="utf-8") if location_report_path.exists() else "Missing.",
        "",
        "01 audit notes",
        "-" * 14,
        audit_notes_path.read_text(encoding="utf-8") if audit_notes_path.exists() else "Missing.",
        "",
        "Summary of 01_file_inventory.csv",
        "-" * 32,
        summarize_csv(RESULTS_DIR / "01_file_inventory.csv"),
        "",
        "Summary of 01_hourly_files_summary.csv",
        "-" * 38,
        summarize_csv(RESULTS_DIR / "01_hourly_files_summary.csv"),
        "",
        "Summary of 01_clean_sessions_summary.csv",
        "-" * 41,
        summarize_csv(RESULTS_DIR / "01_clean_sessions_summary.csv"),
        "",
        "All generated Step 01 result files",
        "-" * 34,
        *(f"- {name}" for name in generated_files),
        "",
    ]
    full_report_path.write_text("\n".join(sections), encoding="utf-8")
    return full_report_path


def print_section(title: str, items: list[str]) -> None:
    print(title)
    if items:
        for item in items:
            print(f"- {item}")
    else:
        print("- None")
    print("")


def main() -> None:
    ensure_directories()

    moved, skipped, duplicates = move_data_root_files()
    location_report_path = write_location_fix_report(moved, skipped, duplicates)

    print("Step 01B data location fix")
    print("==========================")
    print_section("Files moved:", moved)
    print_section("Files skipped:", skipped)
    print_section("Duplicates detected:", duplicates)
    print(f"Final number of files in data/raw/: {len([p for p in RAW_DIR.iterdir() if p.is_file()])}")
    print(f"Saved location fix report to: {location_report_path}")
    print("")

    print("Rerunning Step 01 audit...")
    completed = subprocess.run([sys.executable, str(AUDIT_SCRIPT)], check=False)
    print(f"Step 01 audit return code: {completed.returncode}")
    print("")

    full_report_path = create_full_audit_report(location_report_path, completed.returncode)
    print(f"Created full audit report: {full_report_path}")


if __name__ == "__main__":
    main()
