from __future__ import annotations

import shutil
from copy import deepcopy
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches


ROOT = Path(__file__).resolve().parents[1]
MAN_DIR = ROOT / "manuscript" / "16_reviewer_aware_final"
INPUT_DOCX = MAN_DIR / "16_final_reviewer_ready_manuscript_SECTION6_UPDATED.docx"
OUTPUT_DOCX = MAN_DIR / "16_final_reviewer_ready_manuscript_FIGURES_AND_SECTION4_FIXED.docx"
REPORT_PATH = MAN_DIR / "figure_and_section4_fix_report.txt"
INSERTED_DIR = MAN_DIR / "inserted_figures"

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".svg"}

FIGURE_SOURCES = {
    3: ROOT / "figures" / "16_reviewer_aware_final" / "16_fig3_forecasting_comparison.png",
    4: ROOT / "figures" / "16_reviewer_aware_final" / "16_fig4_statistical_validation.png",
    5: ROOT / "figures" / "16_reviewer_aware_final" / "16_fig5_prediction_intervals.png",
    6: ROOT / "figures" / "16_reviewer_aware_final" / "16_fig6_real_session_scheduling.png",
    7: ROOT / "figures" / "16_reviewer_aware_final" / "16_fig7_synthetic_multisite_scheduling.png",
    8: ROOT / "figures" / "16_reviewer_aware_final" / "16_fig8_site_level_scheduling.png",
}


def find_candidate_images() -> list[Path]:
    return sorted(
        path
        for path in ROOT.rglob("*")
        if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS
    )


def paragraph_has_image(paragraph) -> bool:
    return bool(paragraph._p.xpath(".//*[local-name()='drawing' or local-name()='pict']"))


def caption_paragraph_index(doc: Document, figure_number: int) -> int:
    prefix = f"Figure {figure_number}."
    for idx, paragraph in enumerate(doc.paragraphs):
        if paragraph.text.strip().startswith(prefix):
            return idx
    raise ValueError(f"Could not find caption for {prefix}")


def image_immediately_above_caption(doc: Document, figure_number: int) -> bool:
    idx = caption_paragraph_index(doc, figure_number)
    if idx <= 0:
        return False
    return paragraph_has_image(doc.paragraphs[idx - 1])


def insert_picture_before_paragraph(doc: Document, paragraph, image_path: Path) -> None:
    picture_paragraph = doc.add_paragraph()
    picture_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    picture_paragraph.add_run().add_picture(str(image_path), width=Inches(6.0))
    element = picture_paragraph._p
    element.getparent().remove(element)
    paragraph._p.addprevious(element)


def copy_figure_source(figure_number: int, source_path: Path) -> Path:
    INSERTED_DIR.mkdir(parents=True, exist_ok=True)
    target = INSERTED_DIR / f"figure_{figure_number}_{source_path.name}"
    shutil.copy2(source_path, target)
    return target


def remove_image_paragraph_immediately_above(doc: Document, caption_idx: int) -> None:
    if caption_idx > 0 and paragraph_has_image(doc.paragraphs[caption_idx - 1]):
        element = doc.paragraphs[caption_idx - 1]._p
        element.getparent().remove(element)


def find_paragraph(doc: Document, text: str) -> int:
    for idx, paragraph in enumerate(doc.paragraphs):
        if paragraph.text.strip() == text:
            return idx
    raise ValueError(f"Could not find paragraph: {text}")


def set_paragraph_text(paragraph, text: str) -> None:
    for run in list(paragraph.runs):
        run._element.getparent().remove(run._element)
    paragraph.add_run(text)


def set_centered_equation(paragraph, text: str) -> None:
    set_paragraph_text(paragraph, text)
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER


def delete_paragraph(paragraph) -> None:
    paragraph._element.getparent().remove(paragraph._element)


def fix_section4(doc: Document) -> None:
    replacements = {
        "4.2 Proposed Forecasting Framework": "4.2 Standard Forecasting Benchmarks",
        "4.3 Prediction Intervals and Uncertainty-Aware Forecasting": "4.3 Enhanced Adaptive Hybrid Peak-Aware Ensemble",
        "4.4 Constrained Scheduling Formulation": "4.4 PRC-E-AHPA Peak-Risk Calibration",
        "4.5 Prediction Intervals": "4.5 Prediction Intervals",
        "4.6 Forecast-Informed Constrained Scheduling": "4.6 Forecast-Informed Constrained Scheduling",
        "4.7 Real and Synthetic Scheduling Scenarios": "4.7 Real and Synthetic Scheduling Scenarios",
    }
    for old, new in replacements.items():
        idx = find_paragraph(doc, old)
        set_paragraph_text(doc.paragraphs[idx], new)
        doc.paragraphs[idx].style = "Heading 2"

    equation_replacements = {
        "[\nx_{s,t}=[c_t,z_t,\\ell_{s,t},r_{s,t},e_{s,t},m_{s,t},q_s],\n]":
            "x_{s,t} = [c_t, z_t, ell_{s,t}, r_{s,t}, e_{s,t}, m_{s,t}, q_s]",
        "[\n\\hat{y}^{(m)}{s,t}=f_m(x{s,t}).\n]":
            "y_hat^{(m)}_{s,t} = f_m(x_{s,t})",
        "(1-\\alpha_{s,t})\\hat{y}^{base}{s,t}\n+\n\\alpha{s,t}\\hat{y}^{peak}_{s,t},\n]":
            "y_hat^{EAHPA}_{s,t} = (1 - alpha_{s,t}) y_hat^{base}_{s,t} + alpha_{s,t} y_hat^{peak}_{s,t}",
        "[\n\\epsilon^{val}{s,t}=y^{val}{s,t}-\\hat{y}^{EAHPA}_{s,t}.\n]":
            "epsilon^{val}_{s,t} = y^{val}_{s,t} - y_hat^{EAHPA}_{s,t}",
        "\\hat{y}^{EAHPA}{s,t}\n+\n\\Delta{risk}(x_{s,t}),\n]":
            "y_hat^{PRC}_{s,t} = y_hat^{EAHPA}_{s,t} + Delta_{risk}(x_{s,t})",
        "[\nL_{s,t}=\\hat{y}_{s,t}-q^-,\n]":
            "L_{s,t} = y_hat_{s,t} - q^-",
        "[\nU_{s,t}=\\hat{y}_{s,t}+q^+,\n]":
            "U_{s,t} = y_hat_{s,t} + q^+",
        "[\np_{i,t}=0 \\quad \\text{if } t<a_i \\text{ or } t>d_i,\n]":
            "p_{i,t} = 0 if t < a_i or t > d_i",
        "[\n0 \\leq p_{i,t} \\leq P_i^{max},\n]":
            "0 <= p_{i,t} <= P_i^{max}",
        "[\n\\sum_{t=a_i}^{d_i}p_{i,t}\\Delta t \\leq E_i.\n]":
            "sum_{t=a_i}^{d_i} p_{i,t} Delta t <= E_i",
        "[\nb_t+\\sum_i p_{i,t} \\leq C_t+v_t,\\quad v_t\\geq0.\n]":
            "b_t + sum_i p_{i,t} <= C_t + v_t, v_t >= 0",
    }
    for paragraph in doc.paragraphs:
        text = paragraph.text.strip()
        if text in equation_replacements:
            set_centered_equation(paragraph, equation_replacements[text])

    # Remove empty spacer paragraphs left from the original broken equation blocks inside Section 4 only.
    start = find_paragraph(doc, "4. Methodology")
    end = find_paragraph(doc, "5. Experimental Setup")
    for paragraph in list(doc.paragraphs[start:end]):
        if paragraph.text.strip() == "":
            delete_paragraph(paragraph)


def section4_equations_are_clean(doc: Document) -> bool:
    start = find_paragraph(doc, "4. Methodology")
    end = find_paragraph(doc, "5. Experimental Setup")
    section4_text = "\n".join(paragraph.text for paragraph in doc.paragraphs[start:end])
    broken_patterns = [
        "[\n",
        "\n]",
        "24h [, ]; 168h [, ]",
        "\\hat{y}^{(m)}{s,t}",
        "\\Delta{risk}",
        "\\sum_",
    ]
    expected_headings = [
        "4.1 Leakage-Free Feature Engineering",
        "4.2 Standard Forecasting Benchmarks",
        "4.3 Enhanced Adaptive Hybrid Peak-Aware Ensemble",
        "4.4 PRC-E-AHPA Peak-Risk Calibration",
        "4.5 Prediction Intervals",
        "4.6 Forecast-Informed Constrained Scheduling",
        "4.7 Real and Synthetic Scheduling Scenarios",
    ]
    headings_ok = all(any(p.text.strip() == heading and p.style.name.startswith("Heading") for p in doc.paragraphs) for heading in expected_headings)
    return headings_ok and not any(pattern in section4_text for pattern in broken_patterns)


def main() -> None:
    if not INPUT_DOCX.exists():
        raise FileNotFoundError(INPUT_DOCX)

    candidates = find_candidate_images()
    doc = Document(INPUT_DOCX)
    image_count_before = len(doc.inline_shapes)
    before_status = {
        figure: image_immediately_above_caption(doc, figure)
        for figure in range(3, 9)
    }

    inserted = {}
    generated = {figure: False for figure in range(3, 9)}
    for figure in range(3, 9):
        source = FIGURE_SOURCES[figure]
        if not source.exists():
            alternate = ROOT / "figures" / "12_final_paper_results_pack" / f"12_fig{figure}_{source.name.split('_', 2)[-1]}"
            if alternate.exists():
                source = alternate
            else:
                raise FileNotFoundError(f"No matching image found for Figure {figure}: {source}")
        inserted_path = copy_figure_source(figure, source)
        caption_idx = caption_paragraph_index(doc, figure)
        remove_image_paragraph_immediately_above(doc, caption_idx)
        caption_idx = caption_paragraph_index(doc, figure)
        insert_picture_before_paragraph(doc, doc.paragraphs[caption_idx], inserted_path)
        inserted[figure] = inserted_path

    fix_section4(doc)
    doc.save(OUTPUT_DOCX)

    fixed = Document(OUTPUT_DOCX)
    image_count_after = len(fixed.inline_shapes)
    after_status = {
        figure: image_immediately_above_caption(fixed, figure)
        for figure in range(3, 9)
    }
    all_figures_fixed = all(after_status.values())
    equations_clean = section4_equations_are_clean(fixed)

    report_lines = [
        "Figure and Section 4 fix report",
        "===============================",
        f"Input DOCX: {INPUT_DOCX}",
        f"Output DOCX: {OUTPUT_DOCX}",
        "",
        f"Total inline images before: {image_count_before}",
        f"Total inline images after: {image_count_after}",
        "",
        "Figure 3-8 image status before:",
    ]
    for figure, ok in before_status.items():
        report_lines.append(f"- Figure {figure}: {'image immediately above caption' if ok else 'caption-only or not immediately preceded by image'}")

    report_lines.append("")
    report_lines.append("Exact file inserted for each Figure 3-8:")
    for figure in range(3, 9):
        report_lines.append(f"- Figure {figure}: {inserted[figure]} | generated from CSV: {'yes' if generated[figure] else 'no'}")

    report_lines.extend(
        [
            "",
            f"Confirmation that no Figure 3-8 caption is left without an image: {'yes' if all_figures_fixed else 'no'}",
            f"Confirmation Section 4 equations are no longer broken: {'yes' if equations_clean else 'no'}",
            "",
            "Candidate image files found recursively:",
        ]
    )
    for path in candidates:
        report_lines.append(f"- {path}")

    REPORT_PATH.write_text("\n".join(report_lines) + "\n", encoding="utf-8")
    print("\n".join(report_lines[:30]))
    print(f"... candidate image file count: {len(candidates)}")
    print(f"Report written: {REPORT_PATH}")


if __name__ == "__main__":
    main()
