"""
Step 02: clean and validate session-level EV charging data.

Run from the project root:
    python src/02_clean_sessions.py

This script reads data/raw/clean_sessions.csv and writes new processed outputs.
It never modifies the raw input file.
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any
import re
import sys
import types

import numpy as np


# Environment guard for this workstation: the Python standard-library
# _strptime.py has been overwritten by old project code. Pandas needs a small
# import-time API from _strptime, so provide it locally without editing Python.
if "_strptime" not in sys.modules:
    _strptime_stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    _strptime_stub.LocaleTime = LocaleTime
    _strptime_stub.TimeRE = TimeRE
    _strptime_stub._TimeRE_cache = TimeRE()
    _strptime_stub._regex_cache = {}
    _strptime_stub._getlang = _getlang
    _strptime_stub._strptime = _strptime
    _strptime_stub._strptime_time = _strptime
    _strptime_stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = _strptime_stub

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RAW_FILE = PROJECT_ROOT / "data" / "raw" / "clean_sessions.csv"
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "02_clean_sessions"

FULL_CLEANED_FILE = PROCESSED_DIR / "02_clean_sessions.csv"
SCHEDULING_READY_FILE = PROCESSED_DIR / "02_scheduling_ready_sessions.csv"
REMOVED_RECORDS_FILE = RESULTS_DIR / "02_removed_records.csv"
CLEANING_SUMMARY_FILE = RESULTS_DIR / "02_cleaning_summary.csv"
MISSING_SUMMARY_FILE = RESULTS_DIR / "02_missing_before_after.csv"
SCHEDULING_COLUMNS_FILE = RESULTS_DIR / "02_scheduling_columns_summary.csv"
REPORT_FILE = RESULTS_DIR / "02_clean_sessions_report.txt"

DATETIME_COLUMNS = ["arrival_time", "departure_time", "done_time", "requestedDeparture"]
SCHEDULING_COLUMNS = [
    "arrival_time",
    "departure_time",
    "done_time",
    "energy_kwh",
    "kWhRequested",
    "minutesAvailable",
    "requestedDeparture",
    "stationID",
    "spaceID",
    "siteID",
    "timezone",
]
MAX_SESSION_HOURS = 24 * 7
MAX_AVERAGE_POWER_KW = 50


def parse_datetime(series: pd.Series) -> pd.Series:
    """Parse datetimes safely; invalid values become NaT."""
    try:
        return pd.to_datetime(series, errors="coerce", format="mixed")
    except TypeError:
        return pd.to_datetime(series, errors="coerce")


def example_values(series: pd.Series, limit: int = 5) -> str:
    values = series.dropna().astype(str).head(limit).tolist()
    return " | ".join(values)


def min_max_values(series: pd.Series) -> tuple[Any, Any]:
    non_missing = series.dropna()
    if non_missing.empty:
        return "", ""
    return non_missing.min(), non_missing.max()


def add_reason(reasons: pd.Series, condition: pd.Series, reason: str) -> pd.Series:
    """Append a removal reason to rows where condition is true."""
    updated = reasons.copy()
    condition = condition.fillna(False)
    updated.loc[condition] = updated.loc[condition].apply(
        lambda existing: reason if existing == "" else f"{existing}; {reason}"
    )
    return updated


def build_missing_summary(before: pd.DataFrame, after: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    all_columns = list(dict.fromkeys([*before.columns.tolist(), *after.columns.tolist()]))
    for column in all_columns:
        before_missing = int(before[column].isna().sum()) if column in before.columns else np.nan
        after_missing = int(after[column].isna().sum()) if column in after.columns else np.nan
        rows.append(
            {
                "column_name": column,
                "missing_before": before_missing,
                "missing_before_pct": round(before_missing / len(before) * 100, 4)
                if column in before.columns and len(before)
                else np.nan,
                "missing_after": after_missing,
                "missing_after_pct": round(after_missing / len(after) * 100, 4)
                if column in after.columns and len(after)
                else np.nan,
            }
        )
    return pd.DataFrame(rows)


def summarize_scheduling_columns(df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for column in SCHEDULING_COLUMNS:
        if column not in df.columns:
            rows.append(
                {
                    "column_name": column,
                    "exists": False,
                    "dtype": "",
                    "missing_count": np.nan,
                    "missing_percentage": np.nan,
                    "unique_count": np.nan,
                    "min_value": "",
                    "max_value": "",
                    "example_values": "",
                }
            )
            continue

        series = df[column]
        min_value, max_value = "", ""
        if pd.api.types.is_numeric_dtype(series) or pd.api.types.is_datetime64_any_dtype(series):
            min_value, max_value = min_max_values(series)

        missing = int(series.isna().sum())
        rows.append(
            {
                "column_name": column,
                "exists": True,
                "dtype": str(series.dtype),
                "missing_count": missing,
                "missing_percentage": round(missing / len(df) * 100, 4) if len(df) else 0.0,
                "unique_count": int(series.nunique(dropna=True)),
                "min_value": min_value,
                "max_value": max_value,
                "example_values": example_values(series),
            }
        )
    return pd.DataFrame(rows)


def count_removal_reasons(removed: pd.DataFrame) -> Counter[str]:
    counter: Counter[str] = Counter()
    if "removal_reason" not in removed.columns:
        return counter
    for value in removed["removal_reason"].dropna():
        for reason in str(value).split("; "):
            if reason:
                counter[reason] += 1
    return counter


def write_report(
    original_shape: tuple[int, int],
    cleaned: pd.DataFrame,
    scheduling_ready: pd.DataFrame,
    removed: pd.DataFrame,
    reason_counts: Counter[str],
) -> None:
    zero_count = int(cleaned["is_zero_energy"].sum()) if "is_zero_energy" in cleaned.columns else 0
    issue_lines = []
    if len(removed):
        issue_lines.extend(f"- {reason}: {count}" for reason, count in reason_counts.items())
    else:
        issue_lines.append("- No records removed by conservative validity rules.")
    if zero_count:
        issue_lines.append(f"- Zero-energy sessions retained in cleaned data: {zero_count}")
    if "done_after_departure" in cleaned.columns and cleaned["done_after_departure"].any():
        issue_lines.append(f"- done_time after departure_time flags: {int(cleaned['done_after_departure'].sum())}")
    if (
        "requested_departure_after_departure" in cleaned.columns
        and cleaned["requested_departure_after_departure"].any()
    ):
        issue_lines.append(
            "- requestedDeparture after departure_time flags: "
            f"{int(cleaned['requested_departure_after_departure'].sum())}"
        )

    suitable = len(scheduling_ready) > 0 and {"arrival_time", "departure_time", "energy_kwh"}.issubset(cleaned.columns)
    suitability_text = (
        "The cleaned scheduling-ready subset is suitable for the next preparation step, "
        "with constraints later built from arrival/departure windows and positive energy demand."
        if suitable
        else "The data is not yet suitable for constrained scheduling because the scheduling-ready subset is empty."
    )

    lines = [
        "Step 02 clean sessions report",
        "=" * 29,
        f"Input file used: {RAW_FILE}",
        "",
        "Cleaning rules applied:",
        "- Parsed arrival_time, departure_time, done_time, and requestedDeparture when present.",
        "- Removed rows with missing/invalid arrival_time or departure_time.",
        "- Removed rows where departure_time <= arrival_time.",
        "- Removed rows with missing energy_kwh or energy_kwh < 0.",
        f"- Removed rows with session_duration_hours <= 0 or > {MAX_SESSION_HOURS} hours.",
        f"- Removed rows with average_power_kw > {MAX_AVERAGE_POWER_KW} kW.",
        "- Retained zero-energy sessions in the full cleaned file and flagged them.",
        "- Wrote a separate scheduling-ready file with energy_kwh > 0.",
        "",
        f"Original records/columns: {original_shape[0]} rows, {original_shape[1]} columns",
        f"Cleaned records: {len(cleaned)}",
        f"Removed records: {len(removed)}",
        f"Scheduling-ready records: {len(scheduling_ready)}",
        "",
        "Main data quality issues found:",
        *issue_lines,
        "",
        "Records removed by reason:",
        *(f"- {reason}: {count}" for reason, count in reason_counts.items()),
        *(["- None"] if not reason_counts else []),
        "",
        "Suitability for later constrained scheduling:",
        f"- {suitability_text}",
        "",
        "Recommended next step:",
        "- Create the next numbered script to standardize/load hourly demand inputs and align them with cleaned sessions. "
        "Do not train forecasting models or optimize schedules yet.",
        "",
    ]
    REPORT_FILE.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    if not RAW_FILE.exists():
        raise FileNotFoundError(f"Required input file not found: {RAW_FILE}")

    raw = pd.read_csv(RAW_FILE)
    original_shape = raw.shape
    print(f"Original shape: {original_shape}")

    df = raw.copy()
    original_columns = df.columns.tolist()
    df.columns = [str(column).strip() for column in df.columns]
    if df.columns.tolist() != original_columns:
        print("Column names were stripped of leading/trailing whitespace.")

    # Keep the original row identity for transparent removal reporting.
    df["original_row_index"] = df.index

    for column in DATETIME_COLUMNS:
        if column in df.columns:
            df[column] = parse_datetime(df[column])

    if {"arrival_time", "departure_time"}.issubset(df.columns):
        duration = (df["departure_time"] - df["arrival_time"]).dt.total_seconds() / 3600
        df["session_duration_hours"] = duration
        df["parking_duration_hours"] = duration
        df["minutes_available_from_times"] = duration * 60
    else:
        df["session_duration_hours"] = np.nan
        df["parking_duration_hours"] = np.nan
        df["minutes_available_from_times"] = np.nan

    if {"done_time", "arrival_time"}.issubset(df.columns):
        df["charging_completion_duration_hours"] = (
            df["done_time"] - df["arrival_time"]
        ).dt.total_seconds() / 3600
    else:
        df["charging_completion_duration_hours"] = np.nan

    if "energy_kwh" in df.columns:
        df["energy_kwh"] = pd.to_numeric(df["energy_kwh"], errors="coerce")
        df["average_power_kw"] = df["energy_kwh"] / df["session_duration_hours"]
    else:
        df["energy_kwh"] = np.nan
        df["average_power_kw"] = np.nan

    if "kWhRequested" in df.columns:
        df["requested_energy_kwh"] = pd.to_numeric(df["kWhRequested"], errors="coerce")
    else:
        df["requested_energy_kwh"] = np.nan

    df["is_zero_energy"] = df["energy_kwh"].eq(0)
    df["has_requested_energy"] = df["requested_energy_kwh"].notna()
    df["has_minutes_available"] = (
        pd.to_numeric(df["minutesAvailable"], errors="coerce").notna()
        if "minutesAvailable" in df.columns
        else False
    )
    df["done_after_departure"] = (
        df["done_time"].gt(df["departure_time"])
        if {"done_time", "departure_time"}.issubset(df.columns)
        else False
    )
    df["requested_departure_after_departure"] = (
        df["requestedDeparture"].gt(df["departure_time"])
        if {"requestedDeparture", "departure_time"}.issubset(df.columns)
        else False
    )

    reasons = pd.Series("", index=df.index, dtype="object")
    reasons = add_reason(reasons, df["arrival_time"].isna(), "missing_or_invalid_arrival_time")
    reasons = add_reason(reasons, df["departure_time"].isna(), "missing_or_invalid_departure_time")
    reasons = add_reason(reasons, df["departure_time"].le(df["arrival_time"]), "departure_not_after_arrival")
    reasons = add_reason(reasons, df["energy_kwh"].isna(), "missing_energy_kwh")
    reasons = add_reason(reasons, df["energy_kwh"].lt(0), "negative_energy_kwh")
    reasons = add_reason(reasons, df["session_duration_hours"].le(0), "non_positive_session_duration")
    reasons = add_reason(reasons, df["session_duration_hours"].gt(MAX_SESSION_HOURS), "session_duration_over_7_days")
    reasons = add_reason(reasons, df["average_power_kw"].gt(MAX_AVERAGE_POWER_KW), "average_power_over_50_kw")

    remove_mask = reasons.ne("")
    removed = df.loc[remove_mask].copy()
    removed["removal_reason"] = reasons.loc[remove_mask]

    cleaned = df.loc[~remove_mask].copy()
    scheduling_ready = cleaned.loc[cleaned["energy_kwh"].gt(0)].copy()

    removed_output_columns = ["original_row_index", *df.columns.drop("original_row_index").tolist(), "removal_reason"]
    removed[removed_output_columns].to_csv(REMOVED_RECORDS_FILE, index=False)
    cleaned.to_csv(FULL_CLEANED_FILE, index=False)
    scheduling_ready.to_csv(SCHEDULING_READY_FILE, index=False)

    missing_summary = build_missing_summary(raw, cleaned)
    missing_summary.to_csv(MISSING_SUMMARY_FILE, index=False)

    def safe_min(series_name: str) -> Any:
        return cleaned[series_name].min() if series_name in cleaned.columns and len(cleaned) else ""

    def safe_max(series_name: str) -> Any:
        return cleaned[series_name].max() if series_name in cleaned.columns and len(cleaned) else ""

    summary = pd.DataFrame(
        [
            {
                "original_row_count": len(raw),
                "cleaned_row_count": len(cleaned),
                "removed_row_count": len(removed),
                "removal_percentage": round(len(removed) / len(raw) * 100, 4) if len(raw) else 0.0,
                "zero_energy_sessions_retained": int(cleaned["is_zero_energy"].sum()),
                "scheduling_ready_sessions": len(scheduling_ready),
                "min_arrival_time": safe_min("arrival_time"),
                "max_arrival_time": safe_max("arrival_time"),
                "min_departure_time": safe_min("departure_time"),
                "max_departure_time": safe_max("departure_time"),
                "min_energy_kwh": safe_min("energy_kwh"),
                "max_energy_kwh": safe_max("energy_kwh"),
                "min_session_duration_hours": safe_min("session_duration_hours"),
                "max_session_duration_hours": safe_max("session_duration_hours"),
                "min_average_power_kw": safe_min("average_power_kw"),
                "max_average_power_kw": safe_max("average_power_kw"),
            }
        ]
    )
    summary.to_csv(CLEANING_SUMMARY_FILE, index=False)

    scheduling_summary = summarize_scheduling_columns(cleaned)
    scheduling_summary.to_csv(SCHEDULING_COLUMNS_FILE, index=False)

    reason_counts = count_removal_reasons(removed)
    write_report(original_shape, cleaned, scheduling_ready, removed, reason_counts)

    print(f"Cleaned shape: {cleaned.shape}")
    print(f"Scheduling-ready shape: {scheduling_ready.shape}")
    print(f"Removed records count: {len(removed)}")
    print(f"Zero-energy sessions retained: {int(cleaned['is_zero_energy'].sum())}")
    print("")
    print("Output files saved:")
    for path in [
        FULL_CLEANED_FILE,
        SCHEDULING_READY_FILE,
        REMOVED_RECORDS_FILE,
        CLEANING_SUMMARY_FILE,
        MISSING_SUMMARY_FILE,
        SCHEDULING_COLUMNS_FILE,
        REPORT_FILE,
    ]:
        print(f"- {path}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(1)
