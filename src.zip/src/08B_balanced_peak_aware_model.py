"""
Step 08B: Balanced Peak-Aware Gradient Boosting (BPA-GBM).

Run from the project root:
    python src/08B_balanced_peak_aware_model.py

This corrected contribution step tests multiple peak-weight strengths and uses
a constrained validation rule to improve peak forecasting while controlling
overall MAE degradation. It does not create prediction intervals or scheduling
optimization.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import importlib
import json
import re
import sys
import time
import types
import warnings

import numpy as np


if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
FEATURE_FILE = PROJECT_ROOT / "data" / "processed" / "05B_forecasting_features.csv"
FEATURE_COLUMNS_FILE = PROJECT_ROOT / "results" / "05B_fix_feature_engineering" / "05B_modeling_feature_columns.txt"
STANDARD_SELECTED_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_selected_hyperparameters.csv"
STANDARD_METRICS_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_ml_overall_metrics.csv"
STANDARD_SITE_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_ml_site_metrics.csv"
STANDARD_TEST_PRED_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_test_predictions.csv"
BASELINE_METRICS_FILE = PROJECT_ROOT / "results" / "06_baseline_forecasting" / "06_baseline_overall_metrics.csv"
OLD_PA_METRICS_FILE = PROJECT_ROOT / "results" / "08_peak_aware_model" / "08_pa_overall_metrics.csv"

RESULTS_DIR = PROJECT_ROOT / "results" / "08B_balanced_peak_aware_model"
FIGURES_DIR = PROJECT_ROOT / "figures" / "08B_balanced_peak_aware_model"
MODELS_DIR = PROJECT_ROOT / "models" / "08B_balanced_peak_aware_model"

TARGET = "target_load_kw"
RANDOM_STATE = 42

OUT = {
    "tuning": RESULTS_DIR / "08B_bpa_tuning_results.csv",
    "selected": RESULTS_DIR / "08B_selected_bpa_configurations.csv",
    "overall": RESULTS_DIR / "08B_bpa_overall_metrics.csv",
    "site": RESULTS_DIR / "08B_bpa_site_metrics.csv",
    "val_pred": RESULTS_DIR / "08B_validation_predictions.csv",
    "test_pred": RESULTS_DIR / "08B_test_predictions.csv",
    "vs_standard": RESULTS_DIR / "08B_bpa_vs_standard_ml_comparison.csv",
    "vs_old_pa": RESULTS_DIR / "08B_bpa_vs_old_pa_comparison.csv",
    "all_comp": RESULTS_DIR / "08B_all_methods_comparison.csv",
    "all_rank": RESULTS_DIR / "08B_all_methods_ranking.csv",
    "best": RESULTS_DIR / "08B_best_bpa_summary.csv",
    "importance": RESULTS_DIR / "08B_bpa_feature_importance.csv",
    "packages": RESULTS_DIR / "08B_package_availability.csv",
    "captions": RESULTS_DIR / "08B_figure_captions.txt",
    "leakage": RESULTS_DIR / "08B_leakage_safety_report.txt",
    "method": RESULTS_DIR / "08B_proposed_method_report.txt",
    "results": RESULTS_DIR / "08B_results_report.txt",
    "novelty": RESULTS_DIR / "08B_novelty_contribution_report.txt",
}

WEIGHT_STRATEGIES = {
    "no_weight": (1.00, 1.00, 1.00),
    "mild_peak_weight": (1.00, 1.15, 1.30),
    "balanced_peak_weight": (1.00, 1.25, 1.50),
    "medium_peak_weight": (1.00, 1.50, 2.00),
    "strong_peak_weight": (1.00, 2.00, 3.00),
}


def parse_datetime(series: pd.Series) -> pd.Series:
    try:
        return pd.to_datetime(series, errors="coerce", format="mixed")
    except TypeError:
        return pd.to_datetime(series, errors="coerce")


def clip_prediction(values: Any) -> np.ndarray:
    return np.maximum(np.asarray(values, dtype=float), 0.0)


def make_weights(df: pd.DataFrame, strategy: str) -> pd.Series:
    normal, peak, high = WEIGHT_STRATEGIES[strategy]
    weights = pd.Series(normal, index=df.index, dtype=float)
    weights.loc[df["is_peak_hour"] == 1] = peak
    weights.loc[df["is_high_peak_hour"] == 1] = high
    return weights


def mae(a, p) -> float:
    return float(np.mean(np.abs(p - a))) if len(a) else np.nan


def rmse(a, p) -> float:
    return float(np.sqrt(np.mean((p - a) ** 2))) if len(a) else np.nan


def mape(a, p) -> float:
    mask = a != 0
    return float(np.mean(np.abs((p[mask] - a[mask]) / a[mask])) * 100) if mask.any() else np.nan


def smape(a, p) -> float:
    denom = np.abs(a) + np.abs(p)
    mask = denom != 0
    return float(np.mean(2 * np.abs(p[mask] - a[mask]) / denom[mask]) * 100) if mask.any() else np.nan


def r2(a, p) -> float:
    ss_res = float(np.sum((a - p) ** 2))
    ss_tot = float(np.sum((a - np.mean(a)) ** 2))
    return 1 - ss_res / ss_tot if ss_tot else np.nan


def rate(mask) -> float:
    return float(np.mean(mask) * 100) if len(mask) else np.nan


def peak_metrics(df: pd.DataFrame, pred_col: str, high: bool = False) -> dict[str, float]:
    flag = "is_high_peak_hour" if high else "is_peak_hour"
    prefix = "high_peak" if high else "peak"
    sub = df[df[flag] == 1]
    if sub.empty:
        return {f"{prefix}_{k}": np.nan for k in ["MAE", "RMSE", "underestimation_rate", "bias"]}
    a = sub[TARGET].to_numpy(float)
    p = sub[pred_col].to_numpy(float)
    return {
        f"{prefix}_MAE": mae(a, p),
        f"{prefix}_RMSE": rmse(a, p),
        f"{prefix}_underestimation_rate": rate(p < a),
        f"{prefix}_bias": float(np.mean(p - a)),
    }


def operational_metrics(df: pd.DataFrame, pred_col: str) -> dict[str, float]:
    a = df[TARGET].to_numpy(float)
    p = df[pred_col].to_numpy(float)
    q90, q95 = np.nanquantile(a, [0.90, 0.95])
    m10, m5 = a >= q90, a >= q95
    max_idx = int(np.argmax(a))
    return {
        "top_10_percent_actual_peak_MAE": mae(a[m10], p[m10]),
        "top_5_percent_actual_peak_MAE": mae(a[m5], p[m5]),
        "top_10_percent_peak_underestimation_rate": rate(p[m10] < a[m10]),
        "top_5_percent_peak_underestimation_rate": rate(p[m5] < a[m5]),
        "maximum_actual_load_kw": float(a[max_idx]),
        "predicted_load_at_actual_max_kw": float(p[max_idx]),
        "actual_max_underprediction_kw": float(a[max_idx] - p[max_idx]),
    }


def evaluate_overall(df: pd.DataFrame, model: str, split: str, pred_col: str) -> dict[str, Any]:
    a = df[TARGET].to_numpy(float)
    p = df[pred_col].to_numpy(float)
    peak = peak_metrics(df, pred_col, False)
    high = peak_metrics(df, pred_col, True)
    return {
        "model_name": model,
        "split": split,
        "MAE": mae(a, p),
        "RMSE": rmse(a, p),
        "MAPE": mape(a, p),
        "sMAPE": smape(a, p),
        "R2": r2(a, p),
        "MBE": float(np.mean(p - a)),
        "underestimation_rate": rate(p < a),
        "overestimation_rate": rate(p > a),
        "peak_MAE": peak["peak_MAE"],
        "high_peak_MAE": high["high_peak_MAE"],
        "peak_RMSE": peak["peak_RMSE"],
        "high_peak_RMSE": high["high_peak_RMSE"],
        "peak_underestimation_rate": peak["peak_underestimation_rate"],
        "high_peak_underestimation_rate": high["high_peak_underestimation_rate"],
        "mean_actual_peak_load_kw": float(df.loc[df["is_peak_hour"] == 1, TARGET].mean()),
        "mean_predicted_peak_load_kw": float(df.loc[df["is_peak_hour"] == 1, pred_col].mean()),
        "peak_bias": peak["peak_bias"],
        "high_peak_bias": high["high_peak_bias"],
        **operational_metrics(df, pred_col),
    }


def evaluate_site(df: pd.DataFrame, model: str, split: str, pred_col: str, site_means: dict[str, float]) -> list[dict[str, Any]]:
    rows = []
    for site, sdf in df.groupby("site_id", sort=True):
        a = sdf[TARGET].to_numpy(float)
        p = sdf[pred_col].to_numpy(float)
        peak = peak_metrics(sdf, pred_col, False)
        high = peak_metrics(sdf, pred_col, True)
        max_idx = int(np.argmax(a))
        mean = site_means.get(site, np.nan)
        rows.append(
            {
                "model_name": model,
                "split": split,
                "site_id": site,
                "row_count": len(sdf),
                "MAE": mae(a, p),
                "RMSE": rmse(a, p),
                "normalized_MAE_by_site_train_mean": mae(a, p) / mean if mean else np.nan,
                "normalized_RMSE_by_site_train_mean": rmse(a, p) / mean if mean else np.nan,
                "peak_MAE": peak["peak_MAE"],
                "high_peak_MAE": high["high_peak_MAE"],
                "peak_underestimation_rate": peak["peak_underestimation_rate"],
                "high_peak_underestimation_rate": high["high_peak_underestimation_rate"],
                "MBE": float(np.mean(p - a)),
                "actual_max_load_kw": float(a[max_idx]),
                "predicted_at_actual_max_kw": float(p[max_idx]),
                "actual_max_underprediction_kw": float(a[max_idx] - p[max_idx]),
            }
        )
    return rows


def package_version(name: str) -> tuple[bool, str]:
    try:
        mod = importlib.import_module(name)
        return True, str(getattr(mod, "__version__", "unknown"))
    except Exception:
        return False, ""


def unique_params(params: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen = set()
    out = []
    for p in params:
        key = json.dumps(p, sort_keys=True)
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def selected_params_from_step07(model_name: str) -> dict[str, Any] | None:
    if not STANDARD_SELECTED_FILE.exists():
        return None
    selected = pd.read_csv(STANDARD_SELECTED_FILE)
    row = selected[selected["model_name"] == model_name]
    if row.empty:
        return None
    return json.loads(row.iloc[0]["selected_parameter_json"])


def build_specs(package_rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], bool]:
    specs = []
    joblib_ok, joblib_v = package_version("joblib")
    package_rows.append({"package/model": "joblib", "available": joblib_ok, "version": joblib_v, "action_taken": "save artifacts" if joblib_ok else "skip artifacts"})

    lgb_ok, lgb_v = package_version("lightgbm")
    package_rows.append({"package/model": "lightgbm", "available": lgb_ok, "version": lgb_v, "action_taken": "train BPA_LGBM" if lgb_ok else "skip"})
    if lgb_ok:
        from lightgbm import LGBMRegressor

        params = [
            selected_params_from_step07("LGBMRegressor"),
            {"n_estimators": 300, "learning_rate": 0.05, "num_leaves": 31, "max_depth": -1, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0},
            {"n_estimators": 500, "learning_rate": 0.03, "num_leaves": 31, "max_depth": -1, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0},
            {"n_estimators": 300, "learning_rate": 0.05, "num_leaves": 63, "max_depth": -1, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 2.0},
        ]
        specs.append({"model_name": "BPA_LGBM", "standard_model_name": "LGBMRegressor", "old_pa_model_name": "PA_LGBM", "factory": lambda p: LGBMRegressor(random_state=42, n_jobs=-1, verbose=-1, **p), "params": unique_params([p for p in params if p])})

    cat_ok, cat_v = package_version("catboost")
    package_rows.append({"package/model": "catboost", "available": cat_ok, "version": cat_v, "action_taken": "train BPA_CatBoost" if cat_ok else "skip"})
    if cat_ok:
        from catboost import CatBoostRegressor

        params = [
            selected_params_from_step07("CatBoostRegressor"),
            {"iterations": 300, "learning_rate": 0.05, "depth": 6, "l2_leaf_reg": 3},
            {"iterations": 500, "learning_rate": 0.03, "depth": 6, "l2_leaf_reg": 3},
            {"iterations": 300, "learning_rate": 0.05, "depth": 8, "l2_leaf_reg": 5},
        ]
        specs.append({"model_name": "BPA_CatBoost", "standard_model_name": "CatBoostRegressor", "old_pa_model_name": "PA_CatBoost", "factory": lambda p: CatBoostRegressor(loss_function="RMSE", random_seed=42, verbose=False, **p), "params": unique_params([p for p in params if p])})

    xgb_ok, xgb_v = package_version("xgboost")
    package_rows.append({"package/model": "xgboost", "available": xgb_ok, "version": xgb_v, "action_taken": "train BPA_XGBoost" if xgb_ok else "skip"})
    if xgb_ok:
        from xgboost import XGBRegressor

        params = [
            selected_params_from_step07("XGBRegressor"),
            {"n_estimators": 300, "learning_rate": 0.05, "max_depth": 4, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0},
            {"n_estimators": 500, "learning_rate": 0.03, "max_depth": 4, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0},
            {"n_estimators": 300, "learning_rate": 0.05, "max_depth": 6, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 2.0},
        ]
        specs.append({"model_name": "BPA_XGBoost", "standard_model_name": "XGBRegressor", "old_pa_model_name": "PA_XGBoost", "factory": lambda p: XGBRegressor(objective="reg:squarederror", random_state=42, n_jobs=-1, **p), "params": unique_params([p for p in params if p])})

    skl_ok, skl_v = package_version("sklearn")
    package_rows.append({"package/model": "sklearn GradientBoostingRegressor", "available": skl_ok, "version": skl_v, "action_taken": "train BPA_GradientBoosting" if skl_ok else "skip"})
    if skl_ok:
        from sklearn.ensemble import GradientBoostingRegressor

        params = [
            {"n_estimators": 200, "learning_rate": 0.05, "max_depth": 3, "subsample": 0.8},
            {"n_estimators": 300, "learning_rate": 0.03, "max_depth": 3, "subsample": 0.8},
            {"n_estimators": 200, "learning_rate": 0.05, "max_depth": 4, "subsample": 0.8},
        ]
        specs.append({"model_name": "BPA_GradientBoosting", "standard_model_name": "GradientBoostingRegressor", "old_pa_model_name": "PA_GradientBoosting", "factory": lambda p: GradientBoostingRegressor(random_state=42, **p), "params": params})
    return specs, joblib_ok


def train_candidates(specs, train, val, test, features, best_standard_val_mae, joblib_ok):
    X_train, y_train = train[features], train[TARGET]
    X_val = val[features]
    train_val = pd.concat([train, val], ignore_index=True)
    X_train_val, y_train_val = train_val[features], train_val[TARGET]
    X_test = test[features]
    joblib = importlib.import_module("joblib") if joblib_ok else None
    tuning, selected, importance, successful, skipped = [], [], [], [], []

    for spec in specs:
        rows = []
        for cid, params in enumerate(spec["params"], 1):
            for strategy, (normal_w, peak_w, high_w) in WEIGHT_STRATEGIES.items():
                start = time.perf_counter()
                row = {
                    "model_name": spec["model_name"],
                    "candidate_id": cid,
                    "weight_strategy": strategy,
                    "normal_weight": normal_w,
                    "peak_weight": peak_w,
                    "high_peak_weight": high_w,
                    "parameter_json": json.dumps(params, sort_keys=True),
                    "validation_MAE": np.nan,
                    "validation_RMSE": np.nan,
                    "validation_peak_MAE": np.nan,
                    "validation_high_peak_MAE": np.nan,
                    "validation_peak_underestimation_rate": np.nan,
                    "validation_high_peak_underestimation_rate": np.nan,
                    "validation_MBE": np.nan,
                    "validation_peak_bias": np.nan,
                    "validation_high_peak_bias": np.nan,
                    "mae_penalty_pct_vs_best_standard_val": np.nan,
                    "acceptable_under_3pct": False,
                    "acceptable_under_5pct": False,
                    "balanced_score": np.nan,
                    "training_time_seconds": np.nan,
                    "status": "failed",
                    "error_message_if_failed": "",
                }
                try:
                    model = spec["factory"](params)
                    weights = make_weights(train, strategy)
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        model.fit(X_train, y_train, sample_weight=weights)
                    pred_col = f"pred_{spec['model_name']}_c{cid}_{strategy}"
                    val[pred_col] = clip_prediction(model.predict(X_val))
                    metrics = evaluate_overall(val, spec["model_name"], "validation", pred_col)
                    penalty = 100 * (metrics["MAE"] - best_standard_val_mae) / best_standard_val_mae
                    row.update(
                        {
                            "validation_MAE": metrics["MAE"],
                            "validation_RMSE": metrics["RMSE"],
                            "validation_peak_MAE": metrics["peak_MAE"],
                            "validation_high_peak_MAE": metrics["high_peak_MAE"],
                            "validation_peak_underestimation_rate": metrics["peak_underestimation_rate"],
                            "validation_high_peak_underestimation_rate": metrics["high_peak_underestimation_rate"],
                            "validation_MBE": metrics["MBE"],
                            "validation_peak_bias": metrics["peak_bias"],
                            "validation_high_peak_bias": metrics["high_peak_bias"],
                            "mae_penalty_pct_vs_best_standard_val": penalty,
                            "acceptable_under_3pct": bool(penalty <= 3.0),
                            "acceptable_under_5pct": bool(penalty <= 5.0),
                            "balanced_score": metrics["MAE"] + 0.20 * metrics["peak_MAE"] + 0.10 * metrics["high_peak_MAE"],
                            "training_time_seconds": round(time.perf_counter() - start, 3),
                            "status": "success",
                            "_model": model,
                            "_pred_col": pred_col,
                        }
                    )
                except Exception as exc:
                    row["training_time_seconds"] = round(time.perf_counter() - start, 3)
                    row["error_message_if_failed"] = f"{type(exc).__name__}: {exc}"
                rows.append(row)
        successes = [r for r in rows if r["status"] == "success"]
        tuning.extend([{k: v for k, v in r.items() if not k.startswith("_")} for r in rows])
        if not successes:
            skipped.append(f"{spec['model_name']}: all candidates failed")
            continue
        acceptable3 = [r for r in successes if r["acceptable_under_3pct"]]
        acceptable5 = [r for r in successes if r["acceptable_under_5pct"]]
        if acceptable3:
            best = min(acceptable3, key=lambda r: r["validation_peak_MAE"])
            rule = "lowest validation peak_MAE among candidates within 3% validation MAE penalty"
        elif acceptable5:
            best = min(acceptable5, key=lambda r: r["validation_peak_MAE"])
            rule = "lowest validation peak_MAE among candidates within relaxed 5% validation MAE penalty"
        else:
            best = min(successes, key=lambda r: r["balanced_score"])
            rule = "lowest balanced_score because no candidate met 3% or 5% MAE constraint"

        model_name = spec["model_name"]
        val[f"pred_{model_name}"] = val[best["_pred_col"]]
        final = spec["factory"](json.loads(best["parameter_json"]))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            final.fit(X_train_val, y_train_val, sample_weight=make_weights(train_val, best["weight_strategy"]))
        test[f"pred_{model_name}"] = clip_prediction(final.predict(X_test))
        successful.append(model_name)
        selected.append(
            {
                "model_name": model_name,
                "selected_candidate_id": best["candidate_id"],
                "selected_weight_strategy": best["weight_strategy"],
                "selected_parameter_json": best["parameter_json"],
                "selection_rule_used": rule,
                "validation_MAE": best["validation_MAE"],
                "validation_peak_MAE": best["validation_peak_MAE"],
                "validation_high_peak_MAE": best["validation_high_peak_MAE"],
                "mae_penalty_pct_vs_best_standard_val": best["mae_penalty_pct_vs_best_standard_val"],
            }
        )
        if joblib:
            try:
                joblib.dump(final, MODELS_DIR / f"08B_{model_name}.joblib")
            except Exception as exc:
                skipped.append(f"{model_name}: artifact not saved ({type(exc).__name__}: {exc})")
        if hasattr(final, "feature_importances_"):
            imp = np.asarray(final.feature_importances_, dtype=float)
            for rank, idx in enumerate(np.argsort(imp)[::-1], 1):
                importance.append({"model_name": model_name, "feature_name": features[idx], "importance": imp[idx], "rank": rank})
    return successful, skipped, tuning, selected, importance


def prediction_export(df: pd.DataFrame, models: list[str]) -> pd.DataFrame:
    out = pd.DataFrame({"timestamp": df["timestamp"], "site_id": df["site_id"], "actual_load_kw": df[TARGET], "split": df["split"], "is_peak_hour": df["is_peak_hour"], "is_high_peak_hour": df["is_high_peak_hour"]})
    for model in models:
        out[f"prediction_{model}"] = df[f"pred_{model}"]
    return out


def compare_bpa_to_standard(bpa, standard, specs):
    rows = []
    for spec in specs:
        for split in ["validation", "test"]:
            b = bpa[(bpa["model_name"] == spec["model_name"]) & (bpa["split"] == split)]
            s = standard[(standard["model_name"] == spec["standard_model_name"]) & (standard["split"] == split)]
            if b.empty or s.empty:
                continue
            b, s = b.iloc[0], s.iloc[0]
            rows.append(
                {
                    "model_pair": f"{spec['model_name']} vs {spec['standard_model_name']}",
                    "split": split,
                    "standard_MAE": s.MAE,
                    "bpa_MAE": b.MAE,
                    "delta_MAE": b.MAE - s.MAE,
                    "pct_change_MAE": (b.MAE - s.MAE) / s.MAE * 100,
                    "standard_peak_MAE": s.peak_MAE,
                    "bpa_peak_MAE": b.peak_MAE,
                    "delta_peak_MAE": b.peak_MAE - s.peak_MAE,
                    "pct_change_peak_MAE": (b.peak_MAE - s.peak_MAE) / s.peak_MAE * 100,
                    "standard_high_peak_MAE": s.high_peak_MAE,
                    "bpa_high_peak_MAE": b.high_peak_MAE,
                    "delta_high_peak_MAE": b.high_peak_MAE - s.high_peak_MAE,
                    "pct_change_high_peak_MAE": (b.high_peak_MAE - s.high_peak_MAE) / s.high_peak_MAE * 100,
                    "standard_peak_underestimation_rate": s.peak_underestimation_rate,
                    "bpa_peak_underestimation_rate": b.peak_underestimation_rate,
                    "delta_peak_underestimation_rate": b.peak_underestimation_rate - s.peak_underestimation_rate,
                    "improved_overall_MAE": bool(b.MAE < s.MAE),
                    "improved_peak_MAE": bool(b.peak_MAE < s.peak_MAE),
                    "improved_high_peak_MAE": bool(b.high_peak_MAE < s.high_peak_MAE),
                }
            )
    return pd.DataFrame(rows)


def compare_bpa_to_old_pa(bpa, old_pa, specs):
    rows = []
    for spec in specs:
        for split in ["validation", "test"]:
            b = bpa[(bpa["model_name"] == spec["model_name"]) & (bpa["split"] == split)]
            o = old_pa[(old_pa["model_name"] == spec["old_pa_model_name"]) & (old_pa["split"] == split)]
            if b.empty or o.empty:
                continue
            b, o = b.iloc[0], o.iloc[0]
            rows.append({"model_pair": f"{spec['model_name']} vs {spec['old_pa_model_name']}", "split": split, "old_pa_MAE": o.MAE, "bpa_MAE": b.MAE, "delta_MAE": b.MAE - o.MAE, "old_pa_peak_MAE": o.peak_MAE, "bpa_peak_MAE": b.peak_MAE, "delta_peak_MAE": b.peak_MAE - o.peak_MAE, "bpa_reduces_old_pa_mae_penalty": bool(b.MAE < o.MAE)})
    return pd.DataFrame(rows)


def rank_all(all_methods):
    rows = []
    test = all_methods[all_methods["split"] == "test"].copy()
    if "balanced_score" not in test.columns:
        test["balanced_score"] = test["MAE"] + 0.20 * test["peak_MAE"] + 0.10 * test["high_peak_MAE"]
    for metric in ["MAE", "RMSE", "peak_MAE", "high_peak_MAE", "balanced_score"]:
        sub = test[["model_name", "method_group", metric]].dropna().copy()
        sub["rank_metric"] = f"test {metric}"
        sub["rank_value"] = sub[metric]
        sub["rank_position"] = sub["rank_value"].rank(method="min")
        rows.append(sub[["model_name", "method_group", "rank_metric", "rank_value", "rank_position"]])
    return pd.concat(rows, ignore_index=True)


def best_summary(bpa, standard, old_pa, all_methods, bpa_vs_standard):
    rows = []
    test_bpa = bpa[bpa["split"] == "test"].copy()
    test_bpa["balanced_score"] = test_bpa["MAE"] + 0.20 * test_bpa["peak_MAE"] + 0.10 * test_bpa["high_peak_MAE"]
    selected = pd.read_csv(OUT["selected"])
    rows.append({"summary_item": "best BPA by validation constrained selection", "model_name": selected.iloc[0].model_name, "metric": "selection_rule", "metric_value": selected.iloc[0].selection_rule_used})
    for label, metric in [("best BPA by test MAE", "MAE"), ("best BPA by test peak_MAE", "peak_MAE"), ("best BPA by test high_peak_MAE", "high_peak_MAE"), ("best BPA by balanced test score", "balanced_score")]:
        row = test_bpa.sort_values(metric).iloc[0]
        rows.append({"summary_item": label, "model_name": row.model_name, "metric": metric, "metric_value": row[metric]})
    std_test = standard[standard["split"] == "test"]
    old_test = old_pa[old_pa["split"] == "test"]
    rows.append({"summary_item": "best standard ML test MAE", "model_name": std_test.sort_values("MAE").iloc[0].model_name, "metric": "MAE", "metric_value": std_test["MAE"].min()})
    rows.append({"summary_item": "best standard ML test peak_MAE", "model_name": std_test.sort_values("peak_MAE").iloc[0].model_name, "metric": "peak_MAE", "metric_value": std_test["peak_MAE"].min()})
    rows.append({"summary_item": "old Step 08 best PA test MAE", "model_name": old_test.sort_values("MAE").iloc[0].model_name, "metric": "MAE", "metric_value": old_test["MAE"].min()})
    rows.append({"summary_item": "old Step 08 best PA test peak_MAE", "model_name": old_test.sort_values("peak_MAE").iloc[0].model_name, "metric": "peak_MAE", "metric_value": old_test["peak_MAE"].min()})
    best_std_mae = std_test["MAE"].min()
    best_bpa_mae = test_bpa["MAE"].min()
    rows.append({"summary_item": "whether BPA fixes old Step 08 overall MAE penalty", "model_name": "BPA", "metric": "best_BPA_MAE_less_than_old_PA_MAE", "metric_value": bool(best_bpa_mae < old_test["MAE"].min())})
    rows.append({"summary_item": "whether BPA improves peak_MAE over standard ML", "model_name": "BPA", "metric": "any_pair_improved_peak_MAE", "metric_value": bool(bpa_vs_standard[bpa_vs_standard["split"] == "test"]["improved_peak_MAE"].any())})
    rows.append({"summary_item": "whether BPA keeps overall MAE within 5% of standard ML", "model_name": test_bpa.sort_values("peak_MAE").iloc[0].model_name, "metric": "within_5pct", "metric_value": bool(test_bpa.sort_values("peak_MAE").iloc[0].MAE <= best_std_mae * 1.05)})
    candidates = test_bpa[test_bpa["MAE"] <= best_std_mae * 1.05]
    if not candidates.empty:
        rec = candidates.sort_values("peak_MAE").iloc[0]
        reason = "lowest peak_MAE while within 5% of best standard ML MAE"
    else:
        rec = test_bpa.sort_values("balanced_score").iloc[0]
        reason = "lowest balanced test score because no BPA model stayed within 5% MAE"
    rows.append({"summary_item": "recommended model for the paper", "model_name": rec.model_name, "metric": reason, "metric_value": rec.get("balanced_score", np.nan)})
    return pd.DataFrame(rows)


def add_labels(ax):
    for p in ax.patches:
        h = p.get_height()
        if np.isfinite(h):
            ax.text(p.get_x() + p.get_width() / 2, h, f"{h:.2f}", ha="center", va="bottom", fontsize=8)


def write_reports(successful, skipped, selected, bpa, standard, old_pa, bpa_vs_standard, best, input_shape, counts, features):
    skipped_lines = [f"- {s}" for s in skipped] if skipped else ["- None"]
    selected_lines = [f"- {r.model_name}: {r.selected_weight_strategy}, candidate {r.selected_candidate_id}, {r.selection_rule_used}" for r in selected.itertuples(index=False)]
    best_std = standard[standard["split"] == "test"].sort_values("MAE").iloc[0]
    best_old = old_pa[old_pa["split"] == "test"].sort_values("MAE").iloc[0]
    best_bpa_mae = bpa[bpa["split"] == "test"].sort_values("MAE").iloc[0]
    best_bpa_peak = bpa[bpa["split"] == "test"].sort_values("peak_MAE").iloc[0]
    rec = best[best["summary_item"] == "recommended model for the paper"].iloc[0]

    OUT["leakage"].write_text("\n".join(["Step 08B leakage safety report", "=" * 31, "- Step 05B chronological splits were used.", "- Models were fit on train only during tuning.", "- Hyperparameters and weight strategies were selected on validation only.", "- Test data was used only for final evaluation and analysis.", "- Only approved 05B modeling features were used.", "- Peak labels were not predictors.", "- Sample weights were used only in training.", "- No future information was used.", ""]) , encoding="utf-8")
    OUT["method"].write_text("\n".join(["Step 08B proposed method report", "=" * 32, "BPA-GBM is Balanced Peak-Aware Gradient Boosting for EV charging load forecasting.", "Old aggressive PA weighting improved peak errors but caused too much overall MAE degradation.", "BPA-GBM tests no, mild, balanced, medium, and strong peak weights and selects with a validation MAE constraint.", "Candidates must stay within 3% of the best standard validation MAE; if needed the constraint relaxes to 5%.", "Among acceptable candidates, BPA selects the lowest validation peak_MAE, keeping average-load accuracy under control.", "This corrected contribution preserves normal accuracy while still targeting peak prediction and underestimation.", ""]) , encoding="utf-8")
    OUT["results"].write_text("\n".join(["Step 08B results report", "=" * 24, f"Models evaluated: {', '.join(successful)}", "Models skipped:", *skipped_lines, "", "Selected configurations:", *selected_lines, "", f"Best standard ML test MAE: {best_std.model_name} ({best_std.MAE:.4f})", f"Old PA best test MAE: {best_old.model_name} ({best_old.MAE:.4f})", f"New BPA best test MAE: {best_bpa_mae.model_name} ({best_bpa_mae.MAE:.4f})", f"New BPA best test peak_MAE: {best_bpa_peak.model_name} ({best_bpa_peak.peak_MAE:.4f})", f"BPA fixes old Step 08 MAE penalty: {bool(best_bpa_mae.MAE < best_old.MAE)}", f"BPA improves peak_MAE over standard ML in matched test pairs: {bool(bpa_vs_standard[bpa_vs_standard['split']=='test']['improved_peak_MAE'].any())}", f"Recommended model for paper: {rec.model_name} ({rec.metric})", "Limitations: BPA still trades some normal MAE for peak performance; Step 09 should statistically test the tradeoff before prediction intervals.", ""]) , encoding="utf-8")
    OUT["novelty"].write_text("\n".join(["Step 08B novelty contribution report", "=" * 37, "This study proposes balanced peak-aware calendar-enhanced forecasting for EV charging load prediction.", "The method evaluates multiple peak-weight strategies rather than assuming one aggressive weighting rule.", "Validation-constrained model selection preserves average-load accuracy while improving peak-load prediction.", "The corrected BPA-GBM contribution links leakage-free calendar-enhanced features to operationally relevant peak forecasting.", "This supports later constrained scheduling by reducing peak error without unacceptable degradation in ordinary demand forecasts.", ""]) , encoding="utf-8")
    OUT["captions"].write_text("\n".join(["Fig. 1. Validation MAE versus peak_MAE for BPA weight strategies.", "Fig. 2. Test MAE comparison for standard ML, old PA, and new BPA.", "Fig. 3. Test peak_MAE comparison for standard ML, old PA, and new BPA.", "Fig. 4. Test high_peak_MAE comparison for standard ML, old PA, and new BPA.", "Fig. 5. Test MAE and peak_MAE tradeoff for BPA and standard models.", "Fig. 6. Actual load and best BPA prediction on a seven-day test sample.", "Fig. 7. Actual load, best standard ML prediction, and best BPA prediction on the same sample.", "Fig. 8. Peak underestimation comparison for standard ML, old PA, and new BPA.", "Fig. 9. Site-level peak_MAE for best standard ML and best BPA.", "Fig. 10. Top 20 feature importances for the recommended BPA model."]) + "\n", encoding="utf-8")


def make_figures(tuning, bpa, standard, old_pa, all_methods, bpa_vs_standard, test, importance):
    # 1 tradeoff
    fig, ax = plt.subplots(figsize=(10, 6))
    ok = tuning[tuning["status"] == "success"]
    for strategy, sdf in ok.groupby("weight_strategy"):
        ax.scatter(sdf["validation_MAE"], sdf["validation_peak_MAE"], label=strategy, alpha=0.8)
    ax.set_xlabel("Validation MAE")
    ax.set_ylabel("Validation peak_MAE")
    ax.set_title("BPA validation tradeoff by weight strategy")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "08B_fig1_weight_strategy_tradeoff_validation.png", dpi=300)
    plt.close(fig)
    # 2-4 comparisons
    for filename, metric, title in [("08B_fig2_test_mae_standard_pa_bpa.png", "MAE", "Test MAE"), ("08B_fig3_test_peak_mae_standard_pa_bpa.png", "peak_MAE", "Test peak_MAE"), ("08B_fig4_test_high_peak_mae_standard_pa_bpa.png", "high_peak_MAE", "Test high_peak_MAE")]:
        plot = all_methods[all_methods["split"] == "test"].sort_values(metric).head(12)
        fig, ax = plt.subplots(figsize=(13, 6))
        ax.bar(plot["model_name"] + " (" + plot["method_group"] + ")", plot[metric])
        ax.set_title(title)
        ax.set_ylabel(metric)
        ax.tick_params(axis="x", rotation=35)
        add_labels(ax)
        fig.tight_layout()
        fig.savefig(FIGURES_DIR / filename, dpi=300)
        plt.close(fig)
    # 5 scatter
    plot = pd.concat([standard[standard["split"] == "test"].assign(group="standard"), bpa[bpa["split"] == "test"].assign(group="BPA")])
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(plot["MAE"], plot["peak_MAE"])
    for r in plot.itertuples(index=False):
        ax.text(r.MAE, r.peak_MAE, r.model_name, fontsize=8)
    ax.set_xlabel("Test MAE")
    ax.set_ylabel("Test peak_MAE")
    ax.set_title("BPA vs standard tradeoff")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "08B_fig5_bpa_vs_standard_tradeoff.png", dpi=300)
    plt.close(fig)
    # sample plots
    best_bpa = bpa[bpa["split"] == "test"].sort_values("peak_MAE").iloc[0].model_name
    best_std = standard[standard["split"] == "test"].sort_values("MAE").iloc[0].model_name
    site = test.groupby("site_id").size().sort_values(ascending=False).index[0]
    sdf = test[test["site_id"] == site].sort_values("timestamp")
    sample = sdf[sdf["timestamp"] < sdf["timestamp"].min() + pd.Timedelta(days=7)]
    for filename, include_std in [("08B_fig6_actual_vs_best_bpa_test_sample.png", False), ("08B_fig7_actual_vs_standard_vs_bpa_test_sample.png", True)]:
        fig, ax = plt.subplots(figsize=(12, 5))
        ax.plot(sample["timestamp"], sample[TARGET], label="Actual", linewidth=2)
        ax.plot(sample["timestamp"], sample[f"pred_{best_bpa}"], label=best_bpa)
        if include_std and STANDARD_TEST_PRED_FILE.exists():
            pred = pd.read_csv(STANDARD_TEST_PRED_FILE)
            pred["timestamp"] = parse_datetime(pred["timestamp"])
            col = f"prediction_{best_std}"
            ps = pred[(pred["site_id"] == site) & (pred["timestamp"].isin(sample["timestamp"]))]
            if col in ps.columns:
                ax.plot(ps["timestamp"], ps[col], label=best_std)
        ax.set_title(f"Actual vs prediction sample: {site}")
        ax.set_ylabel("Load (kW)")
        ax.legend()
        fig.autofmt_xdate()
        fig.tight_layout()
        fig.savefig(FIGURES_DIR / filename, dpi=300)
        plt.close(fig)
    # 8 underestimation
    under = all_methods[all_methods["split"] == "test"].sort_values("peak_underestimation_rate").head(12)
    fig, ax = plt.subplots(figsize=(13, 6))
    ax.bar(under["model_name"] + " (" + under["method_group"] + ")", under["peak_underestimation_rate"])
    ax.set_title("Peak underestimation comparison")
    ax.set_ylabel("Peak underestimation rate (%)")
    ax.tick_params(axis="x", rotation=35)
    add_labels(ax)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "08B_fig8_peak_underestimation_standard_pa_bpa.png", dpi=300)
    plt.close(fig)
    # 9 site level
    std_site = pd.read_csv(STANDARD_SITE_FILE)
    bpa_site = pd.read_csv(OUT["site"])
    best_std_peak = standard[standard["split"] == "test"].sort_values("peak_MAE").iloc[0].model_name
    best_bpa_peak = bpa[bpa["split"] == "test"].sort_values("peak_MAE").iloc[0].model_name
    site_plot = pd.concat([std_site[(std_site["split"] == "test") & (std_site["model_name"] == best_std_peak)].assign(group="standard"), bpa_site[(bpa_site["split"] == "test") & (bpa_site["model_name"] == best_bpa_peak)].assign(group="BPA")])
    pivot = site_plot.pivot(index="site_id", columns="group", values="peak_MAE")
    fig, ax = plt.subplots(figsize=(11, 6))
    pivot.plot(kind="bar", ax=ax)
    ax.set_title("Site-level peak_MAE: best standard vs BPA")
    ax.set_ylabel("peak_MAE")
    ax.tick_params(axis="x", rotation=35)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "08B_fig9_site_level_peak_mae_best_standard_vs_bpa.png", dpi=300)
    plt.close(fig)
    # 10 importance
    if not importance.empty:
        rec = bpa[bpa["split"] == "test"].sort_values("peak_MAE").iloc[0].model_name
        imp = importance[importance["model_name"] == rec].sort_values("rank").head(20)
        fig, ax = plt.subplots(figsize=(10, 7))
        ax.barh(imp["feature_name"][::-1], imp["importance"][::-1])
        ax.set_title(f"Top feature importances: {rec}")
        fig.tight_layout()
        fig.savefig(FIGURES_DIR / "08B_fig10_top_feature_importance_best_bpa.png", dpi=300)
        plt.close(fig)


def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    features = [line.strip() for line in FEATURE_COLUMNS_FILE.read_text(encoding="utf-8").splitlines() if line.strip()]
    df = pd.read_csv(FEATURE_FILE)
    input_shape = df.shape
    df["timestamp"] = parse_datetime(df["timestamp"])
    train, val, test = [df[df["split"] == split].copy() for split in ["train", "validation", "test"]]
    counts = df["split"].value_counts().reindex(["train", "validation", "test"], fill_value=0)
    standard = pd.read_csv(STANDARD_METRICS_FILE)
    baseline = pd.read_csv(BASELINE_METRICS_FILE)
    old_pa = pd.read_csv(OLD_PA_METRICS_FILE)
    best_standard_val_mae = standard[standard["split"] == "validation"]["MAE"].min()
    site_means = train.groupby("site_id")[TARGET].mean().to_dict()
    package_rows = []
    specs, joblib_ok = build_specs(package_rows)
    successful, skipped, tuning_rows, selected_rows, importance_rows = train_candidates(specs, train, val, test, features, best_standard_val_mae, joblib_ok)
    tuning = pd.DataFrame(tuning_rows)
    selected = pd.DataFrame(selected_rows)
    importance = pd.DataFrame(importance_rows)
    tuning.to_csv(OUT["tuning"], index=False)
    selected.to_csv(OUT["selected"], index=False)
    pd.DataFrame(package_rows).to_csv(OUT["packages"], index=False)
    if importance.empty:
        importance = pd.DataFrame(columns=["model_name", "feature_name", "importance", "rank"])
    importance.to_csv(OUT["importance"], index=False)

    overall_rows, site_rows = [], []
    for split, sdf in [("validation", val), ("test", test)]:
        for model in successful:
            overall_rows.append(evaluate_overall(sdf, model, split, f"pred_{model}"))
            site_rows.extend(evaluate_site(sdf, model, split, f"pred_{model}", site_means))
    bpa = pd.DataFrame(overall_rows).sort_values(["split", "MAE"])
    site = pd.DataFrame(site_rows).sort_values(["split", "site_id", "MAE"])
    bpa.to_csv(OUT["overall"], index=False)
    site.to_csv(OUT["site"], index=False)
    prediction_export(val, successful).to_csv(OUT["val_pred"], index=False)
    prediction_export(test, successful).to_csv(OUT["test_pred"], index=False)
    bpa_vs_standard = compare_bpa_to_standard(bpa, standard, specs)
    bpa_vs_old = compare_bpa_to_old_pa(bpa, old_pa, specs)
    bpa_vs_standard.to_csv(OUT["vs_standard"], index=False)
    bpa_vs_old.to_csv(OUT["vs_old_pa"], index=False)
    all_methods = pd.concat([baseline.assign(method_group="baseline"), standard.assign(method_group="standard_ml"), old_pa.assign(method_group="old_pa"), bpa.assign(method_group="BPA")], ignore_index=True, sort=False)
    all_methods["balanced_score"] = all_methods["MAE"] + 0.20 * all_methods["peak_MAE"] + 0.10 * all_methods["high_peak_MAE"]
    all_methods.to_csv(OUT["all_comp"], index=False)
    rank_all(all_methods).to_csv(OUT["all_rank"], index=False)
    best = best_summary(bpa, standard, old_pa, all_methods, bpa_vs_standard)
    best.to_csv(OUT["best"], index=False)
    make_figures(tuning, bpa, standard, old_pa, all_methods, bpa_vs_standard, test, importance)
    write_reports(successful, skipped, selected, bpa, standard, old_pa, bpa_vs_standard, best, input_shape, counts, features)

    best_std_mae = standard[standard["split"] == "test"].sort_values("MAE").iloc[0]
    best_std_peak = standard[standard["split"] == "test"].sort_values("peak_MAE").iloc[0]
    best_old_mae = old_pa[old_pa["split"] == "test"].sort_values("MAE").iloc[0]
    best_old_peak = old_pa[old_pa["split"] == "test"].sort_values("peak_MAE").iloc[0]
    best_bpa_mae = bpa[bpa["split"] == "test"].sort_values("MAE").iloc[0]
    best_bpa_peak = bpa[bpa["split"] == "test"].sort_values("peak_MAE").iloc[0]
    rec = best[best["summary_item"] == "recommended model for the paper"].iloc[0]
    print("Step 08B balanced peak-aware model complete")
    print("===========================================")
    print(f"Input shape: {input_shape}")
    print(f"Train/validation/test rows: {int(counts['train'])}/{int(counts['validation'])}/{int(counts['test'])}")
    print(f"Number of features: {len(features)}")
    print("Models evaluated:")
    for model in successful:
        print(f"- {model}")
    print(f"Best standard ML test MAE: {best_std_mae.model_name} ({best_std_mae.MAE:.4f}); peak_MAE {best_std_peak.peak_MAE:.4f}")
    print(f"Old PA best test MAE: {best_old_mae.model_name} ({best_old_mae.MAE:.4f}); peak_MAE {best_old_peak.peak_MAE:.4f}")
    print(f"New BPA best test MAE: {best_bpa_mae.model_name} ({best_bpa_mae.MAE:.4f}); peak_MAE {best_bpa_peak.peak_MAE:.4f}")
    print(f"BPA keeps MAE within 5% of standard ML: {bool(best_bpa_peak.MAE <= best_std_mae.MAE * 1.05)}")
    print(f"BPA improves peak_MAE over standard ML in matched pair: {bool(bpa_vs_standard[bpa_vs_standard['split']=='test']['improved_peak_MAE'].any())}")
    print(f"Recommended model for paper: {rec.model_name}")
    print("")
    print("Output files saved:")
    for path in OUT.values():
        print(f"- {path}")
    print("")
    print("Report locations:")
    print(f"- {OUT['method']}")
    print(f"- {OUT['results']}")
    print(f"- {OUT['leakage']}")
    print(f"- {OUT['novelty']}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(1)
