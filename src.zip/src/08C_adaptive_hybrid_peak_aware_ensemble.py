"""
Step 08C: Adaptive Hybrid Peak-Aware Ensemble (AHPA-Ensemble).

Run from the project root:
    python src/08C_adaptive_hybrid_peak_aware_ensemble.py

This step combines standard ML and peak-aware forecasts using validation-only
hybrid selection. Test labels are used only for final reporting and analysis.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import importlib
import json
import re
import sys
import time
import types
import warnings

import numpy as np


if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
FEATURE_FILE = PROJECT_ROOT / "data" / "processed" / "05B_forecasting_features.csv"
FEATURE_COLUMNS_FILE = PROJECT_ROOT / "results" / "05B_fix_feature_engineering" / "05B_modeling_feature_columns.txt"

BASELINE_METRICS_FILE = PROJECT_ROOT / "results" / "06_baseline_forecasting" / "06_baseline_overall_metrics.csv"
BASELINE_TEST_PRED_FILE = PROJECT_ROOT / "results" / "06_baseline_forecasting" / "06_test_predictions.csv"
STANDARD_METRICS_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_ml_overall_metrics.csv"
STANDARD_SITE_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_ml_site_metrics.csv"
STANDARD_VAL_PRED_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_validation_predictions.csv"
STANDARD_TEST_PRED_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_test_predictions.csv"
OLD_PA_METRICS_FILE = PROJECT_ROOT / "results" / "08_peak_aware_model" / "08_pa_overall_metrics.csv"
OLD_PA_VAL_PRED_FILE = PROJECT_ROOT / "results" / "08_peak_aware_model" / "08_validation_predictions.csv"
OLD_PA_TEST_PRED_FILE = PROJECT_ROOT / "results" / "08_peak_aware_model" / "08_test_predictions.csv"
BPA_METRICS_FILE = PROJECT_ROOT / "results" / "08B_balanced_peak_aware_model" / "08B_bpa_overall_metrics.csv"
BPA_VAL_PRED_FILE = PROJECT_ROOT / "results" / "08B_balanced_peak_aware_model" / "08B_validation_predictions.csv"
BPA_TEST_PRED_FILE = PROJECT_ROOT / "results" / "08B_balanced_peak_aware_model" / "08B_test_predictions.csv"

RESULTS_DIR = PROJECT_ROOT / "results" / "08C_adaptive_hybrid_peak_aware_ensemble"
FIGURES_DIR = PROJECT_ROOT / "figures" / "08C_adaptive_hybrid_peak_aware_ensemble"
MODELS_DIR = PROJECT_ROOT / "models" / "08C_adaptive_hybrid_peak_aware_ensemble"

TARGET = "target_load_kw"
RANDOM_STATE = 42
KEYS = ["timestamp", "site_id", "actual_load_kw", "split"]
PRED_META = ["timestamp", "site_id", "actual_load_kw", "split", "is_peak_hour", "is_high_peak_hour"]


def ensure_dirs() -> None:
    for folder in [RESULTS_DIR, FIGURES_DIR, MODELS_DIR]:
        folder.mkdir(parents=True, exist_ok=True)


def package_version(name: str) -> tuple[bool, str]:
    try:
        mod = importlib.import_module(name)
        return True, str(getattr(mod, "__version__", "unknown"))
    except Exception:
        return False, ""


def clip_prediction(values: Any) -> np.ndarray:
    return np.maximum(np.asarray(values, dtype=float), 0.0)


def mae(a: np.ndarray, p: np.ndarray) -> float:
    return float(np.mean(np.abs(p - a))) if len(a) else np.nan


def rmse(a: np.ndarray, p: np.ndarray) -> float:
    return float(np.sqrt(np.mean((p - a) ** 2))) if len(a) else np.nan


def mape(a: np.ndarray, p: np.ndarray) -> float:
    mask = a != 0
    return float(np.mean(np.abs((p[mask] - a[mask]) / a[mask])) * 100) if mask.any() else np.nan


def smape(a: np.ndarray, p: np.ndarray) -> float:
    denom = np.abs(a) + np.abs(p)
    mask = denom != 0
    return float(np.mean(2 * np.abs(p[mask] - a[mask]) / denom[mask]) * 100) if mask.any() else np.nan


def r2(a: np.ndarray, p: np.ndarray) -> float:
    ss_res = float(np.sum((a - p) ** 2))
    ss_tot = float(np.sum((a - np.mean(a)) ** 2))
    return 1 - ss_res / ss_tot if ss_tot else np.nan


def rate(mask: np.ndarray) -> float:
    return float(np.mean(mask) * 100) if len(mask) else np.nan


def peak_metrics(df: pd.DataFrame, pred_col: str, high: bool = False) -> dict[str, float]:
    flag = "is_high_peak_hour" if high else "is_peak_hour"
    prefix = "high_peak" if high else "peak"
    sub = df[df[flag] == 1]
    if sub.empty:
        return {f"{prefix}_{k}": np.nan for k in ["MAE", "RMSE", "underestimation_rate", "bias"]}
    a = sub[TARGET].to_numpy(float)
    p = sub[pred_col].to_numpy(float)
    return {
        f"{prefix}_MAE": mae(a, p),
        f"{prefix}_RMSE": rmse(a, p),
        f"{prefix}_underestimation_rate": rate(p < a),
        f"{prefix}_bias": float(np.mean(p - a)),
    }


def operational_metrics(df: pd.DataFrame, pred_col: str) -> dict[str, float]:
    a = df[TARGET].to_numpy(float)
    p = df[pred_col].to_numpy(float)
    q90, q95 = np.nanquantile(a, [0.90, 0.95])
    m10, m5 = a >= q90, a >= q95
    max_idx = int(np.argmax(a))
    return {
        "top_10_percent_actual_peak_MAE": mae(a[m10], p[m10]),
        "top_5_percent_actual_peak_MAE": mae(a[m5], p[m5]),
        "top_10_percent_peak_underestimation_rate": rate(p[m10] < a[m10]),
        "top_5_percent_peak_underestimation_rate": rate(p[m5] < a[m5]),
        "maximum_actual_load_kw": float(a[max_idx]),
        "predicted_load_at_actual_max_kw": float(p[max_idx]),
        "actual_max_underprediction_kw": float(a[max_idx] - p[max_idx]),
    }


def evaluate_overall(df: pd.DataFrame, model: str, split: str, pred_col: str) -> dict[str, Any]:
    a = df[TARGET].to_numpy(float)
    p = df[pred_col].to_numpy(float)
    peak = peak_metrics(df, pred_col, False)
    high = peak_metrics(df, pred_col, True)
    return {
        "model_name": model,
        "split": split,
        "MAE": mae(a, p),
        "RMSE": rmse(a, p),
        "MAPE": mape(a, p),
        "sMAPE": smape(a, p),
        "R2": r2(a, p),
        "MBE": float(np.mean(p - a)),
        "underestimation_rate": rate(p < a),
        "overestimation_rate": rate(p > a),
        "peak_MAE": peak["peak_MAE"],
        "high_peak_MAE": high["high_peak_MAE"],
        "peak_RMSE": peak["peak_RMSE"],
        "high_peak_RMSE": high["high_peak_RMSE"],
        "peak_underestimation_rate": peak["peak_underestimation_rate"],
        "high_peak_underestimation_rate": high["high_peak_underestimation_rate"],
        "mean_actual_peak_load_kw": float(df.loc[df["is_peak_hour"] == 1, TARGET].mean()),
        "mean_predicted_peak_load_kw": float(df.loc[df["is_peak_hour"] == 1, pred_col].mean()),
        "peak_bias": peak["peak_bias"],
        "high_peak_bias": high["high_peak_bias"],
        **operational_metrics(df, pred_col),
    }


def evaluate_site(df: pd.DataFrame, model: str, split: str, pred_col: str, site_means: dict[str, float]) -> list[dict[str, Any]]:
    rows = []
    for site, sdf in df.groupby("site_id", sort=True):
        a = sdf[TARGET].to_numpy(float)
        p = sdf[pred_col].to_numpy(float)
        peak = peak_metrics(sdf, pred_col, False)
        high = peak_metrics(sdf, pred_col, True)
        max_idx = int(np.argmax(a))
        mean = site_means.get(site, np.nan)
        rows.append(
            {
                "model_name": model,
                "split": split,
                "site_id": site,
                "row_count": len(sdf),
                "MAE": mae(a, p),
                "RMSE": rmse(a, p),
                "normalized_MAE_by_site_train_mean": mae(a, p) / mean if mean else np.nan,
                "normalized_RMSE_by_site_train_mean": rmse(a, p) / mean if mean else np.nan,
                "peak_MAE": peak["peak_MAE"],
                "high_peak_MAE": high["high_peak_MAE"],
                "underestimation_rate": rate(p < a),
                "peak_underestimation_rate": peak["peak_underestimation_rate"],
                "high_peak_underestimation_rate": high["high_peak_underestimation_rate"],
                "MBE": float(np.mean(p - a)),
                "actual_max_load_kw": float(a[max_idx]),
                "predicted_at_actual_max_kw": float(p[max_idx]),
                "actual_max_underprediction_kw": float(a[max_idx] - p[max_idx]),
            }
        )
    return rows


def prediction_name(col: str) -> str:
    return col.replace("prediction_", "", 1)


def load_prediction_file(path: Path, source: str, diagnostics: list[dict[str, Any]]) -> pd.DataFrame | None:
    if not path.exists():
        diagnostics.append({"source": source, "path": str(path), "status": "missing", "rows": 0, "prediction_columns": ""})
        return None
    df = pd.read_csv(path)
    pred_cols = [c for c in df.columns if c.startswith("prediction_")]
    diagnostics.append(
        {
            "source": source,
            "path": str(path),
            "status": "loaded",
            "rows": len(df),
            "prediction_columns": ", ".join(pred_cols),
        }
    )
    return df


def combine_predictions(files: list[tuple[Path, str]], split: str, diagnostics: list[dict[str, Any]]) -> pd.DataFrame:
    base = None
    for path, source in files:
        df = load_prediction_file(path, source, diagnostics)
        if df is None:
            continue
        pred_cols = [c for c in df.columns if c.startswith("prediction_")]
        keep = PRED_META + pred_cols
        keep = [c for c in keep if c in df.columns]
        df = df[keep].copy()
        df["timestamp"] = df["timestamp"].astype(str)
        if TARGET not in df.columns and "actual_load_kw" in df.columns:
            df[TARGET] = df["actual_load_kw"]
        if base is None:
            base = df
        else:
            before = len(base)
            df_merge = df[KEYS + pred_cols].copy()
            base = base.merge(df_merge, on=KEYS, how="outer", validate="one_to_one")
            diagnostics.append(
                {
                    "source": source,
                    "path": str(path),
                    "status": f"merged_{split}",
                    "rows": len(df),
                    "prediction_columns": ", ".join(pred_cols),
                    "base_rows_before": before,
                    "base_rows_after": len(base),
                    "missing_after_merge": int(base[pred_cols].isna().sum().sum()),
                }
            )
    if base is None:
        raise FileNotFoundError(f"No prediction files were available for {split}.")
    base[TARGET] = base["actual_load_kw"]
    return base


def build_risk_features(features: pd.DataFrame) -> pd.DataFrame:
    df = features.copy()
    if "timestamp" in df.columns:
        df["timestamp"] = df["timestamp"].astype(str)
    if "site_id_encoded" not in df.columns:
        df["site_id_encoded"] = pd.factorize(df["site_id"])[0]
    train = df[df["split"] == "train"].copy()
    thresholds = train.groupby("site_id")[TARGET].quantile(0.90).replace(0, np.nan).to_dict()
    train_mean = train.groupby("site_id")[TARGET].mean().replace(0, np.nan).to_dict()
    df["peak_threshold_90_train_kw"] = df["site_id"].map(thresholds).fillna(train[TARGET].quantile(0.90))
    df["site_train_mean_kw"] = df["site_id"].map(train_mean).fillna(train[TARGET].mean())
    for col in ["lag_1h", "lag_24h", "lag_168h", "rolling_mean_24h", "rolling_mean_168h"]:
        if col not in df.columns:
            df[col] = 0.0
    for col in ["rolling_q90_24h", "rolling_q95_24h", "rolling_q90_168h", "rolling_q95_168h"]:
        if col not in df.columns:
            base = "rolling_mean_24h" if "24h" in col else "rolling_mean_168h"
            df[col] = df.get(base, 0.0)
    for col in ["recent_peak_24h_count", "recent_peak_168h_count"]:
        if col not in df.columns:
            df[col] = 0.0
    for col in ["recent_peak_24h_flag", "recent_peak_168h_flag"]:
        if col not in df.columns:
            count_col = col.replace("_flag", "_count")
            df[col] = (df.get(count_col, 0) > 0).astype(int)
    for col in ["hour", "day_of_week", "is_weekend", "is_business_hour", "is_morning_arrival_period", "is_evening_departure_period"]:
        if col not in df.columns:
            df[col] = 0
    denom = df["peak_threshold_90_train_kw"].replace(0, np.nan)
    df["risk_lag24_vs_site_p90"] = df["lag_24h"] / denom
    df["risk_lag168_vs_site_p90"] = df["lag_168h"] / denom
    df["risk_rollq90_24_vs_site_p90"] = df["rolling_q90_24h"] / denom
    df["risk_rollq90_168_vs_site_p90"] = df["rolling_q90_168h"] / denom
    df["risk_recent_peak_count_norm"] = df["recent_peak_24h_count"] / 24.0
    risk_parts = [
        "risk_lag24_vs_site_p90",
        "risk_lag168_vs_site_p90",
        "risk_rollq90_24_vs_site_p90",
        "risk_rollq90_168_vs_site_p90",
        "risk_recent_peak_count_norm",
        "recent_peak_24h_flag",
        "recent_peak_168h_flag",
    ]
    df["risk_combined_simple"] = df[risk_parts].replace([np.inf, -np.inf], np.nan).fillna(0).mean(axis=1)
    df["risk_max_lag_ratio"] = df[["lag_1h", "lag_24h", "lag_168h"]].max(axis=1) / denom
    if "rolling_max_24h" not in df.columns:
        df["rolling_max_24h"] = df[["rolling_q95_24h", "rolling_q90_24h", "rolling_mean_24h"]].max(axis=1)
    if "rolling_max_168h" not in df.columns:
        df["rolling_max_168h"] = df[["rolling_q95_168h", "rolling_q90_168h", "rolling_mean_168h"]].max(axis=1)
    df["risk_recent_high_load_ratio"] = df["rolling_max_24h"] / denom
    df["risk_weekly_high_load_ratio"] = df["rolling_max_168h"] / denom
    df["risk_business_peak_interaction"] = df["risk_combined_simple"] * df["is_business_hour"]
    df["risk_morning_peak_interaction"] = df["risk_combined_simple"] * df["is_morning_arrival_period"]
    df["risk_recent_peak_interaction"] = df["risk_combined_simple"] * df["recent_peak_24h_flag"]
    risk_cols = base_risk_columns()
    df[risk_cols] = df[risk_cols].replace([np.inf, -np.inf], np.nan).fillna(0)
    return df


def base_risk_columns() -> list[str]:
    return [
        "lag_1h",
        "lag_24h",
        "lag_168h",
        "rolling_mean_24h",
        "rolling_mean_168h",
        "rolling_q90_24h",
        "rolling_q95_24h",
        "rolling_q90_168h",
        "rolling_q95_168h",
        "recent_peak_24h_count",
        "recent_peak_168h_count",
        "recent_peak_24h_flag",
        "recent_peak_168h_flag",
        "hour",
        "day_of_week",
        "is_weekend",
        "is_business_hour",
        "is_morning_arrival_period",
        "is_evening_departure_period",
        "site_id_encoded",
        "risk_lag24_vs_site_p90",
        "risk_lag168_vs_site_p90",
        "risk_rollq90_24_vs_site_p90",
        "risk_rollq90_168_vs_site_p90",
        "risk_recent_peak_count_norm",
        "risk_combined_simple",
        "risk_max_lag_ratio",
        "risk_recent_high_load_ratio",
        "risk_weekly_high_load_ratio",
        "risk_business_peak_interaction",
        "risk_morning_peak_interaction",
        "risk_recent_peak_interaction",
    ]


def merge_risk(preds: pd.DataFrame, risk: pd.DataFrame, split: str) -> pd.DataFrame:
    cols = ["timestamp", "site_id"] + [c for c in base_risk_columns() + ["peak_threshold_90_train_kw", "site_train_mean_kw"] if c in risk.columns]
    sub = risk[risk["split"] == split][cols].copy()
    return preds.merge(sub, on=["timestamp", "site_id"], how="left")


def retry_models(features: pd.DataFrame, feature_cols: list[str], site_means: dict[str, float]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    metrics_rows: list[dict[str, Any]] = []
    error_rows: list[dict[str, Any]] = []
    val_pred = features.loc[features["split"] == "validation", PRED_META].copy()
    test_pred = features.loc[features["split"] == "test", PRED_META].copy()
    val_pred[TARGET] = val_pred["actual_load_kw"]
    test_pred[TARGET] = test_pred["actual_load_kw"]

    specs = []
    try:
        from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestRegressor

        specs = [
            ("RF_Retry", RandomForestRegressor(n_estimators=150, max_depth=14, min_samples_leaf=3, max_features=0.5, n_jobs=-1, random_state=RANDOM_STATE)),
            ("ExtraTrees_Retry", ExtraTreesRegressor(n_estimators=200, max_depth=14, min_samples_leaf=3, max_features=0.5, n_jobs=-1, random_state=RANDOM_STATE)),
            ("HistGB_Retry", HistGradientBoostingRegressor(max_iter=200, learning_rate=0.05, max_leaf_nodes=31, l2_regularization=0.1, random_state=RANDOM_STATE)),
        ]
    except Exception as exc:
        error_rows.append({"model_name": "retry_imports", "status": "failed", "error_message": repr(exc)})

    train = features[features["split"] == "train"].copy()
    val = features[features["split"] == "validation"].copy()
    test = features[features["split"] == "test"].copy()
    X_train = train[feature_cols].replace([np.inf, -np.inf], np.nan).fillna(0)
    y_train = train[TARGET].to_numpy(float)
    X_val = val[feature_cols].replace([np.inf, -np.inf], np.nan).fillna(0)
    X_test = test[feature_cols].replace([np.inf, -np.inf], np.nan).fillna(0)

    joblib_ok, _ = package_version("joblib")
    joblib = importlib.import_module("joblib") if joblib_ok else None
    for name, model in specs:
        start = time.time()
        try:
            model.fit(X_train, y_train)
            val_col = f"prediction_{name}"
            test_col = f"prediction_{name}"
            val_pred[val_col] = clip_prediction(model.predict(X_val))
            test_pred[test_col] = clip_prediction(model.predict(X_test))
            for split, frame, col in [("validation", val_pred, val_col), ("test", test_pred, test_col)]:
                metrics_rows.append(evaluate_overall(frame, name, split, col) | {"training_time_seconds": time.time() - start, "status": "success"})
            if joblib is not None:
                joblib.dump(model, MODELS_DIR / f"08C_{name}.joblib")
        except Exception as exc:
            error_rows.append({"model_name": name, "status": "failed", "error_message": repr(exc)})
    return pd.DataFrame(metrics_rows), val_pred, test_pred, pd.DataFrame(error_rows)


def get_best_standard_metrics() -> tuple[float, float, float, float, str]:
    metrics = pd.read_csv(STANDARD_METRICS_FILE)
    val = metrics[metrics["split"] == "validation"].copy()
    test = metrics[metrics["split"] == "test"].copy()
    best_val_mae = float(val["MAE"].min())
    best_val_peak = float(val["peak_MAE"].min())
    best_test = test.sort_values("MAE").iloc[0]
    return best_val_mae, best_val_peak, float(best_test["MAE"]), float(best_test["peak_MAE"]), str(best_test["model_name"])


def add_candidate(rows: list[dict[str, Any]], preds: dict[str, np.ndarray], name: str, strategy: str, meta: dict[str, Any], val_df: pd.DataFrame, best_val_mae: float, best_val_peak: float) -> None:
    tmp = val_df[PRED_META].copy()
    tmp[TARGET] = tmp["actual_load_kw"]
    tmp["prediction"] = clip_prediction(preds["validation"])
    m = evaluate_overall(tmp, name, "validation", "prediction")
    m.update(meta)
    m["candidate_name"] = name
    m["strategy"] = strategy
    m["balanced_score"] = m["MAE"] + 0.15 * m["peak_MAE"] + 0.05 * m["high_peak_MAE"]
    m["mae_penalty_pct_vs_best_standard_val"] = 100 * (m["MAE"] - best_val_mae) / best_val_mae
    m["passed_2pct_val_MAE_constraint"] = bool(m["MAE"] <= best_val_mae * 1.02)
    m["passed_3pct_val_MAE_constraint"] = bool(m["MAE"] <= best_val_mae * 1.03)
    m["improves_validation_peak_MAE"] = bool(m["peak_MAE"] < best_val_peak)
    rows.append(m)


def build_hybrid_candidates(val_df: pd.DataFrame, test_df: pd.DataFrame, best_val_mae: float, best_val_peak: float) -> tuple[pd.DataFrame, dict[str, dict[str, np.ndarray]]]:
    rows: list[dict[str, Any]] = []
    pred_store: dict[str, dict[str, np.ndarray]] = {}
    pairs = [
        ("LGBMRegressor", "BPA_LGBM"),
        ("LGBMRegressor", "BPA_CatBoost"),
        ("LGBMRegressor", "PA_CatBoost"),
        ("CatBoostRegressor", "BPA_CatBoost"),
        ("CatBoostRegressor", "PA_CatBoost"),
        ("XGBRegressor", "BPA_XGBoost"),
        ("GradientBoostingRegressor", "BPA_GradientBoosting"),
    ]
    retry_std = ["RF_Retry", "ExtraTrees_Retry", "HistGB_Retry"]
    for retry in retry_std:
        if f"prediction_{retry}" in val_df.columns:
            pairs.append((retry, "BPA_CatBoost"))
    alphas_static = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50]
    alphas_gated = [0.15, 0.25, 0.35, 0.50, 0.65, 0.80]
    thresholds = [0.50, 0.60, 0.70, 0.80, 0.90, 1.00]
    risk_scores = ["risk_lag24_vs_site_p90", "risk_lag168_vs_site_p90", "risk_rollq90_24_vs_site_p90", "risk_rollq90_168_vs_site_p90", "risk_combined_simple"]

    for std, peak in pairs:
        s_col, p_col = f"prediction_{std}", f"prediction_{peak}"
        if s_col not in val_df.columns or p_col not in val_df.columns or s_col not in test_df.columns or p_col not in test_df.columns:
            continue
        for alpha in alphas_static:
            name = f"AHPA_static_{std}_plus_{peak}_a{alpha:.2f}"
            val_pred = (1 - alpha) * val_df[s_col].to_numpy(float) + alpha * val_df[p_col].to_numpy(float)
            test_pred = (1 - alpha) * test_df[s_col].to_numpy(float) + alpha * test_df[p_col].to_numpy(float)
            pred_store[name] = {"validation": clip_prediction(val_pred), "test": clip_prediction(test_pred)}
            add_candidate(rows, pred_store[name], name, "static_weighted_blend", {"base_standard_model": std, "peak_model": peak, "alpha": alpha, "risk_score": "", "threshold": np.nan, "meta_model": ""}, val_df, best_val_mae, best_val_peak)
        for risk in risk_scores:
            if risk not in val_df.columns or risk not in test_df.columns:
                continue
            for threshold in thresholds:
                for alpha in alphas_gated:
                    name = f"AHPA_gated_{std}_plus_{peak}_{risk}_t{threshold:.2f}_a{alpha:.2f}"
                    vg = val_df[risk].to_numpy(float) >= threshold
                    tg = test_df[risk].to_numpy(float) >= threshold
                    val_pred = val_df[s_col].to_numpy(float).copy()
                    test_pred = test_df[s_col].to_numpy(float).copy()
                    val_pred[vg] = (1 - alpha) * val_df.loc[vg, s_col].to_numpy(float) + alpha * val_df.loc[vg, p_col].to_numpy(float)
                    test_pred[tg] = (1 - alpha) * test_df.loc[tg, s_col].to_numpy(float) + alpha * test_df.loc[tg, p_col].to_numpy(float)
                    pred_store[name] = {"validation": clip_prediction(val_pred), "test": clip_prediction(test_pred)}
                    add_candidate(rows, pred_store[name], name, "peak_risk_gated_blend", {"base_standard_model": std, "peak_model": peak, "alpha": alpha, "risk_score": risk, "threshold": threshold, "meta_model": ""}, val_df, best_val_mae, best_val_peak)
            for threshold in thresholds:
                name = f"AHPA_switch_{std}_to_{peak}_{risk}_t{threshold:.2f}"
                vg = val_df[risk].to_numpy(float) >= threshold
                tg = test_df[risk].to_numpy(float) >= threshold
                val_pred = val_df[s_col].to_numpy(float).copy()
                test_pred = test_df[s_col].to_numpy(float).copy()
                val_pred[vg] = val_df.loc[vg, p_col].to_numpy(float)
                test_pred[tg] = test_df.loc[tg, p_col].to_numpy(float)
                pred_store[name] = {"validation": clip_prediction(val_pred), "test": clip_prediction(test_pred)}
                add_candidate(rows, pred_store[name], name, "peak_risk_switch", {"base_standard_model": std, "peak_model": peak, "alpha": 1.0, "risk_score": risk, "threshold": threshold, "meta_model": ""}, val_df, best_val_mae, best_val_peak)

    build_meta_candidates(val_df, test_df, rows, pred_store, best_val_mae, best_val_peak)
    return pd.DataFrame(rows), pred_store


def build_meta_candidates(val_df: pd.DataFrame, test_df: pd.DataFrame, rows: list[dict[str, Any]], pred_store: dict[str, dict[str, np.ndarray]], best_val_mae: float, best_val_peak: float) -> None:
    try:
        from sklearn.ensemble import GradientBoostingRegressor
        from sklearn.linear_model import LinearRegression, Ridge
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
        from sklearn.base import clone
    except Exception:
        return
    joblib_ok, _ = package_version("joblib")
    joblib = importlib.import_module("joblib") if joblib_ok else None
    risk_cols = [c for c in base_risk_columns() if c in val_df.columns]
    correction_models = [
        ("ridge", make_pipeline(StandardScaler(), Ridge(alpha=1.0))),
        ("shallow_gbr", GradientBoostingRegressor(n_estimators=80, learning_rate=0.04, max_depth=2, random_state=RANDOM_STATE)),
    ]

    def chronological_oof(model: Any, X: pd.DataFrame, y: np.ndarray, fallback: np.ndarray) -> np.ndarray:
        """Validation-only forward OOF predictions for meta-model selection."""
        n = len(X)
        order = np.argsort(val_df["timestamp"].astype(str).to_numpy())
        pred = fallback.astype(float).copy()
        boundaries = np.linspace(0, n, 5, dtype=int)
        for fold in range(1, len(boundaries) - 1):
            train_order = order[: boundaries[fold]]
            valid_order = order[boundaries[fold] : boundaries[fold + 1]]
            if len(train_order) < 50 or len(valid_order) == 0:
                continue
            local_model = clone(model)
            local_model.fit(X.iloc[train_order], y[train_order])
            pred[valid_order] = local_model.predict(X.iloc[valid_order])
        return pred

    for std in ["LGBMRegressor", "CatBoostRegressor"]:
        s_col = f"prediction_{std}"
        if s_col not in val_df.columns or s_col not in test_df.columns:
            continue
        residual = val_df[TARGET].to_numpy(float) - val_df[s_col].to_numpy(float)
        Xv = val_df[risk_cols].replace([np.inf, -np.inf], np.nan).fillna(0)
        Xt = test_df[risk_cols].replace([np.inf, -np.inf], np.nan).fillna(0)
        for model_id, model in correction_models:
            try:
                name = f"AHPA_error_corrected_{std}_{model_id}"
                val_corr = chronological_oof(model, Xv, residual, np.zeros(len(Xv)))
                model.fit(Xv, residual)
                val_pred = val_df[s_col].to_numpy(float) + val_corr
                test_pred = test_df[s_col].to_numpy(float) + model.predict(Xt)
                pred_store[name] = {"validation": clip_prediction(val_pred), "test": clip_prediction(test_pred)}
                add_candidate(rows, pred_store[name], name, "error_corrected_standard_model", {"base_standard_model": std, "peak_model": "", "alpha": np.nan, "risk_score": "peak_risk_features", "threshold": np.nan, "meta_model": model_id}, val_df, best_val_mae, best_val_peak)
                if joblib is not None:
                    joblib.dump(model, MODELS_DIR / f"08C_{name}.joblib")
            except Exception:
                continue

    sets = {
        "top2": ["prediction_LGBMRegressor", "prediction_BPA_CatBoost"],
        "top3": ["prediction_LGBMRegressor", "prediction_CatBoostRegressor", "prediction_BPA_CatBoost"],
        "top4": ["prediction_LGBMRegressor", "prediction_CatBoostRegressor", "prediction_BPA_LGBM", "prediction_BPA_CatBoost"],
        "top4_plus_risk": ["prediction_LGBMRegressor", "prediction_CatBoostRegressor", "prediction_BPA_LGBM", "prediction_BPA_CatBoost"] + risk_cols,
    }
    learners = [
        ("ridge", make_pipeline(StandardScaler(), Ridge(alpha=1.0))),
        ("linear", LinearRegression()),
        ("shallow_gbr", GradientBoostingRegressor(n_estimators=80, learning_rate=0.04, max_depth=2, random_state=RANDOM_STATE)),
    ]
    for set_id, cols in sets.items():
        if not all(c in val_df.columns and c in test_df.columns for c in cols):
            continue
        Xv = val_df[cols].replace([np.inf, -np.inf], np.nan).fillna(0)
        Xt = test_df[cols].replace([np.inf, -np.inf], np.nan).fillna(0)
        yv = val_df[TARGET].to_numpy(float)
        for learner_id, learner in learners:
            try:
                name = f"AHPA_stacked_{set_id}_{learner_id}"
                fallback = val_df["prediction_LGBMRegressor"].to_numpy(float) if "prediction_LGBMRegressor" in val_df.columns else np.full(len(Xv), np.mean(yv))
                val_pred = chronological_oof(learner, Xv, yv, fallback)
                learner.fit(Xv, yv)
                pred_store[name] = {"validation": clip_prediction(val_pred), "test": clip_prediction(learner.predict(Xt))}
                add_candidate(rows, pred_store[name], name, "stacked_blending_validation_meta_learner", {"base_standard_model": "multiple", "peak_model": "multiple", "alpha": np.nan, "risk_score": "included" if "risk" in set_id else "", "threshold": np.nan, "meta_model": learner_id}, val_df, best_val_mae, best_val_peak)
                if joblib is not None:
                    joblib.dump(learner, MODELS_DIR / f"08C_{name}.joblib")
            except Exception:
                continue


def select_candidates(candidates: pd.DataFrame) -> tuple[pd.DataFrame, str]:
    acceptable = candidates[(candidates["passed_2pct_val_MAE_constraint"]) & (candidates["improves_validation_peak_MAE"])].copy()
    rule = "lowest validation balanced_score among candidates improving peak_MAE within 2% validation MAE"
    if acceptable.empty:
        acceptable = candidates[(candidates["passed_3pct_val_MAE_constraint"]) & (candidates["improves_validation_peak_MAE"])].copy()
        rule = "lowest validation balanced_score among candidates improving peak_MAE within 3% validation MAE"
    if acceptable.empty:
        acceptable = candidates.copy()
        rule = "lowest validation balanced_score because no candidate met peak improvement and 2%/3% MAE constraints"
    primary = acceptable.sort_values("balanced_score").head(1)
    picks = [
        primary,
        candidates.sort_values("MAE").head(1),
        candidates.sort_values("peak_MAE").head(1),
        candidates.sort_values("high_peak_MAE").head(1),
        candidates.sort_values("balanced_score").head(1),
    ]
    selected = pd.concat(picks, ignore_index=True).drop_duplicates("candidate_name")
    selected.loc[selected["candidate_name"] == primary.iloc[0]["candidate_name"], "selection_role"] = "primary_selected_AHPA_Ensemble"
    selected["selection_role"] = selected["selection_role"].fillna("secondary_validation_selected")
    selected["selection_rule_used"] = rule
    return selected, rule


def evaluate_candidate_test(candidates: pd.DataFrame, pred_store: dict[str, dict[str, np.ndarray]], test_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, row in candidates.iterrows():
        name = row["candidate_name"]
        tmp = test_df[PRED_META].copy()
        tmp[TARGET] = tmp["actual_load_kw"]
        tmp["prediction"] = pred_store[name]["test"]
        m = evaluate_overall(tmp, name, "test", "prediction")
        for col in ["strategy", "base_standard_model", "peak_model", "alpha", "risk_score", "threshold", "meta_model"]:
            m[col] = row.get(col, np.nan)
        m["analysis_only_test_evaluation"] = True
        rows.append(m)
    return pd.DataFrame(rows)


def make_comparison_rows(ahpa_metrics: pd.DataFrame, selected_primary_name: str, best_standard_test_mae: float, best_standard_test_peak: float) -> pd.DataFrame:
    rows = []
    sources = [
        ("baseline", BASELINE_METRICS_FILE, "Baseline"),
        ("standard_ml", STANDARD_METRICS_FILE, "Standard ML"),
        ("old_peak_aware", OLD_PA_METRICS_FILE, "Old PA"),
        ("balanced_peak_aware", BPA_METRICS_FILE, "BPA"),
    ]
    for group, path, label in sources:
        if not path.exists():
            continue
        df = pd.read_csv(path)
        test = df[df["split"] == "test"].copy()
        if test.empty:
            continue
        best = test.sort_values("MAE").iloc[0]
        peak_best = test.sort_values("peak_MAE").iloc[0]
        for tag, row in [("best_MAE", best), ("best_peak_MAE", peak_best)]:
            rows.append(
                {
                    "method_name": f"{row['model_name']} ({tag})",
                    "method_group": label,
                    "test_MAE": row["MAE"],
                    "test_RMSE": row["RMSE"],
                    "test_peak_MAE": row["peak_MAE"],
                    "test_high_peak_MAE": row.get("high_peak_MAE", np.nan),
                    "test_peak_underestimation_rate": row.get("peak_underestimation_rate", np.nan),
                }
            )
    ahpa_row = ahpa_metrics[(ahpa_metrics["split"] == "test") & (ahpa_metrics["model_name"] == selected_primary_name)].iloc[0]
    rows.append(
        {
            "method_name": selected_primary_name,
            "method_group": "AHPA-Ensemble",
            "test_MAE": ahpa_row["MAE"],
            "test_RMSE": ahpa_row["RMSE"],
            "test_peak_MAE": ahpa_row["peak_MAE"],
            "test_high_peak_MAE": ahpa_row["high_peak_MAE"],
            "test_peak_underestimation_rate": ahpa_row["peak_underestimation_rate"],
        }
    )
    out = pd.DataFrame(rows).drop_duplicates(["method_name", "method_group"])
    out["delta_MAE_vs_best_standard"] = out["test_MAE"] - best_standard_test_mae
    out["delta_peak_MAE_vs_best_standard"] = out["test_peak_MAE"] - best_standard_test_peak
    out["pct_change_MAE_vs_best_standard"] = 100 * out["delta_MAE_vs_best_standard"] / best_standard_test_mae
    out["pct_change_peak_MAE_vs_best_standard"] = 100 * out["delta_peak_MAE_vs_best_standard"] / best_standard_test_peak
    return out


def save_figures(candidate_val: pd.DataFrame, comparison: pd.DataFrame, selected_name: str, val_df: pd.DataFrame, test_df: pd.DataFrame, selected_pred: dict[str, np.ndarray], ahpa_site: pd.DataFrame) -> None:
    plt.figure(figsize=(8, 6))
    for strategy, sdf in candidate_val.groupby("strategy"):
        plt.scatter(sdf["MAE"], sdf["peak_MAE"], s=12, alpha=0.45, label=strategy)
    plt.xlabel("Validation MAE")
    plt.ylabel("Validation peak_MAE")
    plt.title("08C validation tradeoff candidates")
    plt.legend(fontsize=7)
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08C_fig1_validation_tradeoff_candidates.png", dpi=300)
    plt.close()

    plt.figure(figsize=(7, 5))
    plt.scatter(comparison["test_MAE"], comparison["test_peak_MAE"], s=55)
    for _, r in comparison.iterrows():
        plt.annotate(str(r["method_group"]), (r["test_MAE"], r["test_peak_MAE"]), fontsize=7)
    plt.xlabel("Test MAE")
    plt.ylabel("Test peak_MAE")
    plt.title("08C test tradeoff final methods")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08C_fig2_test_tradeoff_final_methods.png", dpi=300)
    plt.close()

    for idx, metric, title in [
        (3, "test_MAE", "Test MAE comparison"),
        (4, "test_peak_MAE", "Test peak_MAE comparison"),
        (5, "test_high_peak_MAE", "Test high_peak_MAE comparison"),
        (6, "test_peak_underestimation_rate", "Peak underestimation comparison"),
    ]:
        plt.figure(figsize=(9, 5))
        x = comparison["method_group"] + "\n" + comparison["method_name"].astype(str).str.slice(0, 20)
        plt.bar(range(len(comparison)), comparison[metric])
        plt.xticks(range(len(comparison)), x, rotation=35, ha="right", fontsize=7)
        plt.ylabel(metric)
        plt.title(title)
        plt.tight_layout()
        plt.savefig(FIGURES_DIR / f"08C_fig{idx}_{title.lower().replace(' ', '_')}.png", dpi=300)
        plt.close()

    sample = test_df.sort_values(["site_id", "timestamp"]).head(24 * 7).copy()
    sample["AHPA"] = selected_pred["test"][: len(test_df)][sample.index.to_numpy()] if np.array_equal(sample.index.to_numpy(), np.arange(len(sample))) else selected_pred["test"][sample.index.to_numpy()]
    plt.figure(figsize=(10, 5))
    plt.plot(sample["actual_load_kw"].to_numpy(), label="Actual", linewidth=1.5)
    if "prediction_LGBMRegressor" in sample.columns:
        plt.plot(sample["prediction_LGBMRegressor"].to_numpy(), label="Standard LGBM", linewidth=1.0)
    plt.plot(sample["AHPA"].to_numpy(), label="Selected AHPA", linewidth=1.0)
    plt.legend()
    plt.title("Actual vs standard vs AHPA test sample")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08C_fig7_actual_vs_standard_vs_ahpa_test_sample.png", dpi=300)
    plt.close()

    plt.figure(figsize=(10, 5))
    plt.plot(sample["actual_load_kw"].to_numpy(), label="Actual", linewidth=1.5)
    for col, lab in [("prediction_LGBMRegressor", "Standard LGBM"), ("prediction_BPA_CatBoost", "BPA CatBoost")]:
        if col in sample.columns:
            plt.plot(sample[col].to_numpy(), label=lab, linewidth=1.0)
    plt.plot(sample["AHPA"].to_numpy(), label="Selected AHPA", linewidth=1.0)
    plt.legend()
    plt.title("Actual vs standard vs BPA vs AHPA test sample")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08C_fig8_actual_vs_standard_vs_bpa_vs_ahpa_test_sample.png", dpi=300)
    plt.close()

    plt.figure(figsize=(10, 5))
    site_plot = ahpa_site[ahpa_site["split"] == "test"].sort_values("peak_MAE")
    plt.bar(site_plot["site_id"].astype(str), site_plot["peak_MAE"])
    plt.xticks(rotation=45, ha="right")
    plt.ylabel("Peak MAE")
    plt.title("Site-level peak_MAE for selected AHPA candidates")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08C_fig9_site_level_peak_mae.png", dpi=300)
    plt.close()

    counts = candidate_val.groupby("strategy").agg(candidates=("candidate_name", "count"), passed_2pct=("passed_2pct_val_MAE_constraint", "sum"), passed_3pct=("passed_3pct_val_MAE_constraint", "sum")).reset_index()
    plt.figure(figsize=(9, 5))
    x = np.arange(len(counts))
    plt.bar(x - 0.2, counts["candidates"], width=0.2, label="tested")
    plt.bar(x, counts["passed_2pct"], width=0.2, label="2pct")
    plt.bar(x + 0.2, counts["passed_3pct"], width=0.2, label="3pct")
    plt.xticks(x, counts["strategy"], rotation=35, ha="right", fontsize=8)
    plt.legend()
    plt.title("Hybrid strategy counts")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08C_fig10_hybrid_strategy_counts.png", dpi=300)
    plt.close()

    plt.figure(figsize=(8, 5))
    if "risk_combined_simple" in val_df.columns:
        normal = val_df.loc[val_df["is_peak_hour"] == 0, "risk_combined_simple"]
        peak = val_df.loc[val_df["is_peak_hour"] == 1, "risk_combined_simple"]
        plt.hist(normal, bins=40, alpha=0.6, label="normal")
        plt.hist(peak, bins=40, alpha=0.6, label="peak")
        plt.legend()
    plt.title("Risk distribution for validation rows")
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "08C_fig11_meta_or_gating_risk_distribution.png", dpi=300)
    plt.close()


def write_reports(summary: pd.DataFrame, comparison: pd.DataFrame, retry_errors: pd.DataFrame, n_candidates: int, bests: dict[str, Any]) -> None:
    primary = summary[summary["selection_role"] == "primary_selected_AHPA_Ensemble"].iloc[0]
    proposed = """Step 08C proposed method report
=================================
AHPA-Ensemble is an Adaptive Hybrid Peak-Aware Ensemble for EV charging load forecasting.
It treats standard ML and peak-aware models as complementary forecasters rather than forcing one model to solve all operating regimes.
Standard ML is retained for ordinary low-load and moderate-load hours where it gives strong average accuracy.
Peak-aware PA/BPA predictions are blended, switched, or stacked when validation-only evidence suggests better peak behavior.
Pure peak weighting harmed overall MAE in Step 08 and Step 08B because the model paid too much attention to rare high-load rows.
AHPA fixes the tradeoff by testing static blends, risk-gated blends, risk switches, residual correction, and validation-trained stacking.
The selection rule requires validation MAE to stay within 2%, then 3% if needed, while improving validation peak_MAE.
This validation-constrained design avoids overclaiming and makes AHPA a stronger contribution than either standard ML or simple peak weighting alone.
"""
    leakage = """Step 08C leakage safety report
================================
- Step 05B chronological split was used without shuffling or random resplitting.
- Previous model predictions were aligned by timestamp, site_id, actual_load_kw, and split.
- Hybrid parameters and meta-models were selected or fitted using validation rows only.
- Test rows were used only for final evaluation and analysis-only candidate diagnostics.
- Peak labels were not used as test-time predictors.
- Peak-risk gating used past-load and calendar features available before prediction.
- Correction and stacking meta-models were trained only on validation rows after base models were fixed.
- No future load, future sessions, weather, price, traffic, or external data were used.
"""
    novelty = """Step 08C novelty contribution report
=====================================
This study proposes an adaptive hybrid peak-aware ensemble for calendar-enhanced EV charging load forecasting.
The method builds on leakage-free lag, rolling-load, site, and calendar features from Step 05B.
It exploits the complementarity between standard machine-learning models, which are accurate during ordinary hours, and peak-aware models, which better represent high-demand periods.
Instead of applying a single aggressive peak weighting rule, AHPA evaluates adaptive blending, risk-gated switching, residual correction, and validation-trained stacking.
A validation-constrained selection rule preserves average-load accuracy while targeting improved peak-load prediction.
This matters for later constrained scheduling because peak forecast errors directly affect transformer loading, capacity planning, and charging-shift decisions.
"""
    results = f"""Step 08C results report
========================
Previous Step 07 best standard ML test MAE: {bests['standard_test_mae']:.4f} kW; peak_MAE: {bests['standard_test_peak']:.4f} kW.
Previous Step 08 old PA best test MAE: {bests['old_pa_mae']:.4f} kW; peak_MAE: {bests['old_pa_peak']:.4f} kW.
Previous Step 08B BPA best test MAE: {bests['bpa_mae']:.4f} kW; peak_MAE: {bests['bpa_peak']:.4f} kW.
Retry model failures: {len(retry_errors)}.
Hybrid candidates tested: {n_candidates}.
Selected AHPA model: {primary['selected_model_name']}.
Selected strategy: {primary['strategy']}.
Validation MAE: {primary['validation_MAE']:.4f} kW; validation peak_MAE: {primary['validation_peak_MAE']:.4f} kW.
Test MAE: {primary['test_MAE']:.4f} kW; test peak_MAE: {primary['test_peak_MAE']:.4f} kW; test high_peak_MAE: {primary['test_high_peak_MAE']:.4f} kW.
AHPA improves overall MAE vs best standard ML: {primary['test_MAE'] < bests['standard_test_mae']}.
AHPA improves peak_MAE vs best standard ML: {primary['test_peak_MAE'] < bests['standard_test_peak']}.
AHPA passed 2% validation MAE constraint: {primary['passed_2pct_val_MAE_constraint']}.
AHPA passed 3% validation MAE constraint: {primary['passed_3pct_val_MAE_constraint']}.
Final recommendation for paper: use AHPA-Ensemble as the proposed forecasting contribution if the manuscript clearly states the validation-constrained selection rule and reports both average-load and peak-load tradeoffs.
Limitations: test candidate rankings are analysis-only, and any improvement should be confirmed with the next statistical comparison step before scheduling claims are made.
"""
    paper = f"""The proposed AHPA-Ensemble selected {primary['strategy']} using validation-only constrained selection. On the test period, AHPA achieved MAE = {primary['test_MAE']:.4f} kW, peak_MAE = {primary['test_peak_MAE']:.4f} kW, and high_peak_MAE = {primary['test_high_peak_MAE']:.4f} kW, compared with the best Step 07 standard ML result of MAE = {bests['standard_test_mae']:.4f} kW and peak_MAE = {bests['standard_test_peak']:.4f} kW. These results indicate that adaptive hybridization can reduce the tradeoff observed in purely peak-weighted models, although the claim should be presented cautiously because the hybrid was selected using validation performance and the test set was reserved only for final evaluation."""
    captions = """Figure captions for Step 08C
============================
Fig. 1. Validation MAE versus validation peak_MAE for all AHPA hybrid candidates.
Fig. 2. Test MAE versus test peak_MAE for best baseline, standard ML, PA, BPA, and AHPA methods.
Fig. 3. Test MAE comparison across final method groups.
Fig. 4. Test peak_MAE comparison across final method groups.
Fig. 5. Test high_peak_MAE comparison across final method groups.
Fig. 6. Peak underestimation rate comparison across final method groups.
Fig. 7. Representative test-window actual load, standard ML prediction, and selected AHPA prediction.
Fig. 8. Representative test-window actual load, standard ML prediction, BPA prediction, and selected AHPA prediction.
Fig. 9. Site-level peak_MAE for selected AHPA candidates.
Fig. 10. Number of hybrid candidates tested and passing validation MAE constraints by strategy.
Fig. 11. Validation peak-risk distribution used for gating or meta-learning interpretation.
"""
    (RESULTS_DIR / "08C_proposed_method_report.txt").write_text(proposed, encoding="utf-8")
    (RESULTS_DIR / "08C_leakage_safety_report.txt").write_text(leakage, encoding="utf-8")
    (RESULTS_DIR / "08C_novelty_contribution_report.txt").write_text(novelty, encoding="utf-8")
    (RESULTS_DIR / "08C_results_report.txt").write_text(results, encoding="utf-8")
    (RESULTS_DIR / "08C_paper_ready_results_paragraph.txt").write_text(paper, encoding="utf-8")
    (RESULTS_DIR / "08C_figure_captions.txt").write_text(captions, encoding="utf-8")


def main() -> None:
    ensure_dirs()
    feature_cols = [line.strip() for line in FEATURE_COLUMNS_FILE.read_text(encoding="utf-8").splitlines() if line.strip()]
    features = pd.read_csv(FEATURE_FILE)
    if "actual_load_kw" not in features.columns:
        features["actual_load_kw"] = features[TARGET]
    features["timestamp"] = features["timestamp"].astype(str)
    for folder_col in PRED_META:
        if folder_col not in features.columns and folder_col == "actual_load_kw":
            features[folder_col] = features[TARGET]

    risk = build_risk_features(features)
    risk_summary_cols = ["split"] + base_risk_columns()
    risk[risk_summary_cols].describe(include="all").transpose().to_csv(RESULTS_DIR / "08C_peak_risk_feature_summary.csv")
    risk[["timestamp", "site_id", "split"] + base_risk_columns()].to_csv(RESULTS_DIR / "08C_internal_peak_risk_enhanced_features.csv", index=False)

    diagnostics: list[dict[str, Any]] = []
    val_preds = combine_predictions(
        [(STANDARD_VAL_PRED_FILE, "Step07 validation"), (OLD_PA_VAL_PRED_FILE, "Step08 validation"), (BPA_VAL_PRED_FILE, "Step08B validation")],
        "validation",
        diagnostics,
    )
    test_preds = combine_predictions(
        [(BASELINE_TEST_PRED_FILE, "Step06 test"), (STANDARD_TEST_PRED_FILE, "Step07 test"), (OLD_PA_TEST_PRED_FILE, "Step08 test"), (BPA_TEST_PRED_FILE, "Step08B test")],
        "test",
        diagnostics,
    )
    val_preds = merge_risk(val_preds, risk, "validation")
    test_preds = merge_risk(test_preds, risk, "test")

    site_means = features[features["split"] == "train"].groupby("site_id")[TARGET].mean().to_dict()
    retry_metrics, retry_val, retry_test, retry_errors = retry_models(features, feature_cols, site_means)
    retry_metrics.to_csv(RESULTS_DIR / "08C_retry_model_metrics.csv", index=False)
    retry_val.drop(columns=[TARGET], errors="ignore").to_csv(RESULTS_DIR / "08C_retry_model_predictions_validation.csv", index=False)
    retry_test.drop(columns=[TARGET], errors="ignore").to_csv(RESULTS_DIR / "08C_retry_model_predictions_test.csv", index=False)
    retry_errors.to_csv(RESULTS_DIR / "08C_retry_model_error_log.csv", index=False)
    if any(c.startswith("prediction_") for c in retry_val.columns):
        val_preds = val_preds.merge(retry_val[KEYS + [c for c in retry_val.columns if c.startswith("prediction_")]], on=KEYS, how="left")
        test_preds = test_preds.merge(retry_test[KEYS + [c for c in retry_test.columns if c.startswith("prediction_")]], on=KEYS, how="left")

    pd.DataFrame(diagnostics).to_csv(RESULTS_DIR / "08C_prediction_alignment_diagnostics.csv", index=False)
    best_val_mae, best_val_peak, standard_test_mae, standard_test_peak, best_standard_name = get_best_standard_metrics()
    candidate_val, pred_store = build_hybrid_candidates(val_preds, test_preds, best_val_mae, best_val_peak)
    selected, selection_rule = select_candidates(candidate_val)
    candidate_test = evaluate_candidate_test(candidate_val, pred_store, test_preds)

    candidate_val.to_csv(RESULTS_DIR / "08C_hybrid_candidate_validation_results.csv", index=False)
    candidate_test.to_csv(RESULTS_DIR / "08C_hybrid_candidate_test_results.csv", index=False)

    selected_names = selected["candidate_name"].tolist()
    overall_rows: list[dict[str, Any]] = []
    site_rows: list[dict[str, Any]] = []
    val_out = val_preds[PRED_META].copy()
    test_out = test_preds[PRED_META].copy()
    for name in selected_names:
        for split, frame, out_frame in [("validation", val_preds, val_out), ("test", test_preds, test_out)]:
            tmp = frame[PRED_META].copy()
            tmp[TARGET] = tmp["actual_load_kw"]
            col = f"prediction_{name}"
            tmp[col] = pred_store[name][split]
            out_frame[col] = tmp[col]
            overall_rows.append(evaluate_overall(tmp, name, split, col))
            site_rows.extend(evaluate_site(tmp, name, split, col, site_means))
    ahpa_overall = pd.DataFrame(overall_rows)
    ahpa_site = pd.DataFrame(site_rows)
    ahpa_overall.to_csv(RESULTS_DIR / "08C_ahpa_overall_metrics.csv", index=False)
    ahpa_site.to_csv(RESULTS_DIR / "08C_ahpa_site_metrics.csv", index=False)
    val_out.to_csv(RESULTS_DIR / "08C_validation_predictions.csv", index=False)
    test_out.to_csv(RESULTS_DIR / "08C_test_predictions.csv", index=False)

    summary_rows = []
    for _, row in selected.iterrows():
        name = row["candidate_name"]
        test_row = ahpa_overall[(ahpa_overall["model_name"] == name) & (ahpa_overall["split"] == "test")].iloc[0]
        summary_rows.append(
            {
                "selected_model_name": name,
                "selection_role": row["selection_role"],
                "strategy": row["strategy"],
                "base_standard_model": row.get("base_standard_model", ""),
                "peak_model": row.get("peak_model", ""),
                "alpha": row.get("alpha", np.nan),
                "risk_score": row.get("risk_score", ""),
                "threshold": row.get("threshold", np.nan),
                "meta_model": row.get("meta_model", ""),
                "validation_MAE": row["MAE"],
                "validation_peak_MAE": row["peak_MAE"],
                "validation_high_peak_MAE": row["high_peak_MAE"],
                "test_MAE": test_row["MAE"],
                "test_peak_MAE": test_row["peak_MAE"],
                "test_high_peak_MAE": test_row["high_peak_MAE"],
                "selection_rule_used": row["selection_rule_used"],
                "passed_2pct_val_MAE_constraint": row["passed_2pct_val_MAE_constraint"],
                "passed_3pct_val_MAE_constraint": row["passed_3pct_val_MAE_constraint"],
            }
        )
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(RESULTS_DIR / "08C_selected_hybrid_summary.csv", index=False)

    old_pa = pd.read_csv(OLD_PA_METRICS_FILE)
    bpa = pd.read_csv(BPA_METRICS_FILE)
    old_pa_test = old_pa[old_pa["split"] == "test"]
    bpa_test = bpa[bpa["split"] == "test"]
    bests = {
        "standard_test_mae": standard_test_mae,
        "standard_test_peak": standard_test_peak,
        "old_pa_mae": float(old_pa_test["MAE"].min()),
        "old_pa_peak": float(old_pa_test["peak_MAE"].min()),
        "bpa_mae": float(bpa_test["MAE"].min()),
        "bpa_peak": float(bpa_test["peak_MAE"].min()),
    }
    primary_name = summary[summary["selection_role"] == "primary_selected_AHPA_Ensemble"].iloc[0]["selected_model_name"]
    comparison = make_comparison_rows(ahpa_overall, primary_name, standard_test_mae, standard_test_peak)
    comparison.to_csv(RESULTS_DIR / "08C_ahpa_vs_standard_bpa_comparison.csv", index=False)
    ranking = pd.concat(
        [
            comparison.assign(model_name=comparison["method_name"], split="test", MAE=comparison["test_MAE"], RMSE=comparison["test_RMSE"], peak_MAE=comparison["test_peak_MAE"], high_peak_MAE=comparison["test_high_peak_MAE"]),
            candidate_test.assign(method_group="AHPA candidate", test_MAE=candidate_test["MAE"], test_peak_MAE=candidate_test["peak_MAE"], test_high_peak_MAE=candidate_test["high_peak_MAE"]),
        ],
        ignore_index=True,
        sort=False,
    )
    ranking["balanced_score"] = ranking["test_MAE"].fillna(ranking["MAE"]) + 0.15 * ranking["test_peak_MAE"].fillna(ranking["peak_MAE"]) + 0.05 * ranking["test_high_peak_MAE"].fillna(ranking["high_peak_MAE"])
    ranking["rank_test_MAE"] = ranking["test_MAE"].fillna(ranking["MAE"]).rank(method="min")
    ranking["rank_test_peak_MAE"] = ranking["test_peak_MAE"].fillna(ranking["peak_MAE"]).rank(method="min")
    ranking["rank_test_high_peak_MAE"] = ranking["test_high_peak_MAE"].fillna(ranking["high_peak_MAE"]).rank(method="min")
    ranking["rank_balanced_score"] = ranking["balanced_score"].rank(method="min")
    ranking.to_csv(RESULTS_DIR / "08C_final_all_methods_ranking.csv", index=False)

    packages = []
    for pkg in ["pandas", "numpy", "matplotlib", "sklearn", "joblib"]:
        ok, version = package_version(pkg)
        packages.append({"package": pkg, "available": ok, "version": version})
    pd.DataFrame(packages).to_csv(RESULTS_DIR / "08C_package_availability.csv", index=False)

    save_figures(candidate_val, comparison, primary_name, val_preds, test_preds, pred_store[primary_name], ahpa_site)
    write_reports(summary, comparison, retry_errors, len(candidate_val), bests)

    primary = summary[summary["selection_role"] == "primary_selected_AHPA_Ensemble"].iloc[0]
    retry_success = len([c for c in retry_val.columns if c.startswith("prediction_")])
    print("Step 08C adaptive hybrid peak-aware ensemble complete")
    print(f"Input shape: {features.shape}")
    print(f"Train/validation/test rows: {(features['split'] == 'train').sum()}/{(features['split'] == 'validation').sum()}/{(features['split'] == 'test').sum()}")
    print(f"Previous best standard ML test MAE and peak_MAE: {standard_test_mae:.4f}, {standard_test_peak:.4f} ({best_standard_name})")
    print(f"Previous old PA best test MAE and peak_MAE: {bests['old_pa_mae']:.4f}, {bests['old_pa_peak']:.4f}")
    print(f"Previous BPA best test MAE and peak_MAE: {bests['bpa_mae']:.4f}, {bests['bpa_peak']:.4f}")
    print(f"Retry models succeeded/failed: {retry_success}/{len(retry_errors)}")
    print(f"Hybrid candidates tested: {len(candidate_val)}")
    print(f"Candidates passing 2%/3% validation MAE constraint: {int(candidate_val['passed_2pct_val_MAE_constraint'].sum())}/{int(candidate_val['passed_3pct_val_MAE_constraint'].sum())}")
    print(f"Selected AHPA strategy: {primary['strategy']}")
    print(f"Selected AHPA validation MAE and peak_MAE: {primary['validation_MAE']:.4f}, {primary['validation_peak_MAE']:.4f}")
    print(f"Selected AHPA test MAE and peak_MAE: {primary['test_MAE']:.4f}, {primary['test_peak_MAE']:.4f}")
    print(f"AHPA improves over standard ML in MAE: {primary['test_MAE'] < standard_test_mae}")
    print(f"AHPA improves over standard ML in peak_MAE: {primary['test_peak_MAE'] < standard_test_peak}")
    print("Final recommendation for paper: AHPA-Ensemble with validation-constrained selection")
    print(f"Output reports: {RESULTS_DIR}")
    print(f"Output figures: {FIGURES_DIR}")


if __name__ == "__main__":
    main()
