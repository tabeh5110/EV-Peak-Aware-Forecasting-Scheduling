"""
Data audit for the EV charging load prediction and scheduling project.

Run from the project root:
    python src/01_data_audit.py

This script only inspects files in data/raw/. It does not modify, clean,
delete, or overwrite any raw data file.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import re
import sys
import types
import zipfile


# Environment guard:
# This workstation's Python 3.10 standard-library _strptime.py has been
# accidentally overwritten by old project code. Pandas imports _strptime at
# startup, so provide the tiny import-time API pandas expects without modifying
# the external Python installation. The audit uses pandas' flexible parser and
# does not rely on datetime.strptime.
if "_strptime" not in sys.modules:
    _strptime_stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover - import compatibility shim
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover - import compatibility shim
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover - import compatibility shim
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    _strptime_stub.LocaleTime = LocaleTime
    _strptime_stub.TimeRE = TimeRE
    _strptime_stub._TimeRE_cache = TimeRE()
    _strptime_stub._regex_cache = {}
    _strptime_stub._getlang = _getlang
    _strptime_stub._strptime = _strptime
    _strptime_stub._strptime_time = _strptime
    _strptime_stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = _strptime_stub

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = PROJECT_ROOT / "data" / "raw"
OUTPUT_DIR = PROJECT_ROOT / "results" / "01_data_audit"

TIME_NAME_HINTS = (
    "timestamp",
    "time",
    "arrival_time",
    "departure_time",
    "done_time",
    "requesteddeparture",
    "datetime",
    "date",
)

SESSION_COLUMNS = [
    "arrival_time",
    "departure_time",
    "done_time",
    "energy_kwh",
    "kWhRequested",
    "minutesAvailable",
    "stationID",
    "spaceID",
    "siteID",
    "timezone",
    "requestedDeparture",
]

HOURLY_TOTAL_FILES = [
    "Arroyo_Garage_01_hourly_total.csv",
    "California_Garage_01_hourly_total.csv",
    "California_Garage_02_hourly_total.csv",
    "N_Wilson_Garage_01_hourly_total.csv",
    "Parking_Lot_01_hourly_total.csv",
    "S_Wilson_Garage_01_hourly_total.csv",
]

EXPECTED_OFFICIAL_INPUTS = [
    "clean_sessions.csv",
    "hourly_load.csv",
    "hourly_split.csv",
    "transfer_learning_results.csv",
    *HOURLY_TOTAL_FILES,
]


def classify_file(path: Path) -> str:
    """Classify a file by name and extension without changing it."""
    name = path.name.lower()
    suffix = path.suffix.lower()

    if suffix == ".zip":
        return "archive/backup file"
    if name == "clean_sessions.csv":
        return "official raw session data"
    if name in {"hourly_load.csv", "hourly_split.csv"} or name.endswith("_hourly_total.csv"):
        return "official hourly load data"
    if "24h_dataset" in name:
        return "old derived 24h dataset"
    if any(token in name for token in ("result", "prediction", "metric", "summary", "reference")):
        return "old result/reference file"
    if suffix == ".csv":
        return "unreadable/unknown"
    return "unreadable/unknown"


def safe_examples(series: pd.Series, max_examples: int = 5) -> str:
    """Return a compact, readable sample of non-missing values."""
    values = series.dropna().astype(str).head(max_examples).tolist()
    return " | ".join(values)


def is_possible_time_column(column_name: str) -> bool:
    """Detect likely timestamp/date columns from common name fragments."""
    normalized = column_name.strip().lower()
    return any(hint in normalized for hint in TIME_NAME_HINTS)


def parse_time_column(series: pd.Series) -> pd.Series:
    """Safely parse timestamps; invalid values become NaT."""
    try:
        return pd.to_datetime(series, errors="coerce", utc=False, format="mixed")
    except TypeError:
        return pd.to_datetime(series, errors="coerce", utc=False)


def detect_load_column(df: pd.DataFrame) -> str | None:
    """Find the most likely load/power column in an hourly file."""
    preferred_tokens = ("power", "load", "kw", "kwh", "energy")
    numeric_columns = list(df.select_dtypes(include=[np.number]).columns)

    for column in df.columns:
        normalized = str(column).strip().lower()
        if any(token in normalized for token in preferred_tokens):
            return str(column)

    if "0" in df.columns:
        return "0"
    if numeric_columns:
        return str(numeric_columns[-1])
    return None


def read_csv_safely(path: Path) -> tuple[pd.DataFrame | None, str | None]:
    """Read a CSV with safe error handling so one bad file cannot stop the audit."""
    try:
        return pd.read_csv(path), None
    except Exception as exc:  # pandas can raise many parser/encoding exceptions
        return None, f"{type(exc).__name__}: {exc}"


def inspect_zip(path: Path) -> dict[str, Any]:
    """Return simple archive metadata without extracting the zip file."""
    try:
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
        return {
            "zip_file_count": len(names),
            "zip_example_members": " | ".join(names[:10]),
            "read_error": "",
        }
    except Exception as exc:
        return {
            "zip_file_count": np.nan,
            "zip_example_members": "",
            "read_error": f"{type(exc).__name__}: {exc}",
        }


def build_column_dictionary(file_name: str, df: pd.DataFrame) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    total_rows = len(df)
    for column in df.columns:
        series = df[column]
        missing_count = int(series.isna().sum())
        rows.append(
            {
                "file_name": file_name,
                "column_name": str(column),
                "dtype": str(series.dtype),
                "missing_count": missing_count,
                "missing_percentage": round((missing_count / total_rows * 100) if total_rows else 0.0, 4),
                "unique_count": int(series.nunique(dropna=True)),
                "example_values": safe_examples(series),
            }
        )
    return rows


def build_time_ranges(file_name: str, df: pd.DataFrame) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for column in df.columns:
        if not is_possible_time_column(str(column)):
            continue

        parsed = parse_time_column(df[column])
        non_missing_original = int(df[column].notna().sum())
        invalid_count = int(parsed.isna().sum() - df[column].isna().sum())
        valid = parsed.dropna()
        rows.append(
            {
                "file_name": file_name,
                "time_column": str(column),
                "non_missing_values": non_missing_original,
                "min_timestamp": valid.min() if not valid.empty else pd.NaT,
                "max_timestamp": valid.max() if not valid.empty else pd.NaT,
                "invalid_timestamp_count": max(invalid_count, 0),
            }
        )
    return rows


def build_numeric_summary(file_name: str, df: pd.DataFrame) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for column in df.select_dtypes(include=[np.number]).columns:
        series = df[column]
        rows.append(
            {
                "file_name": file_name,
                "column_name": str(column),
                "count": int(series.count()),
                "mean": series.mean(),
                "std": series.std(),
                "min": series.min(),
                "max": series.max(),
                "negative_values": int((series < 0).sum()),
                "zero_values": int((series == 0).sum()),
            }
        )
    return rows


def summarize_clean_sessions(df: pd.DataFrame | None) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for column in SESSION_COLUMNS:
        if df is None or column not in df.columns:
            rows.append(
                {
                    "column_name": column,
                    "exists": False,
                    "missing_count": np.nan,
                    "unique_count": np.nan,
                    "numeric_count": np.nan,
                    "numeric_mean": np.nan,
                    "numeric_std": np.nan,
                    "numeric_min": np.nan,
                    "numeric_max": np.nan,
                    "min_timestamp": "",
                    "max_timestamp": "",
                    "invalid_timestamp_count": np.nan,
                }
            )
            continue

        series = df[column]
        numeric = pd.to_numeric(series, errors="coerce")
        is_numeric = numeric.notna().sum() > 0 and series.dtype.kind in "biufc"
        parsed = parse_time_column(series) if is_possible_time_column(column) else pd.Series(dtype="datetime64[ns]")
        valid_times = parsed.dropna()

        rows.append(
            {
                "column_name": column,
                "exists": True,
                "missing_count": int(series.isna().sum()),
                "unique_count": int(series.nunique(dropna=True)),
                "numeric_count": int(numeric.count()) if is_numeric else np.nan,
                "numeric_mean": numeric.mean() if is_numeric else np.nan,
                "numeric_std": numeric.std() if is_numeric else np.nan,
                "numeric_min": numeric.min() if is_numeric else np.nan,
                "numeric_max": numeric.max() if is_numeric else np.nan,
                "min_timestamp": valid_times.min() if not valid_times.empty else "",
                "max_timestamp": valid_times.max() if not valid_times.empty else "",
                "invalid_timestamp_count": int(parsed.isna().sum() - series.isna().sum())
                if is_possible_time_column(column)
                else np.nan,
            }
        )
    return rows


def summarize_hourly_file(file_name: str, df: pd.DataFrame | None) -> dict[str, Any]:
    if df is None:
        return {
            "file_name": file_name,
            "exists": False,
            "detected_timestamp_column": "",
            "detected_load_column": "",
            "timestamp_min": "",
            "timestamp_max": "",
            "rows": np.nan,
            "missing_timestamps": np.nan,
            "duplicate_timestamps": np.nan,
            "minimum_load": np.nan,
            "maximum_load": np.nan,
            "mean_load": np.nan,
            "negative_loads": np.nan,
            "zero_load_rows": np.nan,
            "column_names": "",
        }

    time_columns = [str(column) for column in df.columns if is_possible_time_column(str(column))]
    timestamp_column = time_columns[0] if time_columns else ("Unnamed: 0" if "Unnamed: 0" in df.columns else "")
    load_column = detect_load_column(df) or ""

    parsed_time = parse_time_column(df[timestamp_column]) if timestamp_column else pd.Series(dtype="datetime64[ns]")
    valid_time = parsed_time.dropna()
    load_values = pd.to_numeric(df[load_column], errors="coerce") if load_column else pd.Series(dtype="float64")

    return {
        "file_name": file_name,
        "exists": True,
        "detected_timestamp_column": timestamp_column,
        "detected_load_column": load_column,
        "timestamp_min": valid_time.min() if not valid_time.empty else "",
        "timestamp_max": valid_time.max() if not valid_time.empty else "",
        "rows": len(df),
        "missing_timestamps": int(parsed_time.isna().sum()) if timestamp_column else np.nan,
        "duplicate_timestamps": int(parsed_time.duplicated().sum()) if timestamp_column else np.nan,
        "minimum_load": load_values.min() if load_column else np.nan,
        "maximum_load": load_values.max() if load_column else np.nan,
        "mean_load": load_values.mean() if load_column else np.nan,
        "negative_loads": int((load_values < 0).sum()) if load_column else np.nan,
        "zero_load_rows": int((load_values == 0).sum()) if load_column else np.nan,
        "column_names": " | ".join(map(str, df.columns)),
    }


def detect_column_naming_issues(dataframes: dict[str, pd.DataFrame]) -> list[str]:
    notes: list[str] = []
    timestamp_names: dict[str, list[str]] = {}
    load_names: dict[str, list[str]] = {}

    for file_name, df in dataframes.items():
        for column in df.columns:
            normalized = str(column).strip().lower()
            if normalized in {"unnamed: 0", "0"}:
                notes.append(f"{file_name}: contains generic column name '{column}'.")
            if is_possible_time_column(str(column)):
                timestamp_names.setdefault(str(column), []).append(file_name)
            if any(token in normalized for token in ("power", "load", "kw", "kwh", "energy")):
                load_names.setdefault(str(column), []).append(file_name)

    if len(timestamp_names) > 1:
        notes.append("Timestamp-like columns use multiple names: " + ", ".join(sorted(timestamp_names)))
    if len(load_names) > 1:
        notes.append("Load/energy-like columns use multiple names: " + ", ".join(sorted(load_names)))
    return notes


def write_audit_notes(
    inventory_df: pd.DataFrame,
    dataframes: dict[str, pd.DataFrame],
    read_errors: dict[str, str],
) -> None:
    present_files = set(inventory_df["file_name"].tolist()) if not inventory_df.empty else set()
    official_present = [
        file_name
        for file_name in EXPECTED_OFFICIAL_INPUTS
        if file_name in present_files
    ]
    official_missing = [
        file_name
        for file_name in EXPECTED_OFFICIAL_INPUTS
        if file_name not in present_files
    ]
    derived_files = inventory_df.loc[
        inventory_df["classification"].eq("old derived 24h dataset"), "file_name"
    ].tolist()
    result_files = inventory_df.loc[
        inventory_df["classification"].eq("old result/reference file"), "file_name"
    ].tolist()
    archives = inventory_df.loc[
        inventory_df["classification"].eq("archive/backup file"), "file_name"
    ].tolist()
    naming_notes = detect_column_naming_issues(dataframes)

    lines = [
        "EV charging data audit notes",
        "=" * 28,
        "",
        "Official recommended input files found in data/raw/:",
        *(f"- {name}" for name in official_present),
        *(["- None found."] if not official_present else []),
        "",
        "Expected official input files not found in data/raw/:",
        *(f"- {name}" for name in official_missing),
        *(["- None missing."] if not official_missing else []),
        "",
        "Files that look like old derived 24h datasets:",
        *(f"- {name}" for name in derived_files),
        *(["- None found."] if not derived_files else []),
        "",
        "Files that look like old results/reference files:",
        *(f"- {name}" for name in result_files),
        *(["- None found."] if not result_files else []),
        "",
        "Archive/backup files:",
        *(f"- {name}" for name in archives),
        *(["- None found."] if not archives else []),
        "",
        "Detected problems and cautions:",
    ]

    if read_errors:
        lines.extend(f"- {name}: {error}" for name, error in read_errors.items())
    if naming_notes:
        lines.extend(f"- {note}" for note in naming_notes)
    if official_missing:
        lines.append(
            "- Several expected official input files are absent from data/raw/. "
            "Check whether they are stored elsewhere before starting cleaning."
        )
    if not read_errors and not naming_notes and not official_missing:
        lines.append("- No major issues detected in this audit pass.")

    lines.extend(
        [
            "",
            "Recommended next step:",
            "- Confirm which files are the official raw inputs, then create the next numbered script "
            "for data organization/cleaning. Do not train models until the input set is confirmed.",
            "",
        ]
    )
    (OUTPUT_DIR / "01_audit_notes.txt").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    inventory_rows: list[dict[str, Any]] = []
    column_rows: list[dict[str, Any]] = []
    time_rows: list[dict[str, Any]] = []
    numeric_rows: list[dict[str, Any]] = []
    hourly_rows: list[dict[str, Any]] = []
    clean_sessions_rows: list[dict[str, Any]] = []
    dataframes: dict[str, pd.DataFrame] = {}
    read_errors: dict[str, str] = {}

    files = sorted([path for path in RAW_DIR.iterdir() if path.is_file()]) if RAW_DIR.exists() else []

    for path in files:
        classification = classify_file(path)
        base_row: dict[str, Any] = {
            "file_name": path.name,
            "extension": path.suffix.lower(),
            "file_size_mb": round(path.stat().st_size / (1024 * 1024), 4),
            "rows": np.nan,
            "columns": np.nan,
            "column_names": "",
            "missing_value_count": np.nan,
            "duplicate_row_count": np.nan,
            "classification": classification,
            "read_error": "",
        }

        if path.suffix.lower() == ".csv":
            df, error = read_csv_safely(path)
            if df is None:
                base_row["read_error"] = error or "Unknown read error"
                read_errors[path.name] = base_row["read_error"]
            else:
                dataframes[path.name] = df
                base_row.update(
                    {
                        "rows": len(df),
                        "columns": len(df.columns),
                        "column_names": " | ".join(map(str, df.columns)),
                        "missing_value_count": int(df.isna().sum().sum()),
                        "duplicate_row_count": int(df.duplicated().sum()),
                    }
                )
                column_rows.extend(build_column_dictionary(path.name, df))
                time_rows.extend(build_time_ranges(path.name, df))
                numeric_rows.extend(build_numeric_summary(path.name, df))
        elif path.suffix.lower() == ".zip":
            base_row.update(inspect_zip(path))

        inventory_rows.append(base_row)

    clean_sessions_df = dataframes.get("clean_sessions.csv")
    clean_sessions_rows = summarize_clean_sessions(clean_sessions_df)

    for file_name in HOURLY_TOTAL_FILES:
        hourly_rows.append(summarize_hourly_file(file_name, dataframes.get(file_name)))

    inventory_df = pd.DataFrame(inventory_rows)
    column_df = pd.DataFrame(column_rows)
    time_df = pd.DataFrame(time_rows)
    numeric_df = pd.DataFrame(numeric_rows)
    hourly_df = pd.DataFrame(hourly_rows)
    clean_sessions_df_out = pd.DataFrame(clean_sessions_rows)

    inventory_df.to_csv(OUTPUT_DIR / "01_file_inventory.csv", index=False)
    column_df.to_csv(OUTPUT_DIR / "01_column_dictionary.csv", index=False)
    time_df.to_csv(OUTPUT_DIR / "01_time_ranges.csv", index=False)
    numeric_df.to_csv(OUTPUT_DIR / "01_numeric_summary.csv", index=False)
    hourly_df.to_csv(OUTPUT_DIR / "01_hourly_files_summary.csv", index=False)
    clean_sessions_df_out.to_csv(OUTPUT_DIR / "01_clean_sessions_summary.csv", index=False)
    write_audit_notes(inventory_df, dataframes, read_errors)

    readable_csv_count = len(dataframes)
    problem_count = len(read_errors)
    official_recommended = inventory_df.loc[
        inventory_df["classification"].isin(["official raw session data", "official hourly load data"]),
        "file_name",
    ].tolist() if not inventory_df.empty else []
    not_direct_use = inventory_df.loc[
        ~inventory_df["classification"].isin(["official raw session data", "official hourly load data"]),
        "file_name",
    ].tolist() if not inventory_df.empty else []

    print("EV data audit complete")
    print("======================")
    print(f"Raw directory scanned: {RAW_DIR}")
    print(f"Number of files found: {len(files)}")
    print(f"Number of readable CSV files: {readable_csv_count}")
    print(f"Number of unreadable/problem files: {problem_count}")
    print("")
    print("Official recommended input files found:")
    if official_recommended:
        for file_name in official_recommended:
            print(f"- {file_name}")
    else:
        print("- None found in data/raw/")
    print("")
    print("Files that should not be used directly yet:")
    if not_direct_use:
        for file_name in not_direct_use:
            print(f"- {file_name}")
    else:
        print("- None")
    print("")
    print(f"Saved audit reports to: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
