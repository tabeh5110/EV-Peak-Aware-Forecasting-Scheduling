"""
Step 11E: Multi-site synthetic scheduling evaluation.

Run from the project root:
    python src/11E_multisite_synthetic_scheduling_evaluation.py

This step evaluates constrained EV charging scheduling on the Step 11D
real-plus-synthetic multi-site scenario. Synthetic sessions are scenario data,
not real charging logs.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import re
import sys
import types
import warnings

import numpy as np


if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "11E_multisite_synthetic_scheduling"
FIGURES_DIR = PROJECT_ROOT / "figures" / "11E_multisite_synthetic_scheduling"

SESSION_FILE = PROCESSED_DIR / "11D_real_plus_synthetic_sessions_for_scheduling.csv"
FORECAST_FILE = PROCESSED_DIR / "10_uncertainty_forecasts_for_scheduling.csv"
HOURLY_FILE = PROCESSED_DIR / "03_hourly_load_all_sites.csv"
GEN_PLAN_FILE = PROJECT_ROOT / "results" / "11D_synthetic_multisite_sessions" / "11D_site_generation_plan.csv"
SCALING_FILE = PROJECT_ROOT / "results" / "11D_synthetic_multisite_sessions" / "11D_site_scaling_factors.csv"
STEP11_OVERALL_FILE = PROJECT_ROOT / "results" / "11_constrained_scheduling" / "11_scheduling_overall_metrics.csv"
STEP11B_METRICS_FILE = PROJECT_ROOT / "results" / "11B_scheduling_robustness" / "11B_sensitivity_scenario_metrics.csv"

SCHEDULED_SESSIONS_FILE = PROCESSED_DIR / "11E_multisite_scheduled_sessions.csv"
SCHEDULED_HOURLY_FILE = PROCESSED_DIR / "11E_multisite_scheduled_hourly_loads.csv"

STRATEGIES = {
    "uncontrolled": None,
    "valley_filling": "dynamic_load",
    "point_forecast": "main_point_forecast_kw",
    "peak_sensitive": "peak_sensitive_point_forecast_kw",
    "uncertainty_aware": "upper_forecast_kw",
    "hybrid_uncertainty_peak": "hybrid_signal_kw",
}
CAPACITY_SCENARIOS = ["capacity_p95", "capacity_p95_plus_10percent", "capacity_mean_plus_2std"]
MAIN_CAPACITY_SCENARIO = "capacity_p95_plus_10percent"
FULLY_SERVED_TOLERANCE_KWH = 0.05


def ensure_dirs() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)


def require(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Required file not found: {path}")


def read_csv(path: Path, **kwargs: Any) -> pd.DataFrame:
    require(path)
    return pd.read_csv(path, **kwargs)


def parse_time(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series, errors="coerce", utc=True)


def pct(num: float, den: float) -> float:
    if den == 0 or pd.isna(den):
        return 0.0
    return 100.0 * float(num) / float(den)


def safe_div(num: float, den: float) -> float:
    if den == 0 or pd.isna(den):
        return 0.0
    return float(num) / float(den)


def load_inputs() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    sessions = read_csv(SESSION_FILE)
    forecasts = read_csv(FORECAST_FILE)
    hourly = read_csv(HOURLY_FILE)
    plan = read_csv(GEN_PLAN_FILE)
    scaling = read_csv(SCALING_FILE)

    sessions["arrival_time"] = parse_time(sessions["arrival_time"])
    sessions["departure_time"] = parse_time(sessions["departure_time"])
    sessions["site_id"] = sessions["site_id"].astype(str)
    sessions["energy_kwh"] = pd.to_numeric(sessions["energy_kwh"], errors="coerce")
    sessions["max_charging_power_kw"] = pd.to_numeric(sessions["max_charging_power_kw"], errors="coerce").fillna(6.6)
    sessions["session_source"] = sessions["session_source"].fillna("unknown").astype(str)
    sessions["scenario_type"] = sessions["scenario_type"].fillna("synthetic_multisite_scenario").astype(str)
    sessions = sessions.dropna(subset=["arrival_time", "departure_time", "energy_kwh", "site_id"])
    sessions = sessions.loc[(sessions["departure_time"] > sessions["arrival_time"]) & (sessions["energy_kwh"] > 0)].copy()
    sessions = sessions.reset_index(drop=True)
    sessions["session_key"] = [f"11E_ROW_{i:07d}" for i in range(len(sessions))]

    forecasts["timestamp"] = parse_time(forecasts["timestamp"])
    forecasts["site_id"] = forecasts["site_id"].astype(str)
    for col in ["main_point_forecast_kw", "peak_sensitive_point_forecast_kw", "upper_forecast_kw", "actual_load_kw"]:
        if col in forecasts.columns:
            forecasts[col] = pd.to_numeric(forecasts[col], errors="coerce").fillna(0.0).clip(lower=0.0)
    forecasts["hybrid_signal_kw"] = 0.7 * forecasts["upper_forecast_kw"] + 0.3 * forecasts["peak_sensitive_point_forecast_kw"]
    forecasts = forecasts.dropna(subset=["timestamp", "site_id"]).sort_values(["site_id", "timestamp"]).reset_index(drop=True)

    hourly["timestamp"] = parse_time(hourly["timestamp"])
    hourly["site_id"] = hourly["site_id"].astype(str)
    hourly["load_kw"] = pd.to_numeric(hourly["load_kw"], errors="coerce").fillna(0.0).clip(lower=0.0)
    return sessions.reset_index(drop=True), forecasts, hourly, plan, scaling


def slot_overlap(arrival: pd.Timestamp, departure: pd.Timestamp, hour: pd.Timestamp) -> float:
    start = max(arrival, hour)
    end = min(departure, hour + pd.Timedelta(hours=1))
    return max(0.0, (end - start).total_seconds() / 3600.0)


def feasible_slots(session: pd.Series, timestamps: pd.Series) -> tuple[np.ndarray, np.ndarray]:
    start_idx = int(timestamps.searchsorted(session["arrival_time"] - pd.Timedelta(hours=1), side="right"))
    end_idx = int(timestamps.searchsorted(session["departure_time"], side="left"))
    idx = np.arange(start_idx, end_idx)
    if len(idx) == 0:
        return idx, np.array([])
    overlaps = np.array([slot_overlap(session["arrival_time"], session["departure_time"], timestamps.iloc[i]) for i in idx])
    keep = overlaps > 1e-9
    return idx[keep], overlaps[keep]


def schedule_site_strategy(
    site_sessions: pd.DataFrame,
    site_hours: pd.DataFrame,
    strategy: str,
    capacity_kw: float,
    capacity_scenario: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    timestamps = site_hours["timestamp"].reset_index(drop=True)
    scheduled = np.zeros(len(site_hours), dtype=float)
    source_loads: dict[str, np.ndarray] = {
        source: np.zeros(len(site_hours), dtype=float) for source in sorted(site_sessions["session_source"].unique())
    }
    signal_col = STRATEGIES[strategy]
    if strategy == "valley_filling" or signal_col is None:
        signal = np.zeros(len(site_hours), dtype=float)
    else:
        signal = site_hours[signal_col].to_numpy(dtype=float)

    session_rows: list[dict[str, Any]] = []
    alloc_rows: list[dict[str, Any]] = []
    ordered = site_sessions.sort_values(["departure_time", "arrival_time", "session_id"]).reset_index(drop=True)

    for _, session in ordered.iterrows():
        demand = float(session["energy_kwh"])
        max_power = float(session["max_charging_power_kw"])
        idx, overlaps = feasible_slots(session, timestamps)
        remaining = demand
        delivered = 0.0
        delay_weight = 0.0
        if len(idx):
            if strategy == "uncontrolled":
                order = np.arange(len(idx))
            elif strategy == "valley_filling":
                order = np.argsort(scheduled[idx])
            else:
                order = np.argsort(signal[idx] + 0.05 * scheduled[idx])

            for local_i in order:
                if remaining <= 1e-9:
                    break
                hour_i = int(idx[local_i])
                overlap = float(overlaps[local_i])
                slot_energy = max_power * overlap
                if strategy == "uncontrolled":
                    allowed = slot_energy
                else:
                    spare_power = max(0.0, capacity_kw - scheduled[hour_i])
                    allowed = min(slot_energy, spare_power * overlap)
                energy = min(remaining, allowed)
                if energy > 1e-9:
                    power = energy / overlap
                    scheduled[hour_i] += power
                    source_loads[str(session["session_source"])][hour_i] += power
                    remaining -= energy
                    delivered += energy
                    delay_weight += ((timestamps.iloc[hour_i] - session["arrival_time"]).total_seconds() / 3600.0) * energy

            if strategy != "uncontrolled" and remaining > 1e-9:
                for local_i in order:
                    if remaining <= 1e-9:
                        break
                    hour_i = int(idx[local_i])
                    overlap = float(overlaps[local_i])
                    slot_energy = max_power * overlap
                    used_energy_equiv = 0.0
                    # Conservative soft pass: allow physical charger energy even when it violates capacity.
                    energy = min(remaining, max(0.0, slot_energy - used_energy_equiv))
                    if energy > 1e-9:
                        power = energy / overlap
                        scheduled[hour_i] += power
                        source_loads[str(session["session_source"])][hour_i] += power
                        remaining -= energy
                        delivered += energy
                        delay_weight += ((timestamps.iloc[hour_i] - session["arrival_time"]).total_seconds() / 3600.0) * energy

        session_rows.append(
            {
                "capacity_scenario": capacity_scenario,
                "strategy": strategy,
                "session_key": session["session_key"],
                "session_id": session["session_id"],
                "site_id": session["site_id"],
                "arrival_time": session["arrival_time"],
                "departure_time": session["departure_time"],
                "energy_requested_kwh": demand,
                "energy_delivered_kwh": delivered,
                "unserved_energy_kwh": max(0.0, demand - delivered),
                "fully_served": delivered + FULLY_SERVED_TOLERANCE_KWH >= demand,
                "max_charging_power_kw": max_power,
                "session_source": session["session_source"],
                "scenario_type": session["scenario_type"],
                "average_delay_hours": safe_div(delay_weight, delivered) if delivered > 0 else np.nan,
            }
        )

    hourly = site_hours[["timestamp", "site_id", "main_point_forecast_kw", "peak_sensitive_point_forecast_kw", "upper_forecast_kw", "hybrid_signal_kw"]].copy()
    hourly["capacity_scenario"] = capacity_scenario
    hourly["strategy"] = strategy
    hourly["scheduled_load_kw"] = scheduled
    hourly["site_capacity_kw"] = capacity_kw
    hourly["capacity_violation_kw"] = np.clip(scheduled - capacity_kw, 0.0, None)
    for source, values in source_loads.items():
        hourly[f"scheduled_load_kw_{source}"] = values
    return hourly, pd.DataFrame(session_rows)


def schedule_uncontrolled_by_site(sessions: pd.DataFrame, forecasts: pd.DataFrame) -> pd.DataFrame:
    frames = []
    for site, site_sessions in sessions.groupby("site_id"):
        site_hours = forecasts.loc[forecasts["site_id"] == site].sort_values("timestamp").reset_index(drop=True)
        if site_hours.empty:
            continue
        h, _ = schedule_site_strategy(site_sessions, site_hours, "uncontrolled", np.inf, "uncontrolled_capacity_basis")
        frames.append(h)
    return pd.concat(frames, ignore_index=True)


def capacity_assumptions(uncontrolled_hourly: pd.DataFrame, hourly: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for site, group in uncontrolled_hourly.groupby("site_id"):
        load = group["scheduled_load_kw"].to_numpy(dtype=float)
        hist = hourly.loc[hourly["site_id"] == site, "load_kw"].to_numpy(dtype=float)
        basis = load if len(load) and np.max(load) > 0 else hist
        if len(basis) == 0:
            basis = np.array([1.0])
        p95 = float(np.percentile(basis, 95))
        mean = float(np.mean(basis))
        std = float(np.std(basis))
        peak = float(np.max(basis))
        rows.append(
            {
                "site_id": site,
                "basis_source": "reconstructed_uncontrolled_scenario_load" if len(load) else "historical_hourly_load",
                "basis_p95_kw": p95,
                "basis_mean_kw": mean,
                "basis_std_kw": std,
                "basis_peak_kw": peak,
                "capacity_p95": p95,
                "capacity_p95_plus_10percent": p95 * 1.10,
                "capacity_mean_plus_2std": mean + 2 * std,
            }
        )
    out = pd.DataFrame(rows)
    out.to_csv(RESULTS_DIR / "11E_site_capacity_assumptions.csv", index=False)
    return out


def run_scheduling(sessions: pd.DataFrame, forecasts: pd.DataFrame, hourly: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    uncontrolled_basis = schedule_uncontrolled_by_site(sessions, forecasts)
    capacities = capacity_assumptions(uncontrolled_basis, hourly)
    capacity_lookup = capacities.set_index("site_id").to_dict("index")
    hourly_frames = []
    session_frames = []
    for capacity_scenario in CAPACITY_SCENARIOS:
        for site, site_sessions in sessions.groupby("site_id"):
            site_hours = forecasts.loc[forecasts["site_id"] == site].sort_values("timestamp").reset_index(drop=True)
            if site_hours.empty:
                continue
            capacity_kw = float(capacity_lookup[site][capacity_scenario])
            for strategy in STRATEGIES:
                h, s = schedule_site_strategy(site_sessions, site_hours, strategy, capacity_kw, capacity_scenario)
                hourly_frames.append(h)
                session_frames.append(s)
    scheduled_hourly = pd.concat(hourly_frames, ignore_index=True)
    scheduled_sessions = pd.concat(session_frames, ignore_index=True)
    return scheduled_hourly, scheduled_sessions, capacities


def load_metrics(load: pd.Series) -> dict[str, float]:
    load = load.astype(float).sort_index()
    peak = float(load.max()) if len(load) else 0.0
    mean = float(load.mean()) if len(load) else 0.0
    ramps = load.diff().abs().fillna(0.0)
    return {
        "peak_load_kw": peak,
        "mean_load_kw": mean,
        "load_std_kw": float(load.std(ddof=0)) if len(load) else 0.0,
        "load_factor": safe_div(mean, peak),
        "ramp_rate_mean": float(ramps.mean()) if len(ramps) else 0.0,
        "ramp_rate_max": float(ramps.max()) if len(ramps) else 0.0,
    }


def summarize_metrics(hourly: pd.DataFrame, sessions: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    overall_rows = []
    for (cap, strategy), h in hourly.groupby(["capacity_scenario", "strategy"]):
        s = sessions.loc[(sessions["capacity_scenario"] == cap) & (sessions["strategy"] == strategy)]
        load = h.groupby("timestamp")["scheduled_load_kw"].sum().sort_index()
        lm = load_metrics(load)
        violations = h["capacity_violation_kw"]
        requested = float(s["energy_requested_kwh"].sum())
        delivered = float(s["energy_delivered_kwh"].sum())
        overall_rows.append(
            {
                "capacity_scenario": cap,
                "strategy": strategy,
                "sessions_total": int(len(s)),
                "real_sessions_count": int((s["session_source"] == "real").sum()),
                "synthetic_sessions_count": int((s["session_source"] == "synthetic_empirical").sum()),
                "total_energy_requested_kwh": requested,
                "total_energy_delivered_kwh": delivered,
                "unserved_energy_kwh": requested - delivered,
                "unserved_energy_percent": pct(requested - delivered, requested),
                "sessions_fully_served_percent": pct(float(s["fully_served"].sum()), len(s)),
                **lm,
                "capacity_violation_hours": int((violations > 1e-9).sum()),
                "capacity_violation_percent": pct(int((violations > 1e-9).sum()), len(h)),
                "max_capacity_violation_kw": float(violations.max()) if len(violations) else 0.0,
                "total_capacity_violation_kwh": float(violations.sum()),
                "average_delay_hours": float(s["average_delay_hours"].mean()) if len(s) else np.nan,
            }
        )
    overall = pd.DataFrame(overall_rows)
    overall = add_peak_reduction(overall, ["capacity_scenario"])

    site_rows = []
    for (cap, strategy, site), h in hourly.groupby(["capacity_scenario", "strategy", "site_id"]):
        s = sessions.loc[(sessions["capacity_scenario"] == cap) & (sessions["strategy"] == strategy) & (sessions["site_id"] == site)]
        lm = load_metrics(h.groupby("timestamp")["scheduled_load_kw"].sum().sort_index())
        violations = h["capacity_violation_kw"]
        requested = float(s["energy_requested_kwh"].sum())
        delivered = float(s["energy_delivered_kwh"].sum())
        site_rows.append(
            {
                "capacity_scenario": cap,
                "strategy": strategy,
                "site_id": site,
                "sessions_total": int(len(s)),
                "real_sessions_count": int((s["session_source"] == "real").sum()),
                "synthetic_sessions_count": int((s["session_source"] == "synthetic_empirical").sum()),
                "total_energy_requested_kwh": requested,
                "total_energy_delivered_kwh": delivered,
                "unserved_energy_kwh": requested - delivered,
                "unserved_energy_percent": pct(requested - delivered, requested),
                "sessions_fully_served_percent": pct(float(s["fully_served"].sum()), len(s)),
                **lm,
                "capacity_violation_hours": int((violations > 1e-9).sum()),
                "capacity_violation_percent": pct(int((violations > 1e-9).sum()), len(h)),
                "max_capacity_violation_kw": float(violations.max()) if len(violations) else 0.0,
                "total_capacity_violation_kwh": float(violations.sum()),
                "average_delay_hours": float(s["average_delay_hours"].mean()) if len(s) else np.nan,
            }
        )
    site_metrics = pd.DataFrame(site_rows)
    site_metrics = add_peak_reduction(site_metrics, ["capacity_scenario", "site_id"])

    source_rows = []
    for (cap, strategy, source), s in sessions.groupby(["capacity_scenario", "strategy", "session_source"]):
        requested = float(s["energy_requested_kwh"].sum())
        delivered = float(s["energy_delivered_kwh"].sum())
        source_rows.append(
            {
                "capacity_scenario": cap,
                "strategy": strategy,
                "session_source": source,
                "sessions_total": int(len(s)),
                "real_sessions_count": int((s["session_source"] == "real").sum()),
                "synthetic_sessions_count": int((s["session_source"] == "synthetic_empirical").sum()),
                "total_energy_requested_kwh": requested,
                "total_energy_delivered_kwh": delivered,
                "unserved_energy_kwh": requested - delivered,
                "unserved_energy_percent": pct(requested - delivered, requested),
                "sessions_fully_served_percent": pct(float(s["fully_served"].sum()), len(s)),
                "average_delay_hours": float(s["average_delay_hours"].mean()) if len(s) else np.nan,
            }
        )
    source_metrics = pd.DataFrame(source_rows)
    return overall, site_metrics, source_metrics


def add_peak_reduction(df: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
    base = df.loc[df["strategy"] == "uncontrolled", group_cols + ["peak_load_kw"]].rename(
        columns={"peak_load_kw": "uncontrolled_peak_load_kw"}
    )
    out = df.merge(base, on=group_cols, how="left")
    out["peak_reduction_kw_vs_uncontrolled"] = out["uncontrolled_peak_load_kw"] - out["peak_load_kw"]
    out["peak_reduction_percent_vs_uncontrolled"] = [
        pct(v, b) for v, b in zip(out["peak_reduction_kw_vs_uncontrolled"], out["uncontrolled_peak_load_kw"])
    ]
    return out


def reports_and_decision(overall: pd.DataFrame, site_metrics: pd.DataFrame, source_metrics: pd.DataFrame, sessions: pd.DataFrame) -> dict[str, Any]:
    main = overall.loc[overall["capacity_scenario"] == MAIN_CAPACITY_SCENARIO].copy()
    best_peak = main.sort_values("peak_reduction_percent_vs_uncontrolled", ascending=False).iloc[0]
    best_capacity = main.sort_values(["capacity_violation_hours", "unserved_energy_percent", "peak_load_kw"]).iloc[0]
    best_service = main.sort_values(["unserved_energy_percent", "sessions_fully_served_percent"], ascending=[True, False]).iloc[0]
    ua = main.loc[main["strategy"] == "uncertainty_aware"].iloc[0]
    uncontrolled = main.loc[main["strategy"] == "uncontrolled"].iloc[0]
    hybrid = main.loc[main["strategy"] == "hybrid_uncertainty_peak"].iloc[0]
    robust_sites = site_metrics.loc[
        (site_metrics["capacity_scenario"] == MAIN_CAPACITY_SCENARIO)
        & (site_metrics["strategy"] == "uncertainty_aware")
        & (site_metrics["unserved_energy_percent"] <= 1.0)
        & (site_metrics["peak_reduction_percent_vs_uncontrolled"] > 0)
    ]["site_id"].nunique()
    total_sites = sessions["site_id"].nunique()
    ua_all_caps = overall.loc[overall["strategy"] == "uncertainty_aware"]
    low_unserved_share = float((ua_all_caps["unserved_energy_percent"] <= 1.0).mean())
    positive_peak_share = float((ua_all_caps["peak_reduction_percent_vs_uncontrolled"] > 0).mean())
    violation_reduction_share = float(
        (
            ua_all_caps.set_index("capacity_scenario")["capacity_violation_hours"]
            < overall.loc[overall["strategy"] == "uncontrolled"].set_index("capacity_scenario")["capacity_violation_hours"]
        ).mean()
    )
    if low_unserved_share >= 0.8 and positive_peak_share >= 0.8 and robust_sites >= max(1, total_sites - 1):
        claim = "strong scenario evidence"
        reason = "uncertainty-aware scheduling works across most sites and capacity scenarios with low unserved energy"
    elif low_unserved_share >= 0.8 and violation_reduction_share >= 0.5:
        claim = "moderate scenario evidence"
        reason = "uncertainty-aware scheduling works in the main setting and several sensitivity cases, but it is scenario rather than real six-site evidence"
    elif positive_peak_share > 0:
        claim = "weak scenario evidence"
        reason = "improvements are inconsistent across capacity scenarios or sites"
    else:
        claim = "not supported"
        reason = "no reliable scheduling benefit was observed"

    recommended = "hybrid_uncertainty_peak" if hybrid["capacity_violation_hours"] <= ua["capacity_violation_hours"] and hybrid["peak_reduction_percent_vs_uncontrolled"] >= ua["peak_reduction_percent_vs_uncontrolled"] else "uncertainty_aware"
    decision = pd.DataFrame(
        [
            {
                "best_strategy_by_peak_reduction": best_peak["strategy"],
                "best_strategy_by_capacity_violations": best_capacity["strategy"],
                "best_strategy_by_energy_service": best_service["strategy"],
                "recommended_strategy_for_paper": recommended,
                "claim_strength": claim,
                "reason": reason,
                "warning_notes": "Synthetic sessions are scenario data only; do not claim real six-site session-log validation.",
            }
        ]
    )
    decision.to_csv(RESULTS_DIR / "11E_final_scheduling_decision.csv", index=False)

    comparison_rows = []
    if STEP11_OVERALL_FILE.exists():
        step11 = pd.read_csv(STEP11_OVERALL_FILE)
        for _, row in step11.iterrows():
            comparison_rows.append(
                {
                    "scenario": "Step 11 real/calendar-aligned one-site",
                    "strategy": row.get("strategy", ""),
                    "peak_reduction_percent": row.get("peak_reduction_percent_vs_uncontrolled", np.nan),
                    "capacity_violation_hours": row.get("capacity_violation_hours", np.nan),
                    "unserved_energy_percent": row.get("unserved_energy_percent", np.nan),
                }
            )
    if STEP11B_METRICS_FILE.exists():
        step11b = pd.read_csv(STEP11B_METRICS_FILE)
        step11b_main = step11b.groupby("strategy", as_index=False).agg(
            peak_reduction_percent=("peak_reduction_percent_vs_uncontrolled", "mean"),
            capacity_violation_hours=("capacity_violation_hours", "mean"),
            unserved_energy_percent=("unserved_energy_percent", "mean"),
        )
        for _, row in step11b_main.iterrows():
            comparison_rows.append({"scenario": "Step 11B robustness mean", **row.to_dict()})
    for _, row in main.iterrows():
        comparison_rows.append(
            {
                "scenario": "Step 11E synthetic multi-site main",
                "strategy": row["strategy"],
                "peak_reduction_percent": row["peak_reduction_percent_vs_uncontrolled"],
                "capacity_violation_hours": row["capacity_violation_hours"],
                "unserved_energy_percent": row["unserved_energy_percent"],
            }
        )
    pd.DataFrame(comparison_rows).to_csv(RESULTS_DIR / "11E_real_vs_synthetic_scheduling_comparison.csv", index=False)

    real_count = int((sessions["session_source"] == "real").sum())
    synth_count = int((sessions["session_source"] == "synthetic_empirical").sum())
    method = f"""Step 11E multisite synthetic scheduling method report
=================================================
Purpose:
Evaluate constrained EV charging scheduling across all six Step 10 forecast sites using the Step 11D real plus synthetic scenario file.

Real and synthetic distinction:
The scenario includes {real_count} calendar-aligned real empirical sessions and {synth_count} synthetic_empirical sessions. Synthetic sessions are not real logs. They are labeled with session_source=synthetic_empirical and scenario_type=synthetic_multisite_scenario.

Scheduling constraints:
Charging is assigned only between arrival_time and departure_time. Hourly charging power is capped by max_charging_power_kw. The scheduler attempts to deliver all requested energy and records unserved energy and capacity violations.

Strategies:
uncontrolled, valley_filling, point_forecast, peak_sensitive, uncertainty_aware, and hybrid_uncertainty_peak.

Capacity assumptions:
Three site-specific capacity scenarios are evaluated: capacity_p95, capacity_p95_plus_10percent, and capacity_mean_plus_2std. Capacities are computed from reconstructed uncontrolled scenario load.

Interpretation:
This is robustness/scalability analysis for a synthetic multi-site scenario, not real six-site validation.
"""

    results = f"""Step 11E multisite synthetic scheduling results report
==================================================
Sites scheduled: {total_sites}
Real sessions used: {real_count}
Synthetic sessions used: {synth_count}
Total sessions: {len(sessions)}
Main capacity scenario: {MAIN_CAPACITY_SCENARIO}

Main scenario energy service:
Recommended strategy: {recommended}
Uncertainty-aware requested energy: {ua.total_energy_requested_kwh:.2f} kWh
Uncertainty-aware delivered energy: {ua.total_energy_delivered_kwh:.2f} kWh
Uncertainty-aware unserved energy: {ua.unserved_energy_kwh:.2f} kWh ({ua.unserved_energy_percent:.3f}%)

Peak and capacity:
Uncontrolled peak load: {uncontrolled.peak_load_kw:.2f} kW
Uncertainty-aware peak load: {ua.peak_load_kw:.2f} kW
Uncertainty-aware peak reduction: {ua.peak_reduction_percent_vs_uncontrolled:.2f}%
Uncontrolled capacity violation hours: {int(uncontrolled.capacity_violation_hours)}
Uncertainty-aware capacity violation hours: {int(ua.capacity_violation_hours)}

Best strategies:
Best by peak reduction: {best_peak.strategy} ({best_peak.peak_reduction_percent_vs_uncontrolled:.2f}%)
Best by capacity violations: {best_capacity.strategy} ({int(best_capacity.capacity_violation_hours)} hours)
Best by energy service: {best_service.strategy}

Site-level robustness:
Uncertainty-aware scheduling achieved positive peak reduction and <=1% unserved energy on {robust_sites} of {total_sites} sites in the main scenario.

Limitations:
This scenario includes synthetic sessions for forecast-only sites. It evaluates scalability and robustness but must not be described as real six-site session-log validation.
"""

    leakage = """Step 11E leakage safety report
================================
- Step 10 forecasts are used only as scheduling signals.
- actual_load_kw is not used to decide scheduling allocations.
- Synthetic sessions were generated and labeled before scheduling.
- Test labels are not used for strategy design or tuning.
- Energy delivery, capacity violations, and peak reductions are evaluated only after schedules are produced.
- Outputs preserve session_source and scenario_type so synthetic sessions are never confused with real logs.
"""

    novelty = """Step 11E novelty contribution report
=====================================
This step tests the scalability of forecast-informed EV charging scheduling using the empirical synthetic multi-site scenario from Step 11D.

Contribution elements:
- Multi-site scheduling across all Step 10 forecast sites.
- Explicit separation of real and synthetic empirical sessions.
- Uncertainty-aware and hybrid uncertainty/peak scheduling.
- Realistic session constraints and site capacity assumptions.
- Feasibility reporting for energy service, unserved energy, and capacity violations.
- Honest scenario-based validation rather than overstated real-data validation.
"""

    paper = f"""Using the Step 11D scenario file, we evaluated constrained EV charging scheduling across six forecast sites with {real_count} calendar-aligned real empirical sessions and {synth_count} synthetic empirical sessions. The synthetic sessions were used only for robustness and scalability analysis and are not real six-site session logs. Under the main {MAIN_CAPACITY_SCENARIO} capacity setting, uncertainty-aware scheduling reduced aggregate peak load from {uncontrolled.peak_load_kw:.2f} kW to {ua.peak_load_kw:.2f} kW ({ua.peak_reduction_percent_vs_uncontrolled:.2f}%) while delivering {ua.total_energy_delivered_kwh:.2f} kWh of {ua.total_energy_requested_kwh:.2f} kWh requested energy, leaving {ua.unserved_energy_percent:.3f}% unserved. Capacity violation hours changed from {int(uncontrolled.capacity_violation_hours)} under uncontrolled charging to {int(ua.capacity_violation_hours)} under uncertainty-aware scheduling. The final scheduling claim is {claim}: {reason}. These results should be interpreted as synthetic multi-site scenario evidence for scheduling robustness and scalability, not as real-world six-site session validation."""

    for name, text in {
        "11E_scheduling_method_report.txt": method,
        "11E_scheduling_results_report.txt": results,
        "11E_leakage_safety_report.txt": leakage,
        "11E_novelty_contribution_report.txt": novelty,
        "11E_paper_ready_scheduling_paragraph.txt": paper,
    }.items():
        (RESULTS_DIR / name).write_text(text, encoding="utf-8")

    return {
        "sites": total_sites,
        "real_sessions": int(real_count),
        "synthetic_sessions": int(synth_count),
        "total_sessions": int(len(sessions)),
        "best_peak": str(best_peak["strategy"]),
        "best_capacity": str(best_capacity["strategy"]),
        "ua_peak_reduction": float(ua["peak_reduction_percent_vs_uncontrolled"]),
        "ua_capacity_reduction": float(uncontrolled["capacity_violation_hours"] - ua["capacity_violation_hours"]),
        "ua_unserved": float(ua["unserved_energy_percent"]),
        "claim": claim,
    }


def make_figures(overall: pd.DataFrame, site_metrics: pd.DataFrame, source_metrics: pd.DataFrame, hourly: pd.DataFrame) -> None:
    main = overall.loc[overall["capacity_scenario"] == MAIN_CAPACITY_SCENARIO].copy()

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.axis("off")
    labels = ["Step 10 forecasts", "11D scenario sessions", "Constrained scheduler", "Multi-site schedules"]
    xs = [0.1, 0.36, 0.63, 0.89]
    for x, label in zip(xs, labels):
        ax.text(x, 0.55, label, ha="center", va="center", bbox={"boxstyle": "round,pad=0.4", "facecolor": "#eef4fb", "edgecolor": "#3b6ea8"})
    for a, b in zip(xs[:-1], xs[1:]):
        ax.annotate("", xy=(b - 0.1, 0.55), xytext=(a + 0.1, 0.55), arrowprops={"arrowstyle": "->"})
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11E_fig1_multisite_scheduling_framework.png", dpi=300)
    plt.close(fig)

    def bar(df: pd.DataFrame, y: str, title: str, ylabel: str, path: str) -> None:
        fig, ax = plt.subplots(figsize=(10, 5))
        ax.bar(df["strategy"], df[y], color="#3b6ea8")
        ax.set_title(title)
        ax.set_ylabel(ylabel)
        ax.tick_params(axis="x", rotation=30)
        ax.grid(axis="y", alpha=0.25)
        fig.tight_layout()
        fig.savefig(FIGURES_DIR / path, dpi=300)
        plt.close(fig)

    bar(main, "peak_load_kw", "Peak load by strategy", "Peak load (kW)", "11E_fig2_peak_load_by_strategy.png")
    bar(main, "peak_reduction_percent_vs_uncontrolled", "Peak reduction by strategy", "Peak reduction (%)", "11E_fig3_peak_reduction_by_strategy.png")
    bar(main, "capacity_violation_hours", "Capacity violations by strategy", "Violation hours", "11E_fig4_capacity_violations_by_strategy.png")
    bar(main, "unserved_energy_percent", "Unserved energy by strategy", "Unserved energy (%)", "11E_fig5_unserved_energy_by_strategy.png")

    pivot = site_metrics.loc[
        (site_metrics["capacity_scenario"] == MAIN_CAPACITY_SCENARIO) & (site_metrics["strategy"] != "uncontrolled")
    ].pivot_table(index="site_id", columns="strategy", values="peak_reduction_percent_vs_uncontrolled", aggfunc="mean")
    fig, ax = plt.subplots(figsize=(12, 5))
    pivot.plot(kind="bar", ax=ax)
    ax.set_title("Site-level peak reduction")
    ax.set_ylabel("Peak reduction (%)")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11E_fig6_site_level_peak_reduction.png", dpi=300)
    plt.close(fig)

    pivot_v = site_metrics.loc[site_metrics["capacity_scenario"] == MAIN_CAPACITY_SCENARIO].pivot_table(
        index="site_id", columns="strategy", values="capacity_violation_hours", aggfunc="mean"
    )
    fig, ax = plt.subplots(figsize=(12, 5))
    pivot_v.plot(kind="bar", ax=ax)
    ax.set_title("Site-level capacity violations")
    ax.set_ylabel("Violation hours")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11E_fig7_site_level_capacity_violations.png", dpi=300)
    plt.close(fig)

    energy = site_metrics.loc[site_metrics["capacity_scenario"] == MAIN_CAPACITY_SCENARIO].copy()
    energy["energy_delivered_percent"] = [pct(r.total_energy_delivered_kwh, r.total_energy_requested_kwh) for r in energy.itertuples()]
    pivot_e = energy.pivot_table(index="site_id", columns="strategy", values="energy_delivered_percent", aggfunc="mean")
    fig, ax = plt.subplots(figsize=(12, 5))
    pivot_e.plot(kind="bar", ax=ax)
    ax.set_title("Energy delivered by site")
    ax.set_ylabel("Energy delivered (%)")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11E_fig8_energy_delivered_by_site.png", dpi=300)
    plt.close(fig)

    sample_site = site_metrics.loc[site_metrics["capacity_scenario"] == MAIN_CAPACITY_SCENARIO].sort_values("total_energy_requested_kwh", ascending=False)["site_id"].iloc[0]
    sample = hourly.loc[(hourly["capacity_scenario"] == MAIN_CAPACITY_SCENARIO) & (hourly["site_id"] == sample_site)].copy()
    start = sample["timestamp"].min()
    sample = sample.loc[(sample["timestamp"] >= start) & (sample["timestamp"] < start + pd.Timedelta(days=7))]
    fig, ax = plt.subplots(figsize=(12, 5))
    for strategy in ["uncontrolled", "point_forecast", "uncertainty_aware", "hybrid_uncertainty_peak"]:
        p = sample.loc[sample["strategy"] == strategy].sort_values("timestamp")
        ax.plot(p["timestamp"], p["scheduled_load_kw"], label=strategy, linewidth=1.2)
    ax.set_title(f"Sample site load profile: {sample_site}")
    ax.set_ylabel("Scheduled load (kW)")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11E_fig9_load_profile_sample_site.png", dpi=300)
    plt.close(fig)

    cap = overall.loc[overall["strategy"] != "uncontrolled"].pivot_table(
        index="capacity_scenario", columns="strategy", values="peak_reduction_percent_vs_uncontrolled", aggfunc="mean"
    )
    fig, ax = plt.subplots(figsize=(11, 5))
    cap.plot(kind="bar", ax=ax)
    ax.set_title("Capacity sensitivity: peak reduction")
    ax.set_ylabel("Peak reduction (%)")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11E_fig10_capacity_sensitivity_peak_reduction.png", dpi=300)
    plt.close(fig)

    src = source_metrics.loc[source_metrics["capacity_scenario"] == MAIN_CAPACITY_SCENARIO].copy()
    src["energy_delivered_percent"] = [pct(r.total_energy_delivered_kwh, r.total_energy_requested_kwh) for r in src.itertuples()]
    pivot_s = src.pivot_table(index="strategy", columns="session_source", values="energy_delivered_percent", aggfunc="mean")
    fig, ax = plt.subplots(figsize=(10, 5))
    pivot_s.plot(kind="bar", ax=ax)
    ax.set_title("Real vs synthetic session source energy service")
    ax.set_ylabel("Energy delivered (%)")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11E_fig11_real_vs_synthetic_session_source_metrics.png", dpi=300)
    plt.close(fig)


def main() -> None:
    ensure_dirs()
    for path in [SESSION_FILE, FORECAST_FILE, HOURLY_FILE, GEN_PLAN_FILE, SCALING_FILE]:
        require(path)
    sessions, forecasts, hourly_raw, _plan, _scaling = load_inputs()
    scheduled_hourly, scheduled_sessions, _capacities = run_scheduling(sessions, forecasts, hourly_raw)
    overall, site_metrics, source_metrics = summarize_metrics(scheduled_hourly, scheduled_sessions)

    scheduled_sessions.to_csv(SCHEDULED_SESSIONS_FILE, index=False)
    scheduled_hourly.to_csv(SCHEDULED_HOURLY_FILE, index=False)
    overall.to_csv(RESULTS_DIR / "11E_overall_metrics.csv", index=False)
    site_metrics.to_csv(RESULTS_DIR / "11E_site_metrics.csv", index=False)
    source_metrics.to_csv(RESULTS_DIR / "11E_session_source_metrics.csv", index=False)
    overall.sort_values(["capacity_scenario", "peak_reduction_percent_vs_uncontrolled"], ascending=[True, False]).to_csv(
        RESULTS_DIR / "11E_strategy_comparison.csv", index=False
    )
    overall.to_csv(RESULTS_DIR / "11E_capacity_sensitivity_metrics.csv", index=False)
    scheduled_hourly.loc[scheduled_hourly["capacity_violation_kw"] > 1e-9].to_csv(
        RESULTS_DIR / "11E_capacity_violation_report.csv", index=False
    )
    scheduled_sessions.loc[scheduled_sessions["unserved_energy_kwh"] > FULLY_SERVED_TOLERANCE_KWH].to_csv(
        RESULTS_DIR / "11E_unserved_energy_report.csv", index=False
    )

    summary = reports_and_decision(overall, site_metrics, source_metrics, sessions)
    make_figures(overall, site_metrics, source_metrics, scheduled_hourly)
    (RESULTS_DIR / "11E_run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("Step 11E multi-site synthetic scheduling evaluation complete")
    print(f"Sites scheduled: {summary['sites']}")
    print(f"Real sessions used: {summary['real_sessions']}")
    print(f"Synthetic sessions used: {summary['synthetic_sessions']}")
    print(f"Total sessions: {summary['total_sessions']}")
    print(f"Capacity scenarios evaluated: {', '.join(CAPACITY_SCENARIOS)}")
    print(f"Strategies evaluated: {', '.join(STRATEGIES.keys())}")
    print(f"Best strategy by peak reduction: {summary['best_peak']}")
    print(f"Best strategy by capacity violations: {summary['best_capacity']}")
    print(f"Uncertainty-aware peak reduction: {summary['ua_peak_reduction']:.2f}%")
    print(f"Uncertainty-aware capacity violation reduction: {summary['ua_capacity_reduction']:.2f} hours")
    print(f"Uncertainty-aware unserved energy percent: {summary['ua_unserved']:.3f}%")
    print(f"Final scheduling claim strength: {summary['claim']}")
    print(f"Scheduled sessions file: {SCHEDULED_SESSIONS_FILE}")
    print(f"Scheduled hourly loads file: {SCHEDULED_HOURLY_FILE}")
    print(f"Reports folder: {RESULTS_DIR}")
    print(f"Figures folder: {FIGURES_DIR}")


if __name__ == "__main__":
    main()
