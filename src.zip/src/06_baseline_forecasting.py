"""
Step 06: leakage-free baseline forecasting models.

Run from the project root:
    python src/06_baseline_forecasting.py

This step evaluates simple baseline forecasters only. It does not train tree
models, create prediction intervals, or run scheduling optimization.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import re
import sys
import types

import numpy as np


# Environment guard for this workstation: the Python standard-library
# _strptime.py has been overwritten by old project code. Pandas/matplotlib need
# a small import-time API from _strptime, so provide it locally without editing
# the external Python installation.
if "_strptime" not in sys.modules:
    _strptime_stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    _strptime_stub.LocaleTime = LocaleTime
    _strptime_stub.TimeRE = TimeRE
    _strptime_stub._TimeRE_cache = TimeRE()
    _strptime_stub._regex_cache = {}
    _strptime_stub._getlang = _getlang
    _strptime_stub._strptime = _strptime
    _strptime_stub._strptime_time = _strptime
    _strptime_stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = _strptime_stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
FEATURE_FILE = PROJECT_ROOT / "data" / "processed" / "05B_forecasting_features.csv"
FEATURE_COLUMNS_FILE = (
    PROJECT_ROOT / "results" / "05B_fix_feature_engineering" / "05B_modeling_feature_columns.txt"
)
RESULTS_DIR = PROJECT_ROOT / "results" / "06_baseline_forecasting"
FIGURES_DIR = PROJECT_ROOT / "figures" / "06_baseline_forecasting"

OVERALL_METRICS_FILE = RESULTS_DIR / "06_baseline_overall_metrics.csv"
SITE_METRICS_FILE = RESULTS_DIR / "06_baseline_site_metrics.csv"
VALIDATION_PREDICTIONS_FILE = RESULTS_DIR / "06_validation_predictions.csv"
TEST_PREDICTIONS_FILE = RESULTS_DIR / "06_test_predictions.csv"
RANKING_FILE = RESULTS_DIR / "06_baseline_model_ranking.csv"
BEST_SUMMARY_FILE = RESULTS_DIR / "06_best_baseline_summary.csv"
CAPTIONS_FILE = RESULTS_DIR / "06_figure_captions.txt"
LEAKAGE_REPORT_FILE = RESULTS_DIR / "06_baseline_leakage_safety_report.txt"
REPORT_FILE = RESULTS_DIR / "06_baseline_forecasting_report.txt"

TARGET = "target_load_kw"
BASE_COLUMNS = ["timestamp", "site_id", "actual_load_kw", "split", "is_peak_hour", "is_high_peak_hour"]


def parse_datetime(series: pd.Series) -> pd.Series:
    try:
        return pd.to_datetime(series, errors="coerce", format="mixed")
    except TypeError:
        return pd.to_datetime(series, errors="coerce")


def load_feature_columns() -> list[str]:
    if not FEATURE_COLUMNS_FILE.exists():
        raise FileNotFoundError(f"Feature list not found: {FEATURE_COLUMNS_FILE}")
    return [line.strip() for line in FEATURE_COLUMNS_FILE.read_text(encoding="utf-8").splitlines() if line.strip()]


def clip_prediction(values: np.ndarray | pd.Series) -> np.ndarray:
    return np.maximum(np.asarray(values, dtype=float), 0.0)


def rmse(actual: np.ndarray, pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((pred - actual) ** 2))) if len(actual) else np.nan


def mae(actual: np.ndarray, pred: np.ndarray) -> float:
    return float(np.mean(np.abs(pred - actual))) if len(actual) else np.nan


def mape(actual: np.ndarray, pred: np.ndarray) -> float:
    mask = actual != 0
    if not mask.any():
        return np.nan
    return float(np.mean(np.abs((pred[mask] - actual[mask]) / actual[mask])) * 100)


def smape(actual: np.ndarray, pred: np.ndarray) -> float:
    denominator = np.abs(actual) + np.abs(pred)
    mask = denominator != 0
    if not mask.any():
        return np.nan
    return float(np.mean(2 * np.abs(pred[mask] - actual[mask]) / denominator[mask]) * 100)


def r2_score_safe(actual: np.ndarray, pred: np.ndarray) -> float:
    if len(actual) == 0:
        return np.nan
    ss_res = float(np.sum((actual - pred) ** 2))
    ss_tot = float(np.sum((actual - np.mean(actual)) ** 2))
    if ss_tot == 0:
        return np.nan
    return 1 - ss_res / ss_tot


def rate(condition: np.ndarray) -> float:
    return float(np.mean(condition) * 100) if len(condition) else np.nan


def peak_metrics(df: pd.DataFrame, pred_col: str, high: bool = False) -> dict[str, float]:
    flag = "is_high_peak_hour" if high else "is_peak_hour"
    subset = df.loc[df[flag] == 1]
    prefix = "high_peak" if high else "peak"
    if subset.empty:
        return {
            f"{prefix}_MAE": np.nan,
            f"{prefix}_RMSE": np.nan,
            f"{prefix}_underestimation_rate": np.nan,
            f"mean_actual_{prefix}_load_kw": np.nan,
            f"mean_predicted_{prefix}_load_kw": np.nan,
        }
    actual = subset[TARGET].to_numpy(dtype=float)
    pred = subset[pred_col].to_numpy(dtype=float)
    return {
        f"{prefix}_MAE": mae(actual, pred),
        f"{prefix}_RMSE": rmse(actual, pred),
        f"{prefix}_underestimation_rate": rate(pred < actual),
        f"mean_actual_{prefix}_load_kw": float(np.mean(actual)),
        f"mean_predicted_{prefix}_load_kw": float(np.mean(pred)),
    }


def evaluate_overall(df: pd.DataFrame, model_name: str, split: str, pred_col: str) -> dict[str, Any]:
    actual = df[TARGET].to_numpy(dtype=float)
    pred = df[pred_col].to_numpy(dtype=float)
    peak = peak_metrics(df, pred_col, high=False)
    high_peak = peak_metrics(df, pred_col, high=True)
    return {
        "model_name": model_name,
        "split": split,
        "MAE": mae(actual, pred),
        "RMSE": rmse(actual, pred),
        "MAPE": mape(actual, pred),
        "sMAPE": smape(actual, pred),
        "R2": r2_score_safe(actual, pred),
        "MBE": float(np.mean(pred - actual)) if len(actual) else np.nan,
        "underestimation_rate": rate(pred < actual),
        "overestimation_rate": rate(pred > actual),
        "peak_MAE": peak["peak_MAE"],
        "high_peak_MAE": high_peak["high_peak_MAE"],
        "peak_RMSE": peak["peak_RMSE"],
        "high_peak_RMSE": high_peak["high_peak_RMSE"],
        "peak_underestimation_rate": peak["peak_underestimation_rate"],
        "high_peak_underestimation_rate": high_peak["high_peak_underestimation_rate"],
        "mean_actual_peak_load_kw": peak["mean_actual_peak_load_kw"],
        "mean_predicted_peak_load_kw": peak["mean_predicted_peak_load_kw"],
    }


def evaluate_site(
    df: pd.DataFrame,
    model_name: str,
    split: str,
    pred_col: str,
    site_train_means: dict[str, float],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for site_id, site_df in df.groupby("site_id", sort=True):
        actual = site_df[TARGET].to_numpy(dtype=float)
        pred = site_df[pred_col].to_numpy(dtype=float)
        site_mean = site_train_means.get(site_id, np.nan)
        peak = peak_metrics(site_df, pred_col, high=False)
        rows.append(
            {
                "model_name": model_name,
                "split": split,
                "site_id": site_id,
                "row_count": len(site_df),
                "MAE": mae(actual, pred),
                "RMSE": rmse(actual, pred),
                "normalized_MAE_by_site_mean": mae(actual, pred) / site_mean if site_mean else np.nan,
                "normalized_RMSE_by_site_mean": rmse(actual, pred) / site_mean if site_mean else np.nan,
                "MBE": float(np.mean(pred - actual)) if len(actual) else np.nan,
                "underestimation_rate": rate(pred < actual),
                "peak_MAE": peak["peak_MAE"],
                "peak_underestimation_rate": peak["peak_underestimation_rate"],
            }
        )
    return rows


def add_rule_based_predictions(
    train: pd.DataFrame,
    validation: pd.DataFrame,
    test: pd.DataFrame,
) -> tuple[list[str], dict[str, float], dict[str, float]]:
    models = [
        "Zero_Load",
        "Global_Train_Mean",
        "Site_Train_Mean",
        "Persistence_1h",
        "Persistence_24h",
        "Persistence_168h",
        "Average_24h_168h",
    ]
    global_train_mean = float(train[TARGET].mean())
    site_train_means = train.groupby("site_id")[TARGET].mean().to_dict()

    for df in [validation, test]:
        df["pred_Zero_Load"] = 0.0
        df["pred_Global_Train_Mean"] = global_train_mean
        df["pred_Site_Train_Mean"] = df["site_id"].map(site_train_means).fillna(global_train_mean)
        df["pred_Persistence_1h"] = df["lag_1h"]
        df["pred_Persistence_24h"] = df["lag_24h"]
        df["pred_Persistence_168h"] = df["lag_168h"]
        df["pred_Average_24h_168h"] = (df["lag_24h"] + df["lag_168h"]) / 2
        for model in models:
            df[f"pred_{model}"] = clip_prediction(df[f"pred_{model}"])
    return models, site_train_means, {"global_train_mean": global_train_mean}


def add_sklearn_predictions(
    train: pd.DataFrame,
    validation: pd.DataFrame,
    test: pd.DataFrame,
    feature_columns: list[str],
    warnings: list[str],
) -> list[str]:
    try:
        from sklearn.linear_model import LinearRegression, Ridge
    except Exception as exc:
        warnings.append(f"sklearn unavailable; skipped Linear/Ridge baselines: {type(exc).__name__}: {exc}")
        return []

    models = [
        ("Linear_Regression_All_Features", LinearRegression()),
        ("Ridge_Regression_All_Features", Ridge(alpha=1.0)),
    ]
    X_train = train[feature_columns].to_numpy(dtype=float)
    y_train = train[TARGET].to_numpy(dtype=float)
    evaluated: list[str] = []
    for model_name, estimator in models:
        try:
            estimator.fit(X_train, y_train)
            validation[f"pred_{model_name}"] = clip_prediction(
                estimator.predict(validation[feature_columns].to_numpy(dtype=float))
            )
            test[f"pred_{model_name}"] = clip_prediction(
                estimator.predict(test[feature_columns].to_numpy(dtype=float))
            )
            evaluated.append(model_name)
        except Exception as exc:
            warnings.append(f"Skipped {model_name}: {type(exc).__name__}: {exc}")
    return evaluated


def build_prediction_export(df: pd.DataFrame, models: list[str]) -> pd.DataFrame:
    output = pd.DataFrame(
        {
            "timestamp": df["timestamp"],
            "site_id": df["site_id"],
            "actual_load_kw": df[TARGET],
            "split": df["split"],
            "is_peak_hour": df["is_peak_hour"],
            "is_high_peak_hour": df["is_high_peak_hour"],
        }
    )
    for model in models:
        output[f"prediction_{model}"] = df[f"pred_{model}"]
    return output


def build_ranking(overall: pd.DataFrame) -> pd.DataFrame:
    rows: list[pd.DataFrame] = []
    for split in ["validation", "test"]:
        split_df = overall.loc[overall["split"] == split]
        for metric in ["MAE", "RMSE", "peak_MAE", "high_peak_MAE"]:
            ranking = split_df[["model_name", "split", metric]].copy()
            ranking = ranking.rename(columns={metric: "metric_value"})
            ranking["rank_metric"] = metric
            ranking["rank"] = ranking["metric_value"].rank(method="min", ascending=True)
            ranking = ranking.sort_values(["rank", "model_name"])
            rows.append(ranking)
    return pd.concat(rows, ignore_index=True)


def build_best_summary(overall: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    metric_map = {
        "best model by MAE": "MAE",
        "best model by RMSE": "RMSE",
        "best model by peak_MAE": "peak_MAE",
        "best model by high_peak_MAE": "high_peak_MAE",
        "best model by lowest underestimation_rate": "underestimation_rate",
    }
    for split in ["validation", "test"]:
        split_df = overall.loc[overall["split"] == split]
        for label, metric in metric_map.items():
            non_missing = split_df.dropna(subset=[metric])
            if non_missing.empty:
                rows.append({"split": split, "selection": label, "model_name": "", "metric": metric, "metric_value": np.nan})
                continue
            row = non_missing.loc[non_missing[metric].idxmin()]
            rows.append(
                {
                    "split": split,
                    "selection": label,
                    "model_name": row["model_name"],
                    "metric": metric,
                    "metric_value": row[metric],
                }
            )
    return pd.DataFrame(rows)


def add_bar_labels(ax: plt.Axes, fmt: str = "{:.2f}") -> None:
    for patch in ax.patches:
        height = patch.get_height()
        if np.isfinite(height):
            ax.text(
                patch.get_x() + patch.get_width() / 2,
                height,
                fmt.format(height),
                ha="center",
                va="bottom",
                fontsize=8,
                rotation=0,
            )


def save_metric_bar(overall: pd.DataFrame, split: str, metric: str, title: str, ylabel: str, path: Path) -> None:
    plot_df = overall.loc[overall["split"] == split].sort_values(metric)
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.bar(plot_df["model_name"], plot_df[metric])
    ax.set_title(title)
    ax.set_xlabel("Baseline model")
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=35)
    add_bar_labels(ax)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def save_actual_vs_best_test(test: pd.DataFrame, best_model: str, path: Path) -> None:
    site_id = test.groupby("site_id").size().sort_values(ascending=False).index[0]
    site_df = test.loc[test["site_id"] == site_id].sort_values("timestamp")
    start = site_df["timestamp"].min()
    sample = site_df.loc[site_df["timestamp"] < start + pd.Timedelta(days=7)]
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(sample["timestamp"], sample[TARGET], label="Actual load", linewidth=2)
    ax.plot(sample["timestamp"], sample[f"pred_{best_model}"], label=best_model, linewidth=1.6)
    ax.set_title(f"Actual vs best baseline test prediction sample: {site_id}")
    ax.set_xlabel("Timestamp")
    ax.set_ylabel("Load (kW)")
    ax.legend()
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def save_site_level_top3(site_metrics: pd.DataFrame, overall: pd.DataFrame, path: Path) -> None:
    top3 = (
        overall.loc[overall["split"] == "test"]
        .sort_values("MAE")
        .head(3)["model_name"]
        .tolist()
    )
    plot_df = site_metrics.loc[(site_metrics["split"] == "test") & (site_metrics["model_name"].isin(top3))]
    pivot = plot_df.pivot(index="site_id", columns="model_name", values="MAE")
    fig, ax = plt.subplots(figsize=(12, 6))
    pivot.plot(kind="bar", ax=ax)
    ax.set_title("Test MAE by site for top 3 baseline models")
    ax.set_xlabel("Site")
    ax.set_ylabel("MAE (kW)")
    ax.tick_params(axis="x", rotation=35)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def write_captions() -> None:
    captions = [
        "Fig. 1. Validation mean absolute error by leakage-free baseline forecasting model.",
        "Fig. 2. Test mean absolute error by leakage-free baseline forecasting model.",
        "Fig. 3. Test peak-hour mean absolute error by leakage-free baseline forecasting model.",
        "Fig. 4. Actual test load and best-by-MAE baseline prediction for a readable seven-day sample from a representative site.",
        "Fig. 5. Site-level test mean absolute error for the three best baseline models by overall test MAE.",
        "Fig. 6. Test underestimation rate by leakage-free baseline forecasting model.",
    ]
    CAPTIONS_FILE.write_text("\n".join(captions) + "\n", encoding="utf-8")


def write_reports(
    input_shape: tuple[int, int],
    counts: pd.Series,
    models: list[str],
    warnings: list[str],
    best_summary: pd.DataFrame,
    overall: pd.DataFrame,
) -> None:
    best_val_mae = best_summary.loc[
        (best_summary["split"] == "validation") & (best_summary["selection"] == "best model by MAE")
    ].iloc[0]
    best_test_mae = best_summary.loc[
        (best_summary["split"] == "test") & (best_summary["selection"] == "best model by MAE")
    ].iloc[0]
    best_test_peak = best_summary.loc[
        (best_summary["split"] == "test") & (best_summary["selection"] == "best model by peak_MAE")
    ].iloc[0]
    seasonal_names = ["Persistence_24h", "Persistence_168h", "Average_24h_168h"]
    seasonal_test = overall.loc[(overall["split"] == "test") & (overall["model_name"].isin(seasonal_names))]
    best_seasonal = seasonal_test.sort_values("MAE").iloc[0] if not seasonal_test.empty else None
    best_under = overall.loc[overall["split"] == "test"].sort_values("underestimation_rate").iloc[0]

    LEAKAGE_REPORT_FILE.write_text(
        "\n".join(
            [
                "Step 06 baseline leakage safety report",
                "=" * 39,
                "",
                "- Existing Step 05B chronological train/validation/test splits were used exactly as saved.",
                "- No random split was created and no shuffling was performed.",
                "- Zero, global-mean, site-mean, and persistence baselines are deterministic rules evaluated on validation/test rows only.",
                "- Global_Train_Mean uses only training target_load_kw rows.",
                "- Site_Train_Mean uses only same-site training target_load_kw rows.",
                "- Persistence baselines use lag_1h, lag_24h, and lag_168h features created from past observations only.",
                "- LinearRegression and Ridge, when available, are fit only on the train split using 05B_modeling_feature_columns.txt.",
                "- Validation and test rows are never used for fitting.",
                "- Negative predictions are clipped to zero only after prediction because EV charging load cannot be negative.",
                "",
            ]
        ),
        encoding="utf-8",
    )

    warning_lines = [f"- {warning}" for warning in warnings] if warnings else ["- None"]
    REPORT_FILE.write_text(
        "\n".join(
            [
                "Step 06 baseline forecasting report",
                "=" * 36,
                "",
                f"Input file used: {FEATURE_FILE}",
                f"Input shape: {input_shape}",
                f"Train rows: {int(counts.get('train', 0))}",
                f"Validation rows: {int(counts.get('validation', 0))}",
                f"Test rows: {int(counts.get('test', 0))}",
                "",
                "Models evaluated:",
                *(f"- {model}" for model in models),
                "",
                f"Best validation baseline by MAE: {best_val_mae.model_name} ({best_val_mae.metric_value:.4f} kW)",
                f"Best test baseline by MAE: {best_test_mae.model_name} ({best_test_mae.metric_value:.4f} kW)",
                f"Best test peak-load baseline by peak_MAE: {best_test_peak.model_name} ({best_test_peak.metric_value:.4f} kW)",
                "",
                "Seasonal baseline observation:",
                (
                    f"- Best simple seasonal test baseline is {best_seasonal.model_name} with MAE {best_seasonal.MAE:.4f} kW."
                    if best_seasonal is not None
                    else "- Seasonal baseline metrics were not available."
                ),
                "- These simple seasonal rules provide important reference points, but they cannot adapt richly to site, calendar, peak-memory, and interaction structure.",
                "",
                "Peak underestimation observation:",
                f"- Lowest overall test underestimation rate: {best_under.model_name} ({best_under.underestimation_rate:.2f}%).",
                "- Peak-hour underestimation remains an important diagnostic for the next peak-aware ML step.",
                "",
                "Why Step 07 ML forecasting is needed next:",
                "- Baselines establish the minimum performance that a stronger method must beat.",
                "- The corrected 05B features contain calendar, lag, rolling, peak-memory, and site-normalized signals that simple rules cannot fully exploit.",
                "- Step 07 should compare machine-learning models against these baselines using the same leakage-free splits.",
                "",
                "Warnings:",
                *warning_lines,
                "",
                "Recommended next step:",
                "- Create Step 07 for ML forecasting using 05B_modeling_feature_columns.txt and compare against these Step 06 baselines. Do not create prediction intervals or scheduling optimization yet.",
                "",
            ]
        ),
        encoding="utf-8",
    )


def main() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)

    if not FEATURE_FILE.exists():
        raise FileNotFoundError(f"Feature dataset not found: {FEATURE_FILE}")

    feature_columns = load_feature_columns()
    df = pd.read_csv(FEATURE_FILE)
    input_shape = df.shape
    df["timestamp"] = parse_datetime(df["timestamp"])
    missing_features = sorted(set(feature_columns) - set(df.columns))
    if missing_features:
        raise ValueError(f"Missing modeling feature columns in feature dataset: {missing_features[:10]}")

    train = df.loc[df["split"] == "train"].copy()
    validation = df.loc[df["split"] == "validation"].copy()
    test = df.loc[df["split"] == "test"].copy()
    counts = df["split"].value_counts().reindex(["train", "validation", "test"], fill_value=0)

    warnings: list[str] = []
    models, site_train_means, _ = add_rule_based_predictions(train, validation, test)
    models.extend(add_sklearn_predictions(train, validation, test, feature_columns, warnings))

    overall_rows: list[dict[str, Any]] = []
    site_rows: list[dict[str, Any]] = []
    for split_name, split_df in [("validation", validation), ("test", test)]:
        for model in models:
            pred_col = f"pred_{model}"
            overall_rows.append(evaluate_overall(split_df, model, split_name, pred_col))
            site_rows.extend(evaluate_site(split_df, model, split_name, pred_col, site_train_means))

    overall = pd.DataFrame(overall_rows).sort_values(["split", "MAE", "model_name"])
    site_metrics = pd.DataFrame(site_rows).sort_values(["split", "site_id", "MAE", "model_name"])
    ranking = build_ranking(overall)
    best_summary = build_best_summary(overall)

    overall.to_csv(OVERALL_METRICS_FILE, index=False)
    site_metrics.to_csv(SITE_METRICS_FILE, index=False)
    build_prediction_export(validation, models).to_csv(VALIDATION_PREDICTIONS_FILE, index=False)
    build_prediction_export(test, models).to_csv(TEST_PREDICTIONS_FILE, index=False)
    ranking.to_csv(RANKING_FILE, index=False)
    best_summary.to_csv(BEST_SUMMARY_FILE, index=False)

    save_metric_bar(overall, "validation", "MAE", "Validation MAE by baseline model", "MAE (kW)", FIGURES_DIR / "06_fig1_baseline_mae_validation.png")
    save_metric_bar(overall, "test", "MAE", "Test MAE by baseline model", "MAE (kW)", FIGURES_DIR / "06_fig2_baseline_mae_test.png")
    save_metric_bar(overall, "test", "peak_MAE", "Test peak-hour MAE by baseline model", "Peak MAE (kW)", FIGURES_DIR / "06_fig3_baseline_peak_mae_test.png")
    best_test_model = best_summary.loc[
        (best_summary["split"] == "test") & (best_summary["selection"] == "best model by MAE"),
        "model_name",
    ].iloc[0]
    save_actual_vs_best_test(test, best_test_model, FIGURES_DIR / "06_fig4_actual_vs_best_baseline_test_sample.png")
    save_site_level_top3(site_metrics, overall, FIGURES_DIR / "06_fig5_site_level_test_mae.png")
    save_metric_bar(
        overall,
        "test",
        "underestimation_rate",
        "Test underestimation rate by baseline model",
        "Underestimation rate (%)",
        FIGURES_DIR / "06_fig6_baseline_underestimation_rate_test.png",
    )
    write_captions()
    write_reports(input_shape, counts, models, warnings, best_summary, overall)

    output_files = [
        OVERALL_METRICS_FILE,
        SITE_METRICS_FILE,
        VALIDATION_PREDICTIONS_FILE,
        TEST_PREDICTIONS_FILE,
        RANKING_FILE,
        BEST_SUMMARY_FILE,
        CAPTIONS_FILE,
        LEAKAGE_REPORT_FILE,
        REPORT_FILE,
    ]
    best_validation = best_summary.loc[
        (best_summary["split"] == "validation") & (best_summary["selection"] == "best model by MAE")
    ].iloc[0]
    best_test = best_summary.loc[
        (best_summary["split"] == "test") & (best_summary["selection"] == "best model by MAE")
    ].iloc[0]

    print("Step 06 baseline forecasting complete")
    print("=====================================")
    print(f"Input shape: {input_shape}")
    print(f"Train/validation/test rows: {int(counts['train'])}/{int(counts['validation'])}/{int(counts['test'])}")
    print("Models successfully evaluated:")
    for model in models:
        print(f"- {model}")
    if warnings:
        print("Warnings:")
        for warning in warnings:
            print(f"- {warning}")
    print(f"Best validation model by MAE: {best_validation.model_name} ({best_validation.metric_value:.4f} kW)")
    print(f"Best test model by MAE: {best_test.model_name} ({best_test.metric_value:.4f} kW)")
    print("")
    print("Output files saved:")
    for path in output_files:
        print(f"- {path}")
    print("")
    print(f"Report location: {REPORT_FILE}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(1)
