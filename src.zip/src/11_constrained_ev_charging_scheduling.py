"""
Step 11: Constrained EV charging scheduling.

Run from the project root:
    python src/11_constrained_ev_charging_scheduling.py

This step builds realistic session-level charging schedules using the
uncertainty-aware forecast file from Step 10. It does not use actual future
load to make scheduling decisions.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import re
import sys
import types
import warnings

import numpy as np


if "_strptime" not in sys.modules:
    stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    stub.LocaleTime = LocaleTime
    stub.TimeRE = TimeRE
    stub._TimeRE_cache = TimeRE()
    stub._regex_cache = {}
    stub._getlang = _getlang
    stub._strptime = _strptime
    stub._strptime_time = _strptime
    stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "11_constrained_scheduling"
FIGURES_DIR = PROJECT_ROOT / "figures" / "11_constrained_scheduling"

SESSION_FILE = PROCESSED_DIR / "02_scheduling_ready_sessions.csv"
HOURLY_FILE = PROCESSED_DIR / "03_hourly_load_all_sites.csv"
FORECAST_FILE = PROCESSED_DIR / "10_uncertainty_forecasts_for_scheduling.csv"
SELECTED_INTERVAL_FILE = PROJECT_ROOT / "results" / "10_prediction_intervals" / "10_selected_interval_method.csv"
PEAK_BY_SITE_FILE = PROJECT_ROOT / "results" / "04_exploratory_analysis" / "04_peak_load_by_site.csv"

SCHEDULED_SESSIONS_FILE = PROCESSED_DIR / "11_scheduled_sessions.csv"
SCHEDULED_HOURLY_FILE = PROCESSED_DIR / "11_scheduled_hourly_loads.csv"

DEFAULT_CHARGER_POWER_KW = 6.6
FULLY_SERVED_TOLERANCE_KWH = 0.05

STRATEGIES = {
    "uncontrolled": {
        "label": "Uncontrolled baseline",
        "signal": None,
        "uses_capacity": False,
    },
    "valley_filling": {
        "label": "Deadline-aware valley filling",
        "signal": "dynamic_load",
        "uses_capacity": True,
    },
    "point_forecast": {
        "label": "Forecast-informed point scheduling",
        "signal": "main_point_forecast_kw",
        "uses_capacity": True,
    },
    "peak_sensitive": {
        "label": "Peak-sensitive scheduling",
        "signal": "peak_sensitive_point_forecast_kw",
        "uses_capacity": True,
    },
    "uncertainty_aware": {
        "label": "Uncertainty-aware upper-bound scheduling",
        "signal": "upper_forecast_kw",
        "uses_capacity": True,
    },
}


def ensure_dirs() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)


def require_file(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Required file not found: {path}")


def read_csv(path: Path, **kwargs: Any) -> pd.DataFrame:
    require_file(path)
    return pd.read_csv(path, **kwargs)


def pick_column(columns: list[str], candidates: list[str]) -> str | None:
    lower_map = {column.lower(): column for column in columns}
    for candidate in candidates:
        if candidate.lower() in lower_map:
            return lower_map[candidate.lower()]
    return None


def parse_timestamp(series: pd.Series) -> pd.Series:
    parsed = pd.to_datetime(series, errors="coerce", utc=True)
    return parsed


def floor_hour(ts: pd.Timestamp) -> pd.Timestamp:
    return ts.floor("H")


def ceil_hour(ts: pd.Timestamp) -> pd.Timestamp:
    return ts.ceil("H")


def safe_rate(numerator: float, denominator: float) -> float:
    if denominator == 0 or pd.isna(denominator):
        return 0.0
    return float(numerator) / float(denominator)


def pct(numerator: float, denominator: float) -> float:
    return 100.0 * safe_rate(numerator, denominator)


def standardize_sessions(sessions: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, str]]:
    columns = list(sessions.columns)
    mapping = {
        "session_id": pick_column(columns, ["session_id", "sessionID", "_id", "id"]),
        "site_id": pick_column(columns, ["site_id", "siteID", "site", "location_id"]),
        "arrival_time": pick_column(columns, ["arrival_time", "arrival", "connectionTime", "connect_time"]),
        "departure_time": pick_column(columns, ["departure_time", "requestedDeparture", "done_time", "disconnectTime"]),
        "done_time": pick_column(columns, ["done_time", "disconnectTime"]),
        "energy_kwh": pick_column(columns, ["energy_kwh", "kWhDelivered", "kwh_delivered", "energy"]),
        "requested_energy_kwh": pick_column(columns, ["requested_energy_kwh", "kWhRequested"]),
        "max_charging_power_kw": pick_column(
            columns,
            ["max_charging_power_kw", "max_power_kw", "charger_power_kw", "pilotSignal", "evse_power_kw"],
        ),
    }

    required = ["arrival_time", "energy_kwh"]
    missing = [name for name in required if mapping[name] is None]
    if missing:
        raise ValueError(f"Missing required session columns after detection: {missing}")

    if mapping["departure_time"] is None:
        mapping["departure_time"] = mapping["done_time"]
    if mapping["departure_time"] is None:
        raise ValueError("No departure-like session column found.")

    standardized = pd.DataFrame()
    standardized["session_id"] = (
        sessions[mapping["session_id"]].astype(str)
        if mapping["session_id"] is not None
        else [f"session_{i:07d}" for i in range(len(sessions))]
    )
    standardized["original_site_id"] = (
        sessions[mapping["site_id"]].astype(str) if mapping["site_id"] is not None else "unknown_site"
    )
    standardized["site_id"] = standardized["original_site_id"]
    standardized["arrival_time"] = parse_timestamp(sessions[mapping["arrival_time"]])
    standardized["departure_time"] = parse_timestamp(sessions[mapping["departure_time"]])
    standardized["energy_kwh"] = pd.to_numeric(sessions[mapping["energy_kwh"]], errors="coerce")

    if mapping["requested_energy_kwh"] is not None:
        requested = pd.to_numeric(sessions[mapping["requested_energy_kwh"]], errors="coerce")
        standardized["requested_energy_kwh"] = requested.fillna(standardized["energy_kwh"])
    else:
        standardized["requested_energy_kwh"] = standardized["energy_kwh"]

    if mapping["max_charging_power_kw"] is not None:
        max_power = pd.to_numeric(sessions[mapping["max_charging_power_kw"]], errors="coerce")
        standardized["max_charging_power_kw"] = max_power.fillna(DEFAULT_CHARGER_POWER_KW)
    else:
        standardized["max_charging_power_kw"] = DEFAULT_CHARGER_POWER_KW

    standardized["max_charging_power_kw"] = standardized["max_charging_power_kw"].clip(lower=0.1, upper=50.0)
    standardized["energy_kwh"] = standardized["energy_kwh"].fillna(standardized["requested_energy_kwh"])
    standardized["duration_hours"] = (
        standardized["departure_time"] - standardized["arrival_time"]
    ).dt.total_seconds() / 3600.0
    standardized["required_average_power_kw"] = standardized["energy_kwh"] / standardized["duration_hours"]

    invalid_mask = (
        standardized["arrival_time"].isna()
        | standardized["departure_time"].isna()
        | (standardized["departure_time"] <= standardized["arrival_time"])
        | standardized["energy_kwh"].isna()
        | (standardized["energy_kwh"] <= 0)
        | standardized["max_charging_power_kw"].isna()
        | (standardized["max_charging_power_kw"] <= 0)
    )
    removed = standardized.loc[invalid_mask].copy()
    valid = standardized.loc[~invalid_mask].copy()
    valid = valid.reset_index(drop=True)
    removed.to_csv(RESULTS_DIR / "11_removed_or_invalid_sessions.csv", index=False)
    return valid, removed, {key: value or "" for key, value in mapping.items()}


def load_forecasts() -> pd.DataFrame:
    forecasts = read_csv(FORECAST_FILE)
    required = {
        "timestamp",
        "site_id",
        "main_point_forecast_kw",
        "peak_sensitive_point_forecast_kw",
        "upper_forecast_kw",
    }
    missing = sorted(required - set(forecasts.columns))
    if missing:
        raise ValueError(f"Step 10 forecast file is missing columns: {missing}")
    forecasts["timestamp"] = parse_timestamp(forecasts["timestamp"])
    forecasts["site_id"] = forecasts["site_id"].astype(str)
    for column in [
        "actual_load_kw",
        "main_point_forecast_kw",
        "peak_sensitive_point_forecast_kw",
        "lower_forecast_kw",
        "upper_forecast_kw",
    ]:
        if column in forecasts.columns:
            forecasts[column] = pd.to_numeric(forecasts[column], errors="coerce").fillna(0.0).clip(lower=0.0)
    forecasts = forecasts.dropna(subset=["timestamp", "site_id"]).sort_values(["site_id", "timestamp"])
    return forecasts.reset_index(drop=True)


def load_hourly() -> pd.DataFrame:
    hourly = read_csv(HOURLY_FILE)
    required = {"timestamp", "site_id", "load_kw"}
    missing = sorted(required - set(hourly.columns))
    if missing:
        raise ValueError(f"Hourly load file is missing columns: {missing}")
    hourly["timestamp"] = parse_timestamp(hourly["timestamp"])
    hourly["site_id"] = hourly["site_id"].astype(str)
    hourly["load_kw"] = pd.to_numeric(hourly["load_kw"], errors="coerce").fillna(0.0).clip(lower=0.0)
    return hourly.dropna(subset=["timestamp", "site_id"]).reset_index(drop=True)


def map_session_sites(sessions: pd.DataFrame, hourly: pd.DataFrame, forecasts: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    forecast_sites = set(forecasts["site_id"].unique())
    hourly_ranges = (
        hourly.groupby("site_id")["timestamp"].agg(["min", "max", "count"]).reset_index().sort_values("count", ascending=False)
    )
    rows = []
    sessions = sessions.copy()
    for original_site, group in sessions.groupby("original_site_id"):
        if original_site in forecast_sites:
            mapped_site = original_site
            reason = "session site already appears in Step 10 forecast file"
        else:
            start = group["arrival_time"].min()
            end = group["departure_time"].max()
            candidates = hourly_ranges.copy()
            candidates["overlap_hours"] = [
                max(0.0, (min(row["max"], end) - max(row["min"], start)).total_seconds() / 3600.0)
                for _, row in candidates.iterrows()
            ]
            if candidates["overlap_hours"].max() > 0:
                mapped_site = str(candidates.sort_values(["overlap_hours", "count"], ascending=False).iloc[0]["site_id"])
                reason = "mapped to hourly site with strongest timestamp overlap"
            else:
                mapped_site = sorted(forecast_sites)[0]
                reason = "mapped to first forecast site because no timestamp-overlap site was available"
        sessions.loc[sessions["original_site_id"] == original_site, "site_id"] = mapped_site
        rows.append(
            {
                "original_site_id": original_site,
                "mapped_site_id": mapped_site,
                "session_count": len(group),
                "reason": reason,
            }
        )
    return sessions, pd.DataFrame(rows)


def sessions_with_forecast_intersection(sessions: pd.DataFrame, forecasts: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    ranges = forecasts.groupby("site_id")["timestamp"].agg(["min", "max", "count"]).reset_index()
    ranges = ranges.rename(columns={"min": "forecast_start", "max": "forecast_end", "count": "forecast_hours"})
    merged = sessions.merge(ranges, on="site_id", how="left")
    intersects = (
        merged["forecast_start"].notna()
        & (merged["departure_time"] >= merged["forecast_start"])
        & (merged["arrival_time"] <= merged["forecast_end"])
    )
    direct = merged.loc[intersects].copy()
    coverage_rows = []
    for site_id, group in merged.groupby("site_id", dropna=False):
        has_range = group["forecast_start"].notna().any()
        coverage_rows.append(
            {
                "site_id": site_id,
                "sessions_after_cleaning": len(group),
                "sessions_directly_overlapping_forecast": int(intersects.loc[group.index].sum()),
                "session_start": group["arrival_time"].min(),
                "session_end": group["departure_time"].max(),
                "forecast_start": group["forecast_start"].dropna().min() if has_range else pd.NaT,
                "forecast_end": group["forecast_end"].dropna().max() if has_range else pd.NaT,
                "forecast_hours": int(group["forecast_hours"].dropna().max()) if has_range else 0,
            }
        )
    return direct[sessions.columns].reset_index(drop=True), pd.DataFrame(coverage_rows)


def build_forecast_horizon_scenario(
    sessions: pd.DataFrame,
    forecasts: pd.DataFrame,
    coverage: pd.DataFrame,
) -> tuple[pd.DataFrame, str]:
    direct, _ = sessions_with_forecast_intersection(sessions, forecasts)
    if len(direct) > 0:
        direct = direct.copy()
        direct["scenario_mode"] = "direct_timestamp_intersection"
        return direct, "direct_timestamp_intersection"

    scenario_frames = []
    forecast_ranges = forecasts.groupby("site_id")["timestamp"].agg(["min", "max"]).reset_index()
    for site_id, group in sessions.groupby("site_id"):
        range_rows = forecast_ranges.loc[forecast_ranges["site_id"] == site_id]
        if range_rows.empty:
            continue
        f_start = range_rows.iloc[0]["min"]
        f_end = range_rows.iloc[0]["max"]
        group = group.sort_values("arrival_time").copy()
        shift = floor_hour(f_start) - floor_hour(group["arrival_time"].min())
        group["original_arrival_time"] = group["arrival_time"]
        group["original_departure_time"] = group["departure_time"]
        group["arrival_time"] = group["arrival_time"] + shift
        group["departure_time"] = group["departure_time"] + shift
        group = group.loc[(group["departure_time"] >= f_start) & (group["arrival_time"] <= f_end)].copy()
        group["arrival_time"] = group["arrival_time"].clip(lower=f_start)
        group["departure_time"] = group["departure_time"].clip(upper=f_end + pd.Timedelta(hours=1))
        group["duration_hours"] = (group["departure_time"] - group["arrival_time"]).dt.total_seconds() / 3600.0
        group = group.loc[group["duration_hours"] > 0].copy()
        if len(group) > 0:
            scenario_frames.append(group)

    if not scenario_frames:
        empty = sessions.iloc[0:0].copy()
        empty["scenario_mode"] = "no_schedulable_sessions"
        return empty, "no_schedulable_sessions"

    scenario = pd.concat(scenario_frames, ignore_index=True)
    scenario["scenario_mode"] = "calendar_aligned_forecast_horizon"
    coverage["fallback_note"] = (
        "No direct session/forecast timestamp intersection was available; real session constraints were "
        "calendar-aligned into the Step 10 forecast horizon for operational scheduling simulation."
    )
    return scenario.reset_index(drop=True), "calendar_aligned_forecast_horizon"


def build_hour_index(forecasts: pd.DataFrame) -> pd.DataFrame:
    keep_cols = [
        "timestamp",
        "site_id",
        "actual_load_kw",
        "main_point_forecast_kw",
        "peak_sensitive_point_forecast_kw",
        "upper_forecast_kw",
        "is_peak_hour",
        "is_high_peak_hour",
    ]
    cols = [column for column in keep_cols if column in forecasts.columns]
    hours = forecasts[cols].copy()
    for column in ["actual_load_kw", "main_point_forecast_kw", "peak_sensitive_point_forecast_kw", "upper_forecast_kw"]:
        if column not in hours.columns:
            hours[column] = 0.0
    return hours.sort_values(["site_id", "timestamp"]).reset_index(drop=True)


def slot_overlap_hours(arrival: pd.Timestamp, departure: pd.Timestamp, hour_start: pd.Timestamp) -> float:
    hour_end = hour_start + pd.Timedelta(hours=1)
    overlap_start = max(arrival, hour_start)
    overlap_end = min(departure, hour_end)
    return max(0.0, (overlap_end - overlap_start).total_seconds() / 3600.0)


def feasible_slots(session: pd.Series, site_hours: pd.DataFrame) -> pd.DataFrame:
    timestamps = site_hours["timestamp"].reset_index(drop=True)
    start_bound = session["arrival_time"] - pd.Timedelta(hours=1)
    end_bound = session["departure_time"]
    start_idx = int(timestamps.searchsorted(start_bound, side="right"))
    end_idx = int(timestamps.searchsorted(end_bound, side="left"))
    slots = site_hours.iloc[start_idx:end_idx].copy()
    if slots.empty:
        return slots
    overlaps = [slot_overlap_hours(session["arrival_time"], session["departure_time"], ts) for ts in slots["timestamp"]]
    slots["overlap_hours"] = overlaps
    slots = slots.loc[slots["overlap_hours"] > 0].copy()
    slots["slot_max_energy_kwh"] = slots["overlap_hours"] * float(session["max_charging_power_kw"])
    return slots


def allocate_uncontrolled(session: pd.Series, site_hours: pd.DataFrame) -> list[dict[str, Any]]:
    remaining = float(session["energy_kwh"])
    allocations = []
    slots = feasible_slots(session, site_hours).sort_values("timestamp")
    for _, slot in slots.iterrows():
        if remaining <= 1e-9:
            break
        energy = min(remaining, float(slot["slot_max_energy_kwh"]))
        if energy > 1e-9:
            allocations.append(
                {
                    "session_id": session["session_id"],
                    "site_id": session["site_id"],
                    "timestamp": slot["timestamp"],
                    "energy_kwh": energy,
                    "power_kw": energy / float(slot["overlap_hours"]),
                    "soft_capacity_violation_kwh": 0.0,
                }
            )
            remaining -= energy
    return allocations


def rank_slots(
    slots: pd.DataFrame,
    strategy: str,
    scheduled_load: dict[pd.Timestamp, float],
    capacity_kw: float,
) -> pd.DataFrame:
    slots = slots.copy()
    if strategy == "valley_filling":
        slots["rank_signal"] = [
            safe_rate(scheduled_load.get(ts, 0.0), capacity_kw) for ts in slots["timestamp"]
        ]
    else:
        signal_column = STRATEGIES[strategy]["signal"]
        slots["rank_signal"] = pd.to_numeric(slots[signal_column], errors="coerce").fillna(0.0)
        slots["rank_signal"] = slots["rank_signal"] + 0.05 * np.array(
            [scheduled_load.get(ts, 0.0) for ts in slots["timestamp"]]
        )
    slots["slack_to_departure_hours"] = (slots["timestamp"] - slots["timestamp"].min()).dt.total_seconds() / 3600.0
    return slots.sort_values(["rank_signal", "timestamp"]).reset_index(drop=True)


def allocate_constrained(
    session: pd.Series,
    site_hours: pd.DataFrame,
    scheduled_load: dict[pd.Timestamp, float],
    capacity_kw: float,
    strategy: str,
) -> list[dict[str, Any]]:
    remaining = float(session["energy_kwh"])
    allocations = []
    slots = feasible_slots(session, site_hours)
    if slots.empty:
        return allocations

    ranked = rank_slots(slots, strategy, scheduled_load, capacity_kw)
    for _, slot in ranked.iterrows():
        if remaining <= 1e-9:
            break
        current_load = scheduled_load.get(slot["timestamp"], 0.0)
        spare_power = max(0.0, capacity_kw - current_load)
        capacity_limited_energy = spare_power * float(slot["overlap_hours"])
        energy = min(remaining, float(slot["slot_max_energy_kwh"]), capacity_limited_energy)
        if energy > 1e-9:
            scheduled_load[slot["timestamp"]] = current_load + energy / float(slot["overlap_hours"])
            allocations.append(
                {
                    "session_id": session["session_id"],
                    "site_id": session["site_id"],
                    "timestamp": slot["timestamp"],
                    "energy_kwh": energy,
                    "power_kw": energy / float(slot["overlap_hours"]),
                    "soft_capacity_violation_kwh": 0.0,
                }
            )
            remaining -= energy

    if remaining > 1e-9:
        ranked_soft = rank_slots(slots, strategy, scheduled_load, capacity_kw)
        for _, slot in ranked_soft.iterrows():
            if remaining <= 1e-9:
                break
            current_load = scheduled_load.get(slot["timestamp"], 0.0)
            already_for_session = sum(
                a["energy_kwh"] for a in allocations if a["timestamp"] == slot["timestamp"]
            )
            slot_left = max(0.0, float(slot["slot_max_energy_kwh"]) - already_for_session)
            energy = min(remaining, slot_left)
            if energy > 1e-9:
                scheduled_load[slot["timestamp"]] = current_load + energy / float(slot["overlap_hours"])
                violation_power = max(0.0, scheduled_load[slot["timestamp"]] - capacity_kw)
                allocations.append(
                    {
                        "session_id": session["session_id"],
                        "site_id": session["site_id"],
                        "timestamp": slot["timestamp"],
                        "energy_kwh": energy,
                        "power_kw": energy / float(slot["overlap_hours"]),
                        "soft_capacity_violation_kwh": violation_power * float(slot["overlap_hours"]),
                    }
                )
                remaining -= energy
    return allocations


def schedule_strategy(
    sessions: pd.DataFrame,
    hours: pd.DataFrame,
    capacities: pd.DataFrame,
    strategy: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    allocations: list[dict[str, Any]] = []
    session_rows: list[dict[str, Any]] = []
    capacity_map = capacities.set_index("site_id")["site_capacity_kw"].to_dict()

    for site_id, site_sessions in sessions.groupby("site_id", sort=True):
        site_hours = hours.loc[hours["site_id"] == site_id].copy().sort_values("timestamp")
        if site_hours.empty:
            continue
        capacity_kw = float(capacity_map.get(site_id, site_hours["upper_forecast_kw"].quantile(0.95)))
        scheduled_load = {ts: 0.0 for ts in site_hours["timestamp"]}
        ordered_sessions = site_sessions.sort_values(["departure_time", "arrival_time"]).reset_index(drop=True)
        for _, session in ordered_sessions.iterrows():
            if strategy == "uncontrolled":
                session_allocations = allocate_uncontrolled(session, site_hours)
                for allocation in session_allocations:
                    ts = allocation["timestamp"]
                    scheduled_load[ts] = scheduled_load.get(ts, 0.0) + allocation["power_kw"]
            else:
                session_allocations = allocate_constrained(session, site_hours, scheduled_load, capacity_kw, strategy)
            allocations.extend([{**allocation, "strategy": strategy} for allocation in session_allocations])

            delivered = sum(a["energy_kwh"] for a in session_allocations)
            first_ts = min([a["timestamp"] for a in session_allocations], default=pd.NaT)
            last_ts = max([a["timestamp"] for a in session_allocations], default=pd.NaT)
            delay_values = [
                (a["timestamp"] - session["arrival_time"]).total_seconds() / 3600.0 * a["energy_kwh"]
                for a in session_allocations
            ]
            avg_delay = safe_rate(sum(delay_values), delivered) if delivered > 0 else np.nan
            session_rows.append(
                {
                    "strategy": strategy,
                    "session_id": session["session_id"],
                    "site_id": site_id,
                    "original_site_id": session["original_site_id"],
                    "arrival_time": session["arrival_time"],
                    "departure_time": session["departure_time"],
                    "energy_requested_kwh": float(session["energy_kwh"]),
                    "energy_delivered_kwh": delivered,
                    "unserved_energy_kwh": max(0.0, float(session["energy_kwh"]) - delivered),
                    "fully_served": delivered + FULLY_SERVED_TOLERANCE_KWH >= float(session["energy_kwh"]),
                    "max_charging_power_kw": float(session["max_charging_power_kw"]),
                    "first_charge_hour": first_ts,
                    "last_charge_hour": last_ts,
                    "average_delay_hours": avg_delay,
                    "scenario_mode": session.get("scenario_mode", ""),
                }
            )

    allocation_df = pd.DataFrame(allocations)
    session_df = pd.DataFrame(session_rows)
    return allocation_df, session_df


def build_hourly_loads(
    hours: pd.DataFrame,
    allocation_frames: list[pd.DataFrame],
    capacities: pd.DataFrame,
) -> pd.DataFrame:
    base = hours.copy()
    capacity_map = capacities.set_index("site_id")["site_capacity_kw"].to_dict()
    frames = []
    for strategy in STRATEGIES:
        strategy_base = base.copy()
        strategy_base["strategy"] = strategy
        strategy_base["site_capacity_kw"] = strategy_base["site_id"].map(capacity_map).fillna(0.0)
        matching_allocations = [df for df in allocation_frames if len(df) and df["strategy"].iloc[0] == strategy]
        if matching_allocations:
            alloc = pd.concat(matching_allocations, ignore_index=True)
            load = (
                alloc.groupby(["site_id", "timestamp"], as_index=False)["power_kw"]
                .sum()
                .rename(columns={"power_kw": "scheduled_load_kw"})
            )
            strategy_base = strategy_base.merge(load, on=["site_id", "timestamp"], how="left")
        else:
            strategy_base["scheduled_load_kw"] = 0.0
        strategy_base["scheduled_load_kw"] = strategy_base["scheduled_load_kw"].fillna(0.0)
        strategy_base["capacity_violation_kw"] = (
            strategy_base["scheduled_load_kw"] - strategy_base["site_capacity_kw"]
        ).clip(lower=0.0)
        frames.append(strategy_base)
    return pd.concat(frames, ignore_index=True)


def capacity_from_uncontrolled(
    uncontrolled_hourly: pd.DataFrame,
    historical_hourly: pd.DataFrame,
    forecasts: pd.DataFrame,
) -> pd.DataFrame:
    rows = []
    for site_id, site_df in forecasts.groupby("site_id"):
        uncontrolled = uncontrolled_hourly.loc[
            (uncontrolled_hourly["site_id"] == site_id) & (uncontrolled_hourly["strategy"] == "uncontrolled"),
            "scheduled_load_kw",
        ]
        if uncontrolled.empty or uncontrolled.max() <= 0:
            historical = historical_hourly.loc[historical_hourly["site_id"] == site_id, "load_kw"]
            basis = historical if not historical.empty else site_df["upper_forecast_kw"]
            basis_source = "historical_hourly_load"
        else:
            basis = uncontrolled
            basis_source = "reconstructed_uncontrolled_session_load"
        p95 = float(np.percentile(basis, 95)) if len(basis) else 0.0
        mean = float(np.mean(basis)) if len(basis) else 0.0
        std = float(np.std(basis)) if len(basis) else 0.0
        peak = float(np.max(basis)) if len(basis) else 0.0
        capacity = max(p95, mean + 2 * std)
        if capacity <= 0:
            capacity = max(1.0, float(site_df["upper_forecast_kw"].quantile(0.95)))
        rows.append(
            {
                "site_id": site_id,
                "site_capacity_kw": capacity,
                "capacity_basis": "max(95th percentile, mean + 2*std)",
                "basis_source": basis_source,
                "basis_p95_kw": p95,
                "basis_mean_kw": mean,
                "basis_std_kw": std,
                "basis_peak_kw": peak,
            }
        )
    return pd.DataFrame(rows)


def compute_metrics(hourly: pd.DataFrame, sessions: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    session_summary = (
        sessions.groupby(["strategy", "site_id"], as_index=False)
        .agg(
            total_energy_requested_kwh=("energy_requested_kwh", "sum"),
            total_energy_delivered_kwh=("energy_delivered_kwh", "sum"),
            unserved_energy_kwh=("unserved_energy_kwh", "sum"),
            sessions_total=("session_id", "nunique"),
            sessions_fully_served=("fully_served", "sum"),
            average_delay_hours=("average_delay_hours", "mean"),
        )
    )
    rows = []
    for (strategy, site_id), group in hourly.groupby(["strategy", "site_id"]):
        loads = group.sort_values("timestamp")["scheduled_load_kw"].astype(float)
        capacity = group["site_capacity_kw"].astype(float)
        violations = group["capacity_violation_kw"].astype(float)
        mean_load = float(loads.mean()) if len(loads) else 0.0
        peak = float(loads.max()) if len(loads) else 0.0
        load_std = float(loads.std(ddof=0)) if len(loads) else 0.0
        load_var = float(loads.var(ddof=0)) if len(loads) else 0.0
        load_factor = safe_rate(mean_load, peak)
        ramps = loads.diff().abs().fillna(0.0)
        rows.append(
            {
                "strategy": strategy,
                "site_id": site_id,
                "peak_load_kw": peak,
                "mean_load_kw": mean_load,
                "load_std_kw": load_std,
                "load_variance": load_var,
                "load_factor": load_factor,
                "ramp_rate_mean": float(ramps.mean()) if len(ramps) else 0.0,
                "ramp_rate_max": float(ramps.max()) if len(ramps) else 0.0,
                "capacity_violation_hours": int((violations > 1e-9).sum()),
                "capacity_violation_percent": pct((violations > 1e-9).sum(), len(group)),
                "max_capacity_violation_kw": float(violations.max()) if len(violations) else 0.0,
                "site_capacity_kw": float(capacity.max()) if len(capacity) else 0.0,
            }
        )
    load_metrics = pd.DataFrame(rows)
    site_metrics = load_metrics.merge(session_summary, on=["strategy", "site_id"], how="left")
    for column in [
        "total_energy_requested_kwh",
        "total_energy_delivered_kwh",
        "unserved_energy_kwh",
        "sessions_total",
        "sessions_fully_served",
    ]:
        site_metrics[column] = site_metrics[column].fillna(0.0)
    site_metrics["unserved_energy_percent"] = [
        pct(row.unserved_energy_kwh, row.total_energy_requested_kwh) for row in site_metrics.itertuples()
    ]
    site_metrics["sessions_fully_served_percent"] = [
        pct(row.sessions_fully_served, row.sessions_total) for row in site_metrics.itertuples()
    ]
    site_metrics["charging_completion_rate"] = site_metrics["sessions_fully_served_percent"]

    uncontrolled = site_metrics.loc[site_metrics["strategy"] == "uncontrolled", ["site_id", "peak_load_kw"]]
    uncontrolled = uncontrolled.rename(columns={"peak_load_kw": "uncontrolled_peak_load_kw"})
    site_metrics = site_metrics.merge(uncontrolled, on="site_id", how="left")
    site_metrics["peak_reduction_kw_vs_uncontrolled"] = (
        site_metrics["uncontrolled_peak_load_kw"] - site_metrics["peak_load_kw"]
    )
    site_metrics["peak_reduction_percent_vs_uncontrolled"] = [
        pct(row.peak_reduction_kw_vs_uncontrolled, row.uncontrolled_peak_load_kw) for row in site_metrics.itertuples()
    ]

    overall_rows = []
    for strategy, group in hourly.groupby("strategy"):
        load_by_hour = group.groupby("timestamp", as_index=False)["scheduled_load_kw"].sum().sort_values("timestamp")
        violations = group["capacity_violation_kw"].astype(float)
        strategy_sessions = sessions.loc[sessions["strategy"] == strategy]
        requested = float(strategy_sessions["energy_requested_kwh"].sum()) if len(strategy_sessions) else 0.0
        delivered = float(strategy_sessions["energy_delivered_kwh"].sum()) if len(strategy_sessions) else 0.0
        unserved = float(strategy_sessions["unserved_energy_kwh"].sum()) if len(strategy_sessions) else 0.0
        peak = float(load_by_hour["scheduled_load_kw"].max()) if len(load_by_hour) else 0.0
        mean_load = float(load_by_hour["scheduled_load_kw"].mean()) if len(load_by_hour) else 0.0
        ramps = load_by_hour["scheduled_load_kw"].diff().abs().fillna(0.0)
        overall_rows.append(
            {
                "strategy": strategy,
                "strategy_label": STRATEGIES[strategy]["label"],
                "total_energy_requested_kwh": requested,
                "total_energy_delivered_kwh": delivered,
                "unserved_energy_kwh": unserved,
                "unserved_energy_percent": pct(unserved, requested),
                "sessions_total": int(strategy_sessions["session_id"].nunique()) if len(strategy_sessions) else 0,
                "sessions_fully_served_percent": pct(strategy_sessions["fully_served"].sum(), len(strategy_sessions))
                if len(strategy_sessions)
                else 0.0,
                "peak_load_kw": peak,
                "mean_load_kw": mean_load,
                "load_std_kw": float(load_by_hour["scheduled_load_kw"].std(ddof=0)) if len(load_by_hour) else 0.0,
                "load_variance": float(load_by_hour["scheduled_load_kw"].var(ddof=0)) if len(load_by_hour) else 0.0,
                "load_factor": safe_rate(mean_load, peak),
                "ramp_rate_mean": float(ramps.mean()) if len(ramps) else 0.0,
                "ramp_rate_max": float(ramps.max()) if len(ramps) else 0.0,
                "capacity_violation_hours": int((violations > 1e-9).sum()),
                "capacity_violation_percent": pct((violations > 1e-9).sum(), len(group)),
                "max_capacity_violation_kw": float(violations.max()) if len(violations) else 0.0,
                "average_delay_hours": float(strategy_sessions["average_delay_hours"].mean())
                if len(strategy_sessions)
                else np.nan,
                "charging_completion_rate": pct(strategy_sessions["fully_served"].sum(), len(strategy_sessions))
                if len(strategy_sessions)
                else 0.0,
            }
        )
    overall = pd.DataFrame(overall_rows)
    uncontrolled_peak = float(overall.loc[overall["strategy"] == "uncontrolled", "peak_load_kw"].iloc[0])
    overall["peak_reduction_kw_vs_uncontrolled"] = uncontrolled_peak - overall["peak_load_kw"]
    overall["peak_reduction_percent_vs_uncontrolled"] = [
        pct(value, uncontrolled_peak) for value in overall["peak_reduction_kw_vs_uncontrolled"]
    ]
    return overall, site_metrics


def write_reports(
    sessions_loaded: int,
    sessions_used: int,
    removed_count: int,
    scenario_mode: str,
    coverage: pd.DataFrame,
    site_mapping: pd.DataFrame,
    capacities: pd.DataFrame,
    overall: pd.DataFrame,
    site_metrics: pd.DataFrame,
    time_start: pd.Timestamp | None,
    time_end: pd.Timestamp | None,
) -> dict[str, str]:
    best_peak = overall.sort_values(
        ["peak_reduction_percent_vs_uncontrolled", "unserved_energy_percent"], ascending=[False, True]
    ).iloc[0]
    best_violations = overall.sort_values(
        ["capacity_violation_hours", "unserved_energy_percent", "peak_load_kw"], ascending=[True, True, True]
    ).iloc[0]
    uncertainty = overall.loc[overall["strategy"] == "uncertainty_aware"].iloc[0]
    uncontrolled = overall.loc[overall["strategy"] == "uncontrolled"].iloc[0]

    direct_note = (
        "A direct session/forecast timestamp intersection was available."
        if scenario_mode == "direct_timestamp_intersection"
        else "The raw session timestamps did not overlap the Step 10 forecast horizon; therefore, the script created a documented calendar-aligned operational scenario using the real session durations, arrival times, departure windows, and energy requests."
    )

    method_report = f"""Step 11 constrained scheduling method report
==============================================
Purpose:
Build realistic constrained EV charging schedules from session-level charging demand and Step 10 uncertainty-aware forecasts.

Scheduling formulation:
Each charging session is represented by an arrival time, departure time, requested energy, and maximum charger power. The scheduler assigns hourly energy within the session availability window only. Energy is never assigned before arrival or after departure.

Session constraints:
- Hourly charging power is capped by the session charger power limit.
- Total delivered energy cannot exceed requested energy.
- The scheduler attempts to deliver all requested energy before departure.
- If the site capacity constraint prevents full service, remaining energy is either scheduled as a soft capacity violation when physically feasible or recorded as unmet energy when the session window is infeasible.

Site capacity assumptions:
For each site, the default site_capacity_kw is max(95th percentile uncontrolled session load, mean + 2*std). If reconstructed uncontrolled load is unavailable, historical hourly load is used as the fallback basis.

Strategies:
- uncontrolled: immediate charging after arrival at the charger power limit.
- valley_filling: deadline-aware scheduling into lower currently scheduled load hours.
- point_forecast: schedules flexible energy into hours with lower E-AHPA point forecasts.
- peak_sensitive: schedules using the PRC-E-AHPA peak-sensitive forecast.
- uncertainty_aware: schedules using the Step 10 upper forecast bound.

Forecast use:
The point, peak-sensitive, and uncertainty-aware strategies use Step 10 forecast columns as scheduling signals. Actual future test load is not used for decisions.

Coverage handling:
{direct_note}

Why this is more realistic than old scheduling:
This step uses session-level arrival/departure windows, energy demand, charger power limits, explicit site capacity assumptions, and feasibility reporting. It avoids reporting peak reduction without also reporting energy delivery, unserved energy, and capacity violations.
"""

    scheduled_site_count = site_metrics.loc[
        site_metrics["total_energy_requested_kwh"] > 0, "site_id"
    ].nunique()

    results_report = f"""Step 11 constrained scheduling results report
================================================
Sessions loaded: {sessions_loaded}
Invalid sessions removed: {removed_count}
Sessions scheduled: {sessions_used}
Sites scheduled: {scheduled_site_count}
Scheduling time period: {time_start} to {time_end}
Scenario mode: {scenario_mode}

Feasibility:
The selected scheduling scenario delivered {uncertainty.total_energy_delivered_kwh:.2f} kWh under uncertainty-aware scheduling out of {uncertainty.total_energy_requested_kwh:.2f} kWh requested.
Unserved energy under uncertainty-aware scheduling was {uncertainty.unserved_energy_kwh:.2f} kWh ({uncertainty.unserved_energy_percent:.2f}%).
The uncertainty-aware full-session service rate was {uncertainty.sessions_fully_served_percent:.2f}%.

Peak and capacity results:
Uncontrolled peak load was {uncontrolled.peak_load_kw:.2f} kW.
Uncertainty-aware peak load was {uncertainty.peak_load_kw:.2f} kW, a reduction of {uncertainty.peak_reduction_kw_vs_uncontrolled:.2f} kW ({uncertainty.peak_reduction_percent_vs_uncontrolled:.2f}%).
Uncertainty-aware capacity violation hours were {int(uncertainty.capacity_violation_hours)}, compared with {int(uncontrolled.capacity_violation_hours)} for uncontrolled charging.

Best strategies:
Best strategy by peak reduction: {best_peak.strategy} ({best_peak.peak_reduction_percent_vs_uncontrolled:.2f}%).
Best strategy by lowest capacity violations: {best_violations.strategy} ({int(best_violations.capacity_violation_hours)} violation hours).

Limitations:
Results depend on the available session file and Step 10 forecast horizon. Because the raw session timestamps and forecast horizon do not fully align in this project version, scenario_mode should be reported when interpreting results. The greedy scheduler is transparent and realistic, but it is not a globally optimal MILP solution.
"""

    leakage_report = """Step 11 leakage safety report
=============================
- Scheduling decisions use session arrival times, departure times, requested energy, charger power limits, site capacity assumptions, and Step 10 forecast columns.
- Actual future load is not used to rank scheduling hours.
- The actual_load_kw column from Step 10 is carried only for evaluation context and plotting, not for scheduling decisions.
- Site capacity is estimated from reconstructed uncontrolled load or historical hourly load, not from future test labels during scheduling.
- Evaluation metrics are computed only after schedules are created.
- No forecasting model is retrained and no data cleaning/modeling code is introduced in this step.
"""

    novelty_report = """Step 11 novelty contribution report
===================================
This step connects the forecasting contribution to an operational EV charging scheduling task. The contribution is not only lower point-forecast error; it is the use of forecast-informed and uncertainty-aware signals inside a constrained session-level scheduler.

Novel elements for the paper:
- E-AHPA point forecasts guide flexible charging away from predicted high-load hours.
- PRC-E-AHPA peak-sensitive forecasts provide a conservative operational variant.
- Step 10 upper prediction bounds are used for uncertainty-aware scheduling.
- Session-level feasibility is enforced with arrival/departure, energy, charger power, and site capacity constraints.
- Results report energy delivery, unserved energy, and capacity violations, avoiding unrealistic peak-reduction claims.

The manuscript should emphasize that uncertainty-aware scheduling is designed to reduce operational risk and capacity violations, not necessarily to maximize peak reduction at any cost.
"""

    paper_paragraph = f"""Using the uncertainty-aware forecasts from Step 10, we evaluated constrained EV charging schedules under five strategies: uncontrolled charging, deadline-aware valley filling, E-AHPA point-forecast scheduling, PRC-E-AHPA peak-sensitive scheduling, and upper-bound uncertainty-aware scheduling. The scheduler enforced session arrival and departure windows, requested energy, charger power limits, and site-level capacity assumptions. In the generated {scenario_mode.replace('_', ' ')} scenario, uncertainty-aware scheduling delivered {uncertainty.total_energy_delivered_kwh:.2f} kWh of {uncertainty.total_energy_requested_kwh:.2f} kWh requested energy, with {uncertainty.unserved_energy_percent:.2f}% unserved energy and {uncertainty.sessions_fully_served_percent:.2f}% fully served sessions. Relative to uncontrolled charging, it reduced peak load from {uncontrolled.peak_load_kw:.2f} kW to {uncertainty.peak_load_kw:.2f} kW ({uncertainty.peak_reduction_percent_vs_uncontrolled:.2f}%) and reduced capacity violation hours from {int(uncontrolled.capacity_violation_hours)} to {int(uncertainty.capacity_violation_hours)}. These results support the operational value of combining peak-aware forecasts with uncertainty bounds, while the feasibility metrics prevent overclaiming peak reductions that would come at the expense of unmet charging demand."""

    captions = """Step 11 figure captions
=======================
Fig. 11.1. Workflow from point forecasts and prediction intervals to constrained EV charging schedules.
Fig. 11.2. Peak scheduled load by strategy.
Fig. 11.3. Peak reduction percentage relative to uncontrolled charging.
Fig. 11.4. Capacity violation hours by strategy.
Fig. 11.5. Unserved energy percentage by strategy.
Fig. 11.6. Representative seven-day scheduled load profiles.
Fig. 11.7. Site-level peak reduction by strategy.
Fig. 11.8. Load factor comparison by strategy.
Fig. 11.9. Energy delivered percentage by strategy.
Fig. 11.10. Upper forecast signal and uncertainty-aware scheduled load for a representative site/week.
"""

    reports = {
        "11_scheduling_method_report.txt": method_report,
        "11_scheduling_results_report.txt": results_report,
        "11_leakage_safety_report.txt": leakage_report,
        "11_novelty_contribution_report.txt": novelty_report,
        "11_paper_ready_scheduling_paragraph.txt": paper_paragraph,
        "11_figure_captions.txt": captions,
    }
    for filename, text in reports.items():
        (RESULTS_DIR / filename).write_text(text, encoding="utf-8")

    summary = {
        "sessions_loaded": sessions_loaded,
        "sessions_used": sessions_used,
        "removed_count": removed_count,
        "scenario_mode": scenario_mode,
        "best_peak_strategy": str(best_peak.strategy),
        "best_capacity_strategy": str(best_violations.strategy),
    }
    (RESULTS_DIR / "11_run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    coverage.to_csv(RESULTS_DIR / "11_scheduling_coverage_report.csv", index=False)
    site_mapping.to_csv(RESULTS_DIR / "11_site_mapping_report.csv", index=False)
    capacities.to_csv(RESULTS_DIR / "11_site_capacity_assumptions.csv", index=False)
    return {
        "best_peak": str(best_peak.strategy),
        "best_violations": str(best_violations.strategy),
        "uncertainty_delivered_percent": f"{pct(uncertainty.total_energy_delivered_kwh, uncertainty.total_energy_requested_kwh):.2f}",
        "uncertainty_unserved_percent": f"{uncertainty.unserved_energy_percent:.2f}",
    }


def plot_bar(df: pd.DataFrame, x: str, y: str, title: str, ylabel: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar(df[x], df[y], color="#3b6ea8")
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=30)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def make_figures(overall: pd.DataFrame, site_metrics: pd.DataFrame, hourly: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.axis("off")
    labels = ["Forecasts", "Uncertainty interval", "Constrained scheduler", "Scheduled load"]
    xs = [0.1, 0.35, 0.62, 0.88]
    for x, label in zip(xs, labels):
        ax.text(
            x,
            0.55,
            label,
            ha="center",
            va="center",
            fontsize=11,
            bbox={"boxstyle": "round,pad=0.45", "facecolor": "#eef4fb", "edgecolor": "#3b6ea8"},
        )
    for start, end in zip(xs[:-1], xs[1:]):
        ax.annotate("", xy=(end - 0.09, 0.55), xytext=(start + 0.09, 0.55), arrowprops={"arrowstyle": "->"})
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11_fig1_scheduling_framework.png", dpi=300)
    plt.close(fig)

    plot_bar(overall, "strategy", "peak_load_kw", "Peak load by strategy", "Peak load (kW)", FIGURES_DIR / "11_fig2_peak_load_comparison.png")
    plot_bar(
        overall,
        "strategy",
        "peak_reduction_percent_vs_uncontrolled",
        "Peak reduction relative to uncontrolled",
        "Peak reduction (%)",
        FIGURES_DIR / "11_fig3_peak_reduction_percent.png",
    )
    plot_bar(
        overall,
        "strategy",
        "capacity_violation_hours",
        "Capacity violation hours",
        "Violation hours",
        FIGURES_DIR / "11_fig4_capacity_violations.png",
    )
    plot_bar(
        overall,
        "strategy",
        "unserved_energy_percent",
        "Unserved energy by strategy",
        "Unserved energy (%)",
        FIGURES_DIR / "11_fig5_unserved_energy.png",
    )

    sample_site = hourly.groupby("site_id")["scheduled_load_kw"].max().sort_values(ascending=False).index[0]
    sample = hourly.loc[hourly["site_id"] == sample_site].copy()
    start = sample["timestamp"].min()
    end = start + pd.Timedelta(days=7)
    sample = sample.loc[(sample["timestamp"] >= start) & (sample["timestamp"] < end)]
    fig, ax = plt.subplots(figsize=(11, 5))
    for strategy in ["uncontrolled", "point_forecast", "uncertainty_aware"]:
        plot_df = sample.loc[sample["strategy"] == strategy].sort_values("timestamp")
        ax.plot(plot_df["timestamp"], plot_df["scheduled_load_kw"], label=strategy, linewidth=1.4)
    ax.set_title(f"Seven-day scheduled load sample: {sample_site}")
    ax.set_ylabel("Scheduled load (kW)")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11_fig6_hourly_load_sample.png", dpi=300)
    plt.close(fig)

    pivot = site_metrics.loc[site_metrics["strategy"] != "uncontrolled"].pivot_table(
        index="site_id", columns="strategy", values="peak_reduction_percent_vs_uncontrolled", aggfunc="mean"
    )
    fig, ax = plt.subplots(figsize=(11, 5))
    pivot.plot(kind="bar", ax=ax)
    ax.set_title("Site-level peak reduction by strategy")
    ax.set_ylabel("Peak reduction (%)")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11_fig7_site_level_peak_reduction.png", dpi=300)
    plt.close(fig)

    plot_bar(overall, "strategy", "load_factor", "Load factor comparison", "Load factor", FIGURES_DIR / "11_fig8_load_factor_comparison.png")
    overall = overall.copy()
    overall["energy_delivered_percent"] = [
        pct(row.total_energy_delivered_kwh, row.total_energy_requested_kwh) for row in overall.itertuples()
    ]
    plot_bar(
        overall,
        "strategy",
        "energy_delivered_percent",
        "Energy delivered by strategy",
        "Energy delivered (%)",
        FIGURES_DIR / "11_fig9_energy_delivered_comparison.png",
    )

    upper_sample = sample.loc[sample["strategy"] == "uncertainty_aware"].sort_values("timestamp")
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(upper_sample["timestamp"], upper_sample["upper_forecast_kw"], label="Upper forecast", linewidth=1.4)
    ax.plot(
        upper_sample["timestamp"],
        upper_sample["scheduled_load_kw"],
        label="Uncertainty-aware scheduled load",
        linewidth=1.4,
    )
    ax.set_title(f"Upper forecast vs scheduled load: {sample_site}")
    ax.set_ylabel("kW")
    ax.legend()
    ax.grid(alpha=0.25)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "11_fig10_forecast_signal_vs_scheduled_load.png", dpi=300)
    plt.close(fig)


def main() -> None:
    ensure_dirs()
    require_file(SESSION_FILE)
    require_file(HOURLY_FILE)
    require_file(FORECAST_FILE)

    raw_sessions = read_csv(SESSION_FILE)
    valid_sessions, removed_sessions, column_mapping = standardize_sessions(raw_sessions)
    hourly = load_hourly()
    forecasts = load_forecasts()
    mapped_sessions, site_mapping = map_session_sites(valid_sessions, hourly, forecasts)
    scenario_sessions, scenario_mode = build_forecast_horizon_scenario(mapped_sessions, forecasts, pd.DataFrame())
    direct_sessions, coverage = sessions_with_forecast_intersection(mapped_sessions, forecasts)
    if scenario_mode != "direct_timestamp_intersection":
        coverage["fallback_used"] = True
        coverage["scenario_mode"] = scenario_mode
    else:
        coverage["fallback_used"] = False
        coverage["scenario_mode"] = scenario_mode

    hours = build_hour_index(forecasts)
    if scenario_sessions.empty:
        raise RuntimeError("No schedulable sessions could be matched or aligned to the Step 10 forecast horizon.")

    uncontrolled_alloc, uncontrolled_sessions = schedule_strategy(
        scenario_sessions,
        hours,
        pd.DataFrame({"site_id": hours["site_id"].unique(), "site_capacity_kw": np.inf}),
        "uncontrolled",
    )
    uncontrolled_hourly_temp = build_hourly_loads(
        hours,
        [uncontrolled_alloc] if len(uncontrolled_alloc) else [],
        pd.DataFrame({"site_id": hours["site_id"].unique(), "site_capacity_kw": np.inf}),
    )
    capacities = capacity_from_uncontrolled(uncontrolled_hourly_temp, hourly, forecasts)

    allocation_frames = []
    session_frames = []
    for strategy in STRATEGIES:
        allocations, strategy_sessions = schedule_strategy(scenario_sessions, hours, capacities, strategy)
        if len(allocations):
            allocation_frames.append(allocations)
        session_frames.append(strategy_sessions)

    scheduled_sessions = pd.concat(session_frames, ignore_index=True)
    scheduled_hourly = build_hourly_loads(hours, allocation_frames, capacities)
    overall, site_metrics = compute_metrics(scheduled_hourly, scheduled_sessions)
    strategy_comparison = overall.sort_values(
        ["peak_reduction_percent_vs_uncontrolled", "capacity_violation_hours"], ascending=[False, True]
    )
    capacity_report = scheduled_hourly.loc[scheduled_hourly["capacity_violation_kw"] > 1e-9].copy()
    unserved_report = scheduled_sessions.loc[scheduled_sessions["unserved_energy_kwh"] > FULLY_SERVED_TOLERANCE_KWH].copy()

    scheduled_sessions.to_csv(SCHEDULED_SESSIONS_FILE, index=False)
    scheduled_hourly.to_csv(SCHEDULED_HOURLY_FILE, index=False)
    overall.to_csv(RESULTS_DIR / "11_scheduling_overall_metrics.csv", index=False)
    site_metrics.to_csv(RESULTS_DIR / "11_scheduling_site_metrics.csv", index=False)
    strategy_comparison.to_csv(RESULTS_DIR / "11_strategy_comparison.csv", index=False)
    capacity_report.to_csv(RESULTS_DIR / "11_capacity_violation_report.csv", index=False)
    unserved_report.to_csv(RESULTS_DIR / "11_unserved_energy_report.csv", index=False)
    pd.DataFrame([column_mapping]).to_csv(RESULTS_DIR / "11_session_column_mapping.csv", index=False)
    if SELECTED_INTERVAL_FILE.exists():
        read_csv(SELECTED_INTERVAL_FILE).to_csv(RESULTS_DIR / "11_step10_selected_interval_used.csv", index=False)

    time_start = scheduled_hourly["timestamp"].min()
    time_end = scheduled_hourly["timestamp"].max()
    summary = write_reports(
        sessions_loaded=len(raw_sessions),
        sessions_used=scenario_sessions["session_id"].nunique(),
        removed_count=len(removed_sessions),
        scenario_mode=scenario_mode,
        coverage=coverage,
        site_mapping=site_mapping,
        capacities=capacities,
        overall=overall,
        site_metrics=site_metrics,
        time_start=time_start,
        time_end=time_end,
    )
    make_figures(overall, site_metrics, scheduled_hourly)

    print("Step 11 constrained EV charging scheduling complete")
    print(f"Sessions loaded: {len(raw_sessions)}")
    print(f"Sessions used: {scenario_sessions['session_id'].nunique()}")
    print(f"Sites scheduled: {scenario_sessions['site_id'].nunique()}")
    print(f"Time range: {time_start} to {time_end}")
    print(f"Scenario mode: {scenario_mode}")
    print(f"Strategies evaluated: {', '.join(STRATEGIES.keys())}")
    print(f"Best strategy by peak reduction: {summary['best_peak']}")
    print(f"Best strategy by lowest capacity violations: {summary['best_violations']}")
    print(f"Uncertainty-aware energy delivered percent: {summary['uncertainty_delivered_percent']}%")
    print(f"Uncertainty-aware unserved energy percent: {summary['uncertainty_unserved_percent']}%")
    print(f"Scheduled sessions file: {SCHEDULED_SESSIONS_FILE}")
    print(f"Scheduled hourly loads file: {SCHEDULED_HOURLY_FILE}")
    print(f"Reports folder: {RESULTS_DIR}")
    print(f"Figures folder: {FIGURES_DIR}")


if __name__ == "__main__":
    main()
