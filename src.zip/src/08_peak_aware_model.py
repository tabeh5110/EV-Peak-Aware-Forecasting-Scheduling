"""
Step 08: proposed peak-aware calendar-enhanced forecasting models.

Run from the project root:
    python src/08_peak_aware_model.py

This step trains PA_LGBM, PA_CatBoost, PA_XGBoost, and optional
PA_GradientBoosting using Step 05B features and peak_sample_weight. It does
not create prediction intervals or scheduling optimization.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import importlib
import json
import re
import sys
import time
import types
import warnings

import numpy as np


if "_strptime" not in sys.modules:
    _strptime_stub = types.ModuleType("_strptime")

    class LocaleTime:  # pragma: no cover
        def __init__(self) -> None:
            self.lang = None
            self.a_weekday = []
            self.f_weekday = []
            self.a_month = []
            self.f_month = []
            self.am_pm = []
            self.LC_date_time = ""
            self.LC_date = ""
            self.LC_time = ""
            self.timezone = (frozenset(), frozenset())

    class TimeRE(dict):  # pragma: no cover
        def __init__(self, locale_time: LocaleTime | None = None) -> None:
            super().__init__()
            self.locale_time = locale_time or LocaleTime()

        def compile(self, _format: str) -> re.Pattern[str]:
            return re.compile("")

    def _getlang() -> None:  # pragma: no cover
        return None

    def _strptime(*_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        raise ValueError("datetime.strptime is unavailable in this Python environment")

    _strptime_stub.LocaleTime = LocaleTime
    _strptime_stub.TimeRE = TimeRE
    _strptime_stub._TimeRE_cache = TimeRE()
    _strptime_stub._regex_cache = {}
    _strptime_stub._getlang = _getlang
    _strptime_stub._strptime = _strptime
    _strptime_stub._strptime_time = _strptime
    _strptime_stub._strptime_datetime = _strptime
    sys.modules["_strptime"] = _strptime_stub

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
FEATURE_FILE = PROJECT_ROOT / "data" / "processed" / "05B_forecasting_features.csv"
FEATURE_COLUMNS_FILE = PROJECT_ROOT / "results" / "05B_fix_feature_engineering" / "05B_modeling_feature_columns.txt"
BASELINE_METRICS_FILE = PROJECT_ROOT / "results" / "06_baseline_forecasting" / "06_baseline_overall_metrics.csv"
STANDARD_ML_METRICS_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_ml_overall_metrics.csv"
STANDARD_ML_SITE_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_ml_site_metrics.csv"
STANDARD_ML_TEST_PREDICTIONS_FILE = PROJECT_ROOT / "results" / "07_ml_forecasting" / "07_test_predictions.csv"

RESULTS_DIR = PROJECT_ROOT / "results" / "08_peak_aware_model"
FIGURES_DIR = PROJECT_ROOT / "figures" / "08_peak_aware_model"
MODELS_DIR = PROJECT_ROOT / "models" / "08_peak_aware_model"

TARGET = "target_load_kw"
RANDOM_STATE = 42

OUT = {
    "tuning": RESULTS_DIR / "08_pa_tuning_results.csv",
    "selected": RESULTS_DIR / "08_selected_pa_hyperparameters.csv",
    "overall": RESULTS_DIR / "08_pa_overall_metrics.csv",
    "site": RESULTS_DIR / "08_pa_site_metrics.csv",
    "validation_predictions": RESULTS_DIR / "08_validation_predictions.csv",
    "test_predictions": RESULTS_DIR / "08_test_predictions.csv",
    "pa_vs_standard": RESULTS_DIR / "08_pa_vs_standard_ml_comparison.csv",
    "all_comparison": RESULTS_DIR / "08_all_methods_comparison.csv",
    "all_ranking": RESULTS_DIR / "08_all_methods_ranking.csv",
    "best": RESULTS_DIR / "08_best_pa_summary.csv",
    "importance": RESULTS_DIR / "08_pa_feature_importance.csv",
    "packages": RESULTS_DIR / "08_package_availability.csv",
    "captions": RESULTS_DIR / "08_figure_captions.txt",
    "leakage": RESULTS_DIR / "08_pa_leakage_safety_report.txt",
    "method": RESULTS_DIR / "08_proposed_method_report.txt",
    "results_report": RESULTS_DIR / "08_peak_aware_results_report.txt",
    "novelty": RESULTS_DIR / "08_novelty_contribution_report.txt",
}


def parse_datetime(series: pd.Series) -> pd.Series:
    try:
        return pd.to_datetime(series, errors="coerce", format="mixed")
    except TypeError:
        return pd.to_datetime(series, errors="coerce")


def clip_prediction(values: Any) -> np.ndarray:
    return np.maximum(np.asarray(values, dtype=float), 0.0)


def mae(a: np.ndarray, p: np.ndarray) -> float:
    return float(np.mean(np.abs(p - a))) if len(a) else np.nan


def rmse(a: np.ndarray, p: np.ndarray) -> float:
    return float(np.sqrt(np.mean((p - a) ** 2))) if len(a) else np.nan


def mape(a: np.ndarray, p: np.ndarray) -> float:
    mask = a != 0
    return float(np.mean(np.abs((p[mask] - a[mask]) / a[mask])) * 100) if mask.any() else np.nan


def smape(a: np.ndarray, p: np.ndarray) -> float:
    denom = np.abs(a) + np.abs(p)
    mask = denom != 0
    return float(np.mean(2 * np.abs(p[mask] - a[mask]) / denom[mask]) * 100) if mask.any() else np.nan


def r2(a: np.ndarray, p: np.ndarray) -> float:
    ss_res = float(np.sum((a - p) ** 2))
    ss_tot = float(np.sum((a - np.mean(a)) ** 2))
    return 1 - ss_res / ss_tot if ss_tot else np.nan


def rate(mask: np.ndarray) -> float:
    return float(np.mean(mask) * 100) if len(mask) else np.nan


def peak_subset_metrics(df: pd.DataFrame, pred_col: str, high: bool = False) -> dict[str, float]:
    flag = "is_high_peak_hour" if high else "is_peak_hour"
    prefix = "high_peak" if high else "peak"
    sub = df.loc[df[flag] == 1]
    if sub.empty:
        return {
            f"{prefix}_MAE": np.nan,
            f"{prefix}_RMSE": np.nan,
            f"{prefix}_underestimation_rate": np.nan,
            f"{prefix}_overprediction_rate": np.nan,
            f"{prefix}_bias": np.nan,
            f"mean_actual_{prefix}_load_kw": np.nan,
            f"mean_predicted_{prefix}_load_kw": np.nan,
        }
    a = sub[TARGET].to_numpy(float)
    p = sub[pred_col].to_numpy(float)
    return {
        f"{prefix}_MAE": mae(a, p),
        f"{prefix}_RMSE": rmse(a, p),
        f"{prefix}_underestimation_rate": rate(p < a),
        f"{prefix}_overprediction_rate": rate(p > a),
        f"{prefix}_bias": float(np.mean(p - a)),
        f"mean_actual_{prefix}_load_kw": float(np.mean(a)),
        f"mean_predicted_{prefix}_load_kw": float(np.mean(p)),
    }


def operational_peak_metrics(df: pd.DataFrame, pred_col: str) -> dict[str, float]:
    a = df[TARGET].to_numpy(float)
    p = df[pred_col].to_numpy(float)
    q90 = np.nanquantile(a, 0.90)
    q95 = np.nanquantile(a, 0.95)
    mask10 = a >= q90
    mask5 = a >= q95
    max_idx = int(np.argmax(a))
    return {
        "top_10_percent_actual_peak_MAE": mae(a[mask10], p[mask10]) if mask10.any() else np.nan,
        "top_5_percent_actual_peak_MAE": mae(a[mask5], p[mask5]) if mask5.any() else np.nan,
        "top_10_percent_peak_underestimation_rate": rate(p[mask10] < a[mask10]) if mask10.any() else np.nan,
        "top_5_percent_peak_underestimation_rate": rate(p[mask5] < a[mask5]) if mask5.any() else np.nan,
        "maximum_actual_load_kw": float(a[max_idx]),
        "predicted_load_at_actual_max_kw": float(p[max_idx]),
        "actual_max_underprediction_kw": float(a[max_idx] - p[max_idx]),
    }


def evaluate_overall(df: pd.DataFrame, model: str, split: str, pred_col: str) -> dict[str, Any]:
    a = df[TARGET].to_numpy(float)
    p = df[pred_col].to_numpy(float)
    peak = peak_subset_metrics(df, pred_col, False)
    high = peak_subset_metrics(df, pred_col, True)
    op = operational_peak_metrics(df, pred_col)
    return {
        "model_name": model,
        "split": split,
        "MAE": mae(a, p),
        "RMSE": rmse(a, p),
        "MAPE": mape(a, p),
        "sMAPE": smape(a, p),
        "R2": r2(a, p),
        "MBE": float(np.mean(p - a)),
        "underestimation_rate": rate(p < a),
        "overestimation_rate": rate(p > a),
        "peak_MAE": peak["peak_MAE"],
        "high_peak_MAE": high["high_peak_MAE"],
        "peak_RMSE": peak["peak_RMSE"],
        "high_peak_RMSE": high["high_peak_RMSE"],
        "peak_underestimation_rate": peak["peak_underestimation_rate"],
        "high_peak_underestimation_rate": high["high_peak_underestimation_rate"],
        "mean_actual_peak_load_kw": peak["mean_actual_peak_load_kw"],
        "mean_predicted_peak_load_kw": peak["mean_predicted_peak_load_kw"],
        "peak_bias": peak["peak_bias"],
        "high_peak_bias": high["high_peak_bias"],
        "peak_overprediction_rate": peak["peak_overprediction_rate"],
        "high_peak_overprediction_rate": high["high_peak_overprediction_rate"],
        **op,
    }


def evaluate_site(df: pd.DataFrame, model: str, split: str, pred_col: str, site_means: dict[str, float]) -> list[dict[str, Any]]:
    rows = []
    for site_id, site_df in df.groupby("site_id", sort=True):
        a = site_df[TARGET].to_numpy(float)
        p = site_df[pred_col].to_numpy(float)
        peak = peak_subset_metrics(site_df, pred_col, False)
        high = peak_subset_metrics(site_df, pred_col, True)
        max_idx = int(np.argmax(a))
        site_mean = site_means.get(site_id, np.nan)
        rows.append(
            {
                "model_name": model,
                "split": split,
                "site_id": site_id,
                "row_count": len(site_df),
                "MAE": mae(a, p),
                "RMSE": rmse(a, p),
                "normalized_MAE_by_site_train_mean": mae(a, p) / site_mean if site_mean else np.nan,
                "normalized_RMSE_by_site_train_mean": rmse(a, p) / site_mean if site_mean else np.nan,
                "MBE": float(np.mean(p - a)),
                "underestimation_rate": rate(p < a),
                "peak_MAE": peak["peak_MAE"],
                "peak_underestimation_rate": peak["peak_underestimation_rate"],
                "high_peak_MAE": high["high_peak_MAE"],
                "high_peak_underestimation_rate": high["high_peak_underestimation_rate"],
                "actual_max_load_kw": float(a[max_idx]),
                "predicted_at_actual_max_kw": float(p[max_idx]),
                "actual_max_underprediction_kw": float(a[max_idx] - p[max_idx]),
            }
        )
    return rows


def package_version(name: str) -> tuple[bool, str]:
    try:
        module = importlib.import_module(name)
        return True, str(getattr(module, "__version__", "unknown"))
    except Exception:
        return False, ""


def build_specs(package_rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], bool]:
    specs = []
    joblib_ok, joblib_v = package_version("joblib")
    package_rows.append({"package/model": "joblib", "available": joblib_ok, "version": joblib_v, "action_taken": "save model artifacts" if joblib_ok else "skip artifacts"})

    lgb_ok, lgb_v = package_version("lightgbm")
    package_rows.append({"package/model": "lightgbm", "available": lgb_ok, "version": lgb_v, "action_taken": "train PA_LGBM" if lgb_ok else "skip PA_LGBM"})
    if lgb_ok:
        from lightgbm import LGBMRegressor

        specs.append(
            {
                "model_name": "PA_LGBM",
                "standard_model_name": "LGBMRegressor",
                "factory": lambda p: LGBMRegressor(random_state=RANDOM_STATE, n_jobs=-1, verbose=-1, **p),
                "params": [
                    {"n_estimators": 300, "learning_rate": 0.05, "num_leaves": 31, "max_depth": -1, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0},
                    {"n_estimators": 500, "learning_rate": 0.03, "num_leaves": 31, "max_depth": -1, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0},
                    {"n_estimators": 300, "learning_rate": 0.05, "num_leaves": 63, "max_depth": -1, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 2.0},
                    {"n_estimators": 500, "learning_rate": 0.03, "num_leaves": 63, "max_depth": -1, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 2.0},
                ],
            }
        )

    cat_ok, cat_v = package_version("catboost")
    package_rows.append({"package/model": "catboost", "available": cat_ok, "version": cat_v, "action_taken": "train PA_CatBoost" if cat_ok else "skip PA_CatBoost"})
    if cat_ok:
        from catboost import CatBoostRegressor

        specs.append(
            {
                "model_name": "PA_CatBoost",
                "standard_model_name": "CatBoostRegressor",
                "factory": lambda p: CatBoostRegressor(loss_function="RMSE", random_seed=RANDOM_STATE, verbose=False, **p),
                "params": [
                    {"iterations": 300, "learning_rate": 0.05, "depth": 6, "l2_leaf_reg": 3},
                    {"iterations": 500, "learning_rate": 0.03, "depth": 6, "l2_leaf_reg": 3},
                    {"iterations": 300, "learning_rate": 0.05, "depth": 8, "l2_leaf_reg": 5},
                    {"iterations": 500, "learning_rate": 0.03, "depth": 8, "l2_leaf_reg": 5},
                ],
            }
        )

    xgb_ok, xgb_v = package_version("xgboost")
    package_rows.append({"package/model": "xgboost", "available": xgb_ok, "version": xgb_v, "action_taken": "train PA_XGBoost" if xgb_ok else "skip PA_XGBoost"})
    if xgb_ok:
        from xgboost import XGBRegressor

        specs.append(
            {
                "model_name": "PA_XGBoost",
                "standard_model_name": "XGBRegressor",
                "factory": lambda p: XGBRegressor(objective="reg:squarederror", random_state=RANDOM_STATE, n_jobs=-1, **p),
                "params": [
                    {"n_estimators": 300, "learning_rate": 0.05, "max_depth": 4, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0},
                    {"n_estimators": 500, "learning_rate": 0.03, "max_depth": 4, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0},
                    {"n_estimators": 300, "learning_rate": 0.05, "max_depth": 6, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 2.0},
                    {"n_estimators": 500, "learning_rate": 0.03, "max_depth": 6, "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 2.0},
                ],
            }
        )

    skl_ok, skl_v = package_version("sklearn")
    package_rows.append({"package/model": "sklearn GradientBoostingRegressor", "available": skl_ok, "version": skl_v, "action_taken": "train PA_GradientBoosting" if skl_ok else "skip PA_GradientBoosting"})
    if skl_ok:
        from sklearn.ensemble import GradientBoostingRegressor

        specs.append(
            {
                "model_name": "PA_GradientBoosting",
                "standard_model_name": "GradientBoostingRegressor",
                "factory": lambda p: GradientBoostingRegressor(random_state=RANDOM_STATE, **p),
                "params": [
                    {"n_estimators": 200, "learning_rate": 0.05, "max_depth": 3, "subsample": 0.8},
                    {"n_estimators": 300, "learning_rate": 0.03, "max_depth": 3, "subsample": 0.8},
                    {"n_estimators": 200, "learning_rate": 0.05, "max_depth": 4, "subsample": 0.8},
                ],
            }
        )
    return specs, joblib_ok


def selection_scores(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    df = pd.DataFrame([r for r in rows if r["status"] == "success"])
    if df.empty:
        return rows
    best_mae = df["validation_MAE"].min()
    best_peak = df["validation_peak_MAE"].min()
    best_high = df["validation_high_peak_MAE"].min()
    for row in rows:
        if row["status"] != "success":
            row["selection_score"] = np.nan
            continue
        row["selection_score"] = (
            0.50 * row["validation_MAE"] / best_mae
            + 0.35 * row["validation_peak_MAE"] / best_peak
            + 0.15 * row["validation_high_peak_MAE"] / best_high
        )
    return rows


def train_pa_models(specs, train, validation, test, features, joblib_ok):
    tuning_rows, selected_rows, importance_rows, successful, skipped = [], [], [], [], []
    X_train, y_train, w_train = train[features], train[TARGET], train["peak_sample_weight"]
    X_val = validation[features]
    train_val = pd.concat([train, validation], ignore_index=True)
    X_train_val, y_train_val, w_train_val = train_val[features], train_val[TARGET], train_val["peak_sample_weight"]
    X_test = test[features]
    joblib_module = importlib.import_module("joblib") if joblib_ok else None

    for spec in specs:
        model_rows = []
        best = None
        for cid, params in enumerate(spec["params"], 1):
            start = time.perf_counter()
            row = {
                "model_name": spec["model_name"],
                "candidate_id": cid,
                "parameter_json": json.dumps(params, sort_keys=True),
                "validation_MAE": np.nan,
                "validation_RMSE": np.nan,
                "validation_peak_MAE": np.nan,
                "validation_high_peak_MAE": np.nan,
                "validation_underestimation_rate": np.nan,
                "validation_peak_underestimation_rate": np.nan,
                "validation_high_peak_underestimation_rate": np.nan,
                "selection_score": np.nan,
                "training_time_seconds": np.nan,
                "status": "failed",
                "error_message_if_failed": "",
            }
            try:
                model = spec["factory"](params)
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    model.fit(X_train, y_train, sample_weight=w_train)
                validation[f"pred_{spec['model_name']}_candidate_{cid}"] = clip_prediction(model.predict(X_val))
                metrics = evaluate_overall(validation, spec["model_name"], "validation", f"pred_{spec['model_name']}_candidate_{cid}")
                row.update(
                    {
                        "validation_MAE": metrics["MAE"],
                        "validation_RMSE": metrics["RMSE"],
                        "validation_peak_MAE": metrics["peak_MAE"],
                        "validation_high_peak_MAE": metrics["high_peak_MAE"],
                        "validation_underestimation_rate": metrics["underestimation_rate"],
                        "validation_peak_underestimation_rate": metrics["peak_underestimation_rate"],
                        "validation_high_peak_underestimation_rate": metrics["high_peak_underestimation_rate"],
                        "training_time_seconds": round(time.perf_counter() - start, 3),
                        "status": "success",
                        "_model": model,
                    }
                )
            except Exception as exc:
                row["training_time_seconds"] = round(time.perf_counter() - start, 3)
                row["error_message_if_failed"] = f"{type(exc).__name__}: {exc}"
            model_rows.append(row)

        model_rows = selection_scores(model_rows)
        tuning_rows.extend([{k: v for k, v in r.items() if k != "_model"} for r in model_rows])
        successes = [r for r in model_rows if r["status"] == "success"]
        if not successes:
            skipped.append(f"{spec['model_name']}: all candidates failed")
            continue
        best = min(successes, key=lambda r: r["selection_score"])
        model_name = spec["model_name"]
        validation[f"pred_{model_name}"] = validation[f"pred_{model_name}_candidate_{best['candidate_id']}"]
        final_model = spec["factory"](json.loads(best["parameter_json"]))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            final_model.fit(X_train_val, y_train_val, sample_weight=w_train_val)
        test[f"pred_{model_name}"] = clip_prediction(final_model.predict(X_test))
        successful.append(model_name)
        selected_rows.append(
            {
                "model_name": model_name,
                "selected_candidate_id": best["candidate_id"],
                "selected_parameter_json": best["parameter_json"],
                "selection_metric": "normalized_peak_aware_score",
                "selection_score": best["selection_score"],
                "validation_MAE": best["validation_MAE"],
                "validation_RMSE": best["validation_RMSE"],
                "validation_peak_MAE": best["validation_peak_MAE"],
                "validation_high_peak_MAE": best["validation_high_peak_MAE"],
            }
        )
        if joblib_module:
            try:
                joblib_module.dump(final_model, MODELS_DIR / f"08_{model_name}.joblib")
            except Exception as exc:
                skipped.append(f"{model_name}: artifact not saved ({type(exc).__name__}: {exc})")
        if hasattr(final_model, "feature_importances_"):
            imp = np.asarray(final_model.feature_importances_, dtype=float)
            for rank, idx in enumerate(np.argsort(imp)[::-1], 1):
                importance_rows.append({"model_name": model_name, "feature_name": features[idx], "importance": imp[idx], "rank": rank})
    return successful, skipped, tuning_rows, selected_rows, importance_rows


def prediction_export(df: pd.DataFrame, models: list[str]) -> pd.DataFrame:
    out = pd.DataFrame(
        {
            "timestamp": df["timestamp"],
            "site_id": df["site_id"],
            "actual_load_kw": df[TARGET],
            "split": df["split"],
            "is_peak_hour": df["is_peak_hour"],
            "is_high_peak_hour": df["is_high_peak_hour"],
        }
    )
    for model in models:
        out[f"prediction_{model}"] = df[f"pred_{model}"]
    return out


def rank_all(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    test = df.loc[df["split"] == "test"].copy()
    metrics = ["MAE", "RMSE", "peak_MAE", "high_peak_MAE", "peak_underestimation_rate", "actual_max_underprediction_kw"]
    for metric in metrics:
        sub = test[["model_name", "method_group", metric]].dropna().copy()
        sub["rank_metric"] = f"test {metric}"
        sub["rank_value"] = sub[metric]
        sub["rank_position"] = sub["rank_value"].rank(method="min", ascending=True)
        rows.append(sub[["model_name", "method_group", "rank_metric", "rank_value", "rank_position"]])
    return pd.concat(rows, ignore_index=True)


def pa_vs_standard(pa: pd.DataFrame, standard: pd.DataFrame, specs: list[dict[str, Any]]) -> pd.DataFrame:
    rows = []
    pairs = {s["model_name"]: s["standard_model_name"] for s in specs}
    for pa_model, std_model in pairs.items():
        for split in ["validation", "test"]:
            pa_row = pa[(pa["model_name"] == pa_model) & (pa["split"] == split)]
            st_row = standard[(standard["model_name"] == std_model) & (standard["split"] == split)]
            if pa_row.empty or st_row.empty:
                continue
            p, s = pa_row.iloc[0], st_row.iloc[0]
            rows.append(
                {
                    "pa_model_name": pa_model,
                    "standard_model_name": std_model,
                    "split": split,
                    "delta_MAE": p.MAE - s.MAE,
                    "delta_peak_MAE": p.peak_MAE - s.peak_MAE,
                    "delta_high_peak_MAE": p.high_peak_MAE - s.high_peak_MAE,
                    "percent_change_MAE": (p.MAE - s.MAE) / s.MAE * 100 if s.MAE else np.nan,
                    "percent_change_peak_MAE": (p.peak_MAE - s.peak_MAE) / s.peak_MAE * 100 if s.peak_MAE else np.nan,
                    "percent_change_high_peak_MAE": (p.high_peak_MAE - s.high_peak_MAE) / s.high_peak_MAE * 100 if s.high_peak_MAE else np.nan,
                    "improved_overall_MAE": bool(p.MAE < s.MAE),
                    "improved_peak_MAE": bool(p.peak_MAE < s.peak_MAE),
                    "improved_high_peak_MAE": bool(p.high_peak_MAE < s.high_peak_MAE),
                }
            )
    return pd.DataFrame(rows)


def best_summary(pa_metrics: pd.DataFrame, all_methods: pd.DataFrame, comparison: pd.DataFrame) -> pd.DataFrame:
    rows = []
    val_selected = pd.read_csv(OUT["selected"]).sort_values("selection_score").iloc[0]
    tests = {
        "best PA model by validation selection score": (val_selected.model_name, "selection_score", val_selected.selection_score),
        "best PA model by test MAE": None,
        "best PA model by test peak_MAE": None,
        "best PA model by test high_peak_MAE": None,
        "best PA model by lowest peak underestimation": None,
        "best overall method among baseline + standard ML + PA by test MAE": None,
        "best overall method among baseline + standard ML + PA by test peak_MAE": None,
    }
    for label, metric in [
        ("best PA model by test MAE", "MAE"),
        ("best PA model by test peak_MAE", "peak_MAE"),
        ("best PA model by test high_peak_MAE", "high_peak_MAE"),
        ("best PA model by lowest peak underestimation", "peak_underestimation_rate"),
    ]:
        row = pa_metrics[pa_metrics["split"] == "test"].sort_values(metric).iloc[0]
        tests[label] = (row.model_name, metric, row[metric])
    for label, metric in [
        ("best overall method among baseline + standard ML + PA by test MAE", "MAE"),
        ("best overall method among baseline + standard ML + PA by test peak_MAE", "peak_MAE"),
    ]:
        row = all_methods[all_methods["split"] == "test"].sort_values(metric).iloc[0]
        tests[label] = (row.model_name, metric, row[metric])
    for label, value in tests.items():
        rows.append({"summary_item": label, "model_name": value[0], "metric": value[1], "metric_value": value[2]})
    test_comp = comparison[comparison["split"] == "test"]
    rows.append({"summary_item": "whether PA improves over standard ML for peak_MAE", "model_name": "paired_comparison", "metric": "any_pair_improved", "metric_value": bool(test_comp["improved_peak_MAE"].any())})
    rows.append({"summary_item": "whether PA improves over standard ML for high_peak_MAE", "model_name": "paired_comparison", "metric": "any_pair_improved", "metric_value": bool(test_comp["improved_high_peak_MAE"].any())})
    best_pa_mae = pa_metrics[pa_metrics["split"] == "test"].sort_values("MAE").iloc[0]
    std = pd.read_csv(STANDARD_ML_METRICS_FILE)
    best_std_mae = std[std["split"] == "test"].sort_values("MAE").iloc[0]
    rows.append({"summary_item": "whether PA sacrifices normal MAE, and by how much", "model_name": best_pa_mae.model_name, "metric": "PA_best_MAE_minus_standard_best_MAE", "metric_value": best_pa_mae.MAE - best_std_mae.MAE})
    return pd.DataFrame(rows)


def add_labels(ax):
    for p in ax.patches:
        h = p.get_height()
        if np.isfinite(h):
            ax.text(p.get_x() + p.get_width() / 2, h, f"{h:.2f}", ha="center", va="bottom", fontsize=8)


def bar(df, metric, title, path):
    plot = df[df["split"] == "test"].sort_values(metric)
    fig, ax = plt.subplots(figsize=(10, 5.5))
    ax.bar(plot["model_name"], plot[metric])
    ax.set_title(title)
    ax.set_ylabel(metric)
    ax.tick_params(axis="x", rotation=25)
    add_labels(ax)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def grouped_standard_pa(comp: pd.DataFrame, metric: str, title: str, path: Path, standard: pd.DataFrame, pa: pd.DataFrame):
    rows = []
    metric_col = metric
    for r in comp[comp["split"] == "test"].itertuples(index=False):
        srow = standard[(standard["model_name"] == r.standard_model_name) & (standard["split"] == "test")].iloc[0]
        prow = pa[(pa["model_name"] == r.pa_model_name) & (pa["split"] == "test")].iloc[0]
        rows.append({"pair": r.pa_model_name.replace("PA_", ""), "model_type": "standard", "value": srow[metric_col]})
        rows.append({"pair": r.pa_model_name.replace("PA_", ""), "model_type": "PA", "value": prow[metric_col]})
    plot = pd.DataFrame(rows)
    pivot = plot.pivot(index="pair", columns="model_type", values="value")
    fig, ax = plt.subplots(figsize=(9, 5.5))
    pivot.plot(kind="bar", ax=ax)
    ax.set_title(title)
    ax.set_ylabel(metric)
    ax.tick_params(axis="x", rotation=0)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def sample_plot(test, best_pa, path, standard_pred=None, best_std=None):
    site = test.groupby("site_id").size().sort_values(ascending=False).index[0]
    sdf = test[test["site_id"] == site].sort_values("timestamp")
    sample = sdf[sdf["timestamp"] < sdf["timestamp"].min() + pd.Timedelta(days=7)]
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(sample["timestamp"], sample[TARGET], label="Actual", linewidth=2)
    ax.plot(sample["timestamp"], sample[f"pred_{best_pa}"], label=best_pa, linewidth=1.5)
    if standard_pred is not None and best_std:
        col = f"prediction_{best_std}"
        if col in standard_pred.columns:
            sp = standard_pred.copy()
            sp["timestamp"] = parse_datetime(sp["timestamp"])
            ss = sp[(sp["site_id"] == site) & (sp["timestamp"].isin(sample["timestamp"]))]
            ax.plot(ss["timestamp"], ss[col], label=best_std, linewidth=1.2)
    ax.set_title(f"Actual vs prediction test sample: {site}")
    ax.set_xlabel("Timestamp")
    ax.set_ylabel("Load (kW)")
    ax.legend()
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def write_reports(successful, skipped, selected, pa_metrics, comp, all_methods, best, package_rows, input_shape, counts, features):
    best_sel = best[best["summary_item"] == "best PA model by validation selection score"].iloc[0]
    best_mae = best[best["summary_item"] == "best PA model by test MAE"].iloc[0]
    best_peak = best[best["summary_item"] == "best PA model by test peak_MAE"].iloc[0]
    test_comp = comp[comp["split"] == "test"]
    selected_lines = [f"- {r.model_name}: candidate {r.selected_candidate_id}, score={r.selection_score:.4f}, {r.selected_parameter_json}" for r in selected.itertuples(index=False)]
    skipped_lines = [f"- {s}" for s in skipped] if skipped else ["- None"]

    OUT["leakage"].write_text(
        "\n".join(
            [
                "Step 08 peak-aware leakage safety report",
                "=" * 42,
                "- Step 05B chronological split was used.",
                "- No random split or shuffling was used.",
                "- Only approved modeling features were used.",
                "- Peak labels were not used as predictors.",
                "- peak_sample_weight was used only as a training weight.",
                "- Hyperparameters were selected using validation split only.",
                "- Test set was used once for final evaluation.",
                "- Final models trained on train+validation after selection.",
                "- No future load, future session, price, weather, or traffic data was used.",
                "",
            ]
        ),
        encoding="utf-8",
    )
    OUT["method"].write_text(
        "\n".join(
            [
                "Step 08 proposed method report",
                "=" * 30,
                "PA-LightGBM, PA-CatBoost, and PA-XGBoost are peak-aware weighted versions of strong gradient boosting forecasters trained on the calendar-enhanced Step 05B feature set.",
                "Peak-aware weighting is needed because ordinary MAE/RMSE optimization can under-penalize high-load hours that are operationally important for grid and charging management.",
                "peak_sample_weight is defined as 1.0 for normal hours, 2.0 for 90th-percentile peak hours, and 3.0 for 95th-percentile high-peak hours using train-only thresholds.",
                "The peak-aware selection score combines normalized validation MAE, validation peak_MAE, and validation high_peak_MAE with weights 0.50, 0.35, and 0.15.",
                "This differs from standard ML by changing both the training emphasis and the validation selection objective toward peak-period performance.",
                "It addresses the old reviewer criticism about weak peak prediction by explicitly optimizing and reporting peak-load errors and underestimation.",
                "Operationally, better peak forecasts support safer transformer loading, demand management, and later constrained EV charging scheduling.",
                "",
            ]
        ),
        encoding="utf-8",
    )
    OUT["results_report"].write_text(
        "\n".join(
            [
                "Step 08 peak-aware results report",
                "=" * 35,
                f"Input shape: {input_shape}",
                f"Train/validation/test rows: {int(counts['train'])}/{int(counts['validation'])}/{int(counts['test'])}",
                f"Number of features: {len(features)}",
                "",
                "Models successfully evaluated:",
                *(f"- {m}" for m in successful),
                "Models skipped and why:",
                *skipped_lines,
                "",
                "Selected hyperparameters:",
                *selected_lines,
                "",
                f"Best PA model by validation selection score: {best_sel.model_name} ({best_sel.metric_value})",
                f"Best PA model by test MAE: {best_mae.model_name} ({float(best_mae.metric_value):.4f})",
                f"Best PA model by test peak_MAE: {best_peak.model_name} ({float(best_peak.metric_value):.4f})",
                "",
                "Comparison with Step 07 standard ML:",
                *(
                    f"- {r.pa_model_name} vs {r.standard_model_name} ({r.split}): delta_MAE={r.delta_MAE:.4f}, delta_peak_MAE={r.delta_peak_MAE:.4f}, delta_high_peak_MAE={r.delta_high_peak_MAE:.4f}"
                    for r in comp.itertuples(index=False)
                ),
                "",
                f"PA improves peak_MAE in at least one test pair: {bool(test_comp['improved_peak_MAE'].any())}",
                f"PA improves high_peak_MAE in at least one test pair: {bool(test_comp['improved_high_peak_MAE'].any())}",
                f"PA reduces peak underestimation for best peak model: see 08_pa_overall_metrics.csv.",
                "Overall MAE tradeoff is quantified in 08_best_pa_summary.csv.",
                "",
                "Recommended next step:",
                "- Use these results to decide whether Step 09 should run statistical testing first or build prediction intervals around the selected peak-aware model.",
                "",
            ]
        ),
        encoding="utf-8",
    )
    OUT["novelty"].write_text(
        "\n".join(
            [
                "Step 08 novelty contribution report",
                "=" * 36,
                "This study proposes a peak-aware calendar-enhanced EV charging load forecasting approach that combines leakage-free calendar, lag, rolling, peak-memory, missingness, site identity, interaction, and train-normalized features with peak-weighted gradient boosting.",
                "The feature contribution from Step 05B provides daily/weekly memory, operational calendar structure, and transparent treatment of zero-load periods.",
                "Peak-weighted learning increases training emphasis on hours above train-only 90th and 95th percentile thresholds.",
                "Validation-based peak-aware model selection chooses configurations using overall MAE, peak_MAE, and high_peak_MAE instead of ordinary error alone.",
                "The operational relevance is direct: reducing peak-load error and underestimation improves the reliability of later constrained charging schedules and grid-aware decisions.",
                "",
            ]
        ),
        encoding="utf-8",
    )
    OUT["captions"].write_text(
        "\n".join(
            [
                "Fig. 1. Test mean absolute error for peak-aware models.",
                "Fig. 2. Test peak-hour mean absolute error for peak-aware models.",
                "Fig. 3. Test high-peak-hour mean absolute error for peak-aware models.",
                "Fig. 4. Test peak_MAE comparison between standard ML and matched peak-aware models.",
                "Fig. 5. Test high_peak_MAE comparison between standard ML and matched peak-aware models.",
                "Fig. 6. Test MAE comparison between standard ML and matched peak-aware models.",
                "Fig. 7. Peak underestimation rate for standard ML and peak-aware models.",
                "Fig. 8. Actual load and best peak-aware model prediction on a seven-day test sample.",
                "Fig. 9. Actual load, best standard ML prediction, and best peak-aware prediction on the same seven-day test sample.",
                "Fig. 10. Top 20 feature importances for the best peak-aware model.",
                "Fig. 11. Site-level peak_MAE for the best standard ML model and best peak-aware model.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    MODELS_DIR.mkdir(parents=True, exist_ok=True)

    features = [x.strip() for x in FEATURE_COLUMNS_FILE.read_text(encoding="utf-8").splitlines() if x.strip()]
    df = pd.read_csv(FEATURE_FILE)
    input_shape = df.shape
    df["timestamp"] = parse_datetime(df["timestamp"])
    if "peak_sample_weight" not in df.columns:
        df["peak_sample_weight"] = 1.0
        df.loc[df["is_peak_hour"] == 1, "peak_sample_weight"] = 2.0
        df.loc[df["is_high_peak_hour"] == 1, "peak_sample_weight"] = 3.0
    train, validation, test = [df[df["split"] == s].copy() for s in ["train", "validation", "test"]]
    counts = df["split"].value_counts().reindex(["train", "validation", "test"], fill_value=0)
    site_means = train.groupby("site_id")[TARGET].mean().to_dict()

    package_rows = []
    specs, joblib_ok = build_specs(package_rows)
    successful, skipped, tuning_rows, selected_rows, importance_rows = train_pa_models(specs, train, validation, test, features, joblib_ok)
    tuning = pd.DataFrame(tuning_rows)
    selected = pd.DataFrame(selected_rows)
    importance = pd.DataFrame(importance_rows)
    tuning.to_csv(OUT["tuning"], index=False)
    selected.to_csv(OUT["selected"], index=False)
    pd.DataFrame(package_rows).to_csv(OUT["packages"], index=False)

    overall_rows, site_rows = [], []
    for split, sdf in [("validation", validation), ("test", test)]:
        for model in successful:
            overall_rows.append(evaluate_overall(sdf, model, split, f"pred_{model}"))
            site_rows.extend(evaluate_site(sdf, model, split, f"pred_{model}", site_means))
    pa_metrics = pd.DataFrame(overall_rows).sort_values(["split", "MAE"])
    site_metrics = pd.DataFrame(site_rows).sort_values(["split", "site_id", "MAE"])
    pa_metrics.to_csv(OUT["overall"], index=False)
    site_metrics.to_csv(OUT["site"], index=False)
    prediction_export(validation, successful).to_csv(OUT["validation_predictions"], index=False)
    prediction_export(test, successful).to_csv(OUT["test_predictions"], index=False)

    standard = pd.read_csv(STANDARD_ML_METRICS_FILE)
    baseline = pd.read_csv(BASELINE_METRICS_FILE)
    comp = pa_vs_standard(pa_metrics, standard, specs)
    comp.to_csv(OUT["pa_vs_standard"], index=False)
    all_methods = pd.concat(
        [baseline.assign(method_group="baseline"), standard.assign(method_group="standard_ml"), pa_metrics.assign(method_group="peak_aware")],
        ignore_index=True,
        sort=False,
    )
    all_methods.to_csv(OUT["all_comparison"], index=False)
    rank_all(all_methods).to_csv(OUT["all_ranking"], index=False)
    best = best_summary(pa_metrics, all_methods, comp)
    best.to_csv(OUT["best"], index=False)
    if importance.empty:
        importance = pd.DataFrame(columns=["model_name", "feature_name", "importance", "rank"])
    importance.to_csv(OUT["importance"], index=False)

    # Figures
    bar(pa_metrics, "MAE", "PA models: test MAE", FIGURES_DIR / "08_fig1_pa_test_mae.png")
    bar(pa_metrics, "peak_MAE", "PA models: test peak_MAE", FIGURES_DIR / "08_fig2_pa_test_peak_mae.png")
    bar(pa_metrics, "high_peak_MAE", "PA models: test high_peak_MAE", FIGURES_DIR / "08_fig3_pa_test_high_peak_mae.png")
    grouped_standard_pa(comp, "peak_MAE", "Standard ML vs PA: test peak_MAE", FIGURES_DIR / "08_fig4_standard_vs_pa_peak_mae.png", standard, pa_metrics)
    grouped_standard_pa(comp, "high_peak_MAE", "Standard ML vs PA: test high_peak_MAE", FIGURES_DIR / "08_fig5_standard_vs_pa_high_peak_mae.png", standard, pa_metrics)
    grouped_standard_pa(comp, "MAE", "Standard ML vs PA: test MAE", FIGURES_DIR / "08_fig6_standard_vs_pa_overall_mae.png", standard, pa_metrics)
    under = pd.concat([standard[standard["split"] == "test"].assign(group="standard"), pa_metrics[pa_metrics["split"] == "test"].assign(group="PA")])
    fig, ax = plt.subplots(figsize=(12, 5.5))
    ax.bar(under["model_name"], under["peak_underestimation_rate"])
    ax.set_title("Peak underestimation rate: standard ML and PA models")
    ax.set_ylabel("Peak underestimation rate (%)")
    ax.tick_params(axis="x", rotation=35)
    add_labels(ax)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "08_fig7_peak_underestimation_rate.png", dpi=300)
    plt.close(fig)
    best_pa = pa_metrics[pa_metrics["split"] == "test"].sort_values("MAE").iloc[0].model_name
    best_std = standard[standard["split"] == "test"].sort_values("MAE").iloc[0].model_name
    sample_plot(test, best_pa, FIGURES_DIR / "08_fig8_actual_vs_best_pa_test_sample.png")
    std_pred = pd.read_csv(STANDARD_ML_TEST_PREDICTIONS_FILE) if STANDARD_ML_TEST_PREDICTIONS_FILE.exists() else None
    sample_plot(test, best_pa, FIGURES_DIR / "08_fig9_actual_vs_best_standard_vs_best_pa_test_sample.png", std_pred, best_std)
    if not importance.empty:
        imp = importance[importance["model_name"] == best_pa].sort_values("rank").head(20)
        fig, ax = plt.subplots(figsize=(10, 7))
        ax.barh(imp["feature_name"][::-1], imp["importance"][::-1])
        ax.set_title(f"Top 20 feature importances: {best_pa}")
        fig.tight_layout()
        fig.savefig(FIGURES_DIR / "08_fig10_top_feature_importance_best_pa.png", dpi=300)
        plt.close(fig)
    best_std_peak = standard[standard["split"] == "test"].sort_values("peak_MAE").iloc[0].model_name
    best_pa_peak = pa_metrics[pa_metrics["split"] == "test"].sort_values("peak_MAE").iloc[0].model_name
    std_site = pd.read_csv(STANDARD_ML_SITE_FILE)
    site_plot = pd.concat(
        [
            std_site[(std_site["split"] == "test") & (std_site["model_name"] == best_std_peak)].assign(group="standard"),
            site_metrics[(site_metrics["split"] == "test") & (site_metrics["model_name"] == best_pa_peak)].assign(group="PA"),
        ]
    )
    pivot = site_plot.pivot(index="site_id", columns="group", values="peak_MAE")
    fig, ax = plt.subplots(figsize=(11, 5.5))
    pivot.plot(kind="bar", ax=ax)
    ax.set_title("Site-level peak_MAE: best standard ML vs best PA")
    ax.set_ylabel("peak_MAE")
    ax.tick_params(axis="x", rotation=35)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "08_fig11_site_level_peak_mae.png", dpi=300)
    plt.close(fig)

    write_reports(successful, skipped, selected, pa_metrics, comp, all_methods, best, package_rows, input_shape, counts, features)

    best_sel = best[best["summary_item"] == "best PA model by validation selection score"].iloc[0]
    best_mae = best[best["summary_item"] == "best PA model by test MAE"].iloc[0]
    best_peak = best[best["summary_item"] == "best PA model by test peak_MAE"].iloc[0]
    test_comp = comp[comp["split"] == "test"]
    best_std_mae = standard[standard["split"] == "test"].sort_values("MAE").iloc[0]
    best_pa_mae = pa_metrics[pa_metrics["split"] == "test"].sort_values("MAE").iloc[0]
    print("Step 08 peak-aware model complete")
    print("=================================")
    print(f"Input shape: {input_shape}")
    print(f"Train/validation/test rows: {int(counts['train'])}/{int(counts['validation'])}/{int(counts['test'])}")
    print(f"Number of features: {len(features)}")
    print("PA models successfully evaluated:")
    for model in successful:
        print(f"- {model}")
    print("PA models skipped:")
    if skipped:
        for item in skipped:
            print(f"- {item}")
    else:
        print("- None")
    print(f"Best PA by validation selection score: {best_sel.model_name} ({best_sel.metric_value})")
    print(f"Best PA by test MAE: {best_mae.model_name} ({float(best_mae.metric_value):.4f})")
    print(f"Best PA by test peak_MAE: {best_peak.model_name} ({float(best_peak.metric_value):.4f})")
    print(f"Best standard ML test MAE: {best_std_mae.model_name} ({best_std_mae.MAE:.4f})")
    print(f"Best PA test MAE: {best_pa_mae.model_name} ({best_pa_mae.MAE:.4f})")
    print(f"PA improved peak_MAE in any matched pair: {bool(test_comp['improved_peak_MAE'].any())}")
    print(f"PA improved high_peak_MAE in any matched pair: {bool(test_comp['improved_high_peak_MAE'].any())}")
    print(f"PA overall MAE change vs best standard ML: {best_pa_mae.MAE - best_std_mae.MAE:.4f}")
    print("")
    print("Output files saved:")
    for path in OUT.values():
        print(f"- {path}")
    print("")
    print("Report locations:")
    print(f"- {OUT['method']}")
    print(f"- {OUT['results_report']}")
    print(f"- {OUT['leakage']}")
    print(f"- {OUT['novelty']}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(1)
